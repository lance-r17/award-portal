"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MODEL_NONSTREAMING_TOKENS = void 0;
// File containing shared constants
/**
 * Model-specific timeout constraints for non-streaming requests
 */
exports.MODEL_NONSTREAMING_TOKENS = {
    'claude-opus-4@20250514': 8192,
    'anthropic.claude-opus-4-1-20250805-v1:0': 8192,
    'claude-opus-4-1@20250805': 8192,
};
//# sourceMappingURL=constants.js.map