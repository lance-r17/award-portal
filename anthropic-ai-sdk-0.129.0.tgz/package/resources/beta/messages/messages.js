"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolError = exports.BetaToolRunner = exports.BETA_CLIENT_TOOL_UNION_KEYS = exports.Messages = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const error_1 = require("../../../error.js");
const BatchesAPI = tslib_1.__importStar(require("./batches.js"));
const resource_1 = require("../../../core/resource.js");
const constants_1 = require("../../../internal/constants.js");
const headers_1 = require("../../../internal/headers.js");
const stainless_helper_header_1 = require("../../../internal/stainless-helper-header.js");
const beta_parser_1 = require("../../../lib/beta-parser.js");
const BetaMessageStream_1 = require("../../../lib/BetaMessageStream.js");
const BetaToolRunner_1 = require("../../../lib/tools/BetaToolRunner.js");
const ToolError_1 = require("../../../lib/tools/ToolError.js");
const batches_1 = require("./batches.js");
const DEPRECATED_MODELS = {};
const MODELS_TO_WARN_WITH_THINKING_ENABLED = ['claude-mythos-preview', 'claude-opus-4-6'];
var Messages = /* @__PURE__ */ (() => {
    class Messages extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.batches = new BatchesAPI.Batches(this._client);
        }
        create(params, options) {
            // Transform deprecated output_format to output_config.format
            const modifiedParams = transformOutputFormat(params);
            const { betas, user_profile_id, workspace_id, ...body } = modifiedParams;
            if (body.model in DEPRECATED_MODELS) {
                console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}\nPlease migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
            }
            if (MODELS_TO_WARN_WITH_THINKING_ENABLED.includes(body.model) &&
                body.thinking &&
                body.thinking.type === 'enabled') {
                console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
            }
            let timeout = options?.timeout ?? this._client._options.timeout;
            if (!body.stream && timeout == null) {
                const maxNonstreamingTokens = constants_1.MODEL_NONSTREAMING_TOKENS[body.model] ?? undefined;
                timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
            }
            // Collect helper info from tools and messages
            const helperHeader = (0, stainless_helper_header_1.stainlessHelperHeader)(body.tools, body.messages);
            return this._client.post('/v1/messages?beta=true', {
                body,
                timeout: timeout ?? 600000,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        ...(betas?.toString() != null ? { 'anthropic-beta': betas?.toString() } : undefined),
                        ...(user_profile_id != null ? { 'anthropic-user-profile-id': user_profile_id } : undefined),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    helperHeader,
                    options?.headers,
                ]),
                stream: modifiedParams.stream ?? false,
            });
        }
        /**
         * Send a structured list of input messages with text and/or image content, along with an expected `output_format` and
         * the response will be automatically parsed and available in the `parsed_output` property of the message.
         *
         * @example
         * ```ts
         * const message = await client.beta.messages.parse({
         *   model: 'claude-3-5-sonnet-20241022',
         *   max_tokens: 1024,
         *   messages: [{ role: 'user', content: 'What is 2+2?' }],
         *   output_format: zodOutputFormat(z.object({ answer: z.number() }), 'math'),
         * });
         *
         * console.log(message.parsed_output?.answer); // 4
         * ```
         */
        parse(params, options) {
            options = {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    { 'anthropic-beta': [...(params.betas ?? []), 'structured-outputs-2025-12-15'].toString() },
                    options?.headers,
                ]),
            };
            return this.create(params, options).then((message) => (0, beta_parser_1.parseBetaMessage)(message, params, { logger: this._client.logger ?? console }));
        }
        /**
         * Create a Message stream
         */
        stream(body, options) {
            return BetaMessageStream_1.BetaMessageStream.createMessage(this, body, options);
        }
        /**
         * Count the number of tokens in a Message.
         *
         * The Token Count API can be used to count the number of tokens in a Message,
         * including tools, images, and documents, without creating it.
         *
         * Learn more about token counting in our
         * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
         *
         * @example
         * ```ts
         * const betaMessageTokensCount =
         *   await client.beta.messages.countTokens({
         *     messages: [{ content: 'Hello, world', role: 'user' }],
         *     model: 'claude-opus-5',
         *   });
         * ```
         */
        countTokens(params, options) {
            // Transform deprecated output_format to output_config.format
            const modifiedParams = transformOutputFormat(params);
            const { betas, user_profile_id, workspace_id, ...body } = modifiedParams;
            return this._client.post('/v1/messages/count_tokens?beta=true', {
                body,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'token-counting-2024-11-01'].toString(),
                        ...(user_profile_id != null ? { 'anthropic-user-profile-id': user_profile_id } : undefined),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
            });
        }
        toolRunner(body, options) {
            return new BetaToolRunner_1.BetaToolRunner(this._client, body, options);
        }
    }
    Messages.Batches = batches_1.Batches;
    Messages.BetaToolRunner = BetaToolRunner_1.BetaToolRunner;
    Messages.ToolError = ToolError_1.ToolError;
    return Messages;
})();
exports.Messages = Messages;
/**
 * Transform deprecated output_format to output_config.format
 * Returns a modified copy of the params without mutating the original
 */
function transformOutputFormat(params) {
    if (!params.output_format) {
        return params;
    }
    if (params.output_config?.format) {
        throw new error_1.AnthropicError('Both output_format and output_config.format were provided. ' +
            'Please use only output_config.format (output_format is deprecated).');
    }
    const { output_format, ...rest } = params;
    return {
        ...rest,
        output_config: {
            ...params.output_config,
            format: output_format,
        },
    };
}
exports.BETA_CLIENT_TOOL_UNION_KEYS = [
    'input_schema',
    'name',
    'allowed_callers',
    'cache_control',
    'defer_loading',
    'description',
    'eager_input_streaming',
    'input_examples',
    'strict',
    'type',
    'configs',
    'display_height_px',
    'display_width_px',
    'display_number',
    'enable_zoom',
    'max_characters',
];
var BetaToolRunner_2 = require("../../../lib/tools/BetaToolRunner.js");
Object.defineProperty(exports, "BetaToolRunner", { enumerable: true, get: function () { return BetaToolRunner_2.BetaToolRunner; } });
var ToolError_2 = require("../../../lib/tools/ToolError.js");
Object.defineProperty(exports, "ToolError", { enumerable: true, get: function () { return ToolError_2.ToolError; } });
//# sourceMappingURL=messages.js.map