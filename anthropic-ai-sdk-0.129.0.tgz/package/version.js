"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VERSION = void 0;
exports.VERSION = '0.129.0'; // x-release-please-version
//# sourceMappingURL=version.js.map