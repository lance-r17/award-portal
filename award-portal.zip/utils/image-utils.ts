export const getBackgroundImage = (theme = "") => {
  const lowercaseTheme = theme.toLowerCase()

  if (lowercaseTheme.includes("innovation") || lowercaseTheme.includes("excellence")) {
    return "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1200&auto=format&fit=crop"
  }
  if (lowercaseTheme.includes("agility") || lowercaseTheme.includes("resilience")) {
    return "https://images.unsplash.com/photo-1492571350019-22de08371fd3?q=80&w=1200&auto=format&fit=crop"
  }
  if (lowercaseTheme.includes("collaboration") || lowercaseTheme.includes("team")) {
    return "https://images.unsplash.com/photo-1582213782179-e0d4aeceebc8?q=80&w=1200&auto=format&fit=crop"
  }
  if (lowercaseTheme.includes("customer")) {
    return "https://images.unsplash.com/photo-1556745757-8d76bdb6984b?q=80&w=1200&auto=format&fit=crop"
  }
  if (lowercaseTheme.includes("leadership") || lowercaseTheme.includes("impact")) {
    return "https://images.unsplash.com/photo-1519389950473-47ba0277781c?q=80&w=1200&auto=format&fit=crop"
  }

  return "https://images.unsplash.com/photo-1531297484001-80022131f5a1?q=80&w=1200&auto=format&fit=crop"
}
