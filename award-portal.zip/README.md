# Spot Award Platform

A comprehensive employee recognition and award management system designed to celebrate achievements, foster a culture of appreciation, and streamline the award nomination and judging process.

## Overview

The Spot Award Platform enables organizations to create, manage, and facilitate various types of employee recognition programs. From peer-to-peer recognitions to formal award events with nominations, judging, and winners, this platform provides a complete solution for employee appreciation initiatives.

## Key Features

### Employee Recognition
- Peer-to-peer recognition system
- Recognition wall to showcase achievements
- Recognition statistics and leaderboards

### Award Programs
- Spot Awards for immediate recognition
- Formal Recognition Awards for quarterly/annual achievements
- Customizable award types and criteria
- Organization-level award quotas

### Nomination & Judging
- Streamlined nomination process
- Manager endorsements
- Judging panel management
- Scoring and evaluation tools

### Administration
- Award event creation and management
- Judge pool management
- Reporting and analytics
- User role management

## Technology Stack

- **Frontend**: Next.js, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API routes, Server Actions
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: Supabase Auth
- **Deployment**: Vercel

## Getting Started

### Prerequisites

- Node.js (v18 or later)
- npm or yarn
- PostgreSQL database
- Supabase account (for authentication)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-organization/spot-award.git
   cd spot-award
