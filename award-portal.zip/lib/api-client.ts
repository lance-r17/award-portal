import type { User } from "@/types/users"

export interface PaginatedResponse<T> {
  users: T[]
  pagination: {
    total: number
    pages: number
    current: number
    limit: number
  }
}

export interface UserFilters {
  page?: number
  limit?: number
  search?: string
  role?: string
  sort?: string
  order?: "asc" | "desc"
}

export async function fetchUsers({
  page = 1,
  limit = 10,
  search = "",
  role = "",
  sort = "name",
  order = "asc",
}: UserFilters): Promise<PaginatedResponse<User>> {
  const params = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    ...(search && { search }),
    ...(role && role !== "all" && { role }),
    sort,
    order,
  })

  const response = await fetch(`/api/users?${params}`)
  if (!response.ok) {
    throw new Error("Failed to fetch users")
  }

  return response.json()
}

export async function createUser(userData: Partial<User>): Promise<User> {
  const response = await fetch("/api/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(userData),
  })

  if (!response.ok) {
    throw new Error("Failed to create user")
  }

  return response.json()
}

export async function updateUser(id: string, userData: Partial<User>): Promise<User> {
  const response = await fetch(`/api/users/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(userData),
  })

  if (!response.ok) {
    throw new Error("Failed to update user")
  }

  return response.json()
}

export async function disableUser(id: string): Promise<User> {
  const response = await fetch(`/api/users/${id}/disable`, {
    method: "POST",
  })

  if (!response.ok) {
    throw new Error("Failed to disable user")
  }

  return response.json()
}

