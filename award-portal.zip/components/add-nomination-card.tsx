"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Plus } from "lucide-react"

interface AddNominationCardProps {
  onClick: () => void
}

export function AddNominationCard({ onClick }: AddNominationCardProps) {
  return (
    <Card
      className="h-full cursor-pointer transition-all border-dashed hover:border-primary hover:shadow-sm flex items-center justify-center"
      onClick={onClick}
    >
      <CardContent className="p-5 flex flex-col items-center justify-center text-center">
        <div className="rounded-full bg-muted p-3 mb-3">
          <Plus className="h-6 w-6 text-muted-foreground" />
        </div>
        <p className="font-medium text-muted-foreground">Add Nomination</p>
        <p className="text-xs text-muted-foreground mt-1">Nominate a colleague or team for an award</p>
      </CardContent>
    </Card>
  )
}

