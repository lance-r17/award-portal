"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Info, Star, BarChart2, Users, Filter, ChevronDown, X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { Judge } from "@/types/judges"

// Mock function to get all scores for all nominations - in a real app, this would be an API call
const getAllScores = (eventId: string): Record<string, Record<string, number>> => {
  // This would be fetched from your backend
  // For now, return mock data
  // Format: { nominationId: { judgeId: score } }
  return {
    "nom-001": {
      "judge-1": 4.5,
      "judge-4": 4.2,
      "judge-6": 3.8,
    },
    "nom-002": {
      "judge-1": 3.7,
      "judge-4": 4.0,
      "judge-6": 3.5,
    },
    "nom-003": {
      "judge-1": 4.8,
      "judge-4": 4.7,
      "judge-6": 4.9,
    },
    "nom-004": {
      "judge-1": 3.2,
      "judge-6": 3.5,
    },
    "nom-005": {
      "judge-4": 4.3,
      "judge-6": 4.1,
    },
    "nom-006": {
      "judge-1": 4.6,
      "judge-4": 4.4,
      "judge-6": 4.7,
    },
    "nom-007": {
      "judge-1": 3.9,
      "judge-6": 3.7,
    },
  }
}

// Mock function to get all judges for an event - in a real app, this would be an API call
const getJudgesForEvent = (eventId: string): Judge[] => {
  // This would be fetched from your backend
  return [
    {
      id: "judge-1",
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      serviceLine: "technology",
      title: "Chief Technology Officer",
      bio: "20+ years experience in technology leadership and innovation",
    },
    {
      id: "judge-4",
      name: "James Wilson",
      email: "james.wilson@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      serviceLine: "cloud-services",
      title: "Cloud Architecture Director",
      bio: "Expert in cloud migration and infrastructure optimization",
    },
    {
      id: "judge-6",
      name: "Robert Kim",
      email: "robert.kim@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RK",
      serviceLine: "cybersecurity",
      title: "Security Operations Lead",
      bio: "Expert in enterprise security and risk management",
    },
  ]
}

interface FacilitatorScoringPanelProps {
  eventId: string
  isPresentationStage: boolean
  nominations: Nomination[]
}

export function FacilitatorScoringPanel({
  eventId,
  isPresentationStage,
  nominations = [], // Provide default empty array to prevent null/undefined
}: FacilitatorScoringPanelProps) {
  const [loading, setLoading] = useState(true)
  const [allScores, setAllScores] = useState<Record<string, Record<string, number>>>({})
  const [judges, setJudges] = useState<Judge[]>([])
  const [activeTab, setActiveTab] = useState<string>("all")
  const [serviceLineFilter, setServiceLineFilter] = useState<string | null>(null)

  // Use useMemo instead of useState + useEffect to avoid infinite loop
  const sortedNominations = useMemo(() => {
    if (!nominations || nominations.length === 0) {
      return []
    }

    // Sort nominations by ID to ensure consistent order
    return [...nominations].sort((a, b) => {
      // First by nomineeServiceLine
      if (a.nomineeServiceLine !== b.nomineeServiceLine) {
        return a.nomineeServiceLine.localeCompare(b.nomineeServiceLine)
      }
      // Then by nomineeName
      if (a.nomineeName && b.nomineeName) {
        return a.nomineeName.localeCompare(b.nomineeName)
      }
      // Fallback to ID if name is missing
      return a.id.localeCompare(b.id)
    })
  }, [nominations])

  // Get unique service lines from nominations
  const serviceLines = useMemo(() => {
    const lines = new Set<string>()
    sortedNominations.forEach((nomination) => {
      const serviceLine = nomination.serviceLine || nomination.nomineeServiceLine
      if (serviceLine) {
        lines.add(serviceLine)
      }
    })
    return Array.from(lines)
  }, [sortedNominations])

  // Filter nominations by service line if a filter is selected
  const filteredNominations = useMemo(() => {
    if (!serviceLineFilter) return sortedNominations

    return sortedNominations.filter((nomination) => {
      const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine
      return nominationServiceLine === serviceLineFilter
    })
  }, [sortedNominations, serviceLineFilter])

  // Calculate average scores for each nomination
  const averageScores = useMemo(() => {
    const averages: Record<string, { average: number; count: number }> = {}

    Object.entries(allScores).forEach(([nominationId, judgeScores]) => {
      const scores = Object.values(judgeScores)
      if (scores.length > 0) {
        const sum = scores.reduce((acc, score) => acc + score, 0)
        averages[nominationId] = {
          average: sum / scores.length,
          count: scores.length,
        }
      }
    })

    return averages
  }, [allScores])

  // Get nominations that have been scored
  const scoredNominations = useMemo(() => {
    return filteredNominations.filter(
      (nomination) => allScores[nomination.id] && Object.keys(allScores[nomination.id]).length > 0,
    )
  }, [filteredNominations, allScores])

  // Get nominations that haven't been scored by any judge
  const unScoredNominations = useMemo(() => {
    return filteredNominations.filter(
      (nomination) => !allScores[nomination.id] || Object.keys(allScores[nomination.id]).length === 0,
    )
  }, [filteredNominations, allScores])

  // Load scores and judges when component mounts
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // In a real app, these would be API calls
        const scores = getAllScores(eventId)
        const eventJudges = getJudgesForEvent(eventId)

        setAllScores(scores)
        setJudges(eventJudges)
      } catch (error) {
        console.error("Error fetching scoring data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId])

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Format score for display
  const formatScore = (score: number) => {
    return score.toFixed(1)
  }

  if (!isPresentationStage) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Scoring is only available during the presentation stage</AlertTitle>
        <AlertDescription>Judges can score nominations once the event enters the presentation stage.</AlertDescription>
      </Alert>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  // If we have no nominations at all, show a specific message
  if (nominations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Scoring Overview</CardTitle>
          <CardDescription>View and analyze scores from all judges.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>No nominations found</AlertTitle>
            <AlertDescription>
              There are no nominations available for this award event. Please check back later.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Scoring Overview</CardTitle>
          <CardDescription>View and analyze scores from all judges.</CardDescription>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
              {serviceLineFilter && <span className="ml-1">: {formatServiceLine(serviceLineFilter)}</span>}
              <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Filter by Service Line</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem
                onClick={() => setServiceLineFilter(null)}
                className={!serviceLineFilter ? "bg-accent" : ""}
              >
                All Service Lines
              </DropdownMenuItem>
              {serviceLines.map((line) => (
                <DropdownMenuItem
                  key={line}
                  onClick={() => setServiceLineFilter(line)}
                  className={serviceLineFilter === line ? "bg-accent" : ""}
                >
                  {formatServiceLine(line)}
                </DropdownMenuItem>
              ))}
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-medium">Scoring Progress</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {scoredNominations.length} of {filteredNominations.length} nominations have been scored
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="bg-muted w-40 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-primary h-full"
                  style={{
                    width: `${filteredNominations.length ? (scoredNominations.length / filteredNominations.length) * 100 : 0}%`,
                  }}
                ></div>
              </div>
              <span className="text-sm font-medium">
                {filteredNominations.length
                  ? Math.round((scoredNominations.length / filteredNominations.length) * 100)
                  : 0}
                %
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="rounded-full bg-blue-100 dark:bg-blue-900/20 p-3">
                  <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Judges</p>
                  <p className="text-2xl font-bold">{judges.length}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="rounded-full bg-green-100 dark:bg-green-900/20 p-3">
                  <BarChart2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Score</p>
                  <p className="text-2xl font-bold">
                    {Object.values(averageScores).length > 0
                      ? formatScore(
                          Object.values(averageScores).reduce((acc, { average }) => acc + average, 0) /
                            Object.values(averageScores).length,
                        )
                      : "N/A"}
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="rounded-full bg-amber-100 dark:bg-amber-900/20 p-3">
                  <Star className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Highest Score</p>
                  <p className="text-2xl font-bold">
                    {Object.values(averageScores).length > 0
                      ? formatScore(Math.max(...Object.values(averageScores).map(({ average }) => average)))
                      : "N/A"}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full mt-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Nominations ({filteredNominations.length})</TabsTrigger>
            <TabsTrigger value="scored">Scored ({scoredNominations.length})</TabsTrigger>
            <TabsTrigger value="unscored">Unscored ({unScoredNominations.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4 mt-4">
            {filteredNominations.length > 0 ? (
              filteredNominations.map((nomination, index) => (
                <NominationScoreCard
                  key={nomination.id}
                  nomination={nomination}
                  averageScore={averageScores[nomination.id]?.average}
                  judgeCount={averageScores[nomination.id]?.count || 0}
                  totalJudges={judges.length}
                  judgeScores={allScores[nomination.id] || {}}
                  judges={judges}
                  index={index}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">No nominations found.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="scored" className="space-y-4 mt-4">
            {scoredNominations.length > 0 ? (
              scoredNominations.map((nomination, index) => (
                <NominationScoreCard
                  key={nomination.id}
                  nomination={nomination}
                  averageScore={averageScores[nomination.id]?.average}
                  judgeCount={averageScores[nomination.id]?.count || 0}
                  totalJudges={judges.length}
                  judgeScores={allScores[nomination.id] || {}}
                  judges={judges}
                  index={index}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">No scored nominations found.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="unscored" className="space-y-4 mt-4">
            {unScoredNominations.length > 0 ? (
              unScoredNominations.map((nomination, index) => (
                <NominationScoreCard
                  key={nomination.id}
                  nomination={nomination}
                  averageScore={undefined}
                  judgeCount={0}
                  totalJudges={judges.length}
                  judgeScores={{}}
                  judges={judges}
                  index={index}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">All nominations have been scored.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

interface NominationScoreCardProps {
  nomination: Nomination
  averageScore?: number
  judgeCount: number
  totalJudges: number
  judgeScores: Record<string, number>
  judges: Judge[]
  index: number
}

function NominationScoreCard({
  nomination,
  averageScore,
  judgeCount,
  totalJudges,
  judgeScores,
  judges,
  index,
}: NominationScoreCardProps) {
  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const awardTypes: Record<string, string> = {
      "star-of-agile": "Star of Agile",
      "star-of-customer-service": "Star of Customer Service",
      "star-of-engagement": "Star of Engagement",
      "star-of-innovation": "Star of Innovation",
      "star-of-leadership": "Star of Leadership",
      "all-star-team": "All-Star Team",
    }
    return awardTypes[awardType] || awardType
  }

  const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""
  const hasScores = judgeCount > 0

  // Get judge details by ID
  const getJudgeById = (judgeId: string) => {
    return judges.find((judge) => judge.id === judgeId)
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Format score for display
  const formatScore = (score: number) => {
    return score.toFixed(1)
  }

  return (
    <div className={cn("rounded-lg border p-4", hasScores ? "border-primary/20 bg-primary/5" : "")}>
      <div className="flex items-start gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm font-medium">
            {index + 1}
          </div>
          <Avatar className="h-12 w-12">
            <AvatarImage
              src={nomination.nominee?.avatar || "/placeholder.svg?height=40&width=40"}
              alt={nomination.nominee?.name || "Unknown"}
            />
            <AvatarFallback>{nomination.nominee?.initials || "??"}</AvatarFallback>
          </Avatar>
        </div>

        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <h3 className="font-medium">
                {nomination.title ||
                  `${getAwardTypeDisplay(nomination.awardType)} - ${nomination.nominee?.name || "Unknown"}`}
              </h3>
              <p className="text-sm">
                <span className="text-muted-foreground">Nominee: </span>
                {nomination.nominee?.name || "Unknown"}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                <span className="font-medium">Service Line: </span>
                {formatServiceLine(nominationServiceLine || "Unknown")}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <Badge variant="secondary" className="whitespace-nowrap">
                {nomination.nominationType === "individual" ? "Individual" : "Team"}
              </Badge>
            </div>
          </div>

          <div className="mt-3">
            <p className="text-sm font-medium mb-1">Justification:</p>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {nomination.justification || "No justification provided"}
            </p>
          </div>

          <div className="mt-4 border-t pt-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={cn(
                        "h-5 w-5",
                        averageScore !== undefined && averageScore >= star - 0.5
                          ? "fill-primary text-primary"
                          : "fill-muted text-muted-foreground",
                      )}
                    />
                  ))}
                </div>
                <div>
                  <span className="text-lg font-bold">
                    {averageScore !== undefined ? formatScore(averageScore) : "N/A"}
                  </span>
                  <span className="text-sm text-muted-foreground ml-2">
                    ({judgeCount} of {totalJudges} judges)
                  </span>
                </div>
              </div>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" disabled={!hasScores}>
                    <BarChart2 className="mr-2 h-4 w-4" />
                    View Score Breakdown
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Score Breakdown</DialogTitle>
                    <DialogDescription>Individual scores from each judge for this nomination.</DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4 my-4">
                    <div className="mb-4 pb-3 border-b">
                      <h3 className="font-medium">{nomination.nominee?.name || "Unknown"}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        <span className="font-medium">Service Line: </span>
                        {formatServiceLine(nominationServiceLine || "Unknown")}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        <span className="font-medium">Award Type: </span>
                        {getAwardTypeDisplay(nomination.awardType)}
                      </p>
                    </div>

                    {Object.entries(judgeScores).map(([judgeId, score]) => {
                      const judge = getJudgeById(judgeId)
                      if (!judge) return null

                      return (
                        <div key={judgeId} className="flex items-center gap-3 p-3 rounded-lg border">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={judge.avatar} alt={judge.name} />
                            <AvatarFallback>{judge.initials}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-medium">{judge.name}</p>
                                <p className="text-xs text-muted-foreground">{formatServiceLine(judge.serviceLine)}</p>
                              </div>
                              <div className="flex items-center gap-2">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={cn(
                                        "h-4 w-4",
                                        score >= star - 0.5
                                          ? "fill-primary text-primary"
                                          : "fill-muted text-muted-foreground",
                                      )}
                                    />
                                  ))}
                                </div>
                                <span className="font-bold">{formatScore(score)}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )
                    })}

                    {/* Judges who haven't scored yet */}
                    {judges
                      .filter((judge) => !Object.keys(judgeScores).includes(judge.id))
                      .map((judge) => (
                        <div key={judge.id} className="flex items-center gap-3 p-3 rounded-lg border bg-muted/20">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={judge.avatar} alt={judge.name} />
                            <AvatarFallback>{judge.initials}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-medium">{judge.name}</p>
                                <p className="text-xs text-muted-foreground">{formatServiceLine(judge.serviceLine)}</p>
                              </div>
                              <Badge variant="outline" className="text-muted-foreground">
                                Not scored yet
                              </Badge>
                            </div>
                          </div>
                        </div>
                      ))}

                    {/* Average score */}
                    {hasScores && (
                      <div className="mt-6 pt-4 border-t">
                        <div className="flex justify-between items-center">
                          <p className="font-medium">Average Score</p>
                          <div className="flex items-center gap-2">
                            <div className="flex">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={cn(
                                    "h-5 w-5",
                                    averageScore !== undefined && averageScore >= star - 0.5
                                      ? "fill-primary text-primary"
                                      : "fill-muted text-muted-foreground",
                                  )}
                                />
                              ))}
                            </div>
                            <span className="font-bold text-lg">
                              {averageScore !== undefined ? formatScore(averageScore) : "N/A"}
                            </span>
                          </div>
                        </div>

                        {/* Score distribution */}
                        <div className="mt-4">
                          <p className="text-sm font-medium mb-2">Score Distribution</p>
                          <div className="space-y-2">
                            {[5, 4, 3, 2, 1].map((rating) => {
                              const count = Object.values(judgeScores).filter(
                                (score) => Math.floor(score) === rating,
                              ).length
                              const percentage = (count / Object.values(judgeScores).length) * 100

                              return (
                                <div key={rating} className="flex items-center gap-2">
                                  <span className="text-sm w-6">{rating}</span>
                                  <Progress value={percentage} className="h-2 flex-1" />
                                  <span className="text-sm w-8">{count}</span>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <DialogClose asChild>
                    <Button variant="outline" className="w-full">
                      <X className="mr-2 h-4 w-4" />
                      Close
                    </Button>
                  </DialogClose>
                </DialogContent>
              </Dialog>
            </div>

            <div className="mt-3">
              <p className="text-xs text-muted-foreground">
                {hasScores
                  ? `${judgeCount} of ${totalJudges} judges have scored this nomination.`
                  : "No judges have scored this nomination yet."}
              </p>
              <Progress value={(judgeCount / totalJudges) * 100} className="h-1 mt-1" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

