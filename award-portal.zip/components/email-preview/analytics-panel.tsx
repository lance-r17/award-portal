import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts"
import type { EmailTemplateFile } from "./file-explorer"

interface AnalyticsPanelProps {
  template: EmailTemplateFile | null
}

// Sample analytics data - in a real app, this would come from your backend
const sampleUsageData = {
  "nomination-submitted": {
    sent: 245,
    opened: 198,
    clicked: 156,
    history: [
      { date: "Jan", count: 15 },
      { date: "Feb", count: 28 },
      { date: "Mar", count: 42 },
      { date: "Apr", count: 35 },
      { date: "May", count: 50 },
      { date: "Jun", count: 75 },
    ],
  },
  "nomination-received": {
    sent: 187,
    opened: 165,
    clicked: 142,
    history: [
      { date: "Jan", count: 12 },
      { date: "Feb", count: 18 },
      { date: "Mar", count: 32 },
      { date: "Apr", count: 45 },
      { date: "May", count: 38 },
      { date: "Jun", count: 42 },
    ],
  },
  "judge-assignment": {
    sent: 56,
    opened: 52,
    clicked: 48,
    history: [
      { date: "Jan", count: 0 },
      { date: "Feb", count: 0 },
      { date: "Mar", count: 12 },
      { date: "Apr", count: 15 },
      { date: "May", count: 14 },
      { date: "Jun", count: 15 },
    ],
  },
  "winner-announcement": {
    sent: 32,
    opened: 30,
    clicked: 28,
    history: [
      { date: "Jan", count: 0 },
      { date: "Feb", count: 0 },
      { date: "Mar", count: 0 },
      { date: "Apr", count: 0 },
      { date: "May", count: 12 },
      { date: "Jun", count: 20 },
    ],
  },
  "comment-notification": {
    sent: 312,
    opened: 245,
    clicked: 178,
    history: [
      { date: "Jan", count: 25 },
      { date: "Feb", count: 42 },
      { date: "Mar", count: 58 },
      { date: "Apr", count: 62 },
      { date: "May", count: 55 },
      { date: "Jun", count: 70 },
    ],
  },
}

export function AnalyticsPanel({ template }: AnalyticsPanelProps) {
  if (!template) {
    return null
  }

  const analyticsData = sampleUsageData[template.path as keyof typeof sampleUsageData]

  if (!analyticsData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Usage Analytics</CardTitle>
          <CardDescription>No analytics data available for this template</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Usage Analytics</CardTitle>
        <CardDescription>Email performance metrics</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold">{analyticsData.sent}</div>
            <div className="text-sm text-muted-foreground">Sent</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{analyticsData.opened}</div>
            <div className="text-sm text-muted-foreground">Opened</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{analyticsData.clicked}</div>
            <div className="text-sm text-muted-foreground">Clicked</div>
          </div>
        </div>

        <div className="h-[200px] mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={analyticsData.history}>
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

