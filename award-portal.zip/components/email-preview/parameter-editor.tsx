"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import type { EmailTemplateFile } from "./file-explorer"

interface ParameterEditorProps {
  template: EmailTemplateFile | null
  initialData: Record<string, any>
  onDataChange: (data: Record<string, any>) => void
}

// Sample presets for different template types
const PRESETS: Record<string, Record<string, Record<string, any>>> = {
  nomination: {
    "Standard Nomination": {
      nominatorName: "Jane Smith",
      nomineeName: "John Doe",
      awardType: "Spot Award",
      eventName: "Q2 Recognition Event",
      nominationDate: "April 15, 2023",
      previewUrl: "#",
    },
    "Team Nomination": {
      nominatorName: "Jane Smith",
      nomineeName: "Engineering Team",
      awardType: "Team Excellence Award",
      eventName: "Annual Awards",
      nominationDate: "June 10, 2023",
      previewUrl: "#",
    },
  },
  judging: {
    "New Judge Assignment": {
      judgeName: "Michael Johnson",
      eventName: "Q2 Recognition Event",
      awardType: "Spot Award",
      nominationCount: 12,
      deadline: "May 10, 2023",
      judgingUrl: "#",
    },
    Reminder: {
      judgeName: "Michael Johnson",
      eventName: "Q2 Recognition Event",
      awardType: "Spot Award",
      nominationCount: 12,
      deadline: "Tomorrow",
      judgingUrl: "#",
    },
  },
  events: {
    "Winner Announcement": {
      recipientName: "Team Member",
      winnerName: "John Doe",
      awardType: "Spot Award",
      eventName: "Q2 Recognition Event",
      announcementDate: "May 20, 2023",
      celebrationDetails: "We will be celebrating this achievement during our next all-hands meeting on May 25, 2023.",
      viewDetailsUrl: "#",
    },
  },
  system: {
    "New Comment": {
      recipientName: "John Doe",
      commenterName: "Sarah Williams",
      nominationTitle: "Outstanding Customer Support",
      commentPreview:
        "I completely agree with this nomination. John has consistently gone above and beyond in supporting our customers.",
      commentDate: "April 18, 2023",
      viewCommentUrl: "#",
    },
  },
}

export function ParameterEditor({ template, initialData, onDataChange }: ParameterEditorProps) {
  const [data, setData] = useState<Record<string, any>>(initialData)
  const [jsonMode, setJsonMode] = useState(false)
  const [jsonValue, setJsonValue] = useState("")
  const [presetCategory, setPresetCategory] = useState<string | null>(null)

  // Update data when template changes
  useEffect(() => {
    setData(initialData)
    setJsonValue(JSON.stringify(initialData, null, 2))

    // Try to determine preset category from template path
    if (template) {
      const pathParts = template.path.split("-")
      const possibleCategory = pathParts[0]
      if (PRESETS[possibleCategory]) {
        setPresetCategory(possibleCategory)
      } else {
        setPresetCategory(null)
      }
    }
  }, [template, initialData])

  // Update parent component when data changes
  useEffect(() => {
    onDataChange(data)
  }, [data, onDataChange])

  // Handle form field changes
  const handleChange = (key: string, value: any) => {
    setData((prev) => {
      const newData = { ...prev, [key]: value }
      setJsonValue(JSON.stringify(newData, null, 2))
      return newData
    })
  }

  // Handle JSON editor changes
  const handleJsonChange = (json: string) => {
    setJsonValue(json)
    try {
      const parsed = JSON.parse(json)
      setData(parsed)
      onDataChange(parsed)
    } catch (e) {
      // Invalid JSON, don't update data
    }
  }

  // Apply a preset
  const applyPreset = (presetName: string) => {
    if (presetCategory && PRESETS[presetCategory] && PRESETS[presetCategory][presetName]) {
      const presetData = PRESETS[presetCategory][presetName]
      setData(presetData)
      setJsonValue(JSON.stringify(presetData, null, 2))
    }
  }

  if (!template) {
    return null
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-base">Template Parameters</CardTitle>
            <CardDescription>Edit the data used to render the template</CardDescription>
          </div>

          {presetCategory && Object.keys(PRESETS[presetCategory]).length > 0 && (
            <Select onValueChange={applyPreset}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select preset" />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(PRESETS[presetCategory]).map((preset) => (
                  <SelectItem key={preset} value={preset}>
                    {preset}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="form" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="form" onClick={() => setJsonMode(false)}>
              Form
            </TabsTrigger>
            <TabsTrigger value="json" onClick={() => setJsonMode(true)}>
              JSON
            </TabsTrigger>
          </TabsList>

          <TabsContent value="form" className="space-y-4 py-4">
            {Object.entries(data).map(([key, value]) => (
              <div key={key} className="space-y-2">
                <Label htmlFor={key} className="capitalize">
                  {key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}
                </Label>

                {typeof value === "string" && value.length > 50 ? (
                  <Textarea id={key} value={value} onChange={(e) => handleChange(key, e.target.value)} rows={3} />
                ) : typeof value === "string" ? (
                  <Input id={key} value={value} onChange={(e) => handleChange(key, e.target.value)} />
                ) : typeof value === "number" ? (
                  <Input
                    id={key}
                    type="number"
                    value={value}
                    onChange={(e) => handleChange(key, Number(e.target.value))}
                  />
                ) : (
                  <Input id={key} value={String(value)} onChange={(e) => handleChange(key, e.target.value)} />
                )}
              </div>
            ))}
          </TabsContent>

          <TabsContent value="json">
            <Textarea
              value={jsonValue}
              onChange={(e) => handleJsonChange(e.target.value)}
              className="font-mono text-sm"
              rows={15}
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

