"use client"

import { CalendarIcon, FileIcon, InfoIcon, LinkIcon } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import type { EmailTemplateFile } from "./file-explorer"

interface TemplateMetadataProps {
  template: EmailTemplateFile | null
  relatedTemplates?: EmailTemplateFile[]
  onSelectRelated: (template: EmailTemplateFile) => void
}

export function TemplateMetadata({ template, relatedTemplates = [], onSelectRelated }: TemplateMetadataProps) {
  if (!template) {
    return null
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Template Information</CardTitle>
        <CardDescription>Details about the selected template</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 text-sm">
        <div className="grid grid-cols-[20px_1fr] items-start gap-2">
          <FileIcon className="h-4 w-4 text-muted-foreground mt-0.5" />
          <div>
            <div className="font-medium">{template.name}</div>
            <div className="text-xs text-muted-foreground">{template.path}</div>
          </div>
        </div>

        {template.description && (
          <div className="grid grid-cols-[20px_1fr] items-start gap-2">
            <InfoIcon className="h-4 w-4 text-muted-foreground mt-0.5" />
            <div>{template.description}</div>
          </div>
        )}

        {template.lastModified && (
          <div className="grid grid-cols-[20px_1fr] items-start gap-2">
            <CalendarIcon className="h-4 w-4 text-muted-foreground mt-0.5" />
            <div>
              <div className="font-medium">Last Modified</div>
              <div className="text-xs text-muted-foreground">{template.lastModified}</div>
            </div>
          </div>
        )}

        {template.category && (
          <div className="pt-2">
            <Badge variant="outline">{template.category}</Badge>
          </div>
        )}

        {relatedTemplates.length > 0 && (
          <>
            <Separator />
            <div>
              <div className="font-medium mb-2">Related Templates</div>
              <div className="space-y-2">
                {relatedTemplates.map((related) => (
                  <div
                    key={related.id}
                    className="grid grid-cols-[20px_1fr] items-center gap-2 cursor-pointer hover:text-primary"
                    onClick={() => onSelectRelated(related)}
                  >
                    <LinkIcon className="h-4 w-4 text-muted-foreground" />
                    <span>{related.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
