"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { SquareSplitHorizontalIcon as SplitHorizontal, X } from "lucide-react"
import type { EmailTemplateFile } from "./file-explorer"

interface TemplateComparisonProps {
  allTemplates: EmailTemplateFile[]
  currentTemplate: EmailTemplateFile | null
  currentHtml: string
  onSelectSecondTemplate: (templatePath: string) => void
  secondTemplateHtml: string | null
}

export function TemplateComparison({
  allTemplates,
  currentTemplate,
  currentHtml,
  onSelectSecondTemplate,
  secondTemplateHtml,
}: TemplateComparisonProps) {
  const [isComparing, setIsComparing] = useState(false)
  const [showDiff, setShowDiff] = useState(false)
  const [secondTemplatePath, setSecondTemplatePath] = useState<string>("")

  // Get all file templates (not folders)
  const fileTemplates = allTemplates.flatMap((item) => {
    if (item.type === "folder" && item.children) {
      return item.children.filter((child) => child.type === "file")
    }
    return item.type === "file" ? [item] : []
  })

  // Toggle comparison mode
  const toggleComparisonMode = () => {
    if (isComparing) {
      setIsComparing(false)
      setSecondTemplatePath("")
      onSelectSecondTemplate("")
    } else {
      setIsComparing(true)
      if (fileTemplates.length > 0 && currentTemplate) {
        // Select a different template than the current one
        const differentTemplate = fileTemplates.find((t) => t.path !== currentTemplate.path)
        if (differentTemplate) {
          setSecondTemplatePath(differentTemplate.path)
          onSelectSecondTemplate(differentTemplate.path)
        }
      }
    }
  }

  // Handle second template selection
  const handleSecondTemplateChange = (path: string) => {
    setSecondTemplatePath(path)
    onSelectSecondTemplate(path)
  }

  if (!currentTemplate) {
    return null
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-base">Template Comparison</CardTitle>
            <CardDescription>Compare this template with another</CardDescription>
          </div>
          <Button
            variant={isComparing ? "default" : "outline"}
            size="sm"
            onClick={toggleComparisonMode}
            className="flex items-center"
          >
            {isComparing ? (
              <>
                <X className="h-4 w-4 mr-2" />
                Close Comparison
              </>
            ) : (
              <>
                <SplitHorizontal className="h-4 w-4 mr-2" />
                Compare
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      {isComparing && (
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <Select value={secondTemplatePath} onValueChange={handleSecondTemplateChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select template to compare" />
                </SelectTrigger>
                <SelectContent>
                  {fileTemplates
                    .filter((template) => template.path !== currentTemplate.path)
                    .map((template) => (
                      <SelectItem key={template.path} value={template.path}>
                        {template.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2 ml-4">
              <Switch id="show-diff" checked={showDiff} onCheckedChange={setShowDiff} />
              <Label htmlFor="show-diff">Highlight differences</Label>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  )
}

