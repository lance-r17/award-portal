"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Copy, Download, Send, Smartphone, Tablet, Monitor, CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import type { EmailTemplateFile } from "./file-explorer"

interface ExportToolsProps {
  template: EmailTemplateFile | null
  htmlContent: string
  templateData: Record<string, any>
}

export function ExportTools({ template, htmlContent, templateData }: ExportToolsProps) {
  const [deviceView, setDeviceView] = useState<"desktop" | "tablet" | "mobile">("desktop")
  const [testEmail, setTestEmail] = useState("")
  const [isSending, setIsSending] = useState(false)
  const [sendResult, setSendResult] = useState<"success" | "error" | null>(null)

  if (!template) {
    return null
  }

  // Copy HTML to clipboard
  const copyHtml = async () => {
    try {
      await navigator.clipboard.writeText(htmlContent)
      toast({
        title: "HTML Copied",
        description: "The template HTML has been copied to your clipboard.",
      })
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy HTML to clipboard.",
        variant: "destructive",
      })
    }
  }

  // Download HTML file
  const downloadHtml = () => {
    const blob = new Blob([htmlContent], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${template.name.replace(".tsx", "")}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Send test email
  const sendTestEmail = async () => {
    if (!testEmail) {
      toast({
        title: "Email Required",
        description: "Please enter a recipient email address.",
        variant: "destructive",
      })
      return
    }

    setIsSending(true)
    setSendResult(null)

    try {
      const response = await fetch("/api/test-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          templateType: template.path,
          email: testEmail,
          data: templateData,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setSendResult("success")
        toast({
          title: "Email Sent",
          description: `Test email sent to ${testEmail}`,
        })
      } else {
        setSendResult("error")
        toast({
          title: "Failed to Send",
          description: result.error || "An error occurred while sending the test email.",
          variant: "destructive",
        })
      }
    } catch (error) {
      setSendResult("error")
      toast({
        title: "Failed to Send",
        description: "An error occurred while sending the test email.",
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={copyHtml} className="flex items-center">
              <Copy className="h-4 w-4 mr-2" />
              Copy HTML
            </Button>
            <Button variant="outline" size="sm" onClick={downloadHtml} className="flex items-center">
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <Tabs defaultValue="desktop" onValueChange={(v) => setDeviceView(v as any)}>
              <TabsList className="h-8">
                <TabsTrigger value="desktop" className="h-7 px-2">
                  <Monitor className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="tablet" className="h-7 px-2">
                  <Tablet className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="mobile" className="h-7 px-2">
                  <Smartphone className="h-4 w-4" />
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="flex items-center space-x-2">
            <Input
              placeholder="recipient@example.com"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              className="w-[200px] h-9"
            />
            <Button
              variant="default"
              size="sm"
              onClick={sendTestEmail}
              disabled={isSending}
              className="flex items-center"
            >
              {isSending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : sendResult === "success" ? (
                <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
              ) : sendResult === "error" ? (
                <AlertCircle className="h-4 w-4 mr-2 text-red-500" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              Send Test
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

