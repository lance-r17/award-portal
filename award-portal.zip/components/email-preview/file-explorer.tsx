"use client"

import { useState, useEffect, useMemo } from "react"
import { ChevronDown, ChevronRight, File, Folder, Search, History } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export type EmailTemplateFile = {
  id: string
  name: string
  path: string
  type: "file" | "folder"
  description?: string
  category?: string
  lastModified?: string
  children?: EmailTemplateFile[]
}

interface FileExplorerProps {
  files: EmailTemplateFile[]
  onSelectFile: (file: EmailTemplateFile) => void
  selectedFilePath?: string
}

export function FileExplorer({ files, onSelectFile, selectedFilePath }: FileExplorerProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({})
  const [recentlyViewed, setRecentlyViewed] = useState<EmailTemplateFile[]>([])
  const [activeFilter, setActiveFilter] = useState<string | null>(null)

  // Initialize all folders as expanded
  useEffect(() => {
    const initialExpanded: Record<string, boolean> = {}
    const initializeExpanded = (items: EmailTemplateFile[]) => {
      items.forEach((item) => {
        if (item.type === "folder") {
          initialExpanded[item.id] = true
          if (item.children) {
            initializeExpanded(item.children)
          }
        }
      })
    }

    initializeExpanded(files)
    setExpandedFolders(initialExpanded)
  }, [files])

  // Add to recently viewed when selecting a file
  useEffect(() => {
    if (selectedFilePath) {
      const findFile = (items: EmailTemplateFile[]): EmailTemplateFile | null => {
        for (const item of items) {
          if (item.path === selectedFilePath) {
            return item
          }
          if (item.children) {
            const found = findFile(item.children)
            if (found) return found
          }
        }
        return null
      }

      const selectedFile = findFile(files)
      if (selectedFile && selectedFile.type === "file") {
        setRecentlyViewed((prev) => {
          const filtered = prev.filter((item) => item.id !== selectedFile.id)
          return [selectedFile, ...filtered].slice(0, 5)
        })
      }
    }
  }, [selectedFilePath, files])

  // Filter files based on search query and category filter
  const filteredFiles = useMemo(() => {
    if (!searchQuery && !activeFilter) return files

    const filterItems = (items: EmailTemplateFile[]): EmailTemplateFile[] => {
      return items.map((item) => {
        // For folders, recursively filter children
        if (item.type === "folder" && item.children) {
          const filteredChildren = filterItems(item.children)
          return {
            ...item,
            children: filteredChildren,
            // Hide folders with no matching children
            hidden: filteredChildren.length === 0 || filteredChildren.every((child) => child.hidden),
          }
        }

        // For files, check if they match the search query and filter
        const matchesSearch =
          !searchQuery ||
          item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()))

        const matchesFilter = !activeFilter || item.category === activeFilter

        return {
          ...item,
          hidden: !(matchesSearch && matchesFilter),
        }
      })
    }

    return filterItems(files)
  }, [files, searchQuery, activeFilter])

  // Toggle folder expansion
  const toggleFolder = (folderId: string) => {
    setExpandedFolders((prev) => ({
      ...prev,
      [folderId]: !prev[folderId],
    }))
  }

  // Categories for filtering
  const categories = useMemo(() => {
    const allCategories = new Set<string>()

    const extractCategories = (items: EmailTemplateFile[]) => {
      items.forEach((item) => {
        if (item.category) {
          allCategories.add(item.category)
        }
        if (item.children) {
          extractCategories(item.children)
        }
      })
    }

    extractCategories(files)
    return Array.from(allCategories)
  }, [files])

  return (
    <div className="flex flex-col h-full">
      <div className="mb-4">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      {/* Category filters */}
      {categories.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={activeFilter === category ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setActiveFilter(activeFilter === category ? null : category)}
            >
              {category}
            </Badge>
          ))}
        </div>
      )}

      {/* Recently viewed */}
      {recentlyViewed.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center text-sm font-medium mb-2">
            <History className="h-4 w-4 mr-1" />
            <span>Recently Viewed</span>
          </div>
          <div className="space-y-1">
            {recentlyViewed.map((file) => (
              <div
                key={file.id}
                className={cn(
                  "flex items-center py-1 px-2 rounded-md cursor-pointer text-sm",
                  selectedFilePath === file.path ? "bg-accent text-accent-foreground" : "hover:bg-accent/50",
                )}
                onClick={() => onSelectFile(file)}
              >
                <File className="h-4 w-4 mr-2 text-muted-foreground" />
                <span>{file.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* File tree */}
      <div className="overflow-auto flex-grow border rounded-md p-2">
        <FileTree
          items={filteredFiles}
          expandedFolders={expandedFolders}
          toggleFolder={toggleFolder}
          onSelectFile={onSelectFile}
          selectedFilePath={selectedFilePath}
          searchQuery={searchQuery}
        />
      </div>
    </div>
  )
}

interface FileTreeProps {
  items: EmailTemplateFile[]
  expandedFolders: Record<string, boolean>
  toggleFolder: (folderId: string) => void
  onSelectFile: (file: EmailTemplateFile) => void
  selectedFilePath?: string
  searchQuery: string
  level?: number
}

function FileTree({
  items,
  expandedFolders,
  toggleFolder,
  onSelectFile,
  selectedFilePath,
  searchQuery,
  level = 0,
}: FileTreeProps) {
  // Highlight matching text in file names
  const highlightMatch = (text: string, query: string) => {
    if (!query) return text

    const index = text.toLowerCase().indexOf(query.toLowerCase())
    if (index === -1) return text

    const before = text.substring(0, index)
    const match = text.substring(index, index + query.length)
    const after = text.substring(index + query.length)

    return (
      <>
        {before}
        <span className="bg-yellow-200 dark:bg-yellow-800">{match}</span>
        {after}
      </>
    )
  }

  return (
    <div className="space-y-1">
      {items.map((item) => {
        if (item.hidden) return null

        return (
          <div key={item.id}>
            <div
              className={cn(
                "flex items-center py-1 px-2 rounded-md cursor-pointer",
                selectedFilePath === item.path ? "bg-accent text-accent-foreground" : "hover:bg-accent/50",
                "text-sm",
              )}
              style={{ paddingLeft: `${level * 12 + 4}px` }}
              onClick={() => {
                if (item.type === "folder") {
                  toggleFolder(item.id)
                } else {
                  onSelectFile(item)
                }
              }}
            >
              {item.type === "folder" ? (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 mr-1"
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleFolder(item.id)
                    }}
                  >
                    {expandedFolders[item.id] ? (
                      <ChevronDown className="h-3 w-3" />
                    ) : (
                      <ChevronRight className="h-3 w-3" />
                    )}
                  </Button>
                  <Folder className="h-4 w-4 mr-2 text-blue-500" />
                  {highlightMatch(item.name, searchQuery)}
                </>
              ) : (
                <>
                  <span className="w-5" />
                  <File className="h-4 w-4 mr-2 text-muted-foreground" />
                  {highlightMatch(item.name, searchQuery)}
                </>
              )}
            </div>

            {item.type === "folder" && item.children && expandedFolders[item.id] && (
              <FileTree
                items={item.children}
                expandedFolders={expandedFolders}
                toggleFolder={toggleFolder}
                onSelectFile={onSelectFile}
                selectedFilePath={selectedFilePath}
                searchQuery={searchQuery}
                level={level + 1}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}

