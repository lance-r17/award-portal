"use client"

import { useState, useEffect } from "react"
import { Check, ChevronsUpDown } from "lucide-react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const employees = [
  { label: "Sarah Johnson", value: "sarah-johnson" },
  { label: "Michael Chen", value: "michael-chen" },
  { label: "Emily Rodriguez", value: "emily-rodriguez" },
  { label: "David Kim", value: "david-kim" },
  { label: "Jessica Patel", value: "jessica-patel" },
  { label: "James Wilson", value: "james-wilson" },
  { label: "Olivia Martinez", value: "olivia-martinez" },
  { label: "Daniel Thompson", value: "daniel-thompson" },
]

const teams = [
  { label: "Engineering Team", value: "engineering-team" },
  { label: "Marketing Team", value: "marketing-team" },
  { label: "Product Team", value: "product-team" },
  { label: "Customer Support Team", value: "customer-support-team" },
  { label: "Sales Team", value: "sales-team" },
  { label: "Design Team", value: "design-team" },
  { label: "Finance Team", value: "finance-team" },
  { label: "HR Team", value: "hr-team" },
]

// Service Lines
const serviceLines = [
  { label: "Digital Transformation", value: "digital-transformation", manager: "Alex Morgan" },
  { label: "Cloud Services", value: "cloud-services", manager: "Jamie Taylor" },
  { label: "Data Analytics", value: "data-analytics", manager: "Sam Wilson" },
  { label: "Cybersecurity", value: "cybersecurity", manager: "Robin Chen" },
  { label: "Enterprise Solutions", value: "enterprise-solutions", manager: "Jordan Lee" },
  { label: "Customer Experience", value: "customer-experience", manager: "Casey Smith" },
  { label: "Financial Services", value: "financial-services", manager: "Taylor Johnson" },
  { label: "Healthcare Solutions", value: "healthcare-solutions", manager: "Morgan Rivera" },
]

const spotIndividualAwardTypes = [
  { label: "Star of Agile", value: "star-of-agile" },
  { label: "Star of Customer Service", value: "star-of-customer-service" },
  { label: "Star of Engagement", value: "star-of-engagement" },
  { label: "Star of Innovation", value: "star-of-innovation" },
  { label: "Star of Leadership", value: "star-of-leadership" },
]

const spotTeamAwardTypes = [{ label: "All-Star Team", value: "all-star-team" }]

const recognitionAwardTypes = [
  { label: "Excellence Award", value: "excellence" },
  { label: "Leadership Award", value: "leadership" },
  { label: "Innovation Award", value: "innovation" },
  { label: "Values Champion", value: "values-champion" },
  { label: "Impact Award", value: "impact" },
]

// Schema for individual nomination
const individualFormSchema = z.object({
  employee: z.string({
    required_error: "Please select an employee to nominate.",
  }),
  serviceLine: z.string({
    required_error: "Please select a service line.",
  }),
  awardType: z.string({
    required_error: "Please select an award type.",
  }),
  justification: z
    .string()
    .min(50, {
      message: "Justification must be at least 50 characters.",
    })
    .max(1000, {
      message: "Justification must not exceed 1000 characters.",
    }),
  impact: z
    .string()
    .min(50, {
      message: "Impact description must be at least 50 characters.",
    })
    .max(500, {
      message: "Impact description must not exceed 500 characters.",
    }),
  supportingInfo: z.string().optional(),
  notifyManager: z.boolean().default(true),
  notifyTeam: z.boolean().default(false),
})

// Schema for team nomination
const teamFormSchema = z.object({
  team: z.string({
    required_error: "Please select a team to nominate.",
  }),
  serviceLine: z.string({
    required_error: "Please select a service line.",
  }),
  awardType: z.string({
    required_error: "Please select an award type.",
  }),
  teamMembers: z.string().min(5, {
    message: "Please list at least some team members.",
  }),
  justification: z
    .string()
    .min(50, {
      message: "Justification must be at least 50 characters.",
    })
    .max(1000, {
      message: "Justification must not exceed 1000 characters.",
    }),
  impact: z
    .string()
    .min(50, {
      message: "Impact description must be at least 50 characters.",
    })
    .max(500, {
      message: "Impact description must not exceed 500 characters.",
    }),
  supportingInfo: z.string().optional(),
  notifyManagers: z.boolean().default(true),
})

interface AwardNominationFormProps {
  awardType: "spot" | "recognition"
  nominationType?: "individual" | "team"
  selectedAwardType?: string | null
}

export function AwardNominationForm({
  awardType,
  nominationType = "individual",
  selectedAwardType = null,
}: AwardNominationFormProps) {
  const [employeeOpen, setEmployeeOpen] = useState(false)
  const [teamOpen, setTeamOpen] = useState(false)
  const [awardTypeOpen, setAwardTypeOpen] = useState(false)
  const [selectedServiceLine, setSelectedServiceLine] = useState<string | null>(null)

  let awardTypes: { label: string; value: string }[] = []

  if (awardType === "spot") {
    awardTypes = nominationType === "individual" ? spotIndividualAwardTypes : spotTeamAwardTypes
  } else {
    awardTypes = recognitionAwardTypes
  }

  // Use the appropriate schema based on nomination type
  const formSchema = nominationType === "individual" ? individualFormSchema : teamFormSchema

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues:
      nominationType === "individual"
        ? {
            justification: "",
            impact: "",
            supportingInfo: "",
            notifyManager: true,
            notifyTeam: false,
          }
        : {
            teamMembers: "",
            justification: "",
            impact: "",
            supportingInfo: "",
            notifyManagers: true,
          },
  })

  // Update the award type when selectedAwardType changes
  useEffect(() => {
    if (selectedAwardType) {
      form.setValue("awardType", selectedAwardType)
    }
  }, [selectedAwardType, form])

  // Get the domain manager name when service line changes
  const getDomainManager = (serviceLineValue: string) => {
    const serviceLine = serviceLines.find((sl) => sl.value === serviceLineValue)
    return serviceLine ? serviceLine.manager : "the domain manager"
  }

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Get the domain manager name
    const domainManager = getDomainManager(values.serviceLine)

    toast({
      title: "Nomination submitted!",
      description: `Your ${nominationType} award nomination has been sent for review. A notification has been sent to ${domainManager}.`,
    })
    console.log(values)
    form.reset()
    setSelectedServiceLine(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Nominate for {awardType === "spot" ? "Spot Award" : "Rewards & Recognition"}
          {nominationType === "team" ? " (Team)" : ""}
        </CardTitle>
        <CardDescription>
          Complete the form below to nominate {nominationType === "individual" ? "a colleague" : "a team"} for their
          outstanding contribution.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {nominationType === "individual" ? (
              <FormField
                control={form.control}
                name="employee"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Nominee</FormLabel>
                    <Popover open={employeeOpen} onOpenChange={setEmployeeOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={employeeOpen}
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value
                              ? employees.find((employee) => employee.value === field.value)?.label
                              : "Select employee"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search employee..." />
                          <CommandList>
                            <CommandEmpty>No employee found.</CommandEmpty>
                            <CommandGroup>
                              {employees.map((employee) => (
                                <CommandItem
                                  key={employee.value}
                                  value={employee.value}
                                  onSelect={(value) => {
                                    form.setValue("employee", value)
                                    setEmployeeOpen(false)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      employee.value === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {employee.label}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ) : (
              <FormField
                control={form.control}
                name="team"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Team to Nominate</FormLabel>
                    <Popover open={teamOpen} onOpenChange={setTeamOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={teamOpen}
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value ? teams.find((team) => team.value === field.value)?.label : "Select team"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search team..." />
                          <CommandList>
                            <CommandEmpty>No team found.</CommandEmpty>
                            <CommandGroup>
                              {teams.map((team) => (
                                <CommandItem
                                  key={team.value}
                                  value={team.value}
                                  onSelect={(value) => {
                                    form.setValue("team", value)
                                    setTeamOpen(false)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      team.value === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {team.label}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Service Line Field */}
            <FormField
              control={form.control}
              name="serviceLine"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Line</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      field.onChange(value)
                      setSelectedServiceLine(value)
                    }}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select service line" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {serviceLines.map((serviceLine) => (
                        <SelectItem key={serviceLine.value} value={serviceLine.value}>
                          {serviceLine.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The service line {nominationType === "individual" ? "the nominee" : "this team"} belongs to.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {nominationType === "team" && (
              <FormField
                control={form.control}
                name="teamMembers"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Key Team Members</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="List the key team members who contributed to this achievement..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      List the names of team members who were instrumental in this achievement.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="awardType"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Award Type</FormLabel>
                  <Popover open={awardTypeOpen} onOpenChange={setAwardTypeOpen}>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={awardTypeOpen}
                          className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                        >
                          {field.value
                            ? awardTypes.find((type) => type.value === field.value)?.label
                            : "Select award type"}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search award type..." />
                        <CommandList>
                          <CommandEmpty>No award type found.</CommandEmpty>
                          <CommandGroup>
                            {awardTypes.map((type) => (
                              <CommandItem
                                key={type.value}
                                value={type.value}
                                onSelect={(value) => {
                                  form.setValue("awardType", value)
                                  setAwardTypeOpen(false)
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    type.value === field.value ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                {type.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="justification"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Justification</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={`Describe why ${nominationType === "individual" ? "this person" : "this team"} deserves the award. Include specific examples of their work or behavior.`}
                      className="min-h-[120px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Be specific about what {nominationType === "individual" ? "they" : "the team"} did and how it
                    relates to the award criteria.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="impact"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Impact</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={`Describe the impact of ${nominationType === "individual" ? "their" : "the team's"} contribution on the team, department, or company.`}
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Explain how {nominationType === "individual" ? "their" : "the team's"} actions positively affected
                    business results, team morale, or customer satisfaction.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supportingInfo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Supporting Information (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Links to relevant documents, feedback, or other supporting information"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Include any links to documents, metrics, or feedback that support this nomination.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4">
              <h4 className="text-sm font-medium">Notification Options</h4>
              <div className="space-y-2">
                {selectedServiceLine && (
                  <div className="rounded-md bg-muted p-3 text-sm">
                    <p>
                      <span className="font-medium">Domain Manager Notification:</span> A notification will be sent to{" "}
                      {getDomainManager(selectedServiceLine)} (Domain Manager for{" "}
                      {serviceLines.find((sl) => sl.value === selectedServiceLine)?.label}).
                    </p>
                  </div>
                )}

                {nominationType === "individual" ? (
                  <>
                    <FormField
                      control={form.control}
                      name="notifyManager"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Notify nominee's manager</FormLabel>
                            <FormDescription>
                              Send a notification to the nominee's manager about this award.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="notifyTeam"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Share with team</FormLabel>
                            <FormDescription>Share this nomination with the nominee's team members.</FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </>
                ) : (
                  <FormField
                    control={form.control}
                    name="notifyManagers"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Notify team managers</FormLabel>
                          <FormDescription>Send a notification to all team managers about this award.</FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                )}
              </div>
            </div>
            <Button type="submit" className="w-full">
              Submit Nomination
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col items-start border-t px-6 py-4">
        <p className="text-xs text-muted-foreground">
          Nominations are reviewed by the {awardType === "spot" ? "department manager" : "awards committee"} within 5
          business days. You will receive a notification when your nomination has been processed.
        </p>
      </CardFooter>
    </Card>
  )
}

