import type React from "react"
import { cn } from "@/lib/utils"
import { DashboardNav } from "@/components/dashboard-nav"

interface DashboardShellProps {
  children: React.ReactNode
  className?: string
}

export function DashboardShell({ children, className }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex flex-1">
        <aside className="hidden md:block">
          <DashboardNav />
        </aside>
        <main className="flex-1 p-6 md:p-8 pt-2">
          <div className={cn("mx-auto max-w-6xl space-y-6", className)}>{children}</div>
        </main>
      </div>
    </div>
  )
}

