"use client"

import { ChevronDown, ChevronRight, File, Folder } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

type FileTreeItem = {
  id: string
  name: string
  type: "file" | "folder"
  children?: FileTreeItem[]
  path?: string
}

interface FileTreeProps {
  items: FileTreeItem[]
  onSelectFile: (path: string) => void
  selectedPath?: string
}

export function FileTree({ items, onSelectFile, selectedPath }: FileTreeProps) {
  return (
    <div className="w-full">
      {items.map((item) => (
        <FileTreeNode key={item.id} item={item} level={0} onSelectFile={onSelectFile} selectedPath={selectedPath} />
      ))}
    </div>
  )
}

interface FileTreeNodeProps {
  item: FileTreeItem
  level: number
  onSelectFile: (path: string) => void
  selectedPath?: string
}

function FileTreeNode({ item, level, onSelectFile, selectedPath }: FileTreeNodeProps) {
  const [expanded, setExpanded] = useState(true)
  const isSelected = item.path === selectedPath

  const toggleExpand = () => {
    if (item.type === "folder") {
      setExpanded(!expanded)
    }
  }

  const handleClick = () => {
    if (item.type === "folder") {
      toggleExpand()
    } else if (item.path) {
      onSelectFile(item.path)
    }
  }

  return (
    <div>
      <div
        className={cn(
          "flex items-center py-1 px-2 rounded-md cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800",
          isSelected && "bg-gray-100 dark:bg-gray-800",
        )}
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={handleClick}
      >
        {item.type === "folder" ? (
          <>
            <span className="mr-1">
              {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </span>
            <Folder className="h-4 w-4 mr-2 text-blue-500" />
          </>
        ) : (
          <>
            <span className="w-5" />
            <File className="h-4 w-4 mr-2 text-gray-500" />
          </>
        )}
        <span className={cn("text-sm", isSelected && "font-medium")}>{item.name}</span>
      </div>

      {item.type === "folder" && expanded && item.children && (
        <div>
          {item.children.map((child) => (
            <FileTreeNode
              key={child.id}
              item={child}
              level={level + 1}
              onSelectFile={onSelectFile}
              selectedPath={selectedPath}
            />
          ))}
        </div>
      )}
    </div>
  )
}
