"use client"

import Link from "next/link"
import type React from "react"
import { cn } from "@/lib/utils"

interface LogoProps {
  size?: "sm" | "md" | "lg"
  showText?: boolean
  className?: string
}

export const Logo: React.FC<LogoProps> = ({ size = "md", showText = false, className }) => {
  let fontSize = "text-lg"
  let height = 8
  let width = 8
  let textSize = "text-xl"

  if (size === "md") {
    fontSize = "text-xl"
    height = 10
    width = 10
    textSize = "text-2xl"
  } else if (size === "lg") {
    fontSize = "text-2xl"
    height = 12
    width = 12
    textSize = "text-3xl"
  }

  return (
    <Link href="/" className={cn("flex items-center font-semibold", className)}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={height * 4}
        height={height * 4}
        viewBox="0 0 64 64"
        className={cn(`h-${height} w-${width}`, fontSize)}
      >
        <path d="M16.028 15.99h31.98v31.98h-31.98z" fill="#fff" />
        <path d="M64 32.02L48 16v32zm-31.98 0L48 16H16.03zM0 32.02l16.028 16V16zm32.02 0l-16 16H48z" fill="#db0011" />
      </svg>
      {showText && <span className={cn("ml-3 font-bold tracking-tight", textSize)}>Spot Award</span>}
    </Link>
  )
}

