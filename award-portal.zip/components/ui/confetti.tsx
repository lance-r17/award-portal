"use client"

import { useEffect, useState } from "react"
import ReactConfetti from "react-confetti"

interface ConfettiProps {
  duration?: number
}

export function Confetti({ duration = 5000 }: ConfettiProps) {
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  const [isActive, setIsActive] = useState(true)

  useEffect(() => {
    // Set dimensions
    const updateDimensions = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    }

    updateDimensions()
    window.addEventListener("resize", updateDimensions)

    // Set timeout to remove confetti
    const timeout = setTimeout(() => {
      setIsActive(false)
    }, duration)

    return () => {
      window.removeEventListener("resize", updateDimensions)
      clearTimeout(timeout)
    }
  }, [duration])

  if (!isActive) return null

  return (
    <ReactConfetti
      width={dimensions.width}
      height={dimensions.height}
      recycle={false}
      numberOfPieces={200}
      gravity={0.15}
      colors={[
        "#f43f5e", // rose-500
        "#ec4899", // pink-500
        "#8b5cf6", // violet-500
        "#3b82f6", // blue-500
        "#10b981", // emerald-500
        "#f59e0b", // amber-500
        "#ef4444", // red-500
      ]}
      tweenDuration={5000}
    />
  )
}

