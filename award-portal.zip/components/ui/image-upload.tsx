"use client"

import type React from "react"

import { useState, useRef } from "react"
import { X, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export interface UploadedImage {
  id: string
  file: File
  url: string
}

interface ImageUploadProps {
  maxImages?: number
  images: UploadedImage[]
  onChange: (images: UploadedImage[]) => void
  disabled?: boolean
}

export function ImageUpload({ maxImages = 5, images = [], onChange, disabled = false }: ImageUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [dragActive, setDragActive] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      addFiles(Array.from(e.target.files))
    }
    // Reset the input value so the same file can be uploaded again if removed
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const addFiles = (files: File[]) => {
    // Filter for only image files
    const imageFiles = files.filter((file) => file.type.startsWith("image/"))

    // Limit to remaining slots
    const remainingSlots = maxImages - images.length
    const filesToAdd = imageFiles.slice(0, remainingSlots)

    if (filesToAdd.length === 0) return

    const newImages = filesToAdd.map((file) => ({
      id: crypto.randomUUID(),
      file,
      url: URL.createObjectURL(file),
    }))

    onChange([...images, ...newImages])
  }

  const removeImage = (id: string) => {
    const updatedImages = images.filter((image) => image.id !== id)
    onChange(updatedImages)
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      addFiles(Array.from(e.dataTransfer.files))
    }
  }

  const handleClick = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className="space-y-4">
      {/* Upload area */}
      {images.length < maxImages && (
        <div
          className={cn(
            "border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors",
            dragActive
              ? "border-primary bg-primary/5"
              : "border-gray-300 hover:border-primary/50 dark:border-gray-600 dark:hover:border-primary/50",
            disabled && "opacity-50 cursor-not-allowed",
          )}
          onClick={disabled ? undefined : handleClick}
          onDragEnter={disabled ? undefined : handleDrag}
          onDragLeave={disabled ? undefined : handleDrag}
          onDragOver={disabled ? undefined : handleDrag}
          onDrop={disabled ? undefined : handleDrop}
        >
          <div className="flex flex-col items-center justify-center space-y-2">
            <Upload className="h-8 w-8 text-gray-400" />
            <div className="text-sm font-medium">Drag and drop images or click to upload</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {images.length} of {maxImages} images uploaded
            </div>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFileChange}
            disabled={disabled}
          />
        </div>
      )}

      {/* Image previews */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {images.map((image) => (
            <div key={image.id} className="relative group">
              <div className="aspect-square rounded-md overflow-hidden border bg-gray-100 dark:bg-gray-800">
                <img
                  src={image.url || "/placeholder.svg"}
                  alt={image.file.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removeImage(image.id)}
                disabled={disabled}
              >
                <X className="h-3 w-3" />
                <span className="sr-only">Remove image</span>
              </Button>
              <div className="text-xs truncate mt-1 text-gray-500 dark:text-gray-400">{image.file.name}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

