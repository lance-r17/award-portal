"use client"

import { Award, ChevronDown, Home, Mail, Settings, Trophy, Users } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
} from "@/components/ui/sidebar"
import { RoleSwitcher } from "@/components/role-switcher"
import { getCurrentUser } from "@/data/mock-users"
import { useEffect, useState } from "react"
import type { User } from "@/types/user"

const navItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: Home,
  },
  {
    title: "Awards",
    href: "/awards",
    icon: Trophy,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
    subItems: [
      {
        title: "User Management",
        href: "/settings/users",
        icon: Users,
      },
      {
        title: "Award Types",
        href: "/settings/award-types",
        icon: Award,
      },
      {
        title: "Judge Pool",
        href: "/settings/judge-pool",
        icon: Trophy,
      },
      {
        title: "Email Logs",
        href: "/settings/email-logs",
        icon: Mail,
      },
    ],
  },
]

export function DashboardNav() {
  const pathname = usePathname()
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [expandedItem, setExpandedItem] = useState<string | null>("Settings") // Default expanded

  // Update the current user when the component mounts or when role changes
  useEffect(() => {
    // Get the current user based on the role in localStorage
    setCurrentUser(getCurrentUser())

    // Listen for storage events (if role changes in another tab)
    const handleStorageChange = () => {
      setCurrentUser(getCurrentUser())
    }

    // Listen for our custom roleChanged event
    const handleRoleChange = () => {
      setCurrentUser(getCurrentUser())
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("roleChanged", handleRoleChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("roleChanged", handleRoleChange)
    }
  }, [])

  // Auto-expand Settings if on a settings page
  useEffect(() => {
    if (pathname.startsWith("/settings") && expandedItem !== "Settings") {
      setExpandedItem("Settings")
    }
  }, [pathname, expandedItem])

  return (
    <SidebarProvider defaultOpen>
      <Sidebar className="w-64 border-r h-screen">
        <SidebarHeader className="flex h-14 items-center border-b px-4">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <Award className="h-6 w-6" />
            <span>RecognizeHub</span>
          </Link>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {navItems.map((item) => (
              <div key={item.href}>
                <SidebarMenuItem>
                  {item.subItems ? (
                    <div className="w-full">
                      <button
                        onClick={() => setExpandedItem(expandedItem === item.title ? null : item.title)}
                        className={`flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium ${
                          pathname === item.href ? "bg-accent text-accent-foreground" : "transparent"
                        } hover:bg-accent hover:text-accent-foreground`}
                      >
                        <div className="flex items-center">
                          <item.icon className="mr-2 h-5 w-5" />
                          <span>{item.title}</span>
                        </div>
                        <ChevronDown
                          className={`h-4 w-4 transition-transform ${expandedItem === item.title ? "rotate-180" : ""}`}
                        />
                      </button>
                    </div>
                  ) : (
                    <SidebarMenuButton asChild isActive={pathname === item.href} tooltip={item.title}>
                      <Link href={item.href}>
                        <item.icon className="h-5 w-5" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>

                {item.subItems && expandedItem === item.title && (
                  <div className="ml-6 mt-1 space-y-1">
                    {item.subItems.map((subItem) => (
                      <SidebarMenuItem key={subItem.href}>
                        <SidebarMenuButton asChild isActive={pathname === subItem.href} tooltip={subItem.title}>
                          <Link href={subItem.href} className="flex items-center gap-2 py-1">
                            <subItem.icon className="h-4 w-4" />
                            <span className="text-sm">{subItem.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="border-t p-4 flex flex-col gap-4">
          <RoleSwitcher />
          {currentUser && (
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-medium">
                {currentUser.initials || currentUser.name.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-medium">{currentUser.name}</p>
                <p className="text-xs text-muted-foreground">{currentUser.title || "Employee"}</p>
              </div>
            </div>
          )}
        </SidebarFooter>
      </Sidebar>
    </SidebarProvider>
  )
}
