"use client"

import { Award, BarChart3, Home, Settings, Trophy, Users } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { RoleSwitcher } from "@/components/role-switcher"
import { getCurrentUser } from "@/data/mock-users"
import { useEffect, useState } from "react"
import type { User } from "@/types/user"

const navItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: Home,
  },
  {
    title: "Recognitions",
    href: "/recognitions",
    icon: Award,
  },
  {
    title: "Awards",
    href: "/awards",
    icon: Trophy,
  },
  {
    title: "Employees",
    href: "/employees",
    icon: Users,
  },
  {
    title: "Leaderboard",
    href: "/leaderboard",
    icon: Trophy,
  },
  {
    title: "Analytics",
    href: "/analytics",
    icon: BarChart3,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
  },
]

export function DashboardNav() {
  const pathname = usePathname()
  const [currentUser, setCurrentUser] = useState<User | null>(null)

  // Update the current user when the component mounts or when role changes
  useEffect(() => {
    // Get the current user based on the role in localStorage
    setCurrentUser(getCurrentUser())

    // Listen for storage events (if role changes in another tab)
    const handleStorageChange = () => {
      setCurrentUser(getCurrentUser())
    }

    // Listen for our custom roleChanged event
    const handleRoleChange = () => {
      setCurrentUser(getCurrentUser())
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("roleChanged", handleRoleChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("roleChanged", handleRoleChange)
    }
  }, [])

  return (
    <SidebarProvider defaultOpen>
      <Sidebar className="w-64 border-r h-screen">
        <SidebarHeader className="flex h-14 items-center border-b px-4">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <Award className="h-6 w-6" />
            <span>RecognizeHub</span>
          </Link>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {navItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton asChild isActive={pathname === item.href} tooltip={item.title}>
                  <Link href={item.href}>
                    <item.icon className="h-5 w-5" />
                    <span>{item.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="border-t p-4 flex flex-col gap-4">
          <RoleSwitcher />
          {currentUser && (
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-medium">
                {currentUser.initials || currentUser.name.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-medium">{currentUser.name}</p>
                <p className="text-xs text-muted-foreground">{currentUser.title || "Employee"}</p>
              </div>
            </div>
          )}
        </SidebarFooter>
      </Sidebar>
      <div className="flex items-center h-14 border-b px-6">
        <SidebarTrigger />
      </div>
    </SidebarProvider>
  )
}

