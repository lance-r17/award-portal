"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Info, CheckCircle, XCircle, Clock, ThumbsUp, ThumbsDown, AlertTriangle } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import { endorseNomination, isUserDomainManagerForNomination } from "@/data/nominations"
import { getAwardTypeDisplay } from "@/data/award-types" // Import the function from award-types

interface DomainManagerEndorsementPanelProps {
  eventId: string
  nominations: Nomination[]
  currentUserId: string
  onEndorsementUpdate?: (updatedNomination: Nomination) => void
}

export function DomainManagerEndorsementPanel({
  eventId,
  nominations = [],
  currentUserId,
  onEndorsementUpdate,
}: DomainManagerEndorsementPanelProps) {
  const [activeTab, setActiveTab] = useState<string>("pending")
  const [endorsementComments, setEndorsementComments] = useState<string>("")
  const [selectedNomination, setSelectedNomination] = useState<Nomination | null>(null)
  const [endorsementAction, setEndorsementAction] = useState<"endorse" | "reject" | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  // Filter nominations that the current user can endorse (as a domain manager)
  const userEndorsableNominations = nominations.filter((nomination) =>
    isUserDomainManagerForNomination(currentUserId, nomination),
  )

  // Pending endorsements
  const pendingEndorsements = userEndorsableNominations.filter(
    (nomination) => !nomination.endorsement || nomination.endorsement.status === "pending",
  )

  // Endorsed nominations
  const endorsedNominations = userEndorsableNominations.filter(
    (nomination) => nomination.endorsement?.status === "endorsed",
  )

  // Rejected endorsements
  const rejectedEndorsements = userEndorsableNominations.filter(
    (nomination) => nomination.endorsement?.status === "rejected",
  )

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Remove the local getAwardTypeDisplay function

  // Handle endorsement action
  const handleEndorsementAction = (nomination: Nomination, action: "endorse" | "reject") => {
    setSelectedNomination(nomination)
    setEndorsementAction(action)
    setEndorsementComments("")
    setIsDialogOpen(true)
  }

  // Submit endorsement
  const submitEndorsement = () => {
    if (!selectedNomination || !endorsementAction) return

    const updatedNomination = endorseNomination(
      selectedNomination.id,
      currentUserId,
      endorsementAction,
      endorsementComments,
    )

    if (updatedNomination) {
      toast({
        title: endorsementAction === "endorse" ? "Nomination Endorsed" : "Nomination Rejected",
        description:
          endorsementAction === "endorse"
            ? "The nomination has been endorsed and will proceed to the presentation stage."
            : "The nomination has been rejected and will not proceed to the presentation stage.",
      })

      // Call the update callback if provided
      if (onEndorsementUpdate) {
        onEndorsementUpdate(updatedNomination)
      }
    } else {
      toast({
        title: "Action Failed",
        description: "There was an error processing your request. Please try again.",
        variant: "destructive",
      })
    }

    setIsDialogOpen(false)
  }

  if (userEndorsableNominations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Domain Manager Endorsements</CardTitle>
          <CardDescription>Review and endorse nominations from your service line.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>No Nominations to Endorse</AlertTitle>
            <AlertDescription>
              You don't have any nominations to review as a domain manager. Nominations will appear here when they are
              submitted for your service line.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Domain Manager Endorsements</CardTitle>
        <CardDescription>
          Review and endorse nominations from your service line. Only endorsed nominations will proceed to the
          presentation stage.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="pending" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="pending">
              Pending ({pendingEndorsements.length})
              {pendingEndorsements.length > 0 && (
                <Badge
                  variant="secondary"
                  className="ml-2 bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-300"
                >
                  {pendingEndorsements.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="endorsed">Endorsed ({endorsedNominations.length})</TabsTrigger>
            <TabsTrigger value="rejected">Rejected ({rejectedEndorsements.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4 mt-4">
            {pendingEndorsements.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="mx-auto h-12 w-12 text-primary/50" />
                <p className="mt-2 text-muted-foreground">No pending endorsements. You're all caught up!</p>
              </div>
            ) : (
              pendingEndorsements.map((nomination, index) => (
                <EndorsementCard
                  key={nomination.id}
                  nomination={nomination}
                  onEndorse={() => handleEndorsementAction(nomination, "endorse")}
                  onReject={() => handleEndorsementAction(nomination, "reject")}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="endorsed" className="space-y-4 mt-4">
            {endorsedNominations.length === 0 ? (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">You haven't endorsed any nominations yet.</p>
              </div>
            ) : (
              endorsedNominations.map((nomination) => (
                <EndorsementCard key={nomination.id} nomination={nomination} isReadOnly />
              ))
            )}
          </TabsContent>

          <TabsContent value="rejected" className="space-y-4 mt-4">
            {rejectedEndorsements.length === 0 ? (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">You haven't rejected any nominations.</p>
              </div>
            ) : (
              rejectedEndorsements.map((nomination) => (
                <EndorsementCard key={nomination.id} nomination={nomination} isReadOnly />
              ))
            )}
          </TabsContent>
        </Tabs>

        {/* Endorsement Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{endorsementAction === "endorse" ? "Endorse Nomination" : "Reject Nomination"}</DialogTitle>
              <DialogDescription>
                {endorsementAction === "endorse"
                  ? "Endorsing this nomination will allow it to proceed to the presentation stage."
                  : "Rejecting this nomination will prevent it from proceeding to the presentation stage."}
              </DialogDescription>
            </DialogHeader>

            {selectedNomination && (
              <div className="py-4">
                <div className="flex items-start gap-3 mb-4">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={selectedNomination.nominee.avatar} alt={selectedNomination.nominee.name} />
                    <AvatarFallback>{selectedNomination.nominee.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">{selectedNomination.nominee.name}</h3>
                    <p className="text-sm text-muted-foreground">{formatServiceLine(selectedNomination.serviceLine)}</p>
                    <p className="text-sm mt-1">{getAwardTypeDisplay(selectedNomination.awardType)}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-1">Comments (Optional):</h4>
                    <Textarea
                      placeholder={
                        endorsementAction === "endorse"
                          ? "Add any comments about why you're endorsing this nomination..."
                          : "Please provide a reason for rejecting this nomination..."
                      }
                      value={endorsementComments}
                      onChange={(e) => setEndorsementComments(e.target.value)}
                      className="min-h-[100px]"
                    />
                  </div>

                  {endorsementAction === "reject" && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Important</AlertTitle>
                      <AlertDescription>
                        Rejecting a nomination is final and will prevent it from being considered for this award cycle.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </div>
            )}

            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button onClick={submitEndorsement} variant={endorsementAction === "endorse" ? "default" : "destructive"}>
                {endorsementAction === "endorse" ? "Endorse" : "Reject"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

interface EndorsementCardProps {
  nomination: Nomination
  onEndorse?: () => void
  onReject?: () => void
  isReadOnly?: boolean
}

function EndorsementCard({ nomination, onEndorse, onReject, isReadOnly = false }: EndorsementCardProps) {
  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Remove the local getAwardTypeDisplay function

  return (
    <div
      className={cn(
        "rounded-lg border p-4",
        nomination.endorsement?.status === "endorsed"
          ? "border-green-200 bg-green-50 dark:border-green-900/30 dark:bg-green-900/10"
          : nomination.endorsement?.status === "rejected"
            ? "border-red-200 bg-red-50 dark:border-red-900/30 dark:bg-red-900/10"
            : "border-amber-200 bg-amber-50 dark:border-amber-900/30 dark:bg-amber-900/10",
      )}
    >
      <div className="flex items-start gap-4">
        <Avatar className="h-12 w-12">
          <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
          <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
        </Avatar>

        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <h3 className="font-medium">{nomination.nominee.name}</h3>
              <p className="text-sm text-muted-foreground">{formatServiceLine(nomination.serviceLine)}</p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="secondary">{getAwardTypeDisplay(nomination.awardType)}</Badge>
                <Badge variant="outline">{nomination.nominationType === "individual" ? "Individual" : "Team"}</Badge>
              </div>
            </div>

            {!isReadOnly && (
              <div className="flex gap-2">
                <Button
                  onClick={onReject}
                  variant="outline"
                  size="sm"
                  className="border-red-200 hover:bg-red-100 hover:text-red-900"
                >
                  <ThumbsDown className="mr-1 h-4 w-4" />
                  Reject
                </Button>
                <Button onClick={onEndorse} size="sm">
                  <ThumbsUp className="mr-1 h-4 w-4" />
                  Endorse
                </Button>
              </div>
            )}

            {isReadOnly && nomination.endorsement && (
              <div>
                {nomination.endorsement.status === "endorsed" ? (
                  <Badge
                    variant="outline"
                    className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300"
                  >
                    <CheckCircle className="mr-1 h-3 w-3" />
                    Endorsed
                  </Badge>
                ) : nomination.endorsement.status === "rejected" ? (
                  <Badge variant="outline" className="bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300">
                    <XCircle className="mr-1 h-3 w-3" />
                    Rejected
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300"
                  >
                    <Clock className="mr-1 h-3 w-3" />
                    Pending
                  </Badge>
                )}
              </div>
            )}
          </div>

          <div className="mt-3">
            <p className="text-sm font-medium mb-1">Justification:</p>
            <p className="text-sm text-muted-foreground">{nomination.justification}</p>
          </div>

          <div className="mt-2">
            <p className="text-sm font-medium mb-1">Impact:</p>
            <p className="text-sm text-muted-foreground">{nomination.impact}</p>
          </div>

          {nomination.endorsement?.comments && (
            <div className="mt-3 p-3 rounded-md bg-background border">
              <p className="text-sm font-medium mb-1">Endorsement Comments:</p>
              <p className="text-sm text-muted-foreground">{nomination.endorsement.comments}</p>
              {nomination.endorsement.endorsedAt && (
                <p className="text-xs text-muted-foreground mt-2">
                  {nomination.endorsement.status === "endorsed" ? "Endorsed" : "Reviewed"} on{" "}
                  {nomination.endorsement.endorsedAt.toLocaleDateString()}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

