import type React from "react"
import type { AwardEvent, AwardEventStage } from "@/types/award-events"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { CalendarCheck, Check, PresentationIcon, Trophy } from "lucide-react"

interface AwardEventStageIndicatorProps {
  event: AwardEvent
  className?: string
}

export function AwardEventStageIndicator({ event, className }: AwardEventStageIndicatorProps) {
  const stages: { key: AwardEventStage; label: string; icon: React.ReactNode }[] = [
    {
      key: "nomination",
      label: "Nomination",
      icon: <CalendarCheck className="h-5 w-5" />,
    },
    {
      key: "presentation",
      label: "Presentation",
      icon: <PresentationIcon className="h-5 w-5" />,
    },
    {
      key: "result",
      label: "Results",
      icon: <Trophy className="h-5 w-5" />,
    },
  ]

  // Determine which stages are completed, current, or upcoming
  const getCurrentStageIndex = () => {
    return stages.findIndex((stage) => stage.key === event.currentStage)
  }

  const currentStageIndex = getCurrentStageIndex()

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-6">
        <div className="space-y-6">
          <h3 className="text-lg font-medium">Award Process Timeline</h3>

          <div className="relative">
            {/* Progress line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-muted">
              <div
                className="absolute top-0 left-0 w-full bg-primary"
                style={{
                  height: `${Math.min(100, (currentStageIndex / (stages.length - 1)) * 100)}%`,
                }}
              ></div>
            </div>

            <div className="space-y-8">
              {stages.map((stage, index) => {
                const isCompleted = index < currentStageIndex
                const isCurrent = index === currentStageIndex
                const isUpcoming = index > currentStageIndex

                const stageDate = isCurrent
                  ? `Ends ${format(event.stages[stage.key].endDate, "MMM d, yyyy")}`
                  : isCompleted
                    ? `Completed on ${format(event.stages[stage.key].endDate, "MMM d, yyyy")}`
                    : `Starts ${format(event.stages[stage.key].startDate, "MMM d, yyyy")}`

                return (
                  <div key={stage.key} className="relative pl-14">
                    <div
                      className={cn(
                        "absolute left-6 top-1 -translate-x-1/2 flex h-5 w-5 items-center justify-center rounded-full border",
                        isCompleted
                          ? "border-primary bg-primary text-primary-foreground"
                          : isCurrent
                            ? "border-primary bg-background"
                            : "border-muted bg-background",
                      )}
                    >
                      {isCompleted ? (
                        <Check className="h-3 w-3 text-primary-foreground" />
                      ) : (
                        <div className={cn("h-2 w-2 rounded-full", isCurrent ? "bg-primary" : "bg-transparent")}></div>
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <div
                          className={cn(
                            "text-sm font-medium",
                            isCompleted
                              ? "text-muted-foreground"
                              : isCurrent
                                ? "text-primary"
                                : "text-muted-foreground",
                          )}
                        >
                          {stage.label} Stage
                        </div>
                        <div
                          className={cn(
                            "rounded-full p-1",
                            isCompleted
                              ? "bg-muted text-muted-foreground"
                              : isCurrent
                                ? "bg-primary/10 text-primary"
                                : "bg-muted text-muted-foreground",
                          )}
                        >
                          {stage.icon}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">{stageDate}</p>
                      {isCurrent && <p className="text-xs font-medium text-primary">Current Stage</p>}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

