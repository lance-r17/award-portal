"use client"

import type React from "react"

import { useState } from "react"
import { CalendarPlus } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"
import { CreateAwardEventForm } from "@/components/award/create-award-event-form"

interface CreateAwardEventDrawerProps {
  buttonVariant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive"
  buttonSize?: "default" | "sm" | "lg" | "icon"
  buttonText?: string
  drawerTitle?: string
  drawerDescription?: string
  existingEvent?: any
  isEditing?: boolean
  currentUser?: {
    id: string
    name: string
    role?: string
  }
  children?: React.ReactNode
}

export function CreateAwardEventDrawer({
  buttonVariant = "default",
  buttonSize = "sm",
  buttonText = "Create Award Event",
  drawerTitle = "Create New Award Event",
  drawerDescription = "Set up a new award event with nomination, presentation, and result stages.",
  existingEvent,
  isEditing = false,
  currentUser = { id: "current-user", name: "Current User" },
  children,
}: CreateAwardEventDrawerProps) {
  const [open, setOpen] = useState(false)

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        {children ? (
          children
        ) : (
          <Button variant={buttonVariant} size={buttonSize}>
            <CalendarPlus className="mr-2 h-4 w-4" />
            {buttonText}
          </Button>
        )}
      </DrawerTrigger>
      <DrawerContent className="max-h-[90vh]">
        <div className="mx-auto w-full max-w-4xl">
          <DrawerHeader>
            <DrawerTitle>{isEditing ? "Edit Award Event" : drawerTitle}</DrawerTitle>
            <DrawerDescription>
              {isEditing ? "Update the award event details and timeline." : drawerDescription}
            </DrawerDescription>
          </DrawerHeader>
          <div className="px-4 pb-0 overflow-y-auto max-h-[calc(90vh-10rem)]">
            <CreateAwardEventForm
              onSuccess={() => setOpen(false)}
              existingEvent={existingEvent}
              isEditing={isEditing}
              currentUser={currentUser}
            />
          </div>
          <DrawerFooter>
            <DrawerClose asChild>
              <Button variant="outline">Cancel</Button>
            </DrawerClose>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  )
}

