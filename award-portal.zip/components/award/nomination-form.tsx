"use client"

import { useEffect, useRef } from "react"
import { useForm } from "react-hook-form"

const NominationForm = () => {
  const form = useForm()

  const isInitialRender = useRef(true)

  useEffect(() => {
    if (form.getValues("awardType") === "team" && !isInitialRender.current) {
      const teamMembers = form.getValues("teamMembers") || []
      const presenterServiceLine = form.getValues("presenterServiceLine")

      // Collect service lines from team members
      const teamServiceLines = teamMembers.map((member) => member.serviceLine).filter(Boolean)

      // Combine presenter and team service lines, removing duplicates
      const allServiceLines = [
        ...new Set([
          ...(Array.isArray(presenterServiceLine) ? presenterServiceLine : [presenterServiceLine]),
          ...teamServiceLines,
        ]),
      ].filter(Boolean)

      // Only update if the service lines have actually changed
      const currentServiceLines = form.getValues("serviceLine") || []
      const serviceLineChanged = JSON.stringify(currentServiceLines.sort()) !== JSON.stringify(allServiceLines.sort())

      if (serviceLineChanged) {
        form.setValue("serviceLine", allServiceLines)
      }
    }
  }, [form.getValues("teamMembers")])

  useEffect(() => {
    isInitialRender.current = false
    return () => {
      isInitialRender.current = true
    }
  }, [])

  return <div>{/* Your form elements go here */}</div>
}

export default NominationForm
