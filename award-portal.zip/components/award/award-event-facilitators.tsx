"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Plus, X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { toast } from "@/components/ui/use-toast"
import { mockUsers } from "@/data/mock-users"

// Sample users for demonstration
const users = mockUsers

interface AwardEventFacilitatorsProps {
  eventId: string
  facilitators: { id: string; name: string }[]
  creatorId: string
  currentUserId: string
  onUpdate?: (facilitators: { id: string; name: string }[]) => void
  readOnly?: boolean
}

export function AwardEventFacilitators({
  eventId,
  facilitators = [],
  creatorId,
  currentUserId,
  onUpdate,
  readOnly = false,
}: AwardEventFacilitatorsProps) {
  const [open, setOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const canManageFacilitators = currentUserId === creatorId || facilitators.some((f) => f.id === currentUserId)

  const availableUsers = users.filter(
    (user) =>
      !facilitators.some((f) => f.id === user.id) &&
      user.id !== creatorId &&
      (user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const handleAddFacilitator = (userId: string) => {
    const user = users.find((u) => u.id === userId)
    if (!user) return

    const updatedFacilitators = [...facilitators, { id: user.id, name: user.name }]

    if (onUpdate) {
      onUpdate(updatedFacilitators)
    }

    toast({
      title: "Facilitator added",
      description: `${user.name} has been added as a facilitator.`,
    })

    setOpen(false)
  }

  const handleRemoveFacilitator = (userId: string) => {
    const updatedFacilitators = facilitators.filter((f) => f.id !== userId)

    if (onUpdate) {
      onUpdate(updatedFacilitators)
    }

    toast({
      title: "Facilitator removed",
      description: "The facilitator has been removed from this award event.",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Award Event Facilitators</CardTitle>
        <CardDescription>
          Facilitators can view and edit this award event, including when it's in draft status.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Current Facilitators</h3>
            {!readOnly && canManageFacilitators && (
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Facilitator
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0" align="end">
                  <Command>
                    <CommandInput placeholder="Search users..." onValueChange={setSearchQuery} />
                    <CommandList>
                      <CommandEmpty>No users found</CommandEmpty>
                      <CommandGroup>
                        {availableUsers.map((user) => (
                          <CommandItem
                            key={user.id}
                            onSelect={() => handleAddFacilitator(user.id)}
                            className="flex items-center gap-2"
                          >
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={user.avatar} alt={user.name} />
                              <AvatarFallback>{user.initials}</AvatarFallback>
                            </Avatar>
                            <div className="flex flex-col">
                              <span>{user.name}</span>
                              <span className="text-xs text-muted-foreground">{user.email}</span>
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            )}
          </div>

          <div className="space-y-2">
            {facilitators.length === 0 ? (
              <p className="text-sm text-muted-foreground">No facilitators assigned yet.</p>
            ) : (
              facilitators.map((facilitator) => {
                const user = users.find((u) => u.id === facilitator.id) || {
                  avatar: "/placeholder.svg?height=40&width=40",
                  initials: facilitator.name
                    .split(" ")
                    .map((n) => n[0])
                    .join(""),
                  email: "",
                }

                return (
                  <div
                    key={facilitator.id}
                    className={cn(
                      "flex items-center justify-between p-2 rounded-md",
                      facilitator.id === currentUserId && "bg-muted/50",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.avatar} alt={facilitator.name} />
                        <AvatarFallback>{user.initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{facilitator.name}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                      {facilitator.id === currentUserId && (
                        <Badge variant="outline" className="ml-2">
                          You
                        </Badge>
                      )}
                    </div>
                    {!readOnly && canManageFacilitators && facilitator.id !== currentUserId && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleRemoveFacilitator(facilitator.id)}
                      >
                        <X className="h-4 w-4" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    )}
                  </div>
                )
              })
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
