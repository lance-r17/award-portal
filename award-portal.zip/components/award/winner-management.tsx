"use client"

import { DialogFooter } from "@/components/ui/dialog"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Info, Trophy, Medal, Star, AlertTriangle, Check, HelpCircle } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { AwardEvent } from "@/types/award-events"
import { getAwardEventById } from "@/data/award-events"
import { getWinningNominationsForEvent, getEligibleScoresForNomination } from "@/data/mock-scores"
import { getNominationsByEventId } from "@/data/nominations"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"
import { AwardQuotas, type AwardQuota } from "@/components/award/award-quotas"
import { getAwardQuotas, getQuotaForAwardType } from "@/data/award-quotas"
import { calculateFinalScore } from "@/types/judges"
import { getJudgeServiceLines } from "@/data/mock-scores" // Assuming this function exists

// Define a new interface for potential winners
interface PotentialWinner extends Nomination {
  averageScore: number
  isSelected: boolean
  tiebreaker?: boolean
}

interface WinnerManagementProps {
  eventId: string
  isPresentationStage: boolean
  isResultStage: boolean
  isFacilitator: boolean
  isHeadJudge: boolean
}

export function WinnerManagement({
  eventId,
  isPresentationStage,
  isResultStage,
  isFacilitator,
  isHeadJudge,
}: WinnerManagementProps) {
  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<string>("quotas")

  // Award quotas state
  const [awardQuotas, setAwardQuotas] = useState<AwardQuota[]>([])

  // Potential winners state
  const [potentialWinners, setPotentialWinners] = useState<Record<string, PotentialWinner[]>>({})
  const [finalizedWinners, setFinalizedWinners] = useState<Nomination[]>([])
  const [tiebreakers, setTiebreakers] = useState<Record<string, PotentialWinner[]>>({})
  const [tiebreakerDecisions, setTiebreakerDecisions] = useState<Record<string, string[]>>({})

  // Publishing state
  const [isPublishing, setIsPublishing] = useState(false)
  const [isPublished, setIsPublished] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const awardEvent = getAwardEventById(eventId)
        setEvent(awardEvent || null)

        if (awardEvent) {
          // Get existing quotas
          const existingQuotas = getAwardQuotas(eventId)
          if (existingQuotas) {
            setAwardQuotas(existingQuotas)
          }

          // If in presentation or result stage, load nominations and calculate potential winners
          if (awardEvent.currentStage === "presentation" || awardEvent.currentStage === "result") {
            const nominations = getNominationsByEventId(eventId).filter((nom) => nom.endorsement?.status === "endorsed")

            // Group nominations by award type
            const groupedNominations: Record<string, PotentialWinner[]> = {}

            nominations.forEach((nomination) => {
              try {
                // Get all scores for this nomination
                const allScores = getEligibleScoresForNomination(nomination.id)

                if (allScores.length === 0) {
                  console.log(`No scores found for nomination ${nomination.id}`)
                  return // Skip this nomination if no scores
                }

                // Get the nominee's service line
                const nomineeServiceLine = Array.isArray(nomination.serviceLine)
                  ? nomination.serviceLine[0]
                  : (nomination.serviceLine as string)

                if (!nomineeServiceLine) {
                  console.log(`No service line found for nomination ${nomination.id}`)
                  return // Skip this nomination if no service line
                }

                // Get a mapping of judge IDs to their service lines
                const judgeServiceLines = getJudgeServiceLines
                  ? getJudgeServiceLines(allScores.map((score) => score.judgeId))
                  : {} // Empty object if function doesn't exist

                // Calculate the final score using the proper function with all required parameters
                const finalScore = calculateFinalScore(allScores, nomineeServiceLine, judgeServiceLines)

                console.log(`Nomination ${nomination.id} has final score: ${finalScore}`)

                // Only consider nominations with score >= 8.0
                if (finalScore >= 8.0) {
                  if (!groupedNominations[nomination.awardType]) {
                    groupedNominations[nomination.awardType] = []
                  }

                  // Check if the nomination is already awarded
                  const isAlreadyAwarded = nomination.status === "awarded"

                  groupedNominations[nomination.awardType].push({
                    ...nomination,
                    averageScore: finalScore,
                    isSelected: isAlreadyAwarded, // Set to true if already awarded
                  })
                }
              } catch (error) {
                console.error(`Error processing nomination ${nomination.id}:`, error)
              }
            })

            // Sort each group by average score (descending)
            Object.keys(groupedNominations).forEach((awardType) => {
              groupedNominations[awardType].sort((a, b) => b.averageScore - a.averageScore)
            })

            setPotentialWinners(groupedNominations)

            // If in result stage, load finalized winners
            if (awardEvent.currentStage === "result") {
              const winners = getWinningNominationsForEvent(eventId)
              setFinalizedWinners(winners)
              setIsPublished(winners.length > 0)
            }
          }
        }
      } catch (error) {
        console.error("Error fetching winner management data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId])

  // Handle quota updates from the AwardQuotas component
  const handleQuotasUpdated = (updatedQuotas: AwardQuota[]) => {
    setAwardQuotas(updatedQuotas)
  }

  // Auto-select winners based on quotas and scores
  const autoSelectWinners = () => {
    const newPotentialWinners = { ...potentialWinners }
    const newTiebreakers: Record<string, PotentialWinner[]> = {}

    // For each award type
    Object.keys(newPotentialWinners).forEach((awardType) => {
      // Get quota for this award type
      const quota = getQuotaForAwardType(eventId, awardType)
      const nominees = newPotentialWinners[awardType]

      // Reset selection
      nominees.forEach((nominee) => {
        nominee.isSelected = false
        nominee.tiebreaker = false
      })

      // If we have fewer or equal nominees than quota, select all
      if (nominees.length <= quota) {
        nominees.forEach((nominee) => {
          nominee.isSelected = true
        })
      } else {
        // Select top nominees up to quota
        for (let i = 0; i < quota; i++) {
          if (i < nominees.length) {
            nominees[i].isSelected = true
          }
        }

        // Check for ties at the quota boundary
        if (quota < nominees.length) {
          const lastSelectedScore = nominees[quota - 1].averageScore
          const nextNomineeIndex = quota

          if (nextNomineeIndex < nominees.length && nominees[nextNomineeIndex].averageScore === lastSelectedScore) {
            // We have a tie at the boundary
            const tiedNominees = nominees.filter((n) => n.averageScore === lastSelectedScore)

            // Mark all tied nominees for tiebreaker
            tiedNominees.forEach((nominee) => {
              nominee.tiebreaker = true
            })

            // Add to tiebreakers
            newTiebreakers[awardType] = tiedNominees
          }
        }
      }
    })

    setPotentialWinners(newPotentialWinners)
    setTiebreakers(newTiebreakers)

    toast({
      title: "Winners auto-selected",
      description:
        Object.keys(newTiebreakers).length > 0
          ? "Tiebreakers detected. Head judge decision required."
          : "Winners have been automatically selected based on scores and quotas.",
    })
  }

  // Handle manual winner selection
  const toggleWinnerSelection = (awardType: string, nominationId: string) => {
    setPotentialWinners((prev) => {
      const newPotentialWinners = { ...prev }
      const nominees = [...newPotentialWinners[awardType]]

      const nomineeIndex = nominees.findIndex((n) => n.id === nominationId)
      if (nomineeIndex >= 0) {
        nominees[nomineeIndex] = {
          ...nominees[nomineeIndex],
          isSelected: !nominees[nomineeIndex].isSelected,
        }
      }

      newPotentialWinners[awardType] = nominees
      return newPotentialWinners
    })
  }

  // Handle tiebreaker decision
  const handleTiebreakerDecision = (awardType: string, selectedIds: string[]) => {
    setTiebreakerDecisions((prev) => ({
      ...prev,
      [awardType]: selectedIds,
    }))

    // Update potential winners based on tiebreaker decision
    setPotentialWinners((prev) => {
      const newPotentialWinners = { ...prev }
      const nominees = [...newPotentialWinners[awardType]]

      // Reset selection for tied nominees
      nominees.forEach((nominee) => {
        if (nominee.tiebreaker) {
          nominee.isSelected = selectedIds.includes(nominee.id)
        }
      })

      newPotentialWinners[awardType] = nominees
      return newPotentialWinners
    })

    toast({
      title: "Tiebreaker resolved",
      description: "Your decision has been applied to the winner selection.",
    })
  }

  // Finalize winners
  const finalizeWinners = () => {
    // Collect all selected winners
    const winners: Nomination[] = []

    Object.keys(potentialWinners).forEach((awardType) => {
      const selectedWinners = potentialWinners[awardType]
        .filter((nominee) => nominee.isSelected)
        .map(({ averageScore, isSelected, tiebreaker, ...nomination }) => nomination)

      winners.push(...selectedWinners)
    })

    setFinalizedWinners(winners)
    setIsPublishing(true)

    // Simulate API call to save winners
    setTimeout(() => {
      setIsPublishing(false)
      setIsPublished(true)
      toast({
        title: "Winners published",
        description: "The winners have been published to the Reward Wall.",
      })
    }, 1500)
  }

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  // Format service line for display
  const formatServiceLine = (line: string | string[] | undefined | null): string => {
    // Handle undefined or null
    if (line === undefined || line === null) {
      return "Unknown"
    }

    // Handle array of service lines
    if (Array.isArray(line)) {
      if (line.length === 0) return "Unknown"

      return line
        .map((item) => {
          if (typeof item !== "string") return "Unknown"
          return item
            .split("-")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ")
        })
        .join(", ")
    }

    // Handle string (for backward compatibility)
    if (typeof line === "string") {
      return line
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
    }

    // Fallback
    return "Unknown"
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Event Not Found</AlertTitle>
        <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
      </Alert>
    )
  }

  if (!isFacilitator && !isHeadJudge) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Access Restricted</AlertTitle>
        <AlertDescription>
          Only facilitators and head judges can access the winner management interface.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Winner Management</CardTitle>
        <CardDescription>
          {isPresentationStage
            ? "Select winners for the award event based on scores and quotas"
            : "Review and manage the winners of the award event"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="quotas" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="quotas">Award Quotas</TabsTrigger>
            <TabsTrigger value="winners">Select Winners</TabsTrigger>
            <TabsTrigger value="publish">Publish Results</TabsTrigger>
          </TabsList>

          <TabsContent value="quotas" className="space-y-6">
            <AwardQuotas
              eventId={eventId}
              isFacilitator={isFacilitator}
              isReadOnly={isResultStage || isPublished}
              onQuotasUpdated={handleQuotasUpdated}
            />

            {isPresentationStage && !isPublished && (
              <div className="flex justify-end">
                <Button onClick={() => setActiveTab("winners")}>Continue to Winner Selection</Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="winners" className="space-y-6">
            <Alert variant="default" className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800/30">
              <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <AlertTitle>About Winner Selection</AlertTitle>
              <AlertDescription>
                Candidates with an average score of 8.0 or higher are eligible to be winners. You can auto-select
                winners based on scores and quotas, or manually select them.
              </AlertDescription>
            </Alert>

            <div className="flex justify-end mb-4">
              <Button
                onClick={autoSelectWinners}
                disabled={isResultStage || isPublished || Object.keys(potentialWinners).length === 0}
              >
                <Trophy className="mr-2 h-4 w-4" />
                Auto-Select Winners
              </Button>
            </div>

            {Object.keys(potentialWinners).length === 0 ? (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>No Qualified Candidates</AlertTitle>
                <AlertDescription>
                  There are no candidates with an average score of 8.0 or higher for any award type.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-8">
                {Object.entries(potentialWinners).map(([awardType, nominees]) => {
                  const quota = getQuotaForAwardType(eventId, awardType)
                  const selectedCount = nominees.filter((n) => n.isSelected).length
                  const hasTiebreaker = tiebreakers[awardType] && tiebreakers[awardType].length > 0

                  return (
                    <div key={awardType} className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold flex items-center">
                          <Medal className="h-5 w-5 text-amber-500 mr-2" />
                          {getAwardTypeDisplay(awardType)}
                        </h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">
                            Selected: {selectedCount} / {quota}
                          </span>
                          {selectedCount > quota && <Badge variant="destructive">Exceeds Quota</Badge>}
                          {hasTiebreaker && (
                            <Badge
                              variant="outline"
                              className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300"
                            >
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Tiebreaker Needed
                            </Badge>
                          )}
                        </div>
                      </div>

                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-[50px]">Select</TableHead>
                            <TableHead>Nominee</TableHead>
                            <TableHead>Service Line</TableHead>
                            <TableHead className="text-center">Score</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {nominees.map((nominee) => (
                            <TableRow
                              key={nominee.id}
                              className={cn(nominee.tiebreaker && "bg-amber-50 dark:bg-amber-900/10")}
                            >
                              <TableCell>
                                <input
                                  type="checkbox"
                                  checked={nominee.isSelected}
                                  onChange={() => toggleWinnerSelection(awardType, nominee.id)}
                                  disabled={isResultStage || isPublished || (nominee.tiebreaker && isHeadJudge)}
                                  className="h-4 w-4"
                                />
                              </TableCell>
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  <Avatar className="h-8 w-8">
                                    <AvatarImage
                                      src={nominee.nominee?.avatar || "/placeholder.svg?height=32&width=32"}
                                      alt={nominee.nominee?.name || "Unknown"}
                                    />
                                    <AvatarFallback>{nominee.nominee?.initials || "??"}</AvatarFallback>
                                  </Avatar>
                                  <span>{nominee.nominee?.name || "Unknown"}</span>
                                </div>
                              </TableCell>
                              <TableCell>{formatServiceLine(nominee.serviceLine || "")}</TableCell>
                              <TableCell className="text-center font-medium">
                                {nominee.averageScore.toFixed(2)}
                              </TableCell>
                              <TableCell>
                                {nominee.tiebreaker ? (
                                  <Badge
                                    variant="outline"
                                    className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300"
                                  >
                                    Tiebreaker
                                  </Badge>
                                ) : nominee.isSelected ? (
                                  <Badge
                                    variant="default"
                                    className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300"
                                  >
                                    <Check className="h-3 w-3 mr-1" />
                                    Selected
                                  </Badge>
                                ) : (
                                  <Badge variant="outline">Not Selected</Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>

                      {hasTiebreaker && isHeadJudge && !tiebreakerDecisions[awardType] && (
                        <TiebreakerDialog
                          awardType={awardType}
                          tiedNominees={tiebreakers[awardType]}
                          quota={quota}
                          onDecision={(selectedIds) => handleTiebreakerDecision(awardType, selectedIds)}
                        />
                      )}
                    </div>
                  )
                })}
              </div>
            )}

            {isPresentationStage && !isPublished && (
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setActiveTab("quotas")}>
                  Back to Quotas
                </Button>
                <Button onClick={() => setActiveTab("publish")}>Continue to Publishing</Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="publish" className="space-y-6">
            <Alert variant="default" className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800/30">
              <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <AlertTitle>About Publishing Results</AlertTitle>
              <AlertDescription>
                Review your winner selections before publishing. Once published, the winners will be visible on the
                Reward Wall when the event enters the result stage.
              </AlertDescription>
            </Alert>

            {Object.keys(potentialWinners).length === 0 ? (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>No Winners Selected</AlertTitle>
                <AlertDescription>
                  There are no winners selected for any award type. Please go back to the Winner Selection tab.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Selected Winners</h3>

                <div className="space-y-6">
                  {Object.entries(potentialWinners).map(([awardType, nominees]) => {
                    const selectedNominees = nominees.filter((n) => n.isSelected)
                    if (selectedNominees.length === 0) return null

                    return (
                      <div key={awardType} className="space-y-4">
                        <h4 className="text-md font-medium flex items-center">
                          <Medal className="h-4 w-4 text-amber-500 mr-2" />
                          {getAwardTypeDisplay(awardType)} ({selectedNominees.length})
                        </h4>

                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                          {selectedNominees.map((nominee) => (
                            <Card key={nominee.id} className="overflow-hidden">
                              <CardContent className="p-4">
                                <div className="flex items-start gap-4">
                                  <Avatar className="h-12 w-12">
                                    <AvatarImage
                                      src={nominee.nominee?.avatar || "/placeholder.svg?height=48&width=48"}
                                      alt={nominee.nominee?.name || "Unknown"}
                                    />
                                    <AvatarFallback>{nominee.nominee?.initials || "??"}</AvatarFallback>
                                  </Avatar>

                                  <div className="flex-1">
                                    <h5 className="font-medium">{nominee.nominee?.name || "Unknown"}</h5>
                                    <p className="text-sm text-muted-foreground">
                                      {formatServiceLine(nominee.serviceLine || "")}
                                    </p>
                                    <div className="flex items-center mt-2">
                                      <Star className="h-4 w-4 text-amber-500 mr-1" />
                                      <span className="text-sm font-medium">{nominee.averageScore.toFixed(2)}</span>
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )
                  })}
                </div>

                {!isPublished ? (
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setActiveTab("winners")}>
                      Back to Winner Selection
                    </Button>
                    <Button
                      onClick={finalizeWinners}
                      disabled={isPublishing}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {isPublishing ? (
                        <>Publishing...</>
                      ) : (
                        <>
                          <Trophy className="mr-2 h-4 w-4" />
                          Publish Winners
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <Alert className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800/30">
                    <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                    <AlertTitle>Winners Published</AlertTitle>
                    <AlertDescription>
                      The winners have been published and will be visible on the Reward Wall when the event enters the
                      result stage.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

interface TiebreakerDialogProps {
  awardType: string
  tiedNominees: PotentialWinner[]
  quota: number
  onDecision: (selectedIds: string[]) => void
}

function TiebreakerDialog({ awardType, tiedNominees, quota, onDecision }: TiebreakerDialogProps) {
  const [open, setOpen] = useState(false)
  const [selectedIds, setSelectedIds] = useState<string[]>([])

  // Calculate how many nominees we need to select from the tied group
  const alreadySelectedCount = tiedNominees.filter((n) => n.isSelected && !n.tiebreaker).length
  const remainingQuota = Math.max(0, quota - alreadySelectedCount)

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  const handleToggleNominee = (nomineeId: string) => {
    setSelectedIds((prev) => {
      if (prev.includes(nomineeId)) {
        return prev.filter((id) => id !== nomineeId)
      } else {
        if (prev.length >= remainingQuota) {
          return [...prev.slice(1), nomineeId]
        }
        return [...prev, nomineeId]
      }
    })
  }

  const handleSubmit = () => {
    onDecision(selectedIds)
    setOpen(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full">
          <HelpCircle className="mr-2 h-4 w-4" />
          Resolve Tiebreaker for {getAwardTypeDisplay(awardType)}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Tiebreaker Decision Required</DialogTitle>
          <DialogDescription>
            There are {tiedNominees.length} nominees with the same score competing for {remainingQuota} remaining
            spot(s). As the head judge, please select which nominee(s) should receive the award.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 my-4">
          {tiedNominees.map((nominee) => (
            <div key={nominee.id} className="flex items-center space-x-3 p-3 border rounded-md">
              <input
                type="checkbox"
                checked={selectedIds.includes(nominee.id)}
                onChange={() => handleToggleNominee(nominee.id)}
                className="h-4 w-4"
              />
              <Avatar className="h-10 w-10">
                <AvatarImage
                  src={nominee.nominee?.avatar || "/placeholder.svg?height=40&width=40"}
                  alt={nominee.nominee?.name || "Unknown"}
                />
                <AvatarFallback>{nominee.nominee?.initials || "??"}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="font-medium">{nominee.nominee?.name || "Unknown"}</p>
                <p className="text-sm text-muted-foreground">Score: {nominee.averageScore.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={selectedIds.length !== remainingQuota}>
            Confirm Selection
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

