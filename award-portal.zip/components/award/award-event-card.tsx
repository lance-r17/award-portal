"use client"

import type { AwardEvent } from "@/types/award-events"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CalendarDays, Clock, MapPin, FileText, Zap, Award } from "lucide-react"
import { format } from "date-fns"
import { getCurrentStageLabel, getStageTimeRemaining } from "@/data/award-events"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { getBackgroundImage } from "@/utils/image-utils"

interface AwardEventCardProps {
  event: AwardEvent
  currentUser?: {
    id: string
    name: string
    role?: string
  }
  onSelect?: (eventId: string) => void
}

export function AwardEventCard({
  event,
  currentUser = { id: "current-user", name: "Current User" },
  onSelect,
}: AwardEventCardProps) {
  const stageLabel = getCurrentStageLabel(event.currentStage)
  const timeRemaining = getStageTimeRemaining(event)

  const isCreatorOrFacilitator =
    event.createdBy?.id === currentUser.id || event.facilitators?.some((f) => f.id === currentUser.id)

  // Only show draft events to creators and facilitators
  if (event.status === "draft" && !isCreatorOrFacilitator) {
    return null
  }

  const handleClick = () => {
    if (onSelect) {
      onSelect(event.id)
    }
  }

  // Format date for display
  const formatStageDate = (date: Date) => {
    return format(date, "EEE, MMM d, yyyy • h:mm a")
  }

  return (
    <Card className="overflow-hidden border-none shadow-md hover:shadow-lg transition-shadow" onClick={handleClick}>
      {/* Image Section */}
      <div
        className="h-52 w-full relative"
        style={{
          backgroundImage: `url(${getBackgroundImage(event.theme)})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Status badges */}
        <div className="absolute top-3 right-3 flex gap-2">
          {event.status === "draft" && (
            <Badge variant="outline" className="bg-background/90 backdrop-blur-sm">
              <FileText className="mr-1 h-3 w-3" />
              Draft
            </Badge>
          )}

          {/* Facilitator avatars */}
          {event.facilitators && event.facilitators.length > 0 && (
            <div className="flex -space-x-2">
              {event.facilitators.slice(0, 3).map((facilitator) => (
                <Avatar key={facilitator.id} className="h-6 w-6 border-2 border-background">
                  <AvatarImage
                    src={`/placeholder.svg?height=24&width=24&text=${facilitator.name[0]}`}
                    alt={facilitator.name}
                  />
                  <AvatarFallback>{facilitator.name[0]}</AvatarFallback>
                </Avatar>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Content Section */}
      <div className="p-5">
        {/* Category Badge */}
        <Badge variant={event.type === "spot" ? "default" : "secondary"} className="mb-3">
          {event.type === "spot" ? (
            <>
              <Zap className="mr-1 h-3.5 w-3.5" /> Spot Award
            </>
          ) : (
            <>
              <Award className="mr-1 h-3.5 w-3.5" /> Recognition Award
            </>
          )}
        </Badge>

        {/* Title and Description */}
        <h3 className="text-xl font-bold mb-1">{event.title}</h3>
        <p className="text-muted-foreground text-sm mb-5 line-clamp-2">{event.description}</p>

        {/* Event Details */}
        <div className="space-y-3 mb-5">
          {/* Date/Time */}
          <div className="flex items-center gap-3">
            <CalendarDays className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm">{formatStageDate(event.stages[event.currentStage].endDate)}</p>
            </div>
          </div>

          {/* Location/Stage */}
          <div className="flex items-center gap-3">
            <MapPin className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm">
                {stageLabel} • {timeRemaining}
              </p>
            </div>
          </div>

          {/* Quarter */}
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm">{event.quarter}</p>
              {event.theme && <p className="text-xs text-muted-foreground">Theme: {event.theme}</p>}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button variant="outline" className="flex-1" onClick={() => onSelect?.(event.id)}>
            View Details
          </Button>

          <Button className="flex-1" variant={event.status === "draft" ? "secondary" : "default"}>
            {event.status === "draft" ? (
              <>Edit Draft</>
            ) : (
              <>
                {event.currentStage === "nomination" && "Submit Nomination"}
                {event.currentStage === "presentation" && "View Presentations"}
                {event.currentStage === "result" && "View Results"}
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  )
}

