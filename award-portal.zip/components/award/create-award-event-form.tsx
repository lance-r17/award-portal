"use client"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { format } from "date-fns"
import { CalendarIcon, FileText, Globe } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Info } from "lucide-react"

const formSchema = z
  .object({
    title: z.string().min(5, {
      message: "Title must be at least 5 characters.",
    }),
    type: z.enum(["spot", "recognition"], {
      required_error: "Please select an award type.",
    }),
    quarter: z.string().min(1, {
      message: "Please enter a quarter or period.",
    }),
    theme: z.string().optional(),
    description: z.string().min(10, {
      message: "Description must be at least 10 characters.",
    }),
    nominationStart: z.date({
      required_error: "Please select a nomination start date.",
    }),
    nominationEnd: z.date({
      required_error: "Please select a nomination end date.",
    }),
    presentationStart: z.date({
      required_error: "Please select a presentation start date.",
    }),
    presentationEnd: z.date({
      required_error: "Please select a presentation end date.",
    }),
    resultStart: z.date({
      required_error: "Please select a result start date.",
    }),
    resultEnd: z.date({
      required_error: "Please select a result end date.",
    }),
    status: z
      .enum(["draft", "published"], {
        required_error: "Please select a status.",
      })
      .default("draft"),
    publishImmediately: z.boolean().default(false),
  })
  .refine((data) => data.nominationEnd > data.nominationStart, {
    message: "Nomination end date must be after start date",
    path: ["nominationEnd"],
  })
  .refine((data) => data.presentationStart >= data.nominationEnd, {
    message: "Presentation start date must be after nomination end date",
    path: ["presentationStart"],
  })
  .refine((data) => data.presentationEnd > data.presentationStart, {
    message: "Presentation end date must be after start date",
    path: ["presentationEnd"],
  })
  .refine((data) => data.resultStart >= data.presentationEnd, {
    message: "Result start date must be after presentation end date",
    path: ["resultStart"],
  })
  .refine((data) => data.resultEnd > data.resultStart, {
    message: "Result end date must be after start date",
    path: ["resultEnd"],
  })

interface CreateAwardEventFormProps {
  onSuccess?: () => void
  existingEvent?: any // Replace with proper type when available
  isEditing?: boolean
  currentUser?: {
    id: string
    name: string
    role?: string
  }
}

export function CreateAwardEventForm({
  onSuccess,
  existingEvent,
  isEditing = false,
  currentUser = { id: "current-user", name: "Current User" },
}: CreateAwardEventFormProps) {
  const now = new Date()
  const isCreatorOrFacilitator = isEditing
    ? existingEvent?.createdBy?.id === currentUser.id ||
      existingEvent?.facilitators?.some((f: any) => f.id === currentUser.id)
    : true

  // Determine which stages can be edited based on status and current date
  const canEditNominationStage =
    !isEditing || existingEvent?.status === "draft" || existingEvent?.stages?.nomination?.startDate > now

  const canEditPresentationStage =
    !isEditing || existingEvent?.status === "draft" || existingEvent?.stages?.presentation?.startDate > now

  const canEditResultStage =
    !isEditing || existingEvent?.status === "draft" || existingEvent?.stages?.result?.startDate > now

  const defaultValues =
    isEditing && existingEvent
      ? {
          title: existingEvent.title,
          type: existingEvent.type,
          quarter: existingEvent.quarter,
          theme: existingEvent.theme || "",
          description: existingEvent.description,
          nominationStart: existingEvent.stages.nomination.startDate,
          nominationEnd: existingEvent.stages.nomination.endDate,
          presentationStart: existingEvent.stages.presentation.startDate,
          presentationEnd: existingEvent.stages.presentation.endDate,
          resultStart: existingEvent.stages.result.startDate,
          resultEnd: existingEvent.stages.result.endDate,
          status: existingEvent.status,
          publishImmediately: false,
        }
      : {
          title: "",
          description: "",
          quarter: "",
          theme: "",
          status: "draft" as const,
          publishImmediately: false,
        }

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues,
  })

  const watchStatus = form.watch("status")
  const watchPublishImmediately = form.watch("publishImmediately")

  function onSubmit(values: z.infer<typeof formSchema>) {
    // If publishImmediately is true, set status to published
    if (values.publishImmediately) {
      values.status = "published"
    }

    // In a real app, we would save the event to the database
    console.log(values)

    toast({
      title: isEditing ? "Award event updated" : "Award event created",
      description: isEditing
        ? `Your award event has been updated successfully${values.status === "published" ? " and published" : ""}.`
        : `Your award event has been created successfully${values.status === "published" ? " and published" : ""}.`,
    })

    form.reset()
    if (onSuccess) {
      onSuccess()
    }
  }

  if (!isCreatorOrFacilitator) {
    return (
      <Alert variant="destructive">
        <Info className="h-4 w-4" />
        <AlertTitle>Permission Denied</AlertTitle>
        <AlertDescription>
          You don't have permission to {isEditing ? "edit" : "create"} this award event.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Event Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Q1 2024 Spot Awards" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Award Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select award type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="spot">Spot Awards</SelectItem>
                      <SelectItem value="recognition">Recognition Awards</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="quarter"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quarter/Period</FormLabel>
                  <FormControl>
                    <Input placeholder="Q1 2024" {...field} />
                  </FormControl>
                  <FormDescription>
                    The quarter or period this award covers (e.g., Q1 2024, Annual 2023)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="theme"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Theme (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Innovation & Excellence" {...field} />
                  </FormControl>
                  <FormDescription>A theme for this award event</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Describe the purpose and focus of this award event..."
                    className="min-h-[80px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Stage Timeline</h3>
              {isEditing && (
                <div className="flex items-center gap-2">
                  <Badge variant={existingEvent?.status === "draft" ? "outline" : "default"}>
                    {existingEvent?.status === "draft" ? (
                      <>
                        <FileText className="mr-1 h-3 w-3" />
                        Draft
                      </>
                    ) : (
                      <>
                        <Globe className="mr-1 h-3 w-3" />
                        Published
                      </>
                    )}
                  </Badge>
                  {existingEvent?.status === "draft" && (
                    <FormField
                      control={form.control}
                      name="publishImmediately"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center gap-2 space-y-0">
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Publish on save</FormLabel>
                        </FormItem>
                      )}
                    />
                  )}
                </div>
              )}
            </div>

            {!isEditing && (
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <div className="mb-2">
                      <FormLabel>Event Status</FormLabel>
                      <FormDescription>
                        Draft events are only visible to you and facilitators. Published events are visible to all
                        users.
                      </FormDescription>
                    </div>
                    <div className="flex items-center space-x-4">
                      <FormControl>
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={field.value === "published"}
                            onCheckedChange={(checked) => {
                              field.onChange(checked ? "published" : "draft")
                            }}
                            id="event-status"
                          />
                          <label
                            htmlFor="event-status"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {field.value === "published" ? (
                              <span className="flex items-center">
                                <Globe className="mr-1 h-4 w-4" />
                                Published
                              </span>
                            ) : (
                              <span className="flex items-center">
                                <FileText className="mr-1 h-4 w-4" />
                                Draft
                              </span>
                            )}
                          </label>
                        </div>
                      </FormControl>
                      <Badge variant={field.value === "published" ? "default" : "outline"}>
                        {field.value === "published" ? "Visible to all" : "Limited visibility"}
                      </Badge>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <div className={cn("rounded-md border p-4", !canEditNominationStage && "opacity-70")}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">Nomination Stage</h4>
                {!canEditNominationStage && (
                  <Badge variant="outline" className="text-muted-foreground">
                    Cannot edit (stage in progress)
                  </Badge>
                )}
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="nominationStart"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground",
                                !canEditNominationStage && "opacity-50 cursor-not-allowed",
                              )}
                              disabled={!canEditNominationStage}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="nominationEnd"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground",
                                !canEditNominationStage && "opacity-50 cursor-not-allowed",
                              )}
                              disabled={!canEditNominationStage}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className={cn("rounded-md border p-4", !canEditPresentationStage && "opacity-70")}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">Presentation Stage</h4>
                {!canEditPresentationStage && (
                  <Badge variant="outline" className="text-muted-foreground">
                    Cannot edit (stage in progress)
                  </Badge>
                )}
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="presentationStart"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground",
                                !canEditPresentationStage && "opacity-50 cursor-not-allowed",
                              )}
                              disabled={!canEditPresentationStage}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="presentationEnd"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground",
                                !canEditPresentationStage && "opacity-50 cursor-not-allowed",
                              )}
                              disabled={!canEditPresentationStage}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className={cn("rounded-md border p-4", !canEditResultStage && "opacity-70")}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">Results Stage</h4>
                {!canEditResultStage && (
                  <Badge variant="outline" className="text-muted-foreground">
                    Cannot edit (stage in progress)
                  </Badge>
                )}
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="resultStart"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground",
                                !canEditResultStage && "opacity-50 cursor-not-allowed",
                              )}
                              disabled={!canEditResultStage}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="resultEnd"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground",
                                !canEditResultStage && "opacity-50 cursor-not-allowed",
                              )}
                              disabled={!canEditResultStage}
                            >
                              {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </div>

          <div className="border-t pt-4 mt-6">
            <p className="text-xs text-muted-foreground mb-4">
              {watchStatus === "published" || watchPublishImmediately
                ? "Once created, this award event will be visible to all employees."
                : "This award event will be saved as a draft and will only be visible to you and facilitators."}{" "}
              Make sure all dates are correct before submitting.
            </p>
            <Button type="submit" className="w-full">
              {isEditing ? "Update" : "Create"} Award Event
              {watchStatus === "published" || watchPublishImmediately ? " and Publish" : ""}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  )
}

