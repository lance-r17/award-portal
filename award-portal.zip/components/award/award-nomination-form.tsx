"use client"

import { useState, useEffect, useMemo, useRef } from "react"
import { Check, ChevronsUpDown, Plus, X } from "lucide-react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"

import { mockUsers, getDomainManagers, type User } from "@/data/mock-users"
import { serviceLines } from "@/data/service-lines"
import { spotIndividualAwardTypes, spotTeamAwardTypes, recognitionAwardTypes, allAwardTypes } from "@/data/award-types"
import type { Nomination } from "@/types/nominations"
import { BenefitAndOutcomeInput } from "@/components/award/benefit-and-outcome-input"

// Add a check at the beginning of the form submission to prevent anonymous users from submitting

// In the AwardNominationForm component, add this import:
import { useUser } from "@/contexts/user-context"

// Update the schema for both individual and team nominations
const benefitAndOutcomeSchema = z
  .object({
    tangibleMetrics: z.array(
      z.object({
        type: z.enum(["headcountSaving", "timeSaving", "costSaving", "customerSatisfaction"]),
        value: z
          .number({
            required_error: "Value is required",
            invalid_type_error: "Value must be a number",
          })
          .min(0, "Value must be greater than or equal to 0"),
        unit: z.string(),
      }),
    ),
    intangibleJustifications: z.array(
      z
        .object({
          type: z.enum(["internalAudit", "riskAvoidance", "regulatoryCompliance", "other"]),
          justification: z
            .string({
              required_error: "Justification is required",
            })
            .min(1, "Justification is required")
            .refine((val) => val.split(/\s+/).length <= 80, "Justification must not exceed 80 words"),
          otherType: z.string().optional(),
        })
        .superRefine((data, ctx) => {
          if (data.type === "other" && (!data.otherType || data.otherType.trim() === "")) {
            ctx.addIssue({
              code: z.ZodIssueCode.custom,
              message: "Please specify the other type",
              path: ["otherType"],
            })
          }
        }),
    ),
  })
  .refine(
    (data) => {
      // At least one metric or justification must be selected
      return data.tangibleMetrics.length > 0 || data.intangibleJustifications.length > 0
    },
    {
      message: "Please select at least one benefit or outcome",
      path: [], // Shows error at the root level
    },
  )

// Schema for individual nomination
const individualFormSchema = z.object({
  employee: z.string({
    required_error: "Please select an employee to nominate.",
  }),
  serviceLine: z.array(z.string()).min(1, {
    message: "At least one service line is required.",
  }),
  domainManagers: z.array(z.string()).min(1, {
    message: "Please select at least one domain manager to notify.",
  }),
  awardType: z.string({
    required_error: "Please select an award type.",
  }),
  nominationSummary: z
    .string()
    .min(100, {
      message: "Nomination summary must be at least 100 characters.",
    })
    .max(1500, {
      message: "Nomination summary must not exceed 1500 characters.",
    }),
  benefitAndOutcome: benefitAndOutcomeSchema,
  supportingInfo: z.string().optional(),
  notifyManager: z.boolean().default(true),
  notifyTeam: z.boolean().default(false),
  eventId: z.string(),
})

// Schema for team nomination
const teamFormSchema = z.object({
  teamName: z.string({
    required_error: "Please enter a team name.",
  }),
  presenter: z.string({
    required_error: "Please select a presenter for the team.",
  }),
  teamMembers: z.array(z.string()).min(1, {
    message: "Please select at least one team member.",
  }),
  serviceLine: z.array(z.string()).min(1, {
    message: "At least one service line is required.",
  }),
  domainManagers: z.array(z.string()).min(1, {
    message: "Please select at least one domain manager to notify.",
  }),
  awardType: z.string({
    required_error: "Please select an award type.",
  }),
  nominationSummary: z
    .string()
    .min(100, {
      message: "Nomination summary must be at least 100 characters.",
    })
    .max(1500, {
      message: "Nomination summary must not exceed 1500 characters.",
    }),
  benefitAndOutcome: benefitAndOutcomeSchema,
  supportingInfo: z.string().optional(),
  notifyManagers: z.boolean().default(true),
  eventId: z.string(),
})

// Define a type for the combined form schema
type CombinedFormSchema = z.infer<typeof individualFormSchema> & z.infer<typeof teamFormSchema>

interface AwardNominationFormProps {
  awardType: "spot" | "recognition"
  nominationType?: "individual" | "team"
  selectedAwardType?: string | null
  eventId?: string
  existingNomination?: Nomination | null
  isEditing?: boolean
  onSubmit: (values: CombinedFormSchema) => void
}

// Then add this inside the component function, near the top:
export function AwardNominationForm({
  awardType,
  nominationType = "individual",
  selectedAwardType = null,
  eventId = "",
  existingNomination = null,
  isEditing = false,
  onSubmit,
}: AwardNominationFormProps) {
  // Add this to check for anonymous users
  const { user } = useUser()
  const isAnonymous = user?.roles?.includes("anonymous")

  const [employeeOpen, setEmployeeOpen] = useState(false)
  const [presenterOpen, setPresenterOpen] = useState(false)
  const [awardTypeOpen, setAwardTypeOpen] = useState(false)
  const [teamMembersOpen, setTeamMembersOpen] = useState(false)
  const [selectedServiceLines, setSelectedServiceLines] = useState<string[]>([])
  const [availableDomainManagers, setAvailableDomainManagers] = useState<User[]>([])
  const [currentNominationType, setCurrentNominationType] = useState<"individual" | "team">(
    existingNomination ? existingNomination.nominationType : nominationType,
  )
  const [summaryCharCount, setSummaryCharCount] = useState(0)

  // Determine available award types based on current nomination type and award type
  const getAvailableAwardTypes = useMemo(() => {
    let awardTypes = allAwardTypes
    if (awardType === "spot") {
      awardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    } else if (awardType === "recognition") {
      awardTypes = recognitionAwardTypes
    }
    return awardTypes.map((type) => ({
      value: type.id,
      label: type.title,
    }))
  }, [awardType])

  // Use the appropriate schema based on nomination type
  const formSchema = currentNominationType === "individual" ? individualFormSchema : teamFormSchema

  // Prepare default values based on existing nomination if in edit mode
  const getDefaultValues = () => {
    if (isEditing && existingNomination) {
      if (existingNomination.nominationType === "individual") {
        return {
          employee: existingNomination.nominee?.id || "",
          serviceLine: Array.isArray(existingNomination.serviceLine)
            ? existingNomination.serviceLine
            : existingNomination.serviceLine
              ? [existingNomination.serviceLine]
              : [],
          domainManagers: existingNomination.domainManagers || [],
          awardType: existingNomination.awardType || "",
          nominationSummary:
            existingNomination.nominationSummary ||
            (existingNomination.justification && existingNomination.impact
              ? `${existingNomination.justification}\n\n${existingNomination.impact}`
              : ""),
          benefitAndOutcome: existingNomination.benefitAndOutcome || {
            tangibleMetrics: [],
            intangibleJustifications: [],
          },
          supportingInfo: existingNomination.supportingInfo || "",
          notifyManager: true,
          notifyTeam: false,
          eventId: eventId,
        }
      } else {
        let teamMembers: string[] = []
        if (existingNomination.team?.members) {
          if (Array.isArray(existingNomination.team.members)) {
            teamMembers = existingNomination.team.members
          } else if (typeof existingNomination.team.members === "string") {
            teamMembers = existingNomination.team.members.split(",").map((m) => m.trim())
          }
        }

        return {
          teamName: existingNomination.team?.name || "",
          presenter: existingNomination.presenter?.id || existingNomination.nominee?.id || "",
          teamMembers: teamMembers,
          serviceLine: Array.isArray(existingNomination.serviceLine)
            ? existingNomination.serviceLine
            : existingNomination.serviceLine
              ? [existingNomination.serviceLine]
              : [],
          domainManagers: existingNomination.domainManagers || [],
          awardType: existingNomination.awardType || "",
          nominationSummary:
            existingNomination.nominationSummary ||
            (existingNomination.justification && existingNomination.impact
              ? `${existingNomination.justification}\n\n${existingNomination.impact}`
              : ""),
          benefitAndOutcome: existingNomination.benefitAndOutcome || {
            tangibleMetrics: [],
            intangibleJustifications: [],
          },
          supportingInfo: existingNomination.supportingInfo || "",
          notifyManagers: true,
          eventId: eventId,
        }
      }
    } else {
      // Default values for new nomination
      return currentNominationType === "individual"
        ? {
            employee: "",
            serviceLine: [],
            domainManagers: [],
            awardType: "",
            nominationSummary: "",
            benefitAndOutcome: {
              tangibleMetrics: [],
              intangibleJustifications: [],
            },
            supportingInfo: "",
            notifyManager: true,
            notifyTeam: false,
            eventId: eventId,
          }
        : {
            teamName: "",
            presenter: "",
            teamMembers: [],
            serviceLine: [],
            domainManagers: [],
            awardType: "",
            nominationSummary: "",
            benefitAndOutcome: {
              tangibleMetrics: [],
              intangibleJustifications: [],
            },
            supportingInfo: "",
            notifyManagers: true,
            eventId: eventId,
          }
    }
  }

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: getDefaultValues(),
  })

  // Set the service lines when editing an existing nomination
  useEffect(() => {
    if (isEditing && existingNomination && existingNomination.serviceLine) {
      const serviceLineArray = Array.isArray(existingNomination.serviceLine)
        ? existingNomination.serviceLine
        : [existingNomination.serviceLine]
      setSelectedServiceLines(serviceLineArray)
    }
  }, [isEditing, existingNomination])

  // Update the award type when selectedAwardType changes
  useEffect(() => {
    if (selectedAwardType) {
      form.setValue("awardType", selectedAwardType)
    }
  }, [selectedAwardType, form])

  // Update event ID when it changes
  useEffect(() => {
    if (eventId) {
      form.setValue("eventId", eventId)
    }
  }, [eventId, form])

  // Update available domain managers when service line changes
  useEffect(() => {
    if (selectedServiceLines.length > 0) {
      // Assuming you want to use the first selected service line to determine domain managers
      setAvailableDomainManagers(getDomainManagers(selectedServiceLines[0]))
      // Only reset domain managers if not editing an existing nomination
      if (!isEditing) {
        form.setValue("domainManagers", [])
      }
    } else {
      setAvailableDomainManagers([])
    }
  }, [selectedServiceLines, form, isEditing])

  // Reset form when nomination type changes
  useEffect(() => {
    if (!isEditing) {
      form.reset(getDefaultValues())
    }
  }, [currentNominationType, isEditing])

  // Get domain manager names from their values
  const getDomainManagerNames = (managerValues: string[]) => {
    return managerValues.map((value) => {
      const manager = availableDomainManagers.find((m) => m.id === value)
      return manager ? manager.name : value
    })
  }

  // Handle award type change
  const handleAwardTypeChange = (value: string) => {
    form.setValue("awardType", value)
    setAwardTypeOpen(false)

    // Determine if this is a team award type
    if (!isEditing) {
      const isTeamAward =
        spotTeamAwardTypes.some((type) => type.id === value) ||
        (awardType === "recognition" && value === "team-excellence")

      setCurrentNominationType(isTeamAward ? "team" : "individual")
    }
  }

  // Watch for changes to employee and presenter fields
  const watchedEmployee = form.watch("employee")
  const watchedPresenter = form.watch("presenter")

  // Update service line when nominee changes
  useEffect(() => {
    if (currentNominationType === "individual" && watchedEmployee) {
      const selectedEmployee = mockUsers.find((user) => user.id === watchedEmployee)
      if (selectedEmployee?.serviceLine) {
        console.log("Setting service line from employee:", selectedEmployee.serviceLine)
        form.setValue("serviceLine", [selectedEmployee.serviceLine])
        setSelectedServiceLines([selectedEmployee.serviceLine])
      }
    }
  }, [watchedEmployee, form, currentNominationType])

  // Update service line when presenter changes (for team nominations)
  useEffect(() => {
    if (currentNominationType === "team" && watchedPresenter) {
      const selectedPresenter = mockUsers.find((user) => user.id === watchedPresenter)
      if (selectedPresenter?.serviceLine) {
        console.log("Setting service line from presenter:", selectedPresenter.serviceLine)
        form.setValue("serviceLine", [selectedPresenter.serviceLine])
        setSelectedServiceLines([selectedPresenter.serviceLine])
      }
    }
  }, [watchedPresenter, form, currentNominationType])

  // Watch for changes to team members
  const watchedTeamMembers = form.watch("teamMembers")

  // Add this ref before the useEffect
  const isInitialRender = useRef(true)

  // Add this cleanup effect
  useEffect(() => {
    isInitialRender.current = false
    return () => {
      isInitialRender.current = true
    }
  }, [])

  // Fix the useEffect that updates service lines
  useEffect(() => {
    // Only run this effect for team awards and skip the initial render
    if (currentNominationType === "team" && !isInitialRender.current) {
      try {
        const teamMembers = form.getValues("teamMembers") || []
        const presenter = form.getValues("presenter")

        // Get the presenter's service line
        const presenterUser = mockUsers.find((user) => user.id === presenter)
        const presenterServiceLine = presenterUser?.serviceLine || ""

        // Get all team members' service lines
        const teamMemberServiceLines = teamMembers
          .map((memberId) => {
            const member = mockUsers.find((user) => user.id === memberId)
            return member?.serviceLine || ""
          })
          .filter(Boolean)

        // Combine all service lines and remove duplicates
        const allServiceLines = [...new Set([presenterServiceLine, ...teamMemberServiceLines])].filter(Boolean)

        // Only update if the service lines have actually changed
        const currentServiceLines = form.getValues("serviceLine") || []
        const serviceLineChanged =
          JSON.stringify([...currentServiceLines].sort()) !== JSON.stringify([...allServiceLines].sort())

        if (serviceLineChanged) {
          console.log("Updating service lines:", allServiceLines)
          form.setValue("serviceLine", allServiceLines)
          setSelectedServiceLines(allServiceLines)
        }
      } catch (error) {
        console.error("Error updating service lines:", error)
      }
    }
  }, [form, currentNominationType, watchedTeamMembers, watchedPresenter])

  // Add this useEffect after the existing useEffect hooks
  useEffect(() => {
    if (isEditing && existingNomination) {
      console.log("Editing existing nomination:", existingNomination)
      console.log("Benefit and outcome data:", existingNomination.benefitAndOutcome)

      // If benefitAndOutcome exists in the nomination but is not being set in the form
      if (
        existingNomination.benefitAndOutcome &&
        (!form.getValues("benefitAndOutcome") || !form.getValues("benefitAndOutcome").tangibleMetrics?.length)
      ) {
        console.log("Setting benefit and outcome data manually")
        form.setValue("benefitAndOutcome", existingNomination.benefitAndOutcome)
      }
    }
  }, [isEditing, existingNomination, form])

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Nominate for {awardType === "spot" ? "Spot Award" : "Rewards & Recognition"}
          {isEditing ? ` (${currentNominationType === "team" ? "Team" : "Individual"})` : ""}
        </CardTitle>
        <CardDescription>
          Complete the form below to nominate {currentNominationType === "individual" ? "a colleague" : "a team"} for
          their outstanding contribution.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!eventId && (
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertTitle>No Active Event</AlertTitle>
            <AlertDescription>
              There is no active award event selected. Nominations can only be submitted during an active event's
              nomination period.
            </AlertDescription>
          </Alert>
        )}

        <Form {...form}>
          {/* Find the form element and update the onSubmit prop: */}
          <form
            onSubmit={(e) => {
              if (isAnonymous) {
                e.preventDefault()
                alert("Anonymous users cannot submit nominations. Please log in with a different role.")
                return
              }
              form.handleSubmit(onSubmit)(e)
            }}
            className="space-y-6"
          >
            {/* Award Type Selection - Only enabled for new nominations */}
            <FormField
              control={form.control}
              name="awardType"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Award Type</FormLabel>
                  {isEditing ? (
                    // Read-only display for editing
                    <div className="flex items-center gap-2">
                      <div className="rounded-md border px-3 py-2 text-sm text-muted-foreground">
                        {getAvailableAwardTypes.find((type) => type.value === field.value)?.label || field.value}
                      </div>
                      <Badge variant="outline">Cannot be changed</Badge>
                    </div>
                  ) : (
                    // Interactive dropdown for new nominations
                    <Popover open={awardTypeOpen} onOpenChange={setAwardTypeOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={awardTypeOpen}
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value
                              ? getAvailableAwardTypes.find((type) => type.value === field.value)?.label
                              : "Select award type"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search award type..." />
                          <CommandList>
                            <CommandEmpty>No award type found.</CommandEmpty>
                            <CommandGroup>
                              {getAvailableAwardTypes.map((type) => (
                                <CommandItem
                                  key={type.value}
                                  value={type.value}
                                  onSelect={(value) => {
                                    handleAwardTypeChange(value)
                                    setAwardTypeOpen(false)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      type.value === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {type.label}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  )}
                  <FormDescription>
                    {isEditing
                      ? "Award type cannot be changed when editing an existing nomination."
                      : "Select the type of award that best matches the achievement you want to recognize."}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {currentNominationType === "individual" ? (
              <FormField
                control={form.control}
                name="employee"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Nominee</FormLabel>
                    <Popover open={employeeOpen} onOpenChange={setEmployeeOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={employeeOpen}
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value ? mockUsers.find((user) => user.id === field.value)?.name : "Select employee"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search employee..." />
                          <CommandList>
                            <CommandEmpty>No employee found.</CommandEmpty>
                            <CommandGroup>
                              {mockUsers.map((user) => (
                                <CommandItem
                                  key={user.id}
                                  value={user.id}
                                  onSelect={(value) => {
                                    form.setValue("employee", value)
                                    setEmployeeOpen(false)

                                    // Immediately set service line
                                    const selectedEmployee = mockUsers.find((user) => user.id === value)
                                    if (selectedEmployee?.serviceLine) {
                                      form.setValue("serviceLine", [selectedEmployee.serviceLine])
                                      setSelectedServiceLines([selectedEmployee.serviceLine])
                                    }
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      user.id === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {user.name}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ) : (
              <>
                {/* Team Name Field */}
                <FormField
                  control={form.control}
                  name="teamName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter the team name" {...field} />
                      </FormControl>
                      <FormDescription>The name of the team you are nominating for this award.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Presenter Field */}
                <FormField
                  control={form.control}
                  name="presenter"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Presenter</FormLabel>
                      <Popover open={presenterOpen} onOpenChange={setPresenterOpen}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              aria-expanded={presenterOpen}
                              className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                            >
                              {field.value
                                ? mockUsers.find((user) => user.id === field.value)?.name
                                : "Select presenter"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0">
                          <Command>
                            <CommandInput placeholder="Search employee..." />
                            <CommandList>
                              <CommandEmpty>No employee found.</CommandEmpty>
                              <CommandGroup>
                                {mockUsers.map((user) => (
                                  <CommandItem
                                    key={user.id}
                                    value={user.id}
                                    onSelect={(value) => {
                                      form.setValue("presenter", value)
                                      setPresenterOpen(false)

                                      // Immediately set service line
                                      const selectedPresenter = mockUsers.find((user) => user.id === value)
                                      if (selectedPresenter?.serviceLine) {
                                        form.setValue("serviceLine", [selectedPresenter.serviceLine])
                                        setSelectedServiceLines([selectedPresenter.serviceLine])
                                      }
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        user.id === field.value ? "opacity-100" : "opacity-0",
                                      )}
                                    />
                                    {user.name}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        The person who will present this team nomination during the presentation stage.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Team Members Field */}
                <FormField
                  control={form.control}
                  name="teamMembers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Members</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <div className="rounded-md border border-input p-2 text-sm">
                            {(field.value ?? []).length > 0 ? (
                              <div className="flex flex-wrap gap-1 mb-2">
                                {(field.value ?? []).map((memberId) => {
                                  const member = mockUsers.find((user) => user.id === memberId)
                                  return (
                                    <Badge key={memberId} variant="secondary" className="mr-1 mb-1">
                                      {member?.name || memberId}
                                      <button
                                        type="button"
                                        className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
                                        onClick={() => {
                                          field.onChange((field.value ?? []).filter((m) => m !== memberId))
                                        }}
                                      >
                                        <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                                        <span className="sr-only">Remove {member?.name || memberId}</span>
                                      </button>
                                    </Badge>
                                  )
                                })}
                              </div>
                            ) : (
                              <div className="text-muted-foreground text-sm py-1">Select team members...</div>
                            )}
                            <Popover open={teamMembersOpen} onOpenChange={setTeamMembersOpen}>
                              <PopoverTrigger asChild>
                                <Button variant="outline" className="h-8 w-full justify-start text-xs mt-1">
                                  <Plus className="mr-2 h-3 w-3" />
                                  Add Team Member
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-full p-0">
                                <Command>
                                  <CommandInput placeholder="Search employees..." />
                                  <CommandList>
                                    <CommandEmpty>No employees found.</CommandEmpty>
                                    <CommandGroup>
                                      {mockUsers
                                        .filter((user) => !(field.value ?? []).includes(user.id))
                                        .map((user) => (
                                          <CommandItem
                                            key={user.id}
                                            value={user.id}
                                            onSelect={(value) => {
                                              field.onChange([...(field.value ?? []), value])
                                              setTeamMembersOpen(false)
                                            }}
                                          >
                                            {user.name}
                                          </CommandItem>
                                        ))}
                                    </CommandGroup>
                                  </CommandList>
                                </Command>
                              </PopoverContent>
                            </Popover>
                          </div>
                        </FormControl>
                      </div>
                      <FormDescription>Select all team members who contributed to this achievement.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}

            {/* Service Line Field - Always read-only */}
            <FormField
              control={form.control}
              name="serviceLine"
              render={({ field }) => {
                // Get the selected person (nominee or presenter)
                const selectedPerson =
                  currentNominationType === "individual"
                    ? form.getValues("employee")
                      ? mockUsers.find((user) => user.id === form.getValues("employee"))?.name
                      : null
                    : form.getValues("presenter")
                      ? mockUsers.find((user) => user.id === form.getValues("presenter"))?.name
                      : null

                return (
                  <FormItem>
                    <FormLabel>Service {field.value?.length > 1 ? "Lines" : "Line"}</FormLabel>
                    {/* Always show as read-only */}
                    <div className="flex flex-col gap-2">
                      {field.value && field.value.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {field.value.map((line, index) => (
                            <div key={index} className="rounded-md border px-3 py-2 text-sm">
                              {serviceLines.find((sl) => sl.value === line)?.label || line}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="rounded-md border px-3 py-2 text-sm text-muted-foreground">
                          No service line selected
                        </div>
                      )}
                      <Badge variant="outline">
                        {currentNominationType === "team"
                          ? "Auto-filled from presenter and team members"
                          : selectedPerson
                            ? `Auto-filled from ${currentNominationType === "individual" ? "nominee" : "presenter"}`
                            : "Will be set automatically"}
                      </Badge>
                    </div>
                    <FormDescription>
                      {currentNominationType === "team"
                        ? "Service lines are automatically collected from the presenter and all team members."
                        : selectedPerson
                          ? `The service line is automatically set based on the ${currentNominationType === "individual" ? "nominee's" : "presenter's"} profile.`
                          : `The service line will be automatically set when you select a ${currentNominationType === "individual" ? "nominee" : "presenter"}.`}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )
              }}
            />

            {/* Domain Managers Field */}
            {selectedServiceLines.length > 0 && availableDomainManagers.length > 0 && (
              <FormField
                control={form.control}
                name="domainManagers"
                render={({ field }) => (
                  <FormItem>
                    <div className="mb-4">
                      <FormLabel className="text-base">Domain Managers to Notify</FormLabel>
                      <FormDescription>
                        Select one or more domain managers to notify about this nomination.
                      </FormDescription>
                    </div>
                    <div className="space-y-4">
                      {availableDomainManagers.map((manager) => (
                        <FormItem key={manager.id} className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(manager.id)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), manager.id]
                                  : (field.value || []).filter((value) => value !== manager.id)
                                field.onChange(updatedValue)
                              }}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm font-medium">{manager.name}</FormLabel>
                            <FormDescription>{manager.email}</FormDescription>
                          </div>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="nominationSummary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nomination Summary</FormLabel>
                  <div className="text-sm text-muted-foreground mb-2">{field.value?.length || 0} / 1500 characters</div>
                  <FormControl>
                    <Textarea
                      placeholder={`* A brief of why this nominee is being nominated relevant to the award.\n* Highlight the key accomplishment (achievements or contributions)\n* Describe any presence of value (Group values, Technology priorities or CTO focus/OKRs) from accomplishment`}
                      className="min-h-[200px]"
                      {...field}
                      onChange={(e) => {
                        field.onChange(e)
                        setSummaryCharCount(e.target.value.length)
                      }}
                    />
                  </FormControl>
                  <FormDescription>
                    Be specific about what {currentNominationType === "individual" ? "they" : "the team"} did, how it
                    relates to the award criteria, and how their actions positively affected business results, team
                    morale, or customer satisfaction.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="benefitAndOutcome"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Benefit and Outcome</FormLabel>
                  <FormControl>
                    <BenefitAndOutcomeInput
                      value={field.value || { tangibleMetrics: [], intangibleJustifications: [] }}
                      onChange={field.onChange}
                      error={{
                        tangibleMetrics: form.formState.errors.benefitAndOutcome?.tangibleMetrics?.map(
                          (e) => e?.message,
                        ),
                        intangibleJustifications:
                          form.formState.errors.benefitAndOutcome?.intangibleJustifications?.map((e) => e?.message),
                      }}
                    />
                  </FormControl>
                  <FormDescription>
                    Provide tangible metrics and intangible justifications for the benefits and outcomes of this
                    nomination.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supportingInfo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Supporting Information (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Links to relevant documents, feedback, or other supporting information"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Include any links to documents, metrics, or feedback that support this nomination.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4">
              <h4 className="text-sm font-medium">Additional Notification Options</h4>
              <div className="space-y-2">
                {currentNominationType === "individual" ? (
                  <>
                    <FormField
                      control={form.control}
                      name="notifyManager"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Notify nominee's manager</FormLabel>
                            <FormDescription>
                              Send a notification to the nominee's manager about this award.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="notifyTeam"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Share with team</FormLabel>
                            <FormDescription>Share this nomination with the nominee's team members.</FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </>
                ) : (
                  <FormField
                    control={form.control}
                    name="notifyManagers"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Notify team managers</FormLabel>
                          <FormDescription>Send a notification to all team managers about this award.</FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                )}
              </div>
            </div>
            {/* Also update the submit button to be disabled for anonymous users: */}
            <Button type="submit" className="w-full" disabled={!eventId || isAnonymous}>
              {isEditing ? "Update Nomination" : "Submit Nomination"}
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col items-start border-t px-6 py-4">
        <p className="text-xs text-muted-foreground">
          Nominations are reviewed during the presentation stage. You will receive a notification when the results are
          announced.
        </p>
      </CardFooter>
    </Card>
  )
}

