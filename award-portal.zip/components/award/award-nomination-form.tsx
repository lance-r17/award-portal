"use client"

import { useState, useEffect, useMemo } from "react"
import { Check, ChevronsUpDown, Plus, X } from "lucide-react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"

import { mockUsers, getDomainManagers, type User } from "@/data/mock-users"
import { serviceLines } from "@/data/service-lines"
import { spotIndividualAwardTypes, spotTeamAwardTypes, recognitionAwardTypes, allAwardTypes } from "@/data/award-types"
import type { Nomination } from "@/types/nominations"

// Schema for individual nomination
const individualFormSchema = z.object({
  employee: z.string({
    required_error: "Please select an employee to nominate.",
  }),
  serviceLine: z.string({
    required_error: "Please select a service line.",
  }),
  domainManagers: z.array(z.string()).min(1, {
    message: "Please select at least one domain manager to notify.",
  }),
  awardType: z.string({
    required_error: "Please select an award type.",
  }),
  justification: z
    .string()
    .min(50, {
      message: "Justification must be at least 50 characters.",
    })
    .max(1000, {
      message: "Justification must not exceed 1000 characters.",
    }),
  impact: z
    .string()
    .min(50, {
      message: "Impact description must be at least 50 characters.",
    })
    .max(500, {
      message: "Impact description must not exceed 500 characters.",
    }),
  supportingInfo: z.string().optional(),
  notifyManager: z.boolean().default(true),
  notifyTeam: z.boolean().default(false),
  eventId: z.string(),
})

// Schema for team nomination
const teamFormSchema = z.object({
  teamName: z.string({
    required_error: "Please enter a team name.",
  }),
  presenter: z.string({
    required_error: "Please select a presenter for the team.",
  }),
  teamMembers: z.array(z.string()).min(1, {
    message: "Please select at least one team member.",
  }),
  serviceLine: z.string({
    required_error: "Please select a service line.",
  }),
  domainManagers: z.array(z.string()).min(1, {
    message: "Please select at least one domain manager to notify.",
  }),
  awardType: z.string({
    required_error: "Please select an award type.",
  }),
  justification: z
    .string()
    .min(50, {
      message: "Justification must be at least 50 characters.",
    })
    .max(1000, {
      message: "Justification must not exceed 1000 characters.",
    }),
  impact: z
    .string()
    .min(50, {
      message: "Impact description must be at least 50 characters.",
    })
    .max(500, {
      message: "Impact description must not exceed 500 characters.",
    }),
  supportingInfo: z.string().optional(),
  notifyManagers: z.boolean().default(true),
  eventId: z.string(),
})

// Define a type for the combined form schema
type CombinedFormSchema = z.infer<typeof individualFormSchema> & z.infer<typeof teamFormSchema>

interface AwardNominationFormProps {
  awardType: "spot" | "recognition"
  nominationType?: "individual" | "team"
  selectedAwardType?: string | null
  eventId?: string
  existingNomination?: Nomination | null
  isEditing?: boolean
  onSubmit: (values: CombinedFormSchema) => void
}

export function AwardNominationForm({
  awardType,
  nominationType = "individual",
  selectedAwardType = null,
  eventId = "",
  existingNomination = null,
  isEditing = false,
  onSubmit,
}: AwardNominationFormProps) {
  const [employeeOpen, setEmployeeOpen] = useState(false)
  const [presenterOpen, setPresenterOpen] = useState(false)
  const [awardTypeOpen, setAwardTypeOpen] = useState(false)
  const [teamMembersOpen, setTeamMembersOpen] = useState(false)
  const [selectedServiceLine, setSelectedServiceLine] = useState<string | null>(null)
  const [availableDomainManagers, setAvailableDomainManagers] = useState<User[]>([])
  const [currentNominationType, setCurrentNominationType] = useState<"individual" | "team">(
    existingNomination ? existingNomination.nominationType : nominationType,
  )

  // Determine available award types based on current nomination type and award type
  const getAvailableAwardTypes = useMemo(() => {
    let awardTypes = allAwardTypes
    if (awardType === "spot") {
      awardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    } else if (awardType === "recognition") {
      awardTypes = recognitionAwardTypes
    }
    return awardTypes.map((type) => ({
      value: type.id,
      label: type.title,
    }))
  }, [awardType])

  // Use the appropriate schema based on nomination type
  const formSchema = currentNominationType === "individual" ? individualFormSchema : teamFormSchema

  // Prepare default values based on existing nomination if in edit mode
  const getDefaultValues = () => {
    if (isEditing && existingNomination) {
      if (existingNomination.nominationType === "individual") {
        return {
          employee: existingNomination.nominee?.id || "",
          serviceLine: existingNomination.serviceLine || "",
          domainManagers: existingNomination.domainManagers || [],
          awardType: existingNomination.awardType || "",
          justification: existingNomination.justification || "",
          impact: existingNomination.impact || "",
          supportingInfo: existingNomination.supportingInfo || "",
          notifyManager: true,
          notifyTeam: false,
          eventId: eventId,
        }
      } else {
        let teamMembers: string[] = []
        if (existingNomination.team?.members) {
          if (Array.isArray(existingNomination.team.members)) {
            teamMembers = existingNomination.team.members
          } else if (typeof existingNomination.team.members === "string") {
            teamMembers = existingNomination.team.members.split(",").map((m) => m.trim())
          }
        }

        return {
          teamName: existingNomination.team?.name || "",
          presenter: existingNomination.presenter?.id || existingNomination.nominee?.id || "",
          teamMembers: teamMembers,
          serviceLine: existingNomination.serviceLine || "",
          domainManagers: existingNomination.domainManagers || [],
          awardType: existingNomination.awardType || "",
          justification: existingNomination.justification || "",
          impact: existingNomination.impact || "",
          supportingInfo: existingNomination.supportingInfo || "",
          notifyManagers: true,
          eventId: eventId,
        }
      }
    } else {
      // Default values for new nomination
      return currentNominationType === "individual"
        ? {
            employee: "",
            serviceLine: "",
            domainManagers: [],
            awardType: "",
            justification: "",
            impact: "",
            supportingInfo: "",
            notifyManager: true,
            notifyTeam: false,
            eventId: eventId,
          }
        : {
            teamName: "",
            presenter: "",
            teamMembers: [],
            serviceLine: "",
            domainManagers: [],
            awardType: "",
            justification: "",
            impact: "",
            supportingInfo: "",
            notifyManagers: true,
            eventId: eventId,
          }
    }
  }

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: getDefaultValues(),
  })

  // Set the service line when editing an existing nomination
  useEffect(() => {
    if (isEditing && existingNomination && existingNomination.serviceLine) {
      const serviceLine = serviceLines.find((line) => line.value === existingNomination.serviceLine)
      setSelectedServiceLine(serviceLine?.value || null)
    }
  }, [isEditing, existingNomination])

  // Update the award type when selectedAwardType changes
  useEffect(() => {
    if (selectedAwardType) {
      form.setValue("awardType", selectedAwardType)
    }
  }, [selectedAwardType, form])

  // Update event ID when it changes
  useEffect(() => {
    if (eventId) {
      form.setValue("eventId", eventId)
    }
  }, [eventId, form])

  // Update available domain managers when service line changes
  useEffect(() => {
    if (selectedServiceLine) {
      setAvailableDomainManagers(getDomainManagers(selectedServiceLine))
      // Only reset domain managers if not editing an existing nomination
      if (!isEditing) {
        form.setValue("domainManagers", [])
      }
    } else {
      setAvailableDomainManagers([])
    }
  }, [selectedServiceLine, form, isEditing])

  // Reset form when nomination type changes
  useEffect(() => {
    if (!isEditing) {
      form.reset(getDefaultValues())
    }
  }, [currentNominationType, isEditing])

  // Get domain manager names from their values
  const getDomainManagerNames = (managerValues: string[]) => {
    return managerValues.map((value) => {
      const manager = availableDomainManagers.find((m) => m.id === value)
      return manager ? manager.name : value
    })
  }

  // Handle award type change
  const handleAwardTypeChange = (value: string) => {
    form.setValue("awardType", value)
    setAwardTypeOpen(false)

    // Determine if this is a team award type
    if (!isEditing) {
      const isTeamAward =
        spotTeamAwardTypes.some((type) => type.id === value) ||
        (awardType === "recognition" && value === "team-excellence")

      setCurrentNominationType(isTeamAward ? "team" : "individual")
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Nominate for {awardType === "spot" ? "Spot Award" : "Rewards & Recognition"}
          {isEditing ? ` (${currentNominationType === "team" ? "Team" : "Individual"})` : ""}
        </CardTitle>
        <CardDescription>
          Complete the form below to nominate {currentNominationType === "individual" ? "a colleague" : "a team"} for
          their outstanding contribution.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!eventId && (
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertTitle>No Active Event</AlertTitle>
            <AlertDescription>
              There is no active award event selected. Nominations can only be submitted during an active event's
              nomination period.
            </AlertDescription>
          </Alert>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Award Type Selection - Only enabled for new nominations */}
            <FormField
              control={form.control}
              name="awardType"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Award Type</FormLabel>
                  {isEditing ? (
                    // Read-only display for editing
                    <div className="flex items-center gap-2">
                      <div className="rounded-md border px-3 py-2 text-sm text-muted-foreground">
                        {getAvailableAwardTypes.find((type) => type.value === field.value)?.label || field.value}
                      </div>
                      <Badge variant="outline">Cannot be changed</Badge>
                    </div>
                  ) : (
                    // Interactive dropdown for new nominations
                    <Popover open={awardTypeOpen} onOpenChange={setAwardTypeOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={awardTypeOpen}
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value
                              ? getAvailableAwardTypes.find((type) => type.value === field.value)?.label
                              : "Select award type"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search award type..." />
                          <CommandList>
                            <CommandEmpty>No award type found.</CommandEmpty>
                            <CommandGroup>
                              {getAvailableAwardTypes.map((type) => (
                                <CommandItem
                                  key={type.value}
                                  value={type.value}
                                  onSelect={(value) => {
                                    handleAwardTypeChange(value)
                                    setAwardTypeOpen(false)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      type.value === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {type.label}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  )}
                  <FormDescription>
                    {isEditing
                      ? "Award type cannot be changed when editing an existing nomination."
                      : "Select the type of award that best matches the achievement you want to recognize."}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {currentNominationType === "individual" ? (
              <FormField
                control={form.control}
                name="employee"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Nominee</FormLabel>
                    <Popover open={employeeOpen} onOpenChange={setEmployeeOpen}>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={employeeOpen}
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value ? mockUsers.find((user) => user.id === field.value)?.name : "Select employee"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search employee..." />
                          <CommandList>
                            <CommandEmpty>No employee found.</CommandEmpty>
                            <CommandGroup>
                              {mockUsers.map((user) => (
                                <CommandItem
                                  key={user.id}
                                  value={user.id}
                                  onSelect={(value) => {
                                    form.setValue("employee", value)
                                    setEmployeeOpen(false)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      user.id === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {user.name}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ) : (
              <>
                {/* Team Name Field */}
                <FormField
                  control={form.control}
                  name="teamName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter the team name" {...field} />
                      </FormControl>
                      <FormDescription>The name of the team you are nominating for this award.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Presenter Field */}
                <FormField
                  control={form.control}
                  name="presenter"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Presenter</FormLabel>
                      <Popover open={presenterOpen} onOpenChange={setPresenterOpen}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              aria-expanded={presenterOpen}
                              className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                            >
                              {field.value
                                ? mockUsers.find((user) => user.id === field.value)?.name
                                : "Select presenter"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0">
                          <Command>
                            <CommandInput placeholder="Search employee..." />
                            <CommandList>
                              <CommandEmpty>No employee found.</CommandEmpty>
                              <CommandGroup>
                                {mockUsers.map((user) => (
                                  <CommandItem
                                    key={user.id}
                                    value={user.id}
                                    onSelect={(value) => {
                                      form.setValue("presenter", value)
                                      setPresenterOpen(false)
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        user.id === field.value ? "opacity-100" : "opacity-0",
                                      )}
                                    />
                                    {user.name}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        The person who will present this team nomination during the presentation stage.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Team Members Field */}
                <FormField
                  control={form.control}
                  name="teamMembers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Members</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <div className="rounded-md border border-input p-2 text-sm">
                            {(field.value ?? []).length > 0 ? (
                              <div className="flex flex-wrap gap-1 mb-2">
                                {(field.value ?? []).map((memberId) => {
                                  const member = mockUsers.find((user) => user.id === memberId)
                                  return (
                                    <Badge key={memberId} variant="secondary" className="mr-1 mb-1">
                                      {member?.name || memberId}
                                      <button
                                        type="button"
                                        className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
                                        onClick={() => {
                                          field.onChange((field.value ?? []).filter((m) => m !== memberId))
                                        }}
                                      >
                                        <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                                        <span className="sr-only">Remove {member?.name || memberId}</span>
                                      </button>
                                    </Badge>
                                  )
                                })}
                              </div>
                            ) : (
                              <div className="text-muted-foreground text-sm py-1">Select team members...</div>
                            )}
                            <Popover open={teamMembersOpen} onOpenChange={setTeamMembersOpen}>
                              <PopoverTrigger asChild>
                                <Button variant="outline" className="h-8 w-full justify-start text-xs mt-1">
                                  <Plus className="mr-2 h-3 w-3" />
                                  Add Team Member
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-full p-0">
                                <Command>
                                  <CommandInput placeholder="Search employees..." />
                                  <CommandList>
                                    <CommandEmpty>No employees found.</CommandEmpty>
                                    <CommandGroup>
                                      {mockUsers
                                        .filter((user) => !(field.value ?? []).includes(user.id))
                                        .map((user) => (
                                          <CommandItem
                                            key={user.id}
                                            value={user.id}
                                            onSelect={(value) => {
                                              field.onChange([...(field.value ?? []), value])
                                              setTeamMembersOpen(false)
                                            }}
                                          >
                                            {user.name}
                                          </CommandItem>
                                        ))}
                                    </CommandGroup>
                                  </CommandList>
                                </Command>
                              </PopoverContent>
                            </Popover>
                          </div>
                        </FormControl>
                      </div>
                      <FormDescription>Select all team members who contributed to this achievement.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}

            {/* Service Line Field */}
            <FormField
              control={form.control}
              name="serviceLine"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Line</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      const selectedLine = serviceLines.find((line) => line.value === value)
                      field.onChange(value)
                      setSelectedServiceLine(selectedLine?.value || null)
                    }}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select service line" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {serviceLines.map((serviceLine) => (
                        <SelectItem key={serviceLine.value} value={serviceLine.value}>
                          {serviceLine.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The service line {currentNominationType === "individual" ? "the nominee" : "this team"} belongs to.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Domain Managers Field */}
            {selectedServiceLine && availableDomainManagers.length > 0 && (
              <FormField
                control={form.control}
                name="domainManagers"
                render={({ field }) => (
                  <FormItem>
                    <div className="mb-4">
                      <FormLabel className="text-base">Domain Managers to Notify</FormLabel>
                      <FormDescription>
                        Select one or more domain managers to notify about this nomination.
                      </FormDescription>
                    </div>
                    <div className="space-y-4">
                      {availableDomainManagers.map((manager) => (
                        <FormItem key={manager.id} className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(manager.id)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), manager.id]
                                  : (field.value || []).filter((value) => value !== manager.id)
                                field.onChange(updatedValue)
                              }}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm font-medium">{manager.name}</FormLabel>
                            <FormDescription>{manager.email}</FormDescription>
                          </div>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="justification"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Justification</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={`Describe why ${currentNominationType === "individual" ? "this person" : "this team"} deserves the award. Include specific examples of their work or behavior.`}
                      className="min-h-[120px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Be specific about what {currentNominationType === "individual" ? "they" : "the team"} did and how it
                    relates to the award criteria.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="impact"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Impact</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={`Describe the impact of ${currentNominationType === "individual" ? "their" : "the team's"} contribution on the team, department, or company.`}
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Explain how {currentNominationType === "individual" ? "their" : "the team's"} actions positively
                    affected business results, team morale, or customer satisfaction.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supportingInfo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Supporting Information (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Links to relevant documents, feedback, or other supporting information"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Include any links to documents, metrics, or feedback that support this nomination.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4">
              <h4 className="text-sm font-medium">Additional Notification Options</h4>
              <div className="space-y-2">
                {currentNominationType === "individual" ? (
                  <>
                    <FormField
                      control={form.control}
                      name="notifyManager"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Notify nominee's manager</FormLabel>
                            <FormDescription>
                              Send a notification to the nominee's manager about this award.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="notifyTeam"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Share with team</FormLabel>
                            <FormDescription>Share this nomination with the nominee's team members.</FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </>
                ) : (
                  <FormField
                    control={form.control}
                    name="notifyManagers"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Notify team managers</FormLabel>
                          <FormDescription>Send a notification to all team managers about this award.</FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                )}
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={!eventId}>
              {isEditing ? "Update Nomination" : "Submit Nomination"}
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col items-start border-t px-6 py-4">
        <p className="text-xs text-muted-foreground">
          Nominations are reviewed during the presentation stage. You will receive a notification when the results are
          announced.
        </p>
      </CardFooter>
    </Card>
  )
}

