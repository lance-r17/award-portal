"use client"

import { useState, useEffect } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import type { BenefitAndOutcome, TangibleMetric, IntangibleJustification } from "@/types/nominations"

interface BenefitAndOutcomeInputProps {
  value: BenefitAndOutcome
  onChange: (value: BenefitAndOutcome) => void
  error?: {
    tangibleMetrics?: string[]
    intangibleJustifications?: string[]
  }
}

// Update tangibleOptions array to remove customerSatisfaction
const tangibleOptions = [
  { value: "headcountSaving", label: "Headcount Saving", unit: "FTE" },
  { value: "timeSaving", label: "Time Saving", unit: "hours/year" },
  { value: "costSaving", label: "Cost Saving", unit: "USD" },
]

// Add customerSatisfaction to intangibleOptions
const intangibleOptions = [
  { value: "customerSatisfaction", label: "Customer Satisfaction" },
  { value: "internalAudit", label: "Internal audit and compliance adherence" },
  { value: "riskAvoidance", label: "Risk avoidance & mitigation" },
  { value: "regulatoryCompliance", label: "Regulatory compliances" },
  { value: "other", label: "Others" },
]

export function BenefitAndOutcomeInput({ value, onChange, error }: BenefitAndOutcomeInputProps) {
  // Initialize state with default empty arrays if value is undefined
  const [tangibleMetrics, setTangibleMetrics] = useState<TangibleMetric[]>([])
  const [intangibleJustifications, setIntangibleJustifications] = useState<IntangibleJustification[]>([])

  // Debug log for initial value
  useEffect(() => {
    console.log("Initial value received:", value)
  }, [])

  // Effect to initialize and update state when value changes
  useEffect(() => {
    console.log("Value changed:", value)

    // Ensure value exists and has the expected structure
    if (value) {
      // Handle tangible metrics
      if (Array.isArray(value.tangibleMetrics)) {
        console.log("Setting tangible metrics:", value.tangibleMetrics)
        setTangibleMetrics(value.tangibleMetrics)
      }

      // Handle intangible justifications
      if (Array.isArray(value.intangibleJustifications)) {
        console.log("Setting intangible justifications:", value.intangibleJustifications)
        setIntangibleJustifications(value.intangibleJustifications)
      }
    }
  }, [value])

  // Debug log for state updates
  useEffect(() => {
    console.log("Current state - tangibleMetrics:", tangibleMetrics)
    console.log("Current state - intangibleJustifications:", intangibleJustifications)
  }, [tangibleMetrics, intangibleJustifications])

  const handleTangibleChange = (type: TangibleMetric["type"], newValue?: number) => {
    console.log("Handling tangible change:", { type, newValue })

    const existingMetricIndex = tangibleMetrics.findIndex((metric) => metric.type === type)
    let updatedMetrics = [...tangibleMetrics]

    if (existingMetricIndex >= 0) {
      if (newValue !== undefined) {
        // Update existing metric
        updatedMetrics[existingMetricIndex] = {
          ...updatedMetrics[existingMetricIndex],
          value: newValue,
        }
      } else {
        // Remove metric if no value
        updatedMetrics = updatedMetrics.filter((_, index) => index !== existingMetricIndex)
      }
    } else if (newValue !== undefined) {
      // Add new metric
      const newMetric = {
        type,
        value: newValue,
        unit: tangibleOptions.find((option) => option.value === type)?.unit || "",
      }
      updatedMetrics.push(newMetric)
    }

    console.log("Updated tangible metrics:", updatedMetrics)
    setTangibleMetrics(updatedMetrics)
    onChange({ ...value, tangibleMetrics: updatedMetrics })
  }

  // Update the handleIntangibleChange function to remove value and unit
  const handleIntangibleChange = (
    type: IntangibleJustification["type"],
    justification?: string,
    otherType?: string,
  ) => {
    console.log("Handling intangible change:", { type, justification, otherType })

    const existingIndex = intangibleJustifications.findIndex((item) => item.type === type)
    let updatedJustifications = [...intangibleJustifications]

    if (existingIndex >= 0) {
      if (justification !== undefined) {
        // Update existing justification
        updatedJustifications[existingIndex] = {
          ...updatedJustifications[existingIndex],
          justification,
          ...(type === "other" && { otherType }),
        }
      } else {
        // Remove justification
        updatedJustifications = updatedJustifications.filter((_, index) => index !== existingIndex)
      }
    } else if (justification !== undefined) {
      // Add new justification
      updatedJustifications.push({
        type,
        justification,
        ...(type === "other" && { otherType }),
      })
    }

    console.log("Updated intangible justifications:", updatedJustifications)
    setIntangibleJustifications(updatedJustifications)
    onChange({ ...value, intangibleJustifications: updatedJustifications })
  }

  const getMetricError = (type: string) => {
    const index = tangibleMetrics.findIndex((metric) => metric.type === type)
    return error?.tangibleMetrics?.[index]
  }

  const getJustificationError = (type: string) => {
    const index = intangibleJustifications.findIndex((item) => item.type === type)
    return error?.intangibleJustifications?.[index]
  }

  // Helper function to get metric value
  const getMetricValue = (type: string): number | undefined => {
    const metric = tangibleMetrics.find((m) => m.type === type)
    return metric?.value
  }

  // Helper function to get justification value
  const getJustificationValue = (type: string): string => {
    const justification = intangibleJustifications.find((j) => j.type === type)
    return justification?.justification || ""
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Tangible Metrics</h3>
        <p className="text-sm text-muted-foreground mb-4">Select applicable metrics and provide values:</p>
        {tangibleOptions.map((option) => {
          const isChecked = tangibleMetrics.some((metric) => metric.type === option.value)
          const metricValue = getMetricValue(option.value)
          const error = getMetricError(option.value)

          return (
            <div key={option.value} className="flex items-start space-x-2 mb-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={`tangible-${option.value}`}
                  checked={isChecked}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      handleTangibleChange(option.value as TangibleMetric["type"], 0)
                    } else {
                      handleTangibleChange(option.value as TangibleMetric["type"])
                    }
                  }}
                />
                <Label htmlFor={`tangible-${option.value}`}>{option.label}</Label>
              </div>
              {isChecked && (
                <div className="flex-1 max-w-[200px]">
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      placeholder={`Enter ${option.label}`}
                      value={metricValue ?? ""}
                      onChange={(e) =>
                        handleTangibleChange(option.value as TangibleMetric["type"], Number(e.target.value))
                      }
                      className={error ? "border-red-500" : ""}
                    />
                    <span className="text-sm text-muted-foreground whitespace-nowrap">{option.unit}</span>
                  </div>
                  {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
                </div>
              )}
            </div>
          )
        })}
      </div>

      <div>
        <h3 className="text-lg font-medium">Intangible Justifications</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Select applicable areas and provide justifications (max 80 words each):
        </p>
        {intangibleOptions.map((option) => {
          const isChecked = intangibleJustifications.some((item) => item.type === option.value)
          const justificationValue = getJustificationValue(option.value)
          const currentJustification = intangibleJustifications.find((item) => item.type === option.value)
          const error = getJustificationError(option.value)

          return (
            <div key={option.value} className="mb-6">
              <div className="flex items-center space-x-2 mb-2">
                <Checkbox
                  id={`intangible-${option.value}`}
                  checked={isChecked}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      handleIntangibleChange(option.value as IntangibleJustification["type"], "")
                    } else {
                      handleIntangibleChange(option.value as IntangibleJustification["type"])
                    }
                  }}
                />
                <Label htmlFor={`intangible-${option.value}`}>{option.label}</Label>
              </div>
              {isChecked && (
                <div className="mt-2 space-y-2">
                  {option.value === "other" && (
                    <div>
                      <Input
                        placeholder="Specify other type"
                        value={currentJustification?.otherType || ""}
                        onChange={(e) => handleIntangibleChange("other", justificationValue, e.target.value)}
                        className={error ? "border-red-500" : ""}
                      />
                      {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
                    </div>
                  )}
                  {/* Removed customerSatisfaction value and unit input */}
                  <div>
                    <Textarea
                      placeholder={`Enter justification for ${option.label}`}
                      value={justificationValue}
                      onChange={(e) =>
                        handleIntangibleChange(
                          option.value as IntangibleJustification["type"],
                          e.target.value,
                          currentJustification?.otherType,
                        )
                      }
                      className={`h-24 ${error ? "border-red-500" : ""}`}
                    />
                    <div className="flex justify-between mt-1">
                      <p className="text-sm text-muted-foreground">
                        {justificationValue.split(/\s+/).length || 0}
                        /80 words
                      </p>
                      {error && <p className="text-sm text-red-500">{error}</p>}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
