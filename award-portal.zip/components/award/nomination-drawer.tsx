"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import { Separator } from "@/components/ui/separator"
import type { Nomination } from "@/types/nominations"
import { CalendarDays, ExternalLink, Users, Edit, X, Clock, CheckCircle, XCircle, ImageIcon } from "lucide-react"
import { getAwardTypeDisplay } from "@/data/award-types"

interface NominationDrawerProps {
  nomination: Nomination | null
  open: boolean
  onOpenChange: (open: boolean) => void
  canEdit: boolean
  onEdit?: () => void
  currentUserId: string
}

export function NominationDrawer({
  nomination,
  open,
  onOpenChange,
  canEdit,
  onEdit,
  currentUserId,
}: NominationDrawerProps) {
  if (!nomination) return null

  // Ensure the service line formatting has proper error handling
  const formatServiceLine = (serviceLine: string | string[] | undefined): string => {
    try {
      if (!serviceLine) return ""

      if (Array.isArray(serviceLine)) {
        if (serviceLine.length === 0) return ""

        return serviceLine
          .map((line) => (typeof line === "string" ? line.replace(/-/g, " ") : ""))
          .filter(Boolean)
          .join(", ")
      }

      return typeof serviceLine === "string" ? serviceLine.replace(/-/g, " ") : ""
    } catch (error) {
      console.error("Error formatting service line:", error)
      return ""
    }
  }

  // Get presenter information if available
  const presenter = nomination.presenter || (nomination.nominationType === "team" ? nomination.nominee : null)

  // Check if the current user is the nominee or nominator
  const isNomineeOrNominator = currentUserId === nomination.nominee.id || currentUserId === nomination.nominator.id

  // Check if nomination has images
  const hasImages = nomination.images && nomination.images.length > 0

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh]">
        <div className="mx-auto w-full max-w-3xl">
          <DrawerHeader className="flex justify-between items-start">
            <div>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="px-3 py-1 text-base">
                  {getAwardTypeDisplay(nomination.awardType)}
                </Badge>
                <Badge variant={nomination.nominationType === "individual" ? "default" : "secondary"}>
                  {nomination.nominationType === "individual" ? "Individual" : "Team"}
                </Badge>
              </div>
              <DrawerTitle className="mt-4 text-2xl">{nomination.nominee.name}</DrawerTitle>
              <DrawerDescription>
                {nomination.nominee.department} • Nomination ID: {nomination.id}
              </DrawerDescription>
            </div>
            <div className="flex gap-2">
              {(canEdit || isNomineeOrNominator) && (
                <Button variant="outline" size="icon" onClick={onEdit}>
                  <Edit className="h-4 w-4" />
                  <span className="sr-only">Edit</span>
                </Button>
              )}
              <DrawerClose asChild>
                <Button variant="ghost" size="icon">
                  <X className="h-4 w-4" />
                  <span className="sr-only">Close</span>
                </Button>
              </DrawerClose>
            </div>
          </DrawerHeader>

          <div className="p-4 pb-0 overflow-y-auto max-h-[calc(90vh-10rem)]">
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
                    <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{nomination.nominee.name}</p>
                    <p className="text-sm text-muted-foreground">{nomination.nominee.department}</p>
                  </div>
                </div>

                <div className="sm:ml-auto flex items-center gap-2 text-sm">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <span>Nominated on {nomination.createdAt.toLocaleDateString()}</span>
                </div>
              </div>

              {/* Endorsement Status */}
              <div className="flex items-center justify-between border-t border-b py-3">
                <span className="text-sm font-medium">Domain Manager Endorsement</span>
                {!nomination.endorsement || nomination.endorsement.status === "pending" ? (
                  <Badge
                    variant="outline"
                    className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300"
                  >
                    <Clock className="mr-1 h-3 w-3" />
                    Pending Endorsement
                  </Badge>
                ) : nomination.endorsement.status === "endorsed" ? (
                  <Badge
                    variant="outline"
                    className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300"
                  >
                    <CheckCircle className="mr-1 h-3 w-3" />
                    Endorsed
                  </Badge>
                ) : nomination.endorsement.status === "rejected" ? (
                  <Badge variant="outline" className="bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300">
                    <XCircle className="mr-1 h-3 w-3" />
                    Endorsement Declined
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300"
                  >
                    <Clock className="mr-1 h-3 w-3" />
                    Pending Endorsement
                  </Badge>
                )}
              </div>

              {/* Endorsement Details */}
              {nomination.endorsement && (
                <div className="text-sm space-y-2">
                  <p className="font-medium">Endorsement Details:</p>
                  {nomination.endorsement.endorsedBy && (
                    <p>
                      <span className="text-muted-foreground">Reviewed by:</span> {nomination.endorsement.endorsedBy}
                    </p>
                  )}
                  {nomination.endorsement.endorsedAt && (
                    <p>
                      <span className="text-muted-foreground">Date:</span>{" "}
                      {nomination.endorsement.endorsedAt.toLocaleDateString()}
                    </p>
                  )}
                  {nomination.endorsement.comments && (
                    <div>
                      <p className="text-muted-foreground">Comment:</p>
                      <p className="mt-1 p-2 bg-muted rounded-md">{nomination.endorsement.comments}</p>
                    </div>
                  )}
                </div>
              )}

              {nomination.nominationType === "team" && (
                <>
                  {/* Team Members */}
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <h3 className="font-medium">Team Members</h3>
                    </div>
                    <p className="text-sm">
                      {Array.isArray(nomination.team?.members)
                        ? nomination.team.members
                            .map((m) => {
                              // If it's an ID, try to find the employee name
                              const employee =
                                typeof m === "string" && m.includes("-")
                                  ? { name: m } // Default to using the ID as name
                                  : { name: m }
                              return employee.name
                            })
                            .join(", ")
                        : nomination.team?.members || "No team members listed"}
                    </p>
                  </div>
                </>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
                {/* Display presenter for team nominations */}
                {nomination.nominationType === "team" && presenter && presenter.id !== nomination.nominee.id ? (
                  <>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={presenter.avatar} alt={presenter.name} />
                        <AvatarFallback>{presenter.initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">Presenter: {presenter.name}</p>
                        <p className="text-xs text-muted-foreground">{presenter.department}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={nomination.nominator.avatar} alt={nomination.nominator.name} />
                        <AvatarFallback>{nomination.nominator.initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">Nominated by: {nomination.nominator.name}</p>
                        <p className="text-xs text-muted-foreground">{nomination.nominator.department}</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={nomination.nominator.avatar} alt={nomination.nominator.name} />
                      <AvatarFallback>{nomination.nominator.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Nominated by: {nomination.nominator.name}</p>
                      <p className="text-xs text-muted-foreground">{nomination.nominator.department}</p>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Nomination Summary</h3>
                <p className="text-sm whitespace-pre-line">
                  {nomination.nominationSummary ||
                    (nomination.justification && nomination.impact
                      ? `${nomination.justification}\n\n${nomination.impact}`
                      : nomination.justification || nomination.impact || "No summary provided.")}
                </p>
              </div>

              {/* Images Section */}
              {hasImages && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="h-4 w-4 text-muted-foreground" />
                    <h3 className="font-medium">Supporting Images</h3>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {nomination.images.map((image, index) => (
                      <div key={image.id} className="relative group">
                        <a href={image.url} target="_blank" rel="noopener noreferrer">
                          <img
                            src={image.url || "/placeholder.svg"}
                            alt={image.filename || `Supporting image ${index + 1}`}
                            className="rounded-md object-cover w-full aspect-square hover:opacity-90 transition-opacity"
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-md">
                            <span className="text-white text-xs font-medium">View</span>
                          </div>
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Add a separator before the new section if it doesn't exist */}
              <Separator className="my-6" />

              {/* Add after the nomination summary section */}
              <div className="space-y-4 mt-6">
                <h3 className="text-lg font-semibold">Benefits and Outcomes</h3>

                {nomination.benefitAndOutcome?.tangibleMetrics?.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground">Tangible Metrics</h4>
                    <div className="grid gap-2">
                      {nomination.benefitAndOutcome.tangibleMetrics.map((metric, index) => (
                        <div key={index} className="flex items-center justify-between p-2 rounded-lg border">
                          <span className="capitalize">{metric.type.replace(/([A-Z])/g, " $1").trim()}</span>
                          <Badge variant="secondary">
                            {metric.value} {metric.unit}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {nomination.benefitAndOutcome?.intangibleJustifications?.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground">Intangible Benefits</h4>
                    <div className="grid gap-3">
                      {nomination.benefitAndOutcome.intangibleJustifications.map((item, index) => (
                        <div key={index} className="space-y-1">
                          <div className="font-medium capitalize">
                            {item.otherType || item.type.replace(/([A-Z])/g, " $1").trim()}
                          </div>
                          <p className="text-sm text-muted-foreground">{item.justification}</p>
                          {index < nomination.benefitAndOutcome.intangibleJustifications.length - 1 && (
                            <Separator className="mt-2" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {nomination.supportingInfo && (
                <div>
                  <h3 className="font-medium mb-2">Supporting Information</h3>
                  <a
                    href={nomination.supportingInfo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary flex items-center gap-1 hover:underline"
                  >
                    <ExternalLink className="h-3 w-3" />
                    {nomination.supportingInfo}
                  </a>
                </div>
              )}
              {nomination.supportingInfo &&
                Array.isArray(nomination.supportingInfo) &&
                nomination.supportingInfo.length > 0 && (
                  <div>
                    <h3 className="font-medium mb-2">Supporting Information</h3>
                    <ul>
                      {nomination.supportingInfo.map((info, index) => (
                        <li key={index}>
                          <a
                            href={info}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-primary flex items-center gap-1 hover:underline"
                          >
                            <ExternalLink className="h-3 w-3" />
                            {info}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

              <div>
                <h3 className="font-medium mb-2">Service Line</h3>
                <p className="text-sm capitalize">{formatServiceLine(nomination.serviceLine)}</p>
              </div>
            </div>
          </div>

          <DrawerFooter>
            <DrawerClose asChild>
              <Button variant="outline">Close</Button>
            </DrawerClose>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  )
}

