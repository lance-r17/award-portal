"use client"

import { Plus } from "lucide-react"
import { useUser } from "@/contexts/user-context"

// Update the AddNominationCard component to disable the card for anonymous users
export function AddNominationCard({ onClick }: { onClick: () => void }) {
  const { user } = useUser()
  const isAnonymous = user?.roles?.includes("anonymous")

  console.log("AddNominationCard - User:", user?.name, "isAnonymous:", isAnonymous)

  if (isAnonymous) {
    return null // Don't render anything for anonymous users
  }

  return (
    <div
      className="rounded-lg border border-dashed p-6 h-full flex flex-col items-center justify-center text-center cursor-pointer hover:border-primary hover:bg-primary/5"
      onClick={onClick}
    >
      <div className="rounded-full bg-primary/10 p-3 mb-4">
        <Plus className="h-6 w-6 text-primary" />
      </div>
      <h3 className="font-medium mb-1">Add Nomination</h3>
      <p className="text-sm text-muted-foreground mb-4">Recognize outstanding contributions</p>
    </div>
  )
}

