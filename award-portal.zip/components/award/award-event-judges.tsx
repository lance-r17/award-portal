"use client"

import { useState, useEffect, useMemo } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Info, Plus, X, UserCheck, AlertTriangle } from "lucide-react"
import type { AwardEvent } from "@/types/award-events"
import type { User } from "@/types/users"
import { cn } from "@/lib/utils"
import { mockUsers } from "@/data/mock-users"
import { serviceLines } from "@/data/service-lines"
import { getJudgesForEvent, assignJudgeToEvent, removeJudgeFromEvent } from "@/data/event-judges"
import { getJudgePool } from "@/data/mock-users"

interface AwardEventJudgesProps {
  eventId: string
  event: AwardEvent
  isFacilitator: boolean
  currentUserId: string
}

export function AwardEventJudges({ eventId, event, isFacilitator, currentUserId }: AwardEventJudgesProps) {
  const [judges, setJudges] = useState<User[]>([])
  const [open, setOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  // Load judges when component mounts
  useEffect(() => {
    const eventJudgeIds = getJudgesForEvent(eventId)
    const eventJudges = mockUsers.filter((user) => eventJudgeIds.includes(user.id))
    setJudges(eventJudges)
  }, [eventId])

  // Get available judges from the judge pool
  const availableJudges = useMemo(() => {
    const judgePool = getJudgePool()
    const currentJudgeIds = judges.map((judge) => judge.id)
    return judgePool.filter(
      (judge) =>
        !currentJudgeIds.includes(judge.id) &&
        (judge.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          judge.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (judge.title && judge.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
          judge.serviceLine.toLowerCase().includes(searchQuery.toLowerCase())),
    )
  }, [judges, searchQuery])

  const getAvailableServiceLines = () => {
    const selectedServiceLines = judges.map((judge) => judge.serviceLine)
    return serviceLines.filter((line) => !selectedServiceLines.includes(line.value))
  }

  // Group available judges by service line
  const getGroupedAvailableJudges = () => {
    const grouped: Record<string, User[]> = {}

    availableJudges.forEach((judge) => {
      if (!grouped[judge.serviceLine]) {
        grouped[judge.serviceLine] = []
      }
      grouped[judge.serviceLine].push(judge)
    })

    return grouped
  }

  const handleAddJudge = (judgeId: string) => {
    const judge = availableJudges.find((j) => j.id === judgeId)
    if (!judge) return

    // Check if we already have a judge from this service line
    if (judges.some((j) => j.serviceLine === judge.serviceLine)) {
      toast({
        title: "Cannot add judge",
        description: `You already have a judge from the ${formatServiceLine(judge.serviceLine)} service line.`,
        variant: "destructive",
      })
      return
    }

    assignJudgeToEvent(judgeId, eventId)
    setJudges((prev) => [...prev, judge])

    toast({
      title: "Judge added",
      description: `${judge.name} has been added as a judge for this award event.`,
    })

    setOpen(false)
  }

  const handleRemoveJudge = (judgeId: string) => {
    removeJudgeFromEvent(judgeId, eventId)
    setJudges((prev) => prev.filter((judge) => judge.id !== judgeId))

    toast({
      title: "Judge removed",
      description: "The judge has been removed from this award event.",
    })
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  const canManageJudges = isFacilitator && event.status === "published" && event.currentStage !== "result"

  if (event.status !== "published") {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Judges can only be added to published events</AlertTitle>
        <AlertDescription>
          Once this award event is published, facilitators will be able to invite judges.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div>
          <CardTitle>Award Event Judges</CardTitle>
          <CardDescription>
            Judges evaluate nominations and determine award winners. One judge from each service line can be invited.
          </CardDescription>
        </div>
      </CardHeader>

      <CardContent>
        {event.currentStage === "result" && (
          <Alert className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Judges Panel Finalized</AlertTitle>
            <AlertDescription>
              This award event is in the result stage. The judge panel has been finalized and can no longer be modified.
            </AlertDescription>
          </Alert>
        )}

        {!isFacilitator && (
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertTitle>Facilitator Access Only</AlertTitle>
            <AlertDescription>Only facilitators can manage the judge list for this award event.</AlertDescription>
          </Alert>
        )}

        <div className="mb-6">
          <h3 className="text-sm font-medium mb-3">Judge Panel</h3>
          <div className="flex items-center">
            <div className="flex -space-x-2 mr-2">
              {judges.map((judge) => (
                <Avatar
                  key={judge.id}
                  className="border-2 border-background h-10 w-10 hover:z-10 transition-all"
                  title={`${judge.name} (${formatServiceLine(judge.serviceLine)})`}
                >
                  <AvatarImage src={judge.avatar} alt={judge.name} />
                  <AvatarFallback>{judge.initials}</AvatarFallback>
                </Avatar>
              ))}
            </div>

            {/* Always show the plus button if there are available service lines */}
            {canManageJudges && getAvailableServiceLines().length > 0 && (
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-10 w-10 rounded-full border-dashed border-2 ml-2 bg-background hover:bg-muted"
                    title="Add a judge"
                  >
                    <Plus className="h-5 w-5" />
                    <span className="sr-only">Add judge</span>
                  </Button>
                </PopoverTrigger>

                <PopoverContent className="p-0 w-80" align="end">
                  <Command>
                    <CommandInput
                      placeholder="Search judges by name, title, or service line..."
                      onValueChange={setSearchQuery}
                    />
                    <CommandList className="max-h-[300px]">
                      <CommandEmpty>No judges available for the remaining service lines</CommandEmpty>

                      {Object.entries(getGroupedAvailableJudges()).map(([serviceLine, judges]) => (
                        <CommandGroup key={serviceLine} heading={formatServiceLine(serviceLine)}>
                          {judges.map((judge) => (
                            <CommandItem
                              key={judge.id}
                              onSelect={() => handleAddJudge(judge.id)}
                              className="flex items-center gap-2 cursor-pointer"
                            >
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={judge.avatar} alt={judge.name} />
                                <AvatarFallback>{judge.initials}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">{judge.name}</p>
                                <p className="text-xs text-muted-foreground truncate">{judge.title}</p>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      ))}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            )}

            {judges.length > 0 && (
              <div className="ml-4 text-sm text-muted-foreground">
                {judges.length} of {serviceLines.length} service lines represented
              </div>
            )}
          </div>

          {judges.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {serviceLines.map((line) => {
                const hasJudge = judges.some((j) => j.serviceLine === line.value)
                return (
                  <Badge
                    key={line.value}
                    variant={hasJudge ? "default" : "outline"}
                    className={cn("text-xs", !hasJudge && "text-muted-foreground border-dashed")}
                  >
                    {formatServiceLine(line.label)}
                    {!hasJudge && " (needed)"}
                  </Badge>
                )
              })}
            </div>
          )}
        </div>

        {judges.length === 0 ? (
          <div className="text-center py-8">
            {canManageJudges ? (
              <div className="space-y-3">
                <UserCheck className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="text-muted-foreground">
                  No judges have been invited yet. Add judges to evaluate nominations.
                </p>
                {getAvailableServiceLines().length === 0 && (
                  <Alert variant="destructive" className="mt-4 max-w-md mx-auto">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>All service lines covered</AlertTitle>
                    <AlertDescription>You've added judges from all available service lines.</AlertDescription>
                  </Alert>
                )}
              </div>
            ) : (
              <p className="text-muted-foreground">No judges have been invited to this award event yet.</p>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {judges.map((judge) => (
              <div key={judge.id} className="flex items-start gap-4 p-4 rounded-lg border">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={judge.avatar} alt={judge.name} />
                  <AvatarFallback>{judge.initials}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">{judge.name}</h3>
                      <p className="text-sm text-muted-foreground">{judge.title}</p>
                    </div>
                    <Badge variant="outline">{formatServiceLine(judge.serviceLine)}</Badge>
                  </div>
                  <p className="mt-2 text-sm">{judge.bio}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{judge.email}</p>
                </div>
                {canManageJudges && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    onClick={() => handleRemoveJudge(judge.id)}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                )}
              </div>
            ))}

            {canManageJudges && getAvailableServiceLines().length === 0 && (
              <Alert className="mt-4">
                <Info className="h-4 w-4" />
                <AlertTitle>All service lines covered</AlertTitle>
                <AlertDescription>You've added judges from all available service lines.</AlertDescription>
              </Alert>
            )}
          </div>
        )}

        <div className="mt-6 rounded-lg border p-4 bg-muted/50">
          <h3 className="font-medium mb-2">About Judging Process</h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start gap-2">
              <span className="bg-primary/10 text-primary rounded-full h-5 w-5 flex items-center justify-center shrink-0 mt-0.5">
                1
              </span>
              <span>Judges are invited from different service lines to ensure diverse perspectives.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="bg-primary/10 text-primary rounded-full h-5 w-5 flex items-center justify-center shrink-0 mt-0.5">
                2
              </span>
              <span>Each judge reviews nominations during the presentation stage.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="bg-primary/10 text-primary rounded-full h-5 w-5 flex items-center justify-center shrink-0 mt-0.5">
                3
              </span>
              <span>Judges score nominations based on impact, innovation, and alignment with award criteria.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="bg-primary/10 text-primary rounded-full h-5 w-5 flex items-center justify-center shrink-0 mt-0.5">
                4
              </span>
              <span>Final winners are determined by consensus among the judging panel.</span>
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}

