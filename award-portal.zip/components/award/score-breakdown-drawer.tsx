"use client"

import { Button } from "@/components/ui/button"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import { Separator } from "@/components/ui/separator"
import { mockUsers } from "@/data/mock-users"
import { nominations } from "@/data/nominations"
import { calculateWeightedScore, type Score } from "@/types/judges"
import type { Nomination } from "@/types/nominations"
import type { User } from "@/types/users"
import { useState } from "react"

interface ScoreBreakdownDrawerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  nominationId: string
  eventId: string
  scores?: Score[] // Make scores optional
}

export function ScoreBreakdownDrawer({
  open,
  onOpenChange,
  nominationId,
  eventId,
  scores = [], // Default to empty array if scores is undefined
}: ScoreBreakdownDrawerProps) {
  const [activeTab, setActiveTab] = useState<"summary" | "details">("summary")

  // Get the nomination details
  const nomination = nominations.find((nom) => nom.id === nominationId)
  if (!nomination) return null

  // No need to filter scores if we're already passing the correct ones
  const nominationScores = scores

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent>
        <div className="mx-auto w-full max-w-4xl">
          <DrawerHeader>
            <DrawerTitle>Score Breakdown</DrawerTitle>
            <DrawerDescription>
              {nomination.nomineeName} - {nomination.title}
            </DrawerDescription>
          </DrawerHeader>
          <div className="p-4">
            <div className="flex space-x-4 mb-4">
              <Button variant={activeTab === "summary" ? "default" : "outline"} onClick={() => setActiveTab("summary")}>
                Summary
              </Button>
              <Button variant={activeTab === "details" ? "default" : "outline"} onClick={() => setActiveTab("details")}>
                Detailed Breakdown
              </Button>
            </div>

            {activeTab === "summary" ? (
              <SummaryTab nomination={nomination} scores={nominationScores} />
            ) : (
              <DetailsTab nomination={nomination} scores={nominationScores} />
            )}
          </div>
          <DrawerFooter>
            <DrawerClose asChild>
              <Button variant="outline">Close</Button>
            </DrawerClose>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  )
}

interface SummaryTabProps {
  nomination: Nomination
  scores: Score[]
}

function SummaryTab({ nomination, scores }: SummaryTabProps) {
  // Calculate average weighted score
  const totalWeightedScore = scores.reduce((sum, score) => {
    return sum + calculateWeightedScore(score.criteria)
  }, 0)
  const averageScore = scores.length > 0 ? totalWeightedScore / scores.length : 0

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Overall Score</h3>
        <div className="mt-2 text-3xl font-bold">{averageScore.toFixed(2)}</div>
        <p className="text-sm text-muted-foreground">Based on {scores.length} judge evaluations</p>
      </div>

      <Separator />

      <div>
        <h3 className="text-lg font-medium mb-4">Judge Scores</h3>
        {scores.length > 0 ? (
          <div className="space-y-3">
            {scores.map((score) => {
              const judge = mockUsers.find((user) => user.id === score.judgeId)
              return <JudgeScoreRow key={score.judgeId} judge={judge} criteria={score.criteria} />
            })}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No scores available</p>
        )}
      </div>
    </div>
  )
}

interface DetailsTabProps {
  nomination: Nomination
  scores: Score[]
}

function DetailsTab({ nomination, scores }: DetailsTabProps) {
  // Group scores by criteria
  const criteriaScores: Record<string, number[]> = {}

  scores.forEach((score) => {
    Object.entries(score.criteria).forEach(([criterion, value]) => {
      if (!criteriaScores[criterion]) {
        criteriaScores[criterion] = []
      }
      criteriaScores[criterion].push(value)
    })
  })

  // Calculate average for each criterion
  const criteriaSummary = Object.entries(criteriaScores).map(([criterion, values]) => {
    const sum = values.reduce((acc, val) => acc + val, 0)
    const average = values.length > 0 ? sum / values.length : 0
    return { criterion, average }
  })

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Criteria Breakdown</h3>
        <div className="space-y-3">
          {criteriaSummary.map(({ criterion, average }) => (
            <div key={criterion} className="flex justify-between items-center">
              <div className="capitalize">{criterion}</div>
              <div className="font-medium">{average.toFixed(2)}</div>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h3 className="text-lg font-medium mb-4">Judge Comments</h3>
        {scores.length > 0 ? (
          <div className="space-y-4">
            {scores
              .filter((score) => score.comments)
              .map((score) => {
                const judge = mockUsers.find((user) => user.id === score.judgeId)
                return (
                  <div key={score.judgeId} className="border rounded-lg p-3">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">{judge?.name || "Unknown Judge"}</div>
                      <div className="text-sm text-muted-foreground">
                        Score: {calculateWeightedScore(score.criteria).toFixed(2)}
                      </div>
                    </div>
                    <p className="text-sm">{score.comments}</p>
                  </div>
                )
              })}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No comments available</p>
        )}
      </div>
    </div>
  )
}

interface JudgeScoreRowProps {
  judge: User | undefined
  criteria: Record<string, number>
}

function JudgeScoreRow({ judge, criteria }: JudgeScoreRowProps) {
  // Calculate weighted score to display
  const weightedScore = calculateWeightedScore(criteria)

  return (
    <div className="flex justify-between items-center p-2 border rounded-md">
      <div className="font-medium">{judge?.name || "Unknown Judge"}</div>
      <div className="font-bold">{weightedScore.toFixed(2)}</div>
    </div>
  )
}
