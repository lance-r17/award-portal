"use client"

import { useState, useEffect } from "react"
import { AwardNominationForm } from "@/components/award/award-nomination-form"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"
import type { Nomination } from "@/types/nominations"
import { useUser } from "@/contexts/user-context"

interface NominationFormDrawerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  eventId: string
  awardType?: string | null
  nominationType?: "individual" | "team"
  nomination?: Nomination | null // For editing existing nominations
  isEditing?: boolean
}

export function NominationFormDrawer({
  open,
  onOpenChange,
  eventId,
  awardType = null,
  nominationType = "individual",
  nomination = null,
  isEditing = false,
}: NominationFormDrawerProps) {
  const [selectedAwardType, setSelectedAwardType] = useState<string | null>(awardType)
  const [selectedNominationType, setSelectedNominationType] = useState<"individual" | "team">(nominationType)

  const { user } = useUser()
  const isAnonymous = user?.roles?.includes("anonymous")

  useEffect(() => {
    if (isAnonymous && open) {
      // Close the drawer if an anonymous user somehow opens it
      onOpenChange(false)
      alert("Anonymous users cannot submit nominations. Please log in with a different role.")
    }
  }, [isAnonymous, open, onOpenChange])

  // Update award type and nomination type when props change
  useEffect(() => {
    if (awardType) {
      setSelectedAwardType(awardType)
    }

    if (nomination) {
      setSelectedAwardType(nomination.awardType)
      setSelectedNominationType(nomination.nominationType)
    } else {
      setSelectedNominationType(nominationType)
    }
  }, [awardType, nomination, nominationType])

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh]">
        <div className="mx-auto w-full max-w-4xl">
          <DrawerHeader className="flex justify-between items-center">
            <div>
              <DrawerTitle>{isEditing ? "Edit Nomination" : "Add New Nomination"}</DrawerTitle>
              <DrawerDescription>
                {isEditing
                  ? "Update your nomination details below"
                  : "Complete the form to nominate a colleague or team for an award"}
              </DrawerDescription>
            </div>
            <DrawerClose asChild>
              <Button variant="ghost" size="icon">
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </Button>
            </DrawerClose>
          </DrawerHeader>

          <div className="px-4 pb-0 overflow-y-auto max-h-[calc(90vh-10rem)]">
            {isAnonymous ? (
              <div className="p-6 text-center">
                <p className="text-red-500 mb-4">Anonymous users cannot submit nominations.</p>
                <p>Please switch to a different role to nominate someone for an award.</p>
              </div>
            ) : (
              <AwardNominationForm
                awardType="spot"
                nominationType={selectedNominationType}
                selectedAwardType={selectedAwardType}
                eventId={eventId}
                existingNomination={nomination}
                isEditing={isEditing}
              />
            )}
          </div>

          <DrawerFooter className="pt-2">
            <DrawerClose asChild>
              <Button variant="outline">Cancel</Button>
            </DrawerClose>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  )
}

