"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"

import { Button } from "@/components/ui/button"
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
} from "@/components/ui/drawer"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

const formSchema = z.object({
  endorsement: z.string().min(10, {
    message: "Endorsement must be at least 10 characters.",
  }),
})

interface EndorsementFormProps {
  open: boolean
  setOpen: (open: boolean) => void
  nominationId: string // Assuming you need the nomination ID
  onSuccess?: () => void // Optional callback for successful endorsement
}

export function EndorsementForm({ open, setOpen, nominationId, onSuccess }: EndorsementFormProps) {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      endorsement: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)
    try {
      // Simulate an API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Here you would typically make an API call to submit the endorsement
      // Example:
      // const response = await fetch('/api/endorse', {
      //   method: 'POST',
      //   body: JSON.stringify({ nominationId: nominationId, endorsement: values.endorsement }),
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      // });

      // if (!response.ok) {
      //   throw new Error('Failed to submit endorsement');
      // }

      toast({
        title: "Success!",
        description: "Your endorsement has been submitted.",
      })

      setOpen(false)
      form.reset()
      onSuccess?.() // Call the success callback if provided
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: error.message || "There was an error submitting your endorsement.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerContent>
        <div className="mx-auto w-full max-w-sm">
          <DrawerHeader>
            <DrawerTitle>Endorse Nomination</DrawerTitle>
            <DrawerDescription>Add your endorsement to this nomination.</DrawerDescription>
          </DrawerHeader>
          <div className="p-4 pb-0">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="endorsement"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Endorsement</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Write your endorsement here..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DrawerFooter>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Submitting..." : "Submit Endorsement"}
                  </Button>
                </DrawerFooter>
              </form>
            </Form>
          </div>
        </div>
      </DrawerContent>
    </Drawer>
  )
}
