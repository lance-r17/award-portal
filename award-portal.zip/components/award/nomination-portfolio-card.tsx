import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ThumbsUp, MessageSquare } from "lucide-react"
import type { Nomination } from "@/types/nominations"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"

interface NominationPortfolioCardProps {
  nomination: Nomination
  eventId: string
}

export function NominationPortfolioCard({ nomination, eventId }: NominationPortfolioCardProps) {
  // Get award type name
  const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
  const awardType = allAwardTypes.find((type) => type.id === nomination.awardType)
  const awardTypeName = awardType?.name || nomination.awardType

  return (
    <Link href={`/awards/spot-awards/${eventId}/noms/${nomination.id}`}>
      <Card className="h-full transition-all hover:shadow-md">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-2">
              <Avatar className="h-10 w-10">
                <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
                <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-base">{nomination.nominee.name}</CardTitle>
                <CardDescription className="text-xs">{nomination.nominee.department}</CardDescription>
              </div>
            </div>
            <Badge variant="outline" className="text-xs">
              {awardTypeName}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pb-2">
          <p className="text-sm line-clamp-3">{nomination.justification}</p>
        </CardContent>
        <CardFooter className="pt-2 flex justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <ThumbsUp className="h-3 w-3" />
            <span>{nomination.votes?.length || 0}</span>
          </div>
          <div className="flex items-center gap-1">
            <MessageSquare className="h-3 w-3" />
            <span>{nomination.comments?.length || 0}</span>
          </div>
          <div>
            {nomination.endorsement?.status === "endorsed" && (
              <Badge variant="default" className="text-xs">
                Endorsed
              </Badge>
            )}
          </div>
        </CardFooter>
      </Card>
    </Link>
  )
}

