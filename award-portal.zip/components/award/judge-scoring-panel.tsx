"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Info, Star, AlertTriangle, CheckCircle2, Clock } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { User } from "@/types/users"
import { isUserJudgeForEvent } from "@/data/event-judges"
import { getJudgeScores as getJudgeScoresFromMock, saveScore as saveScoreToMock } from "@/data/mock-scores"

// Replace the mock getJudgeScores function with this implementation
// that uses the imported function
const getJudgeScores = (judgeId: string, eventId: string): Record<string, number> => {
  try {
    return getJudgeScoresFromMock(judgeId, eventId)
  } catch (error) {
    console.error("Error fetching judge scores:", error)
    return {} // Fallback to empty object if there's an error
  }
}

// Replace the mock saveScore function with this implementation
// that uses the imported function
const saveScore = async (judgeId: string, nominationId: string, score: number): Promise<boolean> => {
  try {
    console.log(`Saving score ${score} for nomination ${nominationId} by judge ${judgeId}`)
    return await saveScoreToMock(judgeId, nominationId, score)
  } catch (error) {
    console.error("Error saving score:", error)
    return false
  }
}

// Update the JudgeScoringPanel props to include isResultStage
interface JudgeScoringPanelProps {
  eventId: string
  currentJudge: User | null
  isJudge: boolean
  isPresentationStage: boolean
  isResultStage?: boolean // Add this new prop
  nominations: Nomination[]
}

// Update the function signature to include the new prop
export function JudgeScoringPanel({
  eventId,
  currentJudge,
  isJudge,
  isPresentationStage,
  isResultStage = false, // Default to false
  nominations = [],
}: JudgeScoringPanelProps) {
  const [scores, setScores] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(true)
  const [savingScoreId, setSavingScoreId] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("all")

  // Use useMemo instead of useState + useEffect to avoid infinite loop
  const sortedNominations = useMemo(() => {
    if (!nominations || nominations.length === 0) {
      return []
    }

    // Sort nominations by ID to ensure consistent order
    return [...nominations].sort((a, b) => {
      // First by nomineeServiceLine
      if (a.nomineeServiceLine !== b.nomineeServiceLine) {
        return a.nomineeServiceLine.localeCompare(b.nomineeServiceLine)
      }
      // Then by nomineeName
      if (a.nomineeName && b.nomineeName) {
        return a.nomineeName.localeCompare(b.nomineeName)
      }
      // Fallback to ID if name is missing
      return a.id.localeCompare(b.id)
    })
  }, [nominations])

  useEffect(() => {
    // Load scores only
    const fetchData = async () => {
      setLoading(true)
      try {
        if (currentJudge) {
          const judgeScores = getJudgeScores(currentJudge.id, eventId)
          setScores(judgeScores)
        }
      } catch (error) {
        console.error("Error fetching scoring data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId, currentJudge])

  // Filter nominations that the judge can score (not from their own service line)
  const eligibleNominations = useMemo(() => {
    if (!currentJudge) return sortedNominations

    return sortedNominations.filter((nomination) => {
      const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""
      const judgeServiceLine = currentJudge.serviceLine || ""

      // Log for debugging
      console.log(
        `Checking eligibility: nomination service line "${nominationServiceLine}" vs judge service line "${judgeServiceLine}"`,
      )

      // Check if nomineeServiceLine exists before comparing
      if (!nominationServiceLine) {
        console.warn("Nomination missing service line:", nomination)
        return true // Include nominations without service line for now
      }

      const isEligible = nominationServiceLine !== judgeServiceLine
      console.log(`Nomination ${nomination.id} eligible: ${isEligible}`)
      return isEligible
    })
  }, [currentJudge, sortedNominations])

  // Get nominations that have been scored (only from eligible nominations)
  const scoredNominations = useMemo(() => {
    return eligibleNominations.filter((nomination) => scores[nomination.id] !== undefined)
  }, [eligibleNominations, scores])

  // Get nominations that haven't been scored yet (only from eligible nominations)
  const pendingNominations = useMemo(() => {
    return eligibleNominations.filter((nomination) => scores[nomination.id] === undefined)
  }, [eligibleNominations, scores])

  // Add more debugging to identify the issue
  useEffect(() => {
    console.log("Current judge service line:", currentJudge?.serviceLine)
    console.log("All nominations:", sortedNominations.length)
    console.log("Eligible nominations:", eligibleNominations.length)
    console.log("Pending nominations:", pendingNominations.length)
    console.log("Scored nominations:", scoredNominations.length)

    // Log each nomination's service line to check filtering
    sortedNominations.forEach((nom) => {
      console.log(
        `Nomination ${nom.id} service line: ${nom.serviceLine || nom.nomineeServiceLine}, eligible: ${
          !currentJudge || (nom.serviceLine || nom.nomineeServiceLine) !== currentJudge.serviceLine
        }`,
      )
    })
  }, [sortedNominations, eligibleNominations, pendingNominations, scoredNominations, currentJudge])

  // Update handleScoreChange
  const handleScoreChange = (nominationId: string, value: number[]) => {
    // Find the nomination
    const nomination = sortedNominations.find((n) => n.id === nominationId)
    if (!nomination) return

    // Check if the judge can score this nomination
    if (currentJudge && (nomination.serviceLine || nomination.nomineeServiceLine) === currentJudge.serviceLine) {
      return // Cannot score nominations from own service line
    }

    const newScore = value[0]
    setScores((prev) => ({
      ...prev,
      [nominationId]: newScore,
    }))
  }

  // Update handleSubmitScore
  const handleSubmitScore = async (nominationId: string) => {
    if (!currentJudge) return

    // Find the nomination
    const nomination = sortedNominations.find((n) => n.id === nominationId)
    if (!nomination) return

    // Check if the judge can score this nomination
    if ((nomination.serviceLine || nomination.nomineeServiceLine) === currentJudge.serviceLine) {
      toast({
        title: "Cannot score",
        description: "You cannot score nominations from your own service line.",
        variant: "destructive",
      })
      return // Cannot score nominations from own service line
    }

    const score = scores[nominationId]
    if (score === undefined) return

    setSavingScoreId(nominationId)
    try {
      const success = await saveScore(currentJudge.id, nominationId, score)
      if (success) {
        toast({
          title: "Score submitted",
          description: "Your score has been saved successfully.",
        })
      }
    } catch (error) {
      console.error("Error saving score:", error)
      toast({
        title: "Error saving score",
        description: "There was a problem saving your score. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSavingScoreId(null)
    }
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Format score for display
  const formatScore = (score: number) => {
    return score.toFixed(1)
  }

  // Debug information
  useEffect(() => {
    console.log("Nominations received:", nominations.length)
    console.log("Sorted nominations:", sortedNominations.length)
    console.log("Eligible nominations:", eligibleNominations.length)
    if (currentJudge) {
      console.log("Current judge service line:", currentJudge.serviceLine)
    }
  }, [nominations, sortedNominations, eligibleNominations, currentJudge])

  // Replace the isPresentationStage check with a more flexible condition
  if (!isPresentationStage && !isResultStage) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Scoring is only available during the presentation stage</AlertTitle>
        <AlertDescription>Judges can score nominations once the event enters the presentation stage.</AlertDescription>
      </Alert>
    )
  }

  if (isJudge && !currentJudge) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Judge information not found</AlertTitle>
        <AlertDescription>
          Your judge profile could not be loaded. Please contact the event facilitator.
        </AlertDescription>
      </Alert>
    )
  }

  if (!isJudge || !isUserJudgeForEvent(currentJudge?.id || "", eventId)) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Judge Access Only</AlertTitle>
        <AlertDescription>
          The scoring panel is only accessible to judges assigned to this event during the presentation stage.
        </AlertDescription>
      </Alert>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  // If we have no nominations at all, show a specific message
  if (nominations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Judge Scoring Panel</CardTitle>
          <CardDescription>Score nominations based on their presentations.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>No nominations found</AlertTitle>
            <AlertDescription>
              There are no nominations available for this award event. Please check back later.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  // Update the NominationScoringCard to disable scoring in result stage
  return (
    <Card>
      <CardHeader>
        <CardTitle>Judge Scoring Panel</CardTitle>
        <CardDescription>
          {isResultStage
            ? "View your submitted scores. Scoring is closed as the event is in the results stage."
            : "Score nominations based on their presentations. You cannot score nominations from your own service line."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {eligibleNominations.length === 0 ? (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>No nominations to score</AlertTitle>
            <AlertDescription>
              There are no nominations available for you to score at this time.
              {currentJudge && (
                <span>
                  {" "}
                  As a judge from the {formatServiceLine(currentJudge.serviceLine)} service line, you cannot score
                  nominations from your own service line.
                </span>
              )}
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-medium">Your Scoring Progress</h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    You have scored {scoredNominations.length} of {eligibleNominations.length} eligible nominations
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="bg-muted w-40 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-primary h-full"
                      style={{
                        width: `${eligibleNominations.length ? (scoredNominations.length / eligibleNominations.length) * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium">
                    {eligibleNominations.length
                      ? Math.round((scoredNominations.length / eligibleNominations.length) * 100)
                      : 0}
                    %
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="bg-primary/10">
                  <span className="mr-1">⚠️</span> Cannot score nominations from your service line (
                  {formatServiceLine(currentJudge?.serviceLine || "")})
                </Badge>
                <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/20">
                  <Clock className="mr-1 h-3 w-3" /> {pendingNominations.length} pending
                </Badge>
                <Badge variant="outline" className="bg-green-100 dark:bg-green-900/20">
                  <CheckCircle2 className="mr-1 h-3 w-3" /> {scoredNominations.length} scored
                </Badge>
              </div>
            </div>

            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full mt-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="all">All Nominations ({sortedNominations.length})</TabsTrigger>
                <TabsTrigger value="pending">Pending ({pendingNominations.length})</TabsTrigger>
                <TabsTrigger value="scored">Scored ({scoredNominations.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-4 mt-4">
                {sortedNominations.length > 0 ? (
                  sortedNominations.map((nomination, index) => {
                    const canScore =
                      !isResultStage && // Add this condition
                      (!currentJudge ||
                        (nomination.serviceLine || nomination.nomineeServiceLine) !== currentJudge.serviceLine)

                    return (
                      <NominationScoringCard
                        key={nomination.id}
                        nomination={nomination}
                        score={scores[nomination.id]}
                        onScoreChange={(value) => handleScoreChange(nomination.id, value)}
                        onSubmit={() => handleSubmitScore(nomination.id)}
                        isSaving={savingScoreId === nomination.id}
                        index={index}
                        currentJudge={currentJudge}
                        canScore={canScore}
                        isResultStage={isResultStage} // Pass this new prop
                      />
                    )
                  })
                ) : (
                  <div className="text-center py-8">
                    <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                    <p className="mt-2 text-muted-foreground">No nominations found.</p>
                  </div>
                )}
              </TabsContent>

              {/* Update the other TabsContent sections similarly */}
              <TabsContent value="pending" className="space-y-4 mt-4">
                {pendingNominations.length === 0 ? (
                  <div className="text-center py-8">
                    <CheckCircle2 className="mx-auto h-12 w-12 text-primary/50" />
                    <p className="mt-2 text-muted-foreground">You have scored all eligible nominations!</p>
                  </div>
                ) : (
                  pendingNominations.map((nomination, index) => {
                    return (
                      <NominationScoringCard
                        key={nomination.id}
                        nomination={nomination}
                        score={scores[nomination.id]}
                        onScoreChange={(value) => handleScoreChange(nomination.id, value)}
                        onSubmit={() => handleSubmitScore(nomination.id)}
                        isSaving={savingScoreId === nomination.id}
                        index={index}
                        currentJudge={currentJudge}
                        canScore={!isResultStage} // Add this condition
                        isResultStage={isResultStage} // Pass this new prop
                      />
                    )
                  })
                )}
              </TabsContent>

              <TabsContent value="scored" className="space-y-4 mt-4">
                {scoredNominations.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="mx-auto h-12 w-12 text-muted-foreground/50" />
                    <p className="mt-2 text-muted-foreground">You haven't scored any nominations yet.</p>
                  </div>
                ) : (
                  scoredNominations.map((nomination, index) => {
                    return (
                      <NominationScoringCard
                        key={nomination.id}
                        nomination={nomination}
                        score={scores[nomination.id]}
                        onScoreChange={(value) => handleScoreChange(nomination.id, value)}
                        onSubmit={() => handleSubmitScore(nomination.id)}
                        isSaving={savingScoreId === nomination.id}
                        index={index}
                        currentJudge={currentJudge}
                        canScore={!isResultStage} // Add this condition
                        isResultStage={isResultStage} // Pass this new prop
                      />
                    )
                  })
                )}
              </TabsContent>
            </Tabs>

            <div className="mt-6 rounded-lg border p-4 bg-muted/50">
              <h3 className="font-medium mb-2">Scoring Guidelines</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="font-medium">1.0 - 2.0:</span>
                  <span className="text-muted-foreground">Does not meet expectations or criteria for the award.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-medium">2.1 - 3.0:</span>
                  <span className="text-muted-foreground">Meets some expectations but lacks in key areas.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-medium">3.1 - 4.0:</span>
                  <span className="text-muted-foreground">Meets or exceeds expectations in most areas.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-medium">4.1 - 5.0:</span>
                  <span className="text-muted-foreground">
                    Exceptional achievement that significantly exceeds expectations.
                  </span>
                </li>
              </ul>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}

// Update the NominationScoringCard props and component
interface NominationScoringCardProps {
  nomination: Nomination
  score?: number
  onScoreChange: (value: number[]) => void
  onSubmit: () => void
  isSaving: boolean
  index: number
  currentJudge: User | null
  canScore: boolean
  isResultStage?: boolean // Add this new prop
}

function NominationScoringCard({
  nomination,
  score,
  onScoreChange,
  onSubmit,
  isSaving,
  index,
  currentJudge,
  canScore,
  isResultStage = false, // Default to false
}: NominationScoringCardProps) {
  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const awardTypes: Record<string, string> = {
      "star-of-agile": "Star of Agile",
      "star-of-customer-service": "Star of Customer Service",
      "star-of-engagement": "Star of Engagement",
      "star-of-innovation": "Star of Innovation",
      "star-of-leadership": "Star of Leadership",
      "all-star-team": "All-Star Team",
    }
    return awardTypes[awardType] || awardType
  }

  const isScored = score !== undefined
  const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""

  return (
    <div
      className={cn(
        "rounded-lg border p-4",
        isScored ? "border-primary/20 bg-primary/5" : "",
        !canScore ? "border-destructive/20 bg-destructive/5" : "",
      )}
    >
      <div className="flex items-start gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm font-medium">
            {index + 1}
          </div>
          <Avatar className="h-12 w-12">
            <AvatarImage
              src={nomination.nominee?.avatar || "/placeholder.svg?height=40&width=40"}
              alt={nomination.nominee?.name || "Unknown"}
            />
            <AvatarFallback>{nomination.nominee?.initials || "??"}</AvatarFallback>
          </Avatar>
        </div>

        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <h3 className="font-medium">
                {nomination.title ||
                  `${getAwardTypeDisplay(nomination.awardType)} - ${nomination.nominee?.name || "Unknown"}`}
              </h3>
              <p className="text-sm">
                <span className="text-muted-foreground">Nominee: </span>
                {nomination.nominee?.name || "Unknown"}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                <span className="font-medium">Service Line: </span>
                {formatServiceLine(nominationServiceLine || "Unknown")}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <Badge variant="secondary" className="whitespace-nowrap">
                {nomination.nominationType === "individual" ? "Individual" : "Team"}
              </Badge>
            </div>
          </div>

          <div className="mt-3">
            <p className="text-sm font-medium mb-1">Justification:</p>
            <p className="text-sm text-muted-foreground">{nomination.justification || "No justification provided"}</p>
          </div>

          <div className="mt-2">
            <p className="text-sm font-medium mb-1">Impact:</p>
            <p className="text-sm text-muted-foreground">{nomination.impact || "No impact information provided"}</p>
          </div>

          {!canScore ? (
            <div className="mt-4">
              {isResultStage && isScored ? (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm font-medium">Your Score:</p>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={cn(
                              "h-4 w-4",
                              score !== undefined && score >= star - 0.5
                                ? "fill-primary text-primary"
                                : "fill-muted text-muted-foreground",
                            )}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium min-w-[2rem] text-right">
                        {score !== undefined ? formatScore(score) : "-"}
                      </span>
                    </div>
                  </div>
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/30 rounded-md mt-2">
                    <p className="text-sm font-medium text-amber-800 dark:text-amber-300">Scoring Closed</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      The event is now in the results stage. Your submitted score is displayed above, but scoring is no
                      longer available.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                  <p className="text-sm font-medium text-destructive">
                    {isResultStage ? "Scoring Closed" : "Cannot Score"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {isResultStage
                      ? "The event is now in the results stage. Scoring is no longer available."
                      : `As a judge from ${formatServiceLine(currentJudge?.serviceLine || "")}, you cannot score nominations from your own service line.`}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="mt-4 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Your Score:</p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={cn(
                          "h-4 w-4",
                          score !== undefined && score >= star - 0.5
                            ? "fill-primary text-primary"
                            : "fill-muted text-muted-foreground",
                        )}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium min-w-[2rem] text-right">
                    {score !== undefined ? formatScore(score) : "-"}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <Slider
                    defaultValue={[score !== undefined ? score : 3]}
                    value={[score !== undefined ? score : 3]}
                    min={1}
                    max={5}
                    step={0.1}
                    onValueChange={onScoreChange}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">1</span>
                  <div className="w-24"></div>
                  <span className="text-sm text-muted-foreground">5</span>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={onSubmit} disabled={isSaving || score === undefined || isResultStage} size="sm">
                  {isSaving ? "Saving..." : isScored ? "Update Score" : "Submit Score"}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function formatServiceLine(line: string | string[]): string {
  // Handle undefined or null
  if (!line) return "Unknown"

  // Handle array of service lines
  if (Array.isArray(line)) {
    if (line.length === 0) return "Unknown"

    return line
      .map((serviceLine) => {
        if (typeof serviceLine !== "string") return "Unknown"
        return serviceLine
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")
      })
      .join(", ")
  }

  // Handle string (for backward compatibility)
  if (typeof line === "string") {
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Fallback
  return "Unknown"
}

function formatScore(score: number): string {
  return score.toFixed(1)
}

