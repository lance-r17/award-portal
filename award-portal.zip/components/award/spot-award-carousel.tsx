"use client"

import { useState, useEffect, useRef } from "react"
import { CalendarDays, Trophy, Zap, Award, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { AwardEvent } from "@/types/award-events"
import { getCurrentStageLabel, getStageTimeRemaining } from "@/data/award-events"
import { cn } from "@/lib/utils"

interface SpotAwardCarouselProps {
  events: AwardEvent[]
  onEventSelect: (eventId: string) => void
}

export function SpotAwardCarousel({ events, onEventSelect }: SpotAwardCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(true)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const carouselRef = useRef<HTMLDivElement>(null)

  // Auto-advance the carousel
  useEffect(() => {
    if (!autoplay || events.length <= 1) return

    const interval = setInterval(() => {
      setIsTransitioning(true)
      setCurrentIndex((prevIndex) => (prevIndex + 1) % events.length)
    }, 6000)

    return () => clearInterval(interval)
  }, [autoplay, events.length])

  // Reset transition state after animation completes
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsTransitioning(false)
    }, 500)
    return () => clearTimeout(timer)
  }, [currentIndex])

  // Pause autoplay when user interacts with carousel
  const handleManualNavigation = (index: number) => {
    setIsTransitioning(true)
    setCurrentIndex(index)
    setAutoplay(false)
    setTimeout(() => setAutoplay(true), 15000)
  }

  if (events.length === 0) return null

  const currentEvent = events[currentIndex]
  const stageLabel = getCurrentStageLabel(currentEvent.currentStage)
  const timeRemaining = getStageTimeRemaining(currentEvent)
  const stageProgress = Math.round(
    ((new Date().getTime() - currentEvent.stages[currentEvent.currentStage].startDate.getTime()) /
      (currentEvent.stages[currentEvent.currentStage].endDate.getTime() -
        currentEvent.stages[currentEvent.currentStage].startDate.getTime())) *
      100,
  )

  return (
    <div
      ref={carouselRef}
      className={cn(
        "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4 rounded-xl bg-background/5 backdrop-blur transition-all duration-500",
        isTransitioning && "opacity-90 scale-[0.98]",
      )}
    >
      {/* Hero Section */}
      <div className="md:col-span-2 lg:col-span-2 rounded-xl bg-primary/10 p-8 flex flex-col justify-between min-h-[300px]">
        <div>
          <Badge variant="outline" className="mb-4 bg-background/20 backdrop-blur">
            {currentEvent.type === "spot" ? (
              <>
                <Zap className="mr-2 h-4 w-4" /> Spot Award
              </>
            ) : (
              <>
                <Award className="mr-2 h-4 w-4" /> Recognition Award
              </>
            )}
          </Badge>
          <h2 className="text-3xl font-bold mb-2">{currentEvent.title}</h2>
          <p className="text-muted-foreground">{currentEvent.description}</p>
        </div>
        <Button className="w-fit mt-4" onClick={() => onEventSelect(currentEvent.id)}>
          Take a challenge
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>

      {/* Access Card */}
      <div className="rounded-xl bg-primary p-6 text-primary-foreground flex flex-col justify-between group cursor-pointer hover:opacity-95 transition-opacity">
        <div className="flex justify-between items-start mb-4">
          <Trophy className="h-6 w-6" />
          <ArrowRight className="h-6 w-6 transition-transform group-hover:translate-x-1" />
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-2">{stageLabel}</h3>
          <p className="text-primary-foreground/80 text-sm">
            {currentEvent.currentStage === "nomination" && "Submit nominations for outstanding achievements"}
            {currentEvent.currentStage === "presentation" && "View nominee presentations"}
            {currentEvent.currentStage === "result" && "Celebrate the winners"}
          </p>
        </div>
      </div>

      {/* Progress Chart */}
      <div className="rounded-xl bg-card p-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h3 className="font-semibold mb-1">Stage Progress</h3>
            <p className="text-3xl font-bold">{stageProgress}%</p>
          </div>
          <div className="relative flex items-center justify-center">
            <div className="absolute w-16 h-16 rounded-full border-4 border-primary/20 flex items-center justify-center">
              <div className="text-center">
                <span className="block text-sm font-bold">
                  {timeRemaining.includes("day") ? timeRemaining.split(" ")[0] : "0"}
                </span>
                <span className="block text-xs text-muted-foreground">days</span>
              </div>
            </div>
          </div>
        </div>
        <div className="h-[100px] flex items-end">
          <div className="relative w-full h-[60px] bg-muted rounded-md overflow-hidden">
            <div
              className="absolute bottom-0 left-0 w-full bg-primary transition-all duration-500"
              style={{ height: `${stageProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="md:col-span-2 rounded-xl bg-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Event Details</h3>
          <CalendarDays className="h-5 w-5 text-muted-foreground" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Quarter</p>
            <p className="text-2xl font-bold">{currentEvent.quarter}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Theme</p>
            <p className="text-2xl font-bold">{currentEvent.theme || "General"}</p>
          </div>
        </div>
      </div>

      {/* Facilitators */}
      <div className="md:col-span-2 rounded-xl bg-card p-6">
        <h3 className="font-semibold mb-4">Facilitators</h3>
        <div className="flex items-center gap-4">
          <div className="flex -space-x-3">
            {currentEvent.facilitators?.slice(0, 5).map((facilitator) => (
              <Avatar key={facilitator.id} className="border-2 border-background">
                <AvatarImage
                  src={`/placeholder.svg?height=32&width=32&text=${facilitator.name[0]}`}
                  alt={facilitator.name}
                />
                <AvatarFallback>{facilitator.name[0]}</AvatarFallback>
              </Avatar>
            ))}
          </div>
          {currentEvent.facilitators && currentEvent.facilitators.length > 5 && (
            <Badge variant="secondary">+{currentEvent.facilitators.length - 5}</Badge>
          )}
        </div>
      </div>

      {/* Navigation */}
      {events.length > 1 && (
        <div className="col-span-full flex justify-center gap-2">
          {events.map((_, index) => (
            <button
              key={index}
              className={cn(
                "transition-all duration-300 ease-in-out",
                index === currentIndex
                  ? "h-2 w-8 rounded-full bg-primary"
                  : "h-2 w-2 rounded-full bg-muted hover:bg-primary/50",
              )}
              onClick={() => handleManualNavigation(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
