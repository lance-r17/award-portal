import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import Link from "next/link"

interface AwardTypeCardProps {
  title: string
  description: string
  icon: LucideIcon
  href: string
  color?: string
  iconColor?: string
}

export function AwardTypeCard({
  title,
  description,
  icon: Icon,
  href,
  color = "bg-muted",
  iconColor = "text-foreground",
}: AwardTypeCardProps) {
  return (
    <Link href={href}>
      <div className="rounded-lg border p-6 transition-all hover:border-primary hover:shadow-sm">
        <div className="flex items-start gap-4">
          <div className={cn("rounded-full p-2", color)}>
            <Icon className={cn("h-6 w-6", iconColor)} />
          </div>
          <div className="space-y-1">
            <h3 className="font-medium">{title}</h3>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
        </div>
      </div>
    </Link>
  )
}
