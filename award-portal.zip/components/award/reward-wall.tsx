"use client"

import React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Confetti } from "@/components/ui/confetti"
import { Trophy, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { AwardEvent } from "@/types/award-events"
import { getAwardEventById } from "@/data/award-events"
import { getWinningNominationsForEvent } from "@/data/mock-scores"
import { allAwardTypes } from "@/data/award-types"
import { mockUsers } from "@/data/mock-users"

interface RewardWallProps {
  eventId: string
  isResultStage: boolean
}

export function RewardWall({ eventId, isResultStage }: RewardWallProps) {
  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [winners, setWinners] = useState<Nomination[]>([])
  const [loading, setLoading] = useState(true)
  const [showConfetti, setShowConfetti] = useState(false)
  const [activeFilter, setActiveFilter] = useState<string>("all")
  const [expandedWinner, setExpandedWinner] = useState<Nomination | null>(null)

  useEffect(() => {
    const fetchEventAndWinners = async () => {
      setLoading(true)
      try {
        const eventData = await getAwardEventById(eventId)
        const winningNominations = await getWinningNominationsForEvent(eventId)
        setEvent(eventData)
        setWinners(winningNominations)
        if (isResultStage && winningNominations.length > 0) {
          setShowConfetti(true)
          setTimeout(() => setShowConfetti(false), 3000)
        }
      } catch (error) {
        console.error("Failed to fetch event or winners:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchEventAndWinners()
  }, [eventId, isResultStage])

  const filteredWinners = winners.filter((winner) => {
    if (activeFilter === "all") return winner.status === "awarded" || winner.status === "rewarded"
    return winner.nominationType === activeFilter && (winner.status === "awarded" || winner.status === "rewarded")
  })

  // Calculate individual and team award counts
  const individualAwardsCount = winners.filter((winner) => winner.nominationType === "individual").length
  const teamAwardsCount = winners.filter((winner) => winner.nominationType === "team").length

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse space-y-4">
          <div className="h-12 w-64 bg-muted rounded-lg"></div>
          <div className="h-4 w-48 bg-muted rounded-lg mx-auto"></div>
        </div>
      </div>
    )
  }

  if (!event || !isResultStage || winners.length === 0) {
    return (
      <div className="bg-orange-500 rounded-xl p-8 md:p-12 text-white">
        <div className="max-w-2xl mx-auto text-center">
          <Trophy className="h-16 w-16 mx-auto mb-6 opacity-80" />
          <h2 className="text-3xl font-bold mb-4">Results Coming Soon</h2>
          <p className="text-orange-100 text-lg">
            The winners for this award event will be announced once the event enters the result stage.
          </p>
        </div>
      </div>
    )
  }

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  // Get award type icon
  const getAwardTypeIcon = (awardType: string) => {
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award?.icon || Trophy
  }

  return (
    <div className="space-y-8">
      {showConfetti && <Confetti />}

      <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl p-8 md:p-12 text-white">
        <div className="max-w-2xl mx-auto text-center">
          <Trophy className="h-16 w-16 mx-auto mb-6 opacity-80" />
          <h2 className="text-3xl font-bold mb-4">Congratulations to Our Winners!</h2>
          <p className="text-orange-100 text-lg">
            Recognizing outstanding achievements and contributions that drive our success.
          </p>

          <div className="flex justify-center mt-8 gap-4">
            <div className="bg-white/20 rounded-lg p-4 flex-1 max-w-[150px]">
              <div className="text-3xl font-bold mb-1">{winners.length}</div>
              <div className="text-sm text-orange-100">Winners</div>
            </div>
            <div className="bg-white/20 rounded-lg p-4 flex-1 max-w-[150px]">
              <div className="text-3xl font-bold mb-1">{individualAwardsCount}</div>
              <div className="text-sm text-orange-100">Individual</div>
            </div>
            <div className="bg-white/20 rounded-lg p-4 flex-1 max-w-[150px]">
              <div className="text-3xl font-bold mb-1">{teamAwardsCount}</div>
              <div className="text-sm text-orange-100">Teams</div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center mb-8">
        <div className="inline-flex items-center gap-2 p-1 bg-gray-100 dark:bg-gray-800 rounded-full">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveFilter("all")}
            className={cn(
              "rounded-full px-4 text-sm",
              activeFilter === "all"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700",
            )}
          >
            All Winners
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveFilter("individual")}
            className={cn(
              "rounded-full px-4 text-sm",
              activeFilter === "individual"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700",
            )}
          >
            Individual
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveFilter("team")}
            className={cn(
              "rounded-full px-4 text-sm",
              activeFilter === "team"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700",
            )}
          >
            Team
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredWinners.map((winner) => {
          const isWinner = winner.status === "awarded" || winner.status === "rewarded"
          return (
            <Card
              key={winner.id}
              className={cn(
                "overflow-hidden transition-all duration-300",
                expandedWinner?.id === winner.id ? "col-span-full" : "",
              )}
            >
              <CardContent className="p-0">
                <div
                  className={cn(
                    "p-6 cursor-pointer",
                    expandedWinner?.id === winner.id ? "grid md:grid-cols-3 gap-6" : "",
                  )}
                  onClick={() => setExpandedWinner(expandedWinner?.id === winner.id ? null : winner)}
                >
                  <div className={expandedWinner?.id === winner.id ? "col-span-1" : ""}>
                    <div className="flex items-start justify-between mb-4">
                      <Badge
                        variant="outline"
                        className={cn(
                          "rounded-full",
                          winner.nominationType === "team"
                            ? "bg-purple-100 text-purple-700"
                            : "bg-blue-100 text-blue-700",
                        )}
                      >
                        {winner.nominationType === "team" ? "Team Award" : "Individual Award"}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="flex items-center gap-4 mb-4">
                      <div className="relative">
                        <Avatar className="h-16 w-16 rounded-full border-2 border-white shadow-md">
                          <AvatarImage src={winner.nominee?.avatar} alt={winner.nominee?.name} />
                          <AvatarFallback>{winner.nominee?.initials}</AvatarFallback>
                        </Avatar>
                        {isWinner && (
                          <div className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full p-1">
                            <Trophy className="h-4 w-4" />
                          </div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{winner.nominee?.name}</h3>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          {React.createElement(getAwardTypeIcon(winner.awardType), { className: "h-4 w-4 mr-1" })}
                          {getAwardTypeDisplay(winner.awardType)}
                        </div>
                      </div>
                    </div>
                  </div>

                  {expandedWinner?.id === winner.id ? (
                    <div className="col-span-2 space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Nomination Summary</h4>
                        <p className="text-muted-foreground">
                          {winner.nominationSummary ||
                            (winner.justification && winner.impact
                              ? `${winner.justification}\n\n${winner.impact}`
                              : winner.justification || winner.impact || "No summary provided")}
                        </p>
                      </div>

                      {winner.nominationType === "team" && winner.team && (
                        <div>
                          <h4 className="font-medium mb-2">Team Members</h4>
                          <div className="flex flex-wrap gap-2">
                            {winner.team.members?.map((memberId, index) => {
                              const memberData = mockUsers.find((user) => user.id === memberId)
                              return (
                                <div
                                  key={memberId || index}
                                  className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 rounded-full px-3 py-1"
                                >
                                  <Avatar className="h-6 w-6">
                                    <AvatarImage src={memberData?.avatar} alt={memberData?.name} />
                                    <AvatarFallback>{memberData?.initials}</AvatarFallback>
                                  </Avatar>
                                  <span className="text-sm">{memberData?.name}</span>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      )}

                      <div className="pt-4 flex justify-end">
                        <Button variant="outline" size="sm" className="gap-2">
                          <Trophy className="h-4 w-4" />
                          <span>Celebrate this achievement</span>
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-muted-foreground line-clamp-2">
                      {winner.nominationSummary || winner.justification || winner.impact || "No summary provided"}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

