"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Confetti } from "@/components/ui/confetti"
import { Trophy, Medal, Star, Info, Users, User } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { AwardEvent } from "@/types/award-events"
import { getAwardEventById } from "@/data/award-events"
import { getWinningNominationsForEvent } from "@/data/mock-scores"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"

interface RewardWallProps {
  eventId: string
  isResultStage: boolean
}

export function RewardWall({ eventId, isResultStage }: RewardWallProps) {
  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [winners, setWinners] = useState<Nomination[]>([])
  const [loading, setLoading] = useState(true)
  const [showConfetti, setShowConfetti] = useState(false)
  const [activeTab, setActiveTab] = useState<string>("all")

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const awardEvent = getAwardEventById(eventId)
        setEvent(awardEvent || null)

        if (awardEvent && awardEvent.currentStage === "result") {
          const winningNominations = getWinningNominationsForEvent(eventId)
          setWinners(winningNominations)

          // Show confetti animation when winners are loaded
          if (winningNominations.length > 0) {
            setShowConfetti(true)
            setTimeout(() => setShowConfetti(false), 5000) // Hide after 5 seconds
          }
        }
      } catch (error) {
        console.error("Error fetching reward wall data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId])

  // Group winners by award type
  const winnersByAwardType = winners.reduce(
    (acc, winner) => {
      if (!acc[winner.awardType]) {
        acc[winner.awardType] = []
      }
      acc[winner.awardType].push(winner)
      return acc
    },
    {} as Record<string, Nomination[]>,
  )

  // Get individual and team winners
  const individualWinners = winners.filter((winner) => winner.nominationType === "individual")
  const teamWinners = winners.filter((winner) => winner.nominationType === "team")

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Event Not Found</AlertTitle>
        <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
      </Alert>
    )
  }

  if (!isResultStage) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Results Not Available</AlertTitle>
        <AlertDescription>
          The results for this award event will be announced once the event enters the result stage.
        </AlertDescription>
      </Alert>
    )
  }

  if (winners.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Reward Wall</CardTitle>
          <CardDescription>Celebrating excellence and outstanding achievements</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>No Winners Announced Yet</AlertTitle>
            <AlertDescription>
              The winners for this award event have not been announced yet. Please check back later.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="overflow-hidden">
      {showConfetti && <Confetti />}

      <div className="bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 p-6 text-center">
        <Trophy className="h-16 w-16 text-primary mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-2">{event.title} - Winners</h2>
        <p className="text-muted-foreground">Celebrating excellence and outstanding achievements</p>
      </div>

      <CardContent className="p-6">
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="all">All Winners ({winners.length})</TabsTrigger>
            <TabsTrigger value="individual">Individual ({individualWinners.length})</TabsTrigger>
            <TabsTrigger value="team">Team ({teamWinners.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-8">
            {Object.entries(winnersByAwardType).map(([awardType, awardWinners]) => (
              <div key={awardType} className="space-y-4">
                <h3 className="text-xl font-semibold flex items-center">
                  <Medal className="h-5 w-5 text-amber-500 mr-2" />
                  {getAwardTypeDisplay(awardType)}
                </h3>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {awardWinners.map((winner, index) => (
                    <WinnerCard key={winner.id} nomination={winner} rank={index + 1} />
                  ))}
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="individual" className="space-y-8">
            {Object.entries(winnersByAwardType)
              .filter(([_, awardWinners]) => awardWinners[0].nominationType === "individual")
              .map(([awardType, awardWinners]) => (
                <div key={awardType} className="space-y-4">
                  <h3 className="text-xl font-semibold flex items-center">
                    <Medal className="h-5 w-5 text-amber-500 mr-2" />
                    {getAwardTypeDisplay(awardType)}
                  </h3>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {awardWinners.map((winner, index) => (
                      <WinnerCard key={winner.id} nomination={winner} rank={index + 1} />
                    ))}
                  </div>
                </div>
              ))}
          </TabsContent>

          <TabsContent value="team" className="space-y-8">
            {Object.entries(winnersByAwardType)
              .filter(([_, awardWinners]) => awardWinners[0].nominationType === "team")
              .map(([awardType, awardWinners]) => (
                <div key={awardType} className="space-y-4">
                  <h3 className="text-xl font-semibold flex items-center">
                    <Medal className="h-5 w-5 text-amber-500 mr-2" />
                    {getAwardTypeDisplay(awardType)}
                  </h3>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {awardWinners.map((winner, index) => (
                      <WinnerCard key={winner.id} nomination={winner} rank={index + 1} />
                    ))}
                  </div>
                </div>
              ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

interface WinnerCardProps {
  nomination: Nomination
  rank: number
}

function WinnerCard({ nomination, rank }: WinnerCardProps) {
  const isTeam = nomination.nominationType === "team"
  const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  return (
    <Card
      className={cn(
        "overflow-hidden transition-all hover:shadow-md",
        rank === 1 ? "border-amber-500 dark:border-amber-400" : "",
      )}
    >
      {rank === 1 && (
        <div className="bg-amber-500 text-white dark:bg-amber-600 py-1 px-3 text-center text-sm font-medium">
          Top Winner
        </div>
      )}
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className="relative">
            <Avatar className="h-16 w-16">
              <AvatarImage
                src={nomination.nominee?.avatar || "/placeholder.svg?height=64&width=64"}
                alt={nomination.nominee?.name || "Unknown"}
              />
              <AvatarFallback>{nomination.nominee?.initials || "??"}</AvatarFallback>
            </Avatar>
            {rank <= 3 && (
              <div
                className={cn(
                  "absolute -top-2 -right-2 rounded-full p-1.5",
                  rank === 1 ? "bg-amber-500" : rank === 2 ? "bg-zinc-400" : "bg-amber-700",
                )}
              >
                <Trophy className="h-3.5 w-3.5 text-white" />
              </div>
            )}
          </div>

          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <h3 className="font-medium">{nomination.nominee?.name || "Unknown"}</h3>
                <p className="text-sm text-muted-foreground">{formatServiceLine(nominationServiceLine)}</p>
              </div>
              <div className="flex flex-col items-start sm:items-end gap-1">
                <Badge variant={isTeam ? "outline" : "secondary"} className="whitespace-nowrap">
                  {isTeam ? <Users className="mr-1 h-3 w-3" /> : <User className="mr-1 h-3 w-3" />}
                  {isTeam ? "Team" : "Individual"}
                </Badge>
              </div>
            </div>

            <div className="mt-3">
              <p className="text-sm font-medium mb-1">Award:</p>
              <p className="text-sm flex items-center">
                <Star className="h-4 w-4 text-amber-500 mr-1" />
                {getAwardTypeDisplay(nomination.awardType)}
              </p>
            </div>

            <div className="mt-3">
              <p className="text-sm font-medium mb-1">Achievement:</p>
              <p className="text-sm text-muted-foreground line-clamp-3">
                {nomination.impact || nomination.justification || "Outstanding contribution"}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

