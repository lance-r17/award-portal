"use client"

import React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Confetti } from "@/components/ui/confetti"
import {
  Trophy,
  Star,
  Info,
  Users,
  User,
  Quote,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  Award,
  Heart,
  ThumbsUp,
  Lightbulb,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { AwardEvent } from "@/types/award-events"
import { getAwardEventById } from "@/data/award-events"
import { getWinningNominationsForEvent } from "@/data/mock-scores"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"

interface RewardWallProps {
  eventId: string
  isResultStage: boolean
}

export function RewardWall({ eventId, isResultStage }: RewardWallProps) {
  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [winners, setWinners] = useState<Nomination[]>([])
  const [loading, setLoading] = useState(true)
  const [showConfetti, setShowConfetti] = useState(false)
  const [activeTab, setActiveTab] = useState<string>("all")
  const [selectedWinner, setSelectedWinner] = useState<Nomination | null>(null)
  const [isStoryModalOpen, setIsStoryModalOpen] = useState(false)
  const [currentAwardType, setCurrentAwardType] = useState<string | null>(null)
  const [currentIndex, setCurrentIndex] = useState(0)
  const carouselRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const awardEvent = getAwardEventById(eventId)
        setEvent(awardEvent || null)

        if (awardEvent && awardEvent.currentStage === "result") {
          const winningNominations = getWinningNominationsForEvent(eventId)
          setWinners(winningNominations)

          // Show confetti animation when winners are loaded
          if (winningNominations.length > 0) {
            setShowConfetti(true)
            setTimeout(() => setShowConfetti(false), 5000) // Hide after 5 seconds
          }
        }
      } catch (error) {
        console.error("Error fetching reward wall data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId])

  // Group winners by award type
  const winnersByAwardType = winners.reduce(
    (acc, winner) => {
      if (!acc[winner.awardType]) {
        acc[winner.awardType] = []
      }
      acc[winner.awardType].push(winner)
      return acc
    },
    {} as Record<string, Nomination[]>,
  )

  // Get individual and team winners
  const individualWinners = winners.filter((winner) => winner.nominationType === "individual")
  const teamWinners = winners.filter((winner) => winner.nominationType === "team")

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  // Get award type icon
  const getAwardTypeIcon = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award?.icon || Trophy
  }

  // Get award type color
  const getAwardTypeColor = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award?.color || "bg-primary/20"
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Open story modal for a winner
  const openStoryModal = (winner: Nomination) => {
    setSelectedWinner(winner)
    setIsStoryModalOpen(true)
  }

  // Close story modal
  const closeStoryModal = () => {
    setIsStoryModalOpen(false)
    setTimeout(() => setSelectedWinner(null), 300) // Clear after animation completes
  }

  // Handle carousel navigation
  const handleNext = () => {
    if (!currentAwardType) return
    const awardWinners = winnersByAwardType[currentAwardType]
    setCurrentIndex((prev) => (prev + 1) % awardWinners.length)
  }

  const handlePrev = () => {
    if (!currentAwardType) return
    const awardWinners = winnersByAwardType[currentAwardType]
    setCurrentIndex((prev) => (prev - 1 + awardWinners.length) % awardWinners.length)
  }

  // Set current award type for carousel
  const setCarouselAwardType = (awardType: string) => {
    setCurrentAwardType(awardType)
    setCurrentIndex(0)
    // Scroll to carousel
    setTimeout(() => {
      carouselRef.current?.scrollIntoView({ behavior: "smooth", block: "center" })
    }, 100)
  }

  // Generate a random testimonial for storytelling
  const generateTestimonial = (nomination: Nomination) => {
    const testimonials = [
      `"${nomination.nominee.name}'s contribution has transformed how our team approaches challenges."`,
      `"The impact of ${nomination.nominee.name}'s work extends far beyond their immediate responsibilities."`,
      `"What makes ${nomination.nominee.name} exceptional is their ability to inspire others while delivering results."`,
      `"I've seen firsthand how ${nomination.nominee.name} has gone above and beyond expectations."`,
      `"${nomination.nominee.name} exemplifies the values and excellence we strive for as an organization."`,
    ]

    // Use nomination ID as a seed for consistent but seemingly random selection
    const seed = nomination.id.charCodeAt(0) % testimonials.length
    return testimonials[seed]
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Event Not Found</AlertTitle>
        <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
      </Alert>
    )
  }

  if (!isResultStage) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Results Not Available</AlertTitle>
        <AlertDescription>
          The results for this award event will be announced once the event enters the result stage.
        </AlertDescription>
      </Alert>
    )
  }

  if (winners.length === 0) {
    return (
      <div className="bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-900 dark:to-slate-800 rounded-lg p-8 text-center">
        <Trophy className="h-16 w-16 text-amber-500 mx-auto mb-4 opacity-50" />
        <h2 className="text-2xl font-bold mb-2">No Winners Announced Yet</h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          The winners for this award event have not been announced yet. Please check back later when the results are
          finalized.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {showConfetti && <Confetti />}

      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white">
        <div className="absolute inset-0 bg-black/10 z-0"></div>
        <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full"></div>
        <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full"></div>

        <div className="relative z-10 p-8 md:p-12 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Trophy className="h-20 w-20 text-amber-100 mx-auto mb-6" />
          </motion.div>

          <motion.h1
            className="text-3xl md:text-4xl font-bold mb-3"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {event.title} - Winners
          </motion.h1>

          <motion.p
            className="text-amber-100 max-w-2xl mx-auto"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            Celebrating excellence, innovation, and outstanding achievements that have made a significant impact on our
            organization.
          </motion.p>

          <motion.div
            className="flex flex-wrap justify-center gap-2 mt-6"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Badge className="bg-white/20 hover:bg-white/30 text-white border-none py-1.5">
              <Trophy className="mr-1 h-3.5 w-3.5" />
              {winners.length} Winners
            </Badge>
            <Badge className="bg-white/20 hover:bg-white/30 text-white border-none py-1.5">
              <User className="mr-1 h-3.5 w-3.5" />
              {individualWinners.length} Individual Awards
            </Badge>
            <Badge className="bg-white/20 hover:bg-white/30 text-white border-none py-1.5">
              <Users className="mr-1 h-3.5 w-3.5" />
              {teamWinners.length} Team Awards
            </Badge>
          </motion.div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="all" className="text-sm md:text-base">
            All Winners ({winners.length})
          </TabsTrigger>
          <TabsTrigger value="individual" className="text-sm md:text-base">
            Individual ({individualWinners.length})
          </TabsTrigger>
          <TabsTrigger value="team" className="text-sm md:text-base">
            Team ({teamWinners.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-12">
          {/* Featured Winner Carousel */}
          {currentAwardType && (
            <div
              ref={carouselRef}
              className="relative overflow-hidden rounded-xl bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-900 dark:to-slate-800 p-6 md:p-8"
            >
              <div className="absolute top-4 right-4 flex gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handlePrev}
                  className="rounded-full bg-white/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-700"
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleNext}
                  className="rounded-full bg-white/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-700"
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>

              <AnimatePresence mode="wait">
                {winnersByAwardType[currentAwardType] && winnersByAwardType[currentAwardType][currentIndex] && (
                  <motion.div
                    key={winnersByAwardType[currentAwardType][currentIndex].id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="flex flex-col md:flex-row gap-6 md:gap-10 items-center md:items-start"
                  >
                    <div className="relative">
                      <div
                        className={`absolute -inset-3 rounded-full ${getAwardTypeColor(currentAwardType)} blur-lg opacity-70`}
                      ></div>
                      <Avatar className="h-32 w-32 md:h-40 md:w-40 border-4 border-white dark:border-slate-800 relative">
                        <AvatarImage
                          src={
                            winnersByAwardType[currentAwardType][currentIndex].nominee?.avatar ||
                            "/placeholder.svg?height=160&width=160"
                          }
                          alt={winnersByAwardType[currentAwardType][currentIndex].nominee?.name || "Winner"}
                        />
                        <AvatarFallback className="text-3xl">
                          {winnersByAwardType[currentAwardType][currentIndex].nominee?.initials || "??"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -top-2 -right-2 bg-amber-500 text-white rounded-full p-2 shadow-lg">
                        <Trophy className="h-5 w-5" />
                      </div>
                    </div>

                    <div className="flex-1 text-center md:text-left">
                      <div className="inline-flex items-center gap-2 mb-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 text-sm">
                        {React.createElement(getAwardTypeIcon(currentAwardType), { className: "h-4 w-4" })}
                        <span>{getAwardTypeDisplay(currentAwardType)}</span>
                      </div>

                      <h2 className="text-2xl md:text-3xl font-bold mb-2">
                        {winnersByAwardType[currentAwardType][currentIndex].nominee?.name || "Outstanding Contributor"}
                      </h2>

                      <p className="text-muted-foreground mb-4">
                        {formatServiceLine(winnersByAwardType[currentAwardType][currentIndex].serviceLine || "")}
                      </p>

                      <div className="bg-white/60 dark:bg-slate-800/60 rounded-lg p-4 mb-4 relative">
                        <Quote className="absolute text-amber-200 dark:text-amber-900/30 h-8 w-8 -top-2 -left-2" />
                        <p className="italic text-slate-700 dark:text-slate-300">
                          {generateTestimonial(winnersByAwardType[currentAwardType][currentIndex])}
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-start gap-2">
                          <Lightbulb className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                          <p className="text-sm md:text-base">
                            <span className="font-medium">Achievement: </span>
                            {winnersByAwardType[currentAwardType][currentIndex].justification ||
                              "Recognized for exceptional contribution and outstanding performance."}
                          </p>
                        </div>

                        <div className="flex items-start gap-2">
                          <Heart className="h-5 w-5 text-rose-500 mt-0.5 flex-shrink-0" />
                          <p className="text-sm md:text-base">
                            <span className="font-medium">Impact: </span>
                            {winnersByAwardType[currentAwardType][currentIndex].impact ||
                              "Made a significant positive impact on team performance and business outcomes."}
                          </p>
                        </div>
                      </div>

                      <Button
                        className="mt-6 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-none"
                        onClick={() => openStoryModal(winnersByAwardType[currentAwardType][currentIndex])}
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        Read Full Story
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex justify-center mt-6">
                {winnersByAwardType[currentAwardType]?.map((_, index) => (
                  <button
                    key={index}
                    className={`h-2 w-2 rounded-full mx-1 ${
                      index === currentIndex ? "bg-amber-500" : "bg-slate-300 dark:bg-slate-600"
                    }`}
                    onClick={() => setCurrentIndex(index)}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Award Categories */}
          {Object.entries(winnersByAwardType).map(([awardType, awardWinners]) => (
            <div key={awardType} className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold flex items-center">
                  <div
                    className={`${getAwardTypeColor(awardType)} rounded-full p-2 flex items-center justify-center mr-2`}
                  >
                    {React.createElement(getAwardTypeIcon(awardType), { className: "h-6 w-6" })}
                  </div>
                  {getAwardTypeDisplay(awardType)}
                </h3>
                <Button variant="outline" size="sm" onClick={() => setCarouselAwardType(awardType)} className="text-xs">
                  <Sparkles className="mr-1 h-3 w-3" />
                  Feature Winners
                </Button>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {awardWinners.map((winner, index) => (
                  <StoryCard
                    key={winner.id}
                    nomination={winner}
                    rank={index + 1}
                    onClick={() => openStoryModal(winner)}
                  />
                ))}
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="individual" className="space-y-12">
          {Object.entries(winnersByAwardType)
            .filter(([_, awardWinners]) => awardWinners[0].nominationType === "individual")
            .map(([awardType, awardWinners]) => (
              <div key={awardType} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold flex items-center">
                    <div
                      className={`${getAwardTypeColor(awardType)} rounded-full p-2 flex items-center justify-center mr-2`}
                    >
                      {React.createElement(getAwardTypeIcon(awardType), { className: "h-6 w-6" })}
                    </div>
                    {getAwardTypeDisplay(awardType)}
                  </h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCarouselAwardType(awardType)}
                    className="text-xs"
                  >
                    <Sparkles className="mr-1 h-3 w-3" />
                    Feature Winners
                  </Button>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {awardWinners.map((winner, index) => (
                    <StoryCard
                      key={winner.id}
                      nomination={winner}
                      rank={index + 1}
                      onClick={() => openStoryModal(winner)}
                    />
                  ))}
                </div>
              </div>
            ))}
        </TabsContent>

        <TabsContent value="team" className="space-y-12">
          {Object.entries(winnersByAwardType)
            .filter(([_, awardWinners]) => awardWinners[0].nominationType === "team")
            .map(([awardType, awardWinners]) => (
              <div key={awardType} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold flex items-center">
                    <div
                      className={`${getAwardTypeColor(awardType)} rounded-full p-2 flex items-center justify-center mr-2`}
                    >
                      {React.createElement(getAwardTypeIcon(awardType), { className: "h-6 w-6" })}
                    </div>
                    {getAwardTypeDisplay(awardType)}
                  </h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCarouselAwardType(awardType)}
                    className="text-xs"
                  >
                    <Sparkles className="mr-1 h-3 w-3" />
                    Feature Winners
                  </Button>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {awardWinners.map((winner, index) => (
                    <StoryCard
                      key={winner.id}
                      nomination={winner}
                      rank={index + 1}
                      onClick={() => openStoryModal(winner)}
                    />
                  ))}
                </div>
              </div>
            ))}
        </TabsContent>
      </Tabs>

      {/* Story Modal */}
      <AnimatePresence>
        {isStoryModalOpen && selectedWinner && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={closeStoryModal}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-white dark:bg-slate-900 rounded-xl overflow-hidden max-w-3xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                <div className={`h-32 ${getAwardTypeColor(selectedWinner.awardType)}`}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-4 right-4 rounded-full bg-white/20 text-white hover:bg-white/30 z-10"
                    onClick={closeStoryModal}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                </div>

                <div className="px-6 md:px-8 pb-8 -mt-16">
                  <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
                    <Avatar className="h-32 w-32 border-4 border-white dark:border-slate-900 relative">
                      <AvatarImage
                        src={selectedWinner.nominee?.avatar || "/placeholder.svg?height=128&width=128"}
                        alt={selectedWinner.nominee?.name || "Winner"}
                      />
                      <AvatarFallback className="text-3xl">{selectedWinner.nominee?.initials || "??"}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1 text-center md:text-left">
                      <div className="inline-flex items-center gap-2 mb-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 text-sm">
                        {React.createElement(getAwardTypeIcon(selectedWinner.awardType), { className: "h-4 w-4" })}
                        <span>{getAwardTypeDisplay(selectedWinner.awardType)}</span>
                      </div>

                      <h2 className="text-2xl md:text-3xl font-bold mb-1">
                        {selectedWinner.nominee?.name || "Outstanding Contributor"}
                      </h2>

                      <p className="text-muted-foreground mb-2">
                        {formatServiceLine(selectedWinner.serviceLine || "")}
                      </p>

                      <div className="flex flex-wrap gap-2 mt-2">
                        <Badge
                          variant={selectedWinner.nominationType === "team" ? "outline" : "secondary"}
                          className="whitespace-nowrap"
                        >
                          {selectedWinner.nominationType === "team" ? (
                            <Users className="mr-1 h-3 w-3" />
                          ) : (
                            <User className="mr-1 h-3 w-3" />
                          )}
                          {selectedWinner.nominationType === "team" ? "Team Award" : "Individual Award"}
                        </Badge>

                        <Badge
                          variant="outline"
                          className="bg-amber-100/50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300 whitespace-nowrap"
                        >
                          <Trophy className="mr-1 h-3 w-3" />
                          Award Winner
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold flex items-center mb-3">
                        <Star className="h-5 w-5 text-amber-500 mr-2" />
                        The Achievement
                      </h3>
                      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                        <p>
                          {selectedWinner.justification ||
                            "Recognized for exceptional contribution and outstanding performance."}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold flex items-center mb-3">
                        <ThumbsUp className="h-5 w-5 text-amber-500 mr-2" />
                        Impact & Contribution
                      </h3>
                      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                        <p>
                          {selectedWinner.impact ||
                            "Made a significant positive impact on team performance and business outcomes through innovative solutions and dedicated effort."}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold flex items-center mb-3">
                        <Quote className="h-5 w-5 text-amber-500 mr-2" />
                        Testimonial
                      </h3>
                      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4 italic">
                        <p>{generateTestimonial(selectedWinner)}</p>
                        <p className="text-right mt-2 text-sm text-muted-foreground">
                          — {selectedWinner.nominator?.name || "Team Member"}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold flex items-center mb-3">
                        <Award className="h-5 w-5 text-amber-500 mr-2" />
                        Recognition
                      </h3>
                      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                        <p>
                          This achievement has been recognized for its exceptional value to the organization and
                          exemplifies the standards of excellence we strive for.
                        </p>
                        <div className="flex items-center justify-center mt-4">
                          <Trophy className="h-10 w-10 text-amber-500" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 flex justify-end">
                    <Button onClick={closeStoryModal}>Close</Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

interface StoryCardProps {
  nomination: Nomination
  rank: number
  onClick: () => void
}

function StoryCard({ nomination, rank, onClick }: StoryCardProps) {
  const isTeam = nomination.nominationType === "team"
  const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""
  const [isHovered, setIsHovered] = useState(false)

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
    const award = allAwardTypes.find((a) => a.id === awardType)
    return award ? award.title : awardType
  }

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  return (
    <motion.div whileHover={{ y: -5 }} transition={{ type: "spring", stiffness: 300, damping: 20 }}>
      <Card
        className={cn(
          "overflow-hidden transition-all duration-300 cursor-pointer h-full",
          isHovered ? "shadow-lg shadow-amber-200/20 dark:shadow-amber-900/20" : "shadow-md",
          "",
        )}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={onClick}
      >
        <CardContent className="p-0">
          <div className="relative">
            <div className="h-24 bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700"></div>
            <Avatar className="absolute left-4 -bottom-8 h-16 w-16 border-4 border-white dark:border-slate-900">
              <AvatarImage
                src={nomination.nominee?.avatar || "/placeholder.svg?height=64&width=64"}
                alt={nomination.nominee?.name || "Unknown"}
              />
              <AvatarFallback>{nomination.nominee?.initials || "??"}</AvatarFallback>
            </Avatar>
            {rank <= 3 && (
              <div
                className={cn(
                  "absolute top-3 right-3 rounded-full p-1.5 shadow-md",
                  rank === 1 ? "bg-amber-500" : rank === 2 ? "bg-zinc-400" : "bg-amber-700",
                )}
              >
                <Trophy className="h-3.5 w-3.5 text-white" />
              </div>
            )}
          </div>

          <div className="pt-10 px-4 pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
              <div>
                <h3 className="font-medium line-clamp-1">{nomination.nominee?.name || "Unknown"}</h3>
                <p className="text-xs text-muted-foreground">{formatServiceLine(nominationServiceLine)}</p>
              </div>
              <Badge variant={isTeam ? "outline" : "secondary"} className="whitespace-nowrap self-start">
                {isTeam ? <Users className="mr-1 h-3 w-3" /> : <User className="mr-1 h-3 w-3" />}
                {isTeam ? "Team" : "Individual"}
              </Badge>
            </div>

            <div className="mt-3">
              <p className="text-sm font-medium mb-1 flex items-center">
                <Star className="h-4 w-4 text-amber-500 mr-1 flex-shrink-0" />
                {getAwardTypeDisplay(nomination.awardType)}
              </p>
            </div>

            <div className="mt-3">
              <p className="text-xs text-muted-foreground line-clamp-3">
                {nomination.impact || nomination.justification || "Outstanding contribution"}
              </p>
            </div>

            <div
              className={cn(
                "mt-4 text-xs text-amber-600 dark:text-amber-400 font-medium transition-opacity duration-300",
                isHovered ? "opacity-100" : "opacity-0",
              )}
            >
              Read full story <ChevronRight className="inline h-3 w-3" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

