"use client"

import React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Confetti } from "@/components/ui/confetti"
import { Trophy, Users, User, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { AwardEvent } from "@/types/award-events"
import { getAwardEventById } from "@/data/award-events"
import { getWinningNominationsForEvent } from "@/data/mock-scores"
import { allAwardTypes } from "@/data/award-types"
import { mockUsers } from "@/data/mock-users"

// Add animation keyframes for card expansion
const expandAnimations = `
  @keyframes expandFromCenter {
    0% {
      opacity: 0.5;
      transform: scale(0.8);
    }
    100% {
      opacity: 1;
      transform: scale(1);
    }
  }
  
  @keyframes collapseToCenter {
    0% {
      opacity: 1;
      transform: scale(1);
    }
    100% {
      opacity: 0;
      transform: scale(0.8);
    }
  }
  
  .animate-expand-from-center {
    animation: expandFromCenter 0.5s ease-out forwards;
  }
  
  .animate-collapse-to-center {
    animation: collapseToCenter 0.5s ease-in forwards;
  }
`

interface RewardWallVariantProps {
  eventId: string
  isResultStage: boolean
}

// Pastel color palette for bento grid aligned with award type IDs
const awardTypeColors: { [key: string]: { bg: string; text: string; accent: string } } = {
  // Spot Individual Award Types
  "star-of-agile": {
    bg: "bg-blue-50 dark:bg-blue-950/40",
    text: "text-blue-700 dark:text-blue-300",
    accent: "bg-blue-100 dark:bg-blue-900/60",
  },
  "star-of-customer-service": {
    bg: "bg-green-50 dark:bg-green-950/40",
    text: "text-green-700 dark:text-green-300",
    accent: "bg-green-100 dark:bg-green-900/60",
  },
  "star-of-engagement": {
    bg: "bg-red-50 dark:bg-red-950/40",
    text: "text-red-700 dark:text-red-300",
    accent: "bg-red-100 dark:bg-red-900/60",
  },
  "star-of-innovation": {
    bg: "bg-amber-50 dark:bg-amber-950/40",
    text: "text-amber-700 dark:text-amber-300",
    accent: "bg-amber-100 dark:bg-amber-900/60",
  },
  "star-of-leadership": {
    bg: "bg-indigo-50 dark:bg-indigo-950/40",
    text: "text-indigo-700 dark:text-indigo-300",
    accent: "bg-indigo-100 dark:bg-indigo-900/60",
  },

  // Spot Team Award Type
  "all-star-team": {
    bg: "bg-purple-50 dark:bg-purple-950/40",
    text: "text-purple-700 dark:text-purple-300",
    accent: "bg-purple-100 dark:bg-purple-900/60",
  },

  // Recognition Award Types
  excellence: {
    bg: "bg-yellow-50 dark:bg-yellow-950/40",
    text: "text-yellow-700 dark:text-yellow-300",
    accent: "bg-yellow-100 dark:bg-yellow-900/60",
  },
  leadership: {
    bg: "bg-blue-50 dark:bg-blue-950/40",
    text: "text-blue-700 dark:text-blue-300",
    accent: "bg-blue-100 dark:bg-blue-900/60",
  },
  innovation: {
    bg: "bg-purple-50 dark:bg-purple-950/40",
    text: "text-purple-700 dark:text-purple-300",
    accent: "bg-purple-100 dark:bg-purple-900/60",
  },
  "values-champion": {
    bg: "bg-red-50 dark:bg-red-950/40",
    text: "text-red-700 dark:text-red-300",
    accent: "bg-red-100 dark:bg-red-900/60",
  },
  impact: {
    bg: "bg-green-50 dark:bg-green-950/40",
    text: "text-green-700 dark:text-green-300",
    accent: "bg-green-100 dark:bg-green-900/60",
  },
}

function getAwardColors(awardType: string) {
  return (
    awardTypeColors[awardType] || {
      bg: "bg-gray-50 dark:bg-gray-950/40",
      text: "text-gray-700 dark:text-gray-300",
      accent: "bg-gray-100 dark:bg-gray-900/60",
    }
  )
}

// Get award type icon
function getAwardTypeIcon(awardType: string) {
  const award = allAwardTypes.find((a) => a.id === awardType)
  return award?.icon || Trophy
}

// Get award type display name
function getAwardTypeDisplay(awardType: string) {
  const award = allAwardTypes.find((a) => a.id === awardType)
  return award ? award.title : awardType
}

export function RewardWallVariant({ eventId, isResultStage }: RewardWallVariantProps) {
  // Add this at the beginning of the component
  const [isClosing, setIsClosing] = useState(false)

  useEffect(() => {
    // Add the animation styles to the document
    const styleElement = document.createElement("style")
    styleElement.innerHTML = expandAnimations
    document.head.appendChild(styleElement)

    return () => {
      document.head.removeChild(styleElement)
    }
  }, [])

  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [winners, setWinners] = useState<Nomination[]>([])
  const [loading, setLoading] = useState(true)
  const [showConfetti, setShowConfetti] = useState(false)
  const [activeFilter, setActiveFilter] = useState<string>("all")
  const [expandedWinner, setExpandedWinner] = useState<Nomination | null>(null)

  useEffect(() => {
    const fetchEventAndWinners = async () => {
      setLoading(true)
      try {
        const eventData = await getAwardEventById(eventId)
        // Ensure getWinningNominationsForEvent returns nominations with "awarded" or "rewarded" status
        const winningNominations = await getWinningNominationsForEvent(eventId)
        setEvent(eventData)
        setWinners(winningNominations)
        if (isResultStage && winningNominations.length > 0) {
          setShowConfetti(true)
          setTimeout(() => setShowConfetti(false), 3000)
        }
      } catch (error) {
        console.error("Failed to fetch event or winners:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchEventAndWinners()
  }, [eventId, isResultStage])

  const filteredWinners = winners.filter((winner) => {
    if (activeFilter === "all") return winner.status === "awarded" || winner.status === "rewarded"
    return winner.nominationType === activeFilter && (winner.status === "awarded" || winner.status === "rewarded")
  })

  // Calculate individual and team award counts
  const individualAwardsCount = winners.filter((winner) => winner.nominationType === "individual").length
  const teamAwardsCount = winners.filter((winner) => winner.nominationType === "team").length

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse space-y-4">
          <div className="h-12 w-64 bg-muted rounded-lg"></div>
          <div className="h-4 w-48 bg-muted rounded-lg mx-auto"></div>
        </div>
      </div>
    )
  }

  if (!event || !isResultStage || winners.length === 0) {
    return (
      <div className="bg-orange-500 rounded-xl p-8 md:p-12 text-white">
        <div className="max-w-2xl mx-auto text-center">
          <Trophy className="h-16 w-16 mx-auto mb-6 opacity-80" />
          <h2 className="text-3xl font-bold mb-4">Results Coming Soon</h2>
          <p className="text-orange-100 text-lg">
            The winners for this award event will be announced once the event enters the result stage.
          </p>
        </div>
      </div>
    )
  }

  const isWinner = (nomination: Nomination) => nomination.status === "awarded" || nomination.status === "rewarded"

  return (
    <div className="space-y-12">
      {showConfetti && <Confetti />}

      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Celebrating
              <br />
              Excellence
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              Recognizing outstanding achievements and contributions that drive our success.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="bg-orange-100 dark:bg-orange-900/20 rounded-lg p-4 flex-1">
                <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-1">{winners.length}</div>
                <div className="text-sm text-orange-600/80 dark:text-orange-400/80">Winners</div>
              </div>
              <div className="bg-pink-100 dark:bg-pink-900/20 rounded-lg p-4 flex-1">
                <div className="text-3xl font-bold text-pink-600 dark:text-pink-400 mb-1">
                  {Object.keys(winners.reduce((acc, w) => ({ ...acc, [w.awardType]: true }), {})).length}
                </div>
                <div className="text-sm text-pink-600/80 dark:text-pink-400/80">Categories</div>
              </div>
            </div>
          </div>
          <div className="relative aspect-square">
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500 to-pink-500 rounded-3xl transform rotate-45">
              <div className="absolute inset-4 bg-white dark:bg-black rounded-2xl transform -rotate-45 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-orange-100 to-pink-100 dark:from-orange-900/20 dark:to-pink-900/20" />
                <Trophy className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-20 w-20 text-orange-500" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Navigation */}
      <div className="flex justify-center mb-8">
        <div className="inline-flex items-center gap-2 p-1 bg-gray-100 dark:bg-gray-800 rounded-full">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveFilter("all")}
            className={cn(
              "rounded-full px-4 text-sm",
              activeFilter === "all"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700",
            )}
          >
            All Winners
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveFilter("individual")}
            className={cn(
              "rounded-full px-4 text-sm",
              activeFilter === "individual"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700",
            )}
          >
            Individual
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveFilter("team")}
            className={cn(
              "rounded-full px-4 text-sm",
              activeFilter === "team"
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700",
            )}
          >
            Team
          </Button>
        </div>
      </div>

      {/* Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 transition-all duration-700 ease-in-out">
        {/* Expanded Winner Card */}
        {expandedWinner && (
          <Card
            key={`expanded-${expandedWinner.id}`}
            className={cn(
              "col-span-full overflow-hidden rounded-3xl border-0 relative transition-all duration-700 ease-in-out",
              getAwardColors(expandedWinner.awardType).bg,
              isClosing ? "animate-collapse-to-center" : "animate-expand-from-center",
            )}
            style={{ minHeight: "auto" }}
          >
            <CardContent
              className={cn(
                "p-8 flex flex-col md:flex-row gap-8 relative",
                "bg-gradient-to-br from-white/80 to-white/30 dark:from-black/20 dark:to-transparent",
              )}
              style={{ minHeight: "fit-content" }}
            >
              <div
                className={cn(
                  "absolute top-0 right-0 w-32 h-32 -mr-10 -mt-10 rounded-full opacity-20",
                  getAwardColors(expandedWinner.awardType).accent,
                )}
              ></div>

              <div className="flex flex-col items-center md:items-start gap-6 md:w-1/3 md:sticky md:top-6">
                <div className="flex justify-between w-full">
                  <Badge
                    variant="outline"
                    className={cn(
                      "rounded-full border-0 px-4 py-1 text-sm",
                      getAwardColors(expandedWinner.awardType).accent,
                      getAwardColors(expandedWinner.awardType).text,
                    )}
                  >
                    {expandedWinner.nominationType === "team" ? "Team Award" : "Individual Award"}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full hover:bg-white/20 transition-colors"
                    onClick={(e) => {
                      e.stopPropagation()
                      setIsClosing(true)
                      setTimeout(() => {
                        setExpandedWinner(null)
                        setIsClosing(false)
                      }, 500) // Match animation duration
                    }}
                  >
                    ✕
                  </Button>
                </div>

                <div className="relative">
                  <div
                    className={cn(
                      "absolute -inset-1 rounded-full blur-sm opacity-70",
                      getAwardColors(expandedWinner.awardType).accent,
                    )}
                  ></div>
                  <Avatar className="h-28 w-28 rounded-full border-4 border-white dark:border-gray-800 relative">
                    <AvatarImage src={expandedWinner.nominee?.avatar} alt={expandedWinner.nominee?.name} />
                    <AvatarFallback>{expandedWinner.nominee?.initials}</AvatarFallback>
                  </Avatar>
                </div>

                <div className="text-center md:text-left space-y-2">
                  <h3 className={cn("text-2xl font-bold", getAwardColors(expandedWinner.awardType).text)}>
                    {expandedWinner.nominee?.name}
                  </h3>
                  <div className="flex items-center gap-2 justify-center md:justify-start">
                    {React.createElement(getAwardTypeIcon(expandedWinner.awardType), {
                      className: cn("h-5 w-5", getAwardColors(expandedWinner.awardType).text),
                    })}
                    <span className={cn("text-sm font-medium", getAwardColors(expandedWinner.awardType).text)}>
                      {getAwardTypeDisplay(expandedWinner.awardType)}
                    </span>
                  </div>
                </div>

                <div className={cn("w-full rounded-xl p-4 mt-2", getAwardColors(expandedWinner.awardType).accent)}>
                  <div className="text-sm font-medium mb-1">Achievement Highlights</div>
                  <ul className="text-sm space-y-1 list-disc list-inside">
                    <li>Outstanding performance</li>
                    <li>Team collaboration</li>
                    <li>Innovative solutions</li>
                  </ul>
                </div>
              </div>

              <div className="flex-1 space-y-8 py-2 md:pl-8 md:border-l border-gray-200 dark:border-gray-800">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        "h-8 w-8 rounded-full flex items-center justify-center",
                        getAwardColors(expandedWinner.awardType).accent,
                      )}
                    >
                      <span className="text-lg font-bold">1</span>
                    </div>
                    <h4 className="text-lg font-semibold">The Challenge</h4>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">
                    Every great achievement begins with a challenge. {expandedWinner.nominee?.name} faced significant
                    obstacles that required exceptional skills to overcome.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        "h-8 w-8 rounded-full flex items-center justify-center",
                        getAwardColors(expandedWinner.awardType).accent,
                      )}
                    >
                      <span className="text-lg font-bold">2</span>
                    </div>
                    <h4 className="text-lg font-semibold">The Impact</h4>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">
                    {expandedWinner.impact ||
                      "Through dedication and expertise, they created remarkable results that benefited the entire organization."}
                  </p>
                  <blockquote
                    className={cn(
                      "border-l-4 pl-4 italic my-4",
                      `border-${getAwardColors(expandedWinner.awardType).text.split("-")[1]}-400`,
                    )}
                  >
                    "Excellence is not a skill. It's an attitude."
                  </blockquote>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        "h-8 w-8 rounded-full flex items-center justify-center",
                        getAwardColors(expandedWinner.awardType).accent,
                      )}
                    >
                      <span className="text-lg font-bold">3</span>
                    </div>
                    <h4 className="text-lg font-semibold">Why They Won</h4>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">
                    {expandedWinner.justification ||
                      "Their exceptional contribution stood out among peers, demonstrating the values we celebrate."}
                  </p>
                </div>

                {expandedWinner.nominationType === "team" && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div
                        className={cn(
                          "h-8 w-8 rounded-full flex items-center justify-center",
                          getAwardColors(expandedWinner.awardType).accent,
                        )}
                      >
                        <span className="text-lg font-bold">4</span>
                      </div>
                      <h4 className="text-lg font-semibold">The Team</h4>
                    </div>
                    <p className="text-muted-foreground">
                      Great achievements are often the result of exceptional teamwork. This award recognizes the
                      collective effort of dedicated professionals working together.
                    </p>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {expandedWinner.team && expandedWinner.team.members ? (
                        expandedWinner.team.members.map((memberId, index) => {
                          // Find the user data from mockUsers or create a consistent fallback
                          const memberData = mockUsers.find((user) => user.id === memberId)

                          // If member not found, create consistent fallback data based on the ID
                          const fallbackName = memberId
                            .split("-")
                            .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
                            .join(" ")

                          const fallbackInitials = memberId
                            .split("-")
                            .map((part) => part.charAt(0).toUpperCase())
                            .join("")

                          return (
                            <div
                              key={memberId || index}
                              className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 rounded-full px-3 py-1"
                            >
                              <Avatar className="h-6 w-6 rounded-full">
                                <AvatarImage
                                  src={
                                    memberData?.avatar || `/placeholder.svg?height=24&width=24&text=${fallbackInitials}`
                                  }
                                  alt={memberData?.name || fallbackName}
                                />
                                <AvatarFallback>{memberData?.initials || fallbackInitials}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm">{memberData?.name || fallbackName}</span>
                            </div>
                          )
                        })
                      ) : (
                        // Fallback if team members data is not available
                        <div className="text-sm text-muted-foreground italic">
                          This team consists of multiple talented individuals working together to achieve excellence.
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div className="pt-4 flex justify-end">
                  <Button
                    variant="outline"
                    className={cn("rounded-full gap-2", getAwardColors(expandedWinner.awardType).text)}
                  >
                    <Trophy className="h-4 w-4" />
                    <span>Celebrate this achievement</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Featured Winner - Large Card */}
        {(() => {
          const displayWinners = filteredWinners.filter((winner) => !expandedWinner || winner.id !== expandedWinner.id)
          return displayWinners.slice(0, 1).map((winner) => {
            const isWinnerCard = isWinner(winner)
            return (
              <Card
                key={`featured-${winner.id}`}
                className={cn(
                  "row-span-2 col-span-2 overflow-hidden rounded-3xl border-0 relative group cursor-pointer transition-all duration-300 h-[400px] hover:shadow-lg",
                  getAwardColors(winner.awardType).bg,
                  "transform transition-transform duration-300 hover:scale-[1.02]",
                )}
                onClick={() => {
                  if (expandedWinner?.id === winner.id) {
                    setExpandedWinner(null)
                  } else {
                    setExpandedWinner(winner)
                  }
                }}
              >
                <CardContent
                  className={cn(
                    "p-6 h-full flex flex-col relative",
                    "bg-gradient-to-br from-white/80 to-white/30 dark:from-black/20 dark:to-transparent",
                  )}
                >
                  <div
                    className={cn(
                      "absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full opacity-20",
                      getAwardColors(winner.awardType).accent,
                    )}
                  ></div>
                  <div className="flex items-start justify-between mb-4">
                    <Badge
                      variant="outline"
                      className={cn(
                        "rounded-full border-0",
                        getAwardColors(winner.awardType).accent,
                        getAwardColors(winner.awardType).text,
                      )}
                    >
                      Featured Winner
                    </Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      className={cn(
                        "rounded-full opacity-0 group-hover:opacity-100 transition-opacity",
                        getAwardColors(winner.awardType).text,
                      )}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex-1 flex items-center">
                    <div className="space-y-4">
                      <div className="relative">
                        <Avatar className="h-24 w-24 rounded-full border-4 border-white dark:border-gray-800">
                          <AvatarImage src={winner.nominee?.avatar} alt={winner.nominee?.name} />
                          <AvatarFallback>{winner.nominee?.initials}</AvatarFallback>
                        </Avatar>
                      </div>
                      <div>
                        <h3 className={cn("text-2xl font-bold mb-2", getAwardColors(winner.awardType).text)}>
                          {winner.nominee?.name}
                        </h3>
                        <p className="text-muted-foreground line-clamp-2">{winner.justification}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-4">
                    {React.createElement(getAwardTypeIcon(winner.awardType), {
                      className: cn("h-4 w-4", getAwardColors(winner.awardType).text),
                    })}
                    <span className={cn("text-sm font-medium", getAwardColors(winner.awardType).text)}>
                      {getAwardTypeDisplay(winner.awardType)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            )
          })
        })()}

        {/* Stats Card */}
        <Card className="overflow-hidden rounded-3xl border-0 bg-gradient-to-br from-orange-100 to-amber-50 dark:from-orange-950/40 dark:to-amber-950/30 h-[200px]">
          <CardContent className="p-6 h-full flex flex-col justify-between">
            <h3 className="text-lg font-semibold text-orange-900 dark:text-orange-100">Award Distribution</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col items-center">
                <User className="h-8 w-8 text-orange-600 dark:text-orange-400 mb-2" />
                <div className="text-3xl font-bold text-orange-600 dark:text-orange-400">{individualAwardsCount}</div>
                <div className="text-sm text-orange-700/70 dark:text-orange-300/70 text-center">Individual Awards</div>
              </div>
              <div className="flex flex-col items-center">
                <Users className="h-8 w-8 text-orange-600 dark:text-orange-400 mb-2" />
                <div className="text-3xl font-bold text-orange-600 dark:text-orange-400">{teamAwardsCount}</div>
                <div className="text-sm text-orange-700/70 dark:text-orange-300/70 text-center">Team Awards</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Regular Winner Cards */}
        {(() => {
          const displayWinners = filteredWinners.filter((winner) => !expandedWinner || winner.id !== expandedWinner.id)
          return displayWinners.slice(1).map((winner) => {
            const isWinnerCard = isWinner(winner)
            return (
              <Card
                key={winner.id}
                className={cn(
                  "overflow-hidden rounded-3xl border-0 relative group cursor-pointer transition-all duration-300 h-[200px] hover:shadow-lg",
                  getAwardColors(winner.awardType).bg,
                  "transform transition-transform duration-300 hover:scale-[1.02]",
                )}
                onClick={() => {
                  if (expandedWinner?.id === winner.id) {
                    setExpandedWinner(null)
                  } else {
                    setExpandedWinner(winner)
                  }
                }}
              >
                <CardContent
                  className={cn(
                    "p-6 h-full flex flex-col relative transition-all duration-500 ease-in-out",
                    "bg-gradient-to-br from-white/80 to-white/30 dark:from-black/20 dark:to-transparent",
                  )}
                >
                  <div
                    className={cn(
                      "absolute top-0 right-0 w-16 h-16 -mr-6 -mt-6 rounded-full opacity-20",
                      getAwardColors(winner.awardType).accent,
                    )}
                  ></div>
                  <div className="flex items-start justify-between">
                    <div className="relative">
                      <Avatar className="h-12 w-12 rounded-full border-2 border-white dark:border-gray-800">
                        <AvatarImage src={winner.nominee?.avatar} alt={winner.nominee?.name} />
                        <AvatarFallback>{winner.nominee?.initials}</AvatarFallback>
                      </Avatar>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className={cn(
                        "rounded-full opacity-0 group-hover:opacity-100 transition-opacity",
                        getAwardColors(winner.awardType).text,
                      )}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex-1 flex flex-col justify-center">
                    <h3 className={cn("font-semibold mb-1", getAwardColors(winner.awardType).text)}>
                      {winner.nominee?.name}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">{winner.justification}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    {React.createElement(getAwardTypeIcon(winner.awardType), {
                      className: cn("h-4 w-4", getAwardColors(winner.awardType).text),
                    })}
                    <span className={cn("text-sm", getAwardColors(winner.awardType).text)}>
                      {getAwardTypeDisplay(winner.awardType)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            )
          })
        })()}
      </div>
    </div>
  )
}

