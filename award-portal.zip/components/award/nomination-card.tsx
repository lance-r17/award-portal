"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { CheckCircle, Clock, XCircle, Edit } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import { getAwardTypeDisplay } from "@/data/award-types"
import { Button } from "@/components/ui/button"

interface NominationCardProps {
  nomination: Nomination
  onClick?: () => void
  canEdit: boolean
  onEdit?: () => void
}

export function NominationCard({ nomination, onClick, canEdit, onEdit }: NominationCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  // Remove the local getAwardTypeDisplay function

  // Format service line for display
  const formatServiceLine = (line: string) => {
    if (!line) return "Unknown"
    return line
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Get endorsement status badge
  const getEndorsementBadge = () => {
    if (!nomination.endorsement) {
      return (
        <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300">
          <Clock className="mr-1 h-3 w-3" />
          Pending Endorsement
        </Badge>
      )
    }

    switch (nomination.endorsement.status) {
      case "endorsed":
        return (
          <Badge variant="outline" className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300">
            <CheckCircle className="mr-1 h-3 w-3" />
            Endorsed
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300">
            <XCircle className="mr-1 h-3 w-3" />
            Endorsement Declined
          </Badge>
        )
      case "pending":
      default:
        return (
          <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300">
            <Clock className="mr-1 h-3 w-3" />
            Pending Endorsement
          </Badge>
        )
    }
  }

  return (
    <Card
      className={cn(
        "overflow-hidden transition-all duration-200",
        isHovered ? "shadow-md" : "shadow-sm",
        onClick && "cursor-pointer",
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
    >
      <div className="relative">
        {/* Award Type Badge */}
        <div className="absolute top-2 right-2 z-10">
          <Badge
            variant="secondary"
            className={cn(
              "text-xs",
              nomination.nominationType === "team" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800",
              "dark:bg-opacity-20 dark:text-opacity-90",
            )}
          >
            {nomination.nominationType === "team" ? "Team" : "Individual"}
          </Badge>
        </div>

        {/* Card Content */}
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
              <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-sm truncate">{nomination.nominee.name}</h3>
              <p className="text-xs text-muted-foreground">{formatServiceLine(nomination.serviceLine)}</p>
              <p className="text-xs font-medium mt-1">{getAwardTypeDisplay(nomination.awardType)}</p>
            </div>
          </div>

          <div className="mt-3">
            <p className="text-xs text-muted-foreground line-clamp-3">{nomination.justification}</p>
          </div>
        </CardContent>

        <CardFooter className="px-4 py-3 bg-muted/30 flex flex-col items-start">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-1">
              <Avatar className="h-5 w-5">
                <AvatarImage src={nomination.nominator.avatar} alt={nomination.nominator.name} />
                <AvatarFallback className="text-[10px]">{nomination.nominator.initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">
                Nominated by <span className="font-medium">{nomination.nominator.name.split(" ")[0]}</span>
              </span>
            </div>
            {canEdit && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation()
                  onEdit?.()
                }}
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
            )}
          </div>

          {/* Endorsement Status */}
          <div className="mt-2 w-full">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="w-full">{getEndorsementBadge()}</div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Domain Manager Endorsement Status</p>
                  {nomination.endorsement?.endorsedBy && (
                    <p className="text-xs mt-1">
                      {nomination.endorsement.status === "endorsed" ? "Endorsed by" : "Reviewed by"}:{" "}
                      {nomination.endorsement.endorsedBy}
                    </p>
                  )}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardFooter>
      </div>
    </Card>
  )
}

