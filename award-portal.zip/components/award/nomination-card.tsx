"use client"

import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CheckCircle, Clock, XCircle, Edit, ThumbsUp, MessageSquare, Send, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import { getAwardTypeDisplay } from "@/data/award-types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useUser } from "@/contexts/user-context"
import Link from "next/link"
import { keyframes } from "@emotion/react"

const sparkle = keyframes`
  0% { transform: scale(0); opacity: 0; }
  50% { transform: scale(1); opacity: 1; }
  100% { transform: scale(1.5); opacity: 0; }
`

const sparkleStyles = {
  position: "absolute",
  width: "100%",
  height: "100%",
  borderRadius: "50%",
  background: "radial-gradient(circle, rgba(59,130,246,0.8) 0%, rgba(59,130,246,0) 70%)",
  animation: `${sparkle} 0.5s ease-out forwards`,
  pointerEvents: "none",
}

interface NominationCardProps {
  nomination: Nomination
  onClick?: () => void
  canEdit: boolean
  onEdit?: () => void
  onVote?: (nominationId: string, userId: string, userName: string) => void
  onComment?: (
    nominationId: string,
    userId: string,
    userName: string,
    userAvatar: string,
    userInitials: string,
    comment: string,
  ) => void
  eventId?: string // Add this prop
}

export function NominationCard({
  nomination,
  onClick,
  canEdit,
  onEdit,
  onVote,
  onComment,
  eventId,
}: NominationCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [commentText, setCommentText] = useState("")
  const [showComments, setShowComments] = useState(false)
  const { user } = useUser()
  const [isAnimating, setIsAnimating] = useState(false)

  // Format service line for display
  const formatServiceLine = (line: string | string[]) => {
    if (!line) return "Unknown"

    // Handle both string and array formats
    if (Array.isArray(line)) {
      if (line.length === 0) return "Unknown"

      // Format the first service line for display in the card
      // We'll only show the first one to save space
      const firstLine = line[0]
      return firstLine
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
    } else {
      // Handle legacy string format
      return line
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
    }
  }

  // Get a formatted list of all service lines for tooltip
  const getAllServiceLines = (lines: string | string[]) => {
    if (!lines) return ["Unknown"]

    if (Array.isArray(lines)) {
      if (lines.length === 0) return ["Unknown"]

      return lines.map((line) =>
        line
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" "),
      )
    } else {
      // Handle legacy string format
      return [
        lines
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" "),
      ]
    }
  }

  // Get endorsement status badge
  const getEndorsementBadge = () => {
    if (!nomination.endorsement) {
      return (
        <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300">
          <Clock className="mr-1 h-3 w-3" />
          Pending Endorsement
        </Badge>
      )
    }

    switch (nomination.endorsement.status) {
      case "endorsed":
        return (
          <Badge variant="outline" className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300">
            <CheckCircle className="mr-1 h-3 w-3" />
            Endorsed
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300">
            <XCircle className="mr-1 h-3 w-3" />
            Endorsement Declined
          </Badge>
        )
      case "pending":
      default:
        return (
          <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300">
            <Clock className="mr-1 h-3 w-3" />
            Pending Endorsement
          </Badge>
        )
    }
  }

  // Check if the current user has already voted
  const hasUserVoted = () => {
    if (!user || !nomination.votes) return false
    return nomination.votes.some((vote) => vote.userId === user.id)
  }

  // Handle voting with particle animation
  const handleVote = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!user || user.roles?.includes("anonymous") || !onVote) return

    if (!hasUserVoted()) {
      setIsAnimating(true)
      onVote(nomination.id, user.id, user.name)

      // Create particles
      createParticles(e)

      // Reset animation state after animation completes
      setTimeout(() => setIsAnimating(false), 800)
    }
  }

  // Create thumbs-up particles
  const createParticles = (e: React.MouseEvent) => {
    const button = e.currentTarget as HTMLButtonElement
    const rect = button.getBoundingClientRect()
    const x = rect.left + rect.width / 2
    const y = rect.top + rect.height / 2

    // Create container for particles if it doesn't exist
    let container = document.getElementById("particle-container")
    if (!container) {
      container = document.createElement("div")
      container.id = "particle-container"
      container.style.position = "fixed"
      container.style.top = "0"
      container.style.left = "0"
      container.style.width = "100%"
      container.style.height = "100%"
      container.style.pointerEvents = "none"
      container.style.zIndex = "9999"
      document.body.appendChild(container)
    }

    // Create 8 particles
    for (let i = 0; i < 8; i++) {
      const particle = document.createElement("div")

      // Style the particle
      particle.innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" class="lucide lucide-thumbs-up"><path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"/></svg>'
      particle.style.position = "absolute"
      particle.style.left = `${x}px`
      particle.style.top = `${y}px`
      particle.style.color = "#3b82f6" // Blue color
      particle.style.transform = "translate(-50%, -50%)"
      particle.style.opacity = "1"
      particle.style.transition = "all 0.8s cubic-bezier(0.165, 0.84, 0.44, 1)"

      // Add to container
      container.appendChild(particle)

      // Trigger animation in the next frame
      setTimeout(() => {
        // Random direction and distance
        const angle = i * 45 + Math.random() * 30
        const distance = 40 + Math.random() * 60
        const translateX = Math.cos((angle * Math.PI) / 180) * distance
        const translateY = Math.sin((angle * Math.PI) / 180) * distance

        // Apply animation
        particle.style.transform = `translate(calc(-50% + ${translateX}px), calc(-50% + ${translateY}px)) scale(${Math.random() * 0.4 + 0.6})`
        particle.style.opacity = "0"
      }, 10)

      // Remove particle after animation
      setTimeout(() => {
        if (container.contains(particle)) {
          container.removeChild(particle)
        }

        // Remove container if empty
        if (container.childElementCount === 0) {
          document.body.removeChild(container)
        }
      }, 800)
    }
  }

  // Handle comment submission
  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (!user || user.roles?.includes("anonymous") || !commentText.trim() || !onComment) return

    onComment(
      nomination.id,
      user.id,
      user.name,
      user.avatar || "/placeholder.svg?height=40&width=40",
      user.initials ||
        user.name
          .split(" ")
          .map((n) => n[0])
          .join(""),
      commentText.trim(),
    )

    setCommentText("")
  }

  // Format date for display
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Helper function to normalize supportingInfo to an array
  const getSupportingInfoArray = () => {
    if (!nomination.supportingInfo) return []
    if (Array.isArray(nomination.supportingInfo)) return nomination.supportingInfo
    return [nomination.supportingInfo] // Convert string to array with single item
  }

  return (
    <TooltipProvider>
      <Card
        className={cn(
          "overflow-hidden transition-all duration-200",
          isHovered ? "shadow-md" : "shadow-sm",
          onClick && "cursor-pointer",
        )}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={onClick}
      >
        <div className="relative">
          {/* Award Type Badge */}
          <div className="absolute top-2 right-2 z-10">
            <Badge
              variant="secondary"
              className={cn(
                "text-xs",
                nomination.nominationType === "team" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800",
                "dark:bg-opacity-20 dark:text-opacity-90",
              )}
            >
              {nomination.nominationType === "team" ? "Team" : "Individual"}
            </Badge>
          </div>
          {eventId && (
            <div className="absolute top-2 right-24 z-10">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href={`/awards/spot-awards/${eventId}/noms/${nomination.id}`}
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors"
                  >
                    <ExternalLink className="h-3.5 w-3.5 text-primary" />
                    <span className="sr-only">View Portfolio</span>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs">View Full Portfolio</p>
                </TooltipContent>
              </Tooltip>
            </div>
          )}

          {/* Card Content */}
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
                <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-sm truncate">{nomination.nominee.name}</h3>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <p className="text-xs text-muted-foreground">
                      {formatServiceLine(nomination.serviceLine)}
                      {Array.isArray(nomination.serviceLine) &&
                        nomination.serviceLine.length > 1 &&
                        ` +${nomination.serviceLine.length - 1} more`}
                    </p>
                  </TooltipTrigger>
                  {Array.isArray(nomination.serviceLine) && nomination.serviceLine.length > 1 && (
                    <TooltipContent>
                      <p className="text-xs font-medium">Service Lines:</p>
                      <ul className="text-xs mt-1">
                        {getAllServiceLines(nomination.serviceLine).map((line, index) => (
                          <li key={index}>{line}</li>
                        ))}
                      </ul>
                    </TooltipContent>
                  )}
                </Tooltip>
                <p className="text-xs font-medium mt-1">{getAwardTypeDisplay(nomination.awardType)}</p>
              </div>
            </div>

            <div className="mt-3">
              <p className="text-xs text-muted-foreground line-clamp-3">
                {nomination.nominationSummary || nomination.justification}
              </p>
            </div>

            {/* Supporting Info Section - Handle both string and array formats */}
            {nomination.supportingInfo && (
              <div className="mt-3">
                <p className="text-xs font-medium mb-1">Supporting Information:</p>
                <ul className="space-y-1">
                  {getSupportingInfoArray().map((info, index) => (
                    <li key={index}>
                      <a
                        href={info}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-primary hover:underline flex items-center gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <ExternalLink className="h-3 w-3" />
                        <span className="truncate">{info}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>

          <CardFooter className="px-4 py-3 bg-muted/30 flex flex-col items-start">
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-1">
                <Avatar className="h-5 w-5">
                  <AvatarImage src={nomination.nominator.avatar} alt={nomination.nominator.name} />
                  <AvatarFallback className="text-[10px]">{nomination.nominator.initials}</AvatarFallback>
                </Avatar>
                <span className="text-xs text-muted-foreground">
                  Nominated by <span className="font-medium">{nomination.nominator.name.split(" ")[0]}</span>
                </span>
              </div>
              {canEdit && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation()
                    onEdit?.()
                  }}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              )}
            </div>

            {/* Endorsement Status */}
            <div className="mt-2 w-full">
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="w-full">{getEndorsementBadge()}</div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Domain Manager Endorsement Status</p>
                  {nomination.endorsement?.endorsedBy && (
                    <p className="text-xs mt-1">
                      {nomination.endorsement.status === "endorsed" ? "Endorsed by" : "Reviewed by"}:{" "}
                      {nomination.endorsement.endorsedBy}
                    </p>
                  )}
                </TooltipContent>
              </Tooltip>
            </div>

            {/* Voting and Comments Section */}
            <div className="mt-3 w-full border-t pt-2 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={cn(
                      "flex items-center gap-1 px-2 h-7 relative",
                      hasUserVoted() && "text-blue-600 dark:text-blue-400",
                    )}
                    disabled={user?.roles?.includes("anonymous") || hasUserVoted()}
                    onClick={handleVote}
                  >
                    <ThumbsUp
                      className={cn(
                        "h-3.5 w-3.5 relative z-10",
                        isAnimating && "scale-150 text-blue-600 dark:text-blue-400 transition-all duration-300",
                      )}
                    />
                    <span className={cn("text-xs", isAnimating && "scale-125 transition-all duration-300")}>
                      {nomination.votes?.length || 0}
                    </span>
                  </Button>

                  <Popover>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <PopoverTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="flex items-center gap-1 px-2 h-7"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MessageSquare className="h-3.5 w-3.5" />
                            <span className="text-xs">{nomination.comments?.length || 0}</span>
                          </Button>
                        </PopoverTrigger>
                      </TooltipTrigger>
                      <TooltipContent side="top" align="center" className="w-80 p-3">
                        <div className="space-y-2">
                          <h4 className="font-medium text-sm">Recent Comments</h4>
                          <div className="max-h-48 overflow-y-auto space-y-2">
                            {nomination.comments && nomination.comments.length > 0 ? (
                              nomination.comments.slice(0, 5).map((comment) => (
                                <div key={comment.id} className="flex gap-2 text-xs">
                                  <Avatar className="h-5 w-5">
                                    <AvatarImage src={comment.userAvatar} alt={comment.userName} />
                                    <AvatarFallback className="text-[8px]">{comment.userInitials}</AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between">
                                      <span className="font-medium">{comment.userName}</span>
                                      <span className="text-[10px] text-muted-foreground">
                                        {new Date(comment.timestamp).toLocaleDateString()}
                                      </span>
                                    </div>
                                    <p className="text-xs">{comment.text}</p>
                                  </div>
                                </div>
                              ))
                            ) : (
                              <div className="text-center text-xs text-muted-foreground py-2">No comments yet</div>
                            )}
                            {nomination.comments && nomination.comments.length > 5 && (
                              <div className="text-xs text-center">
                                <span className="text-muted-foreground">
                                  +{nomination.comments.length - 5} more comments
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                    <PopoverContent className="w-80" align="start" side="top">
                      <div className="space-y-4">
                        {nomination.comments && nomination.comments.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">Recent Comments</h4>
                            <ScrollArea className="h-[120px]">
                              <div className="space-y-2 pr-4">
                                {nomination.comments.map((comment) => (
                                  <div key={comment.id} className="flex gap-2 text-xs">
                                    <Avatar className="h-5 w-5">
                                      <AvatarImage src={comment.userAvatar} alt={comment.userName} />
                                      <AvatarFallback className="text-[8px]">{comment.userInitials}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                      <div className="flex items-center justify-between">
                                        <span className="font-medium">{comment.userName}</span>
                                        <span className="text-[10px] text-muted-foreground">
                                          {new Date(comment.timestamp).toLocaleDateString()}
                                        </span>
                                      </div>
                                      <p className="text-xs">{comment.text}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </div>
                        )}
                        <div className="space-y-2">
                          <h4 className="font-medium text-sm">Add Comment</h4>
                          <div className="flex gap-2">
                            <Input
                              placeholder="Write a comment..."
                              className="text-xs h-8"
                              value={commentText}
                              onChange={(e) => setCommentText(e.target.value)}
                              onClick={(e) => e.stopPropagation()}
                            />
                            <Button
                              size="sm"
                              className="h-8"
                              onClick={(e) => {
                                e.stopPropagation()
                                if (commentText.trim()) {
                                  handleCommentSubmit(e)
                                }
                              }}
                              disabled={!commentText.trim()}
                            >
                              <Send className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Vote count display - now in the same row */}
                {(nomination.votes?.length || 0) > 0 && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex -space-x-1 overflow-hidden">
                          {nomination.votes?.slice(0, 3).map((vote, i) => (
                            <div
                              key={`${vote.userId}-${i}`}
                              className="inline-block h-5 w-5 rounded-full border-2 border-background"
                            >
                              <Avatar className="h-full w-full">
                                <AvatarFallback className="text-[8px]">
                                  {vote.userName
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </AvatarFallback>
                              </Avatar>
                            </div>
                          ))}
                          {(nomination.votes?.length || 0) > 3 && (
                            <div className="flex items-center justify-center h-5 w-5 rounded-full bg-muted text-[8px] font-medium border-2 border-background">
                              +{(nomination.votes?.length || 0) - 3}
                            </div>
                          )}
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">Supported by:</p>
                        <ul className="text-xs mt-1 space-y-1">
                          {nomination.votes?.slice(0, 5).map((vote, i) => (
                            <li key={`tooltip-${vote.userId}-${i}`}>{vote.userName}</li>
                          ))}
                          {(nomination.votes?.length || 0) > 5 && (
                            <li>and {(nomination.votes?.length || 0) - 5} more...</li>
                          )}
                        </ul>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>

              {/* Comments Section - Using conditional rendering instead of Collapsible */}
              {showComments && (
                <div className="mt-2 border rounded-md p-2 bg-background" onClick={(e) => e.stopPropagation()}>
                  {/* Comment List */}
                  {nomination.comments && nomination.comments.length > 0 ? (
                    <ScrollArea className="h-[120px] w-full pr-3">
                      <div className="space-y-3">
                        {nomination.comments.map((comment) => (
                          <div key={comment.id} className="flex gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={comment.userAvatar} alt={comment.userName} />
                              <AvatarFallback className="text-[10px]">{comment.userInitials}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="bg-muted rounded-md p-2">
                                <div className="flex justify-between items-start">
                                  <p className="text-xs font-medium">{comment.userName}</p>
                                  <span className="text-[10px] text-muted-foreground">
                                    {formatDate(comment.timestamp)}
                                  </span>
                                </div>
                                <p className="text-xs mt-1">{comment.text}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  ) : (
                    <p className="text-xs text-center text-muted-foreground py-2">No comments yet</p>
                  )}

                  {/* Comment Form */}
                  {!user?.roles?.includes("anonymous") && (
                    <form onSubmit={handleCommentSubmit} className="mt-2 flex gap-2">
                      <Input
                        type="text"
                        placeholder="Add a comment..."
                        className="h-8 text-xs"
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                      />
                      <Button
                        type="submit"
                        size="sm"
                        variant="ghost"
                        className="h-8 px-2"
                        disabled={!commentText.trim()}
                      >
                        <Send className="h-3.5 w-3.5" />
                      </Button>
                    </form>
                  )}
                </div>
              )}
            </div>
          </CardFooter>
        </div>
      </Card>
    </TooltipProvider>
  )
}

export default NominationCard
