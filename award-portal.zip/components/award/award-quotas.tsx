"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Edit, Save, Info } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"
import { getAwardEventById } from "@/data/award-events"
import { getAwardQuotas, saveAwardQuotas } from "@/data/award-quotas"
import type { AwardEvent } from "@/types/award-events"

// Define the interface for award quotas
export interface AwardQuota {
  awardTypeId: string
  quota: number
}

interface AwardQuotasProps {
  eventId: string
  isFacilitator: boolean
  isReadOnly?: boolean
  onQuotasUpdated?: (quotas: AwardQuota[]) => void
}

export function AwardQuotas({ eventId, isFacilitator, isReadOnly = false, onQuotasUpdated }: AwardQuotasProps) {
  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [loading, setLoading] = useState(true)
  const [awardQuotas, setAwardQuotas] = useState<AwardQuota[]>([])
  const [editingQuota, setEditingQuota] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const awardEvent = getAwardEventById(eventId)
        setEvent(awardEvent || null)

        if (awardEvent) {
          // Get existing quotas or initialize with defaults
          const existingQuotas = getAwardQuotas(eventId)

          if (existingQuotas && existingQuotas.length > 0) {
            setAwardQuotas(existingQuotas)
          } else {
            // Initialize award quotas with default values
            const defaultQuotas = [...spotIndividualAwardTypes, ...spotTeamAwardTypes].map((awardType) => ({
              awardTypeId: awardType.id,
              quota: 2, // Default quota of 2 winners per award type
            }))
            setAwardQuotas(defaultQuotas)
          }
        }
      } catch (error) {
        console.error("Error fetching award quotas:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId])

  // Handle quota change
  const handleQuotaChange = (awardTypeId: string, value: string) => {
    const quota = Number.parseInt(value, 10)
    if (isNaN(quota) || quota < 1) return

    setAwardQuotas((prev) => prev.map((aq) => (aq.awardTypeId === awardTypeId ? { ...aq, quota } : aq)))
  }

  // Save quota changes
  const saveQuotaChanges = () => {
    setEditingQuota(null)

    // Save quotas to the data store
    saveAwardQuotas(eventId, awardQuotas)

    // Notify parent component if needed
    if (onQuotasUpdated) {
      onQuotasUpdated(awardQuotas)
    }

    toast({
      title: "Quotas updated",
      description: "Award quotas have been updated successfully.",
    })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Event Not Found</AlertTitle>
        <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
      </Alert>
    )
  }

  if (!isFacilitator && !isReadOnly) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Access Restricted</AlertTitle>
        <AlertDescription>Only facilitators can manage award quotas.</AlertDescription>
      </Alert>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Award Quotas</CardTitle>
        <CardDescription>
          {isReadOnly
            ? "View the number of winners for each award type"
            : "Set the maximum number of winners for each award type"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Alert
          variant="default"
          className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800/30 mb-6"
        >
          <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          <AlertTitle>About Award Quotas</AlertTitle>
          <AlertDescription>
            {isReadOnly
              ? "These quotas determine how many winners will be selected for each award type."
              : "Set the maximum number of winners for each award type. If there are more qualified candidates than the quota, winners will be selected based on their scores."}
          </AlertDescription>
        </Alert>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Award Type</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="w-[150px] text-center">Quota</TableHead>
              {!isReadOnly && <TableHead className="w-[100px] text-right">Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {awardQuotas.map((awardQuota) => {
              const awardType = [...spotIndividualAwardTypes, ...spotTeamAwardTypes].find(
                (a) => a.id === awardQuota.awardTypeId,
              )

              return (
                <TableRow key={awardQuota.awardTypeId}>
                  <TableCell className="font-medium">{awardType?.title || awardQuota.awardTypeId}</TableCell>
                  <TableCell>{awardType?.description || "Award type description"}</TableCell>
                  <TableCell className="text-center">
                    {!isReadOnly && editingQuota === awardQuota.awardTypeId ? (
                      <Input
                        type="number"
                        min="1"
                        className="w-16 mx-auto text-center"
                        value={awardQuota.quota}
                        onChange={(e) => handleQuotaChange(awardQuota.awardTypeId, e.target.value)}
                      />
                    ) : (
                      awardQuota.quota
                    )}
                  </TableCell>
                  {!isReadOnly && (
                    <TableCell className="text-right">
                      {editingQuota === awardQuota.awardTypeId ? (
                        <Button size="sm" variant="ghost" onClick={saveQuotaChanges}>
                          <Save className="h-4 w-4 mr-1" />
                          Save
                        </Button>
                      ) : (
                        <Button size="sm" variant="ghost" onClick={() => setEditingQuota(awardQuota.awardTypeId)}>
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                      )}
                    </TableCell>
                  )}
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

