"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Info,
  Star,
  BarChart2,
  Users,
  Filter,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  MessageCircle,
} from "lucide-react"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import type { Nomination } from "@/types/nominations"
import type { Judge, Score } from "@/types/judges"
import { getAllScores, getJudgesForEvent, getDetailedScores } from "@/data/mock-scores"
import { mockUsers } from "@/data/mock-users"
import type { User } from "@/types/users"
import { calculateFinalScore } from "@/types/judges"

interface FacilitatorScoringPanelProps {
  eventId: string
  isPresentationStage: boolean
  nominations: Nomination[]
}

export function FacilitatorScoringPanel({
  eventId,
  isPresentationStage,
  nominations = [],
}: FacilitatorScoringPanelProps) {
  const [loading, setLoading] = useState(true)
  const [allScores, setAllScores] = useState<Record<string, Record<string, number>>>({})
  const [detailedScores, setDetailedScores] = useState<Record<string, Score[]>>({})
  const [averageScores, setAverageScores] = useState<Record<string, number>>({})
  const [judges, setJudges] = useState<Judge[]>([])
  const [activeTab, setActiveTab] = useState<string>("all")
  const [serviceLineFilter, setServiceLineFilter] = useState<string | null>(null)

  // Use useMemo instead of useState + useEffect to avoid infinite loop
  const sortedNominations = useMemo(() => {
    if (!nominations || nominations.length === 0) {
      return []
    }

    // Sort nominations by ID to ensure consistent order
    return [...nominations].sort((a, b) => {
      // First by nomineeServiceLine
      if (a.nomineeServiceLine !== b.nomineeServiceLine) {
        return a.nomineeServiceLine.localeCompare(b.nomineeServiceLine)
      }
      // Then by nomineeName
      if (a.nomineeName && b.nomineeName) {
        return a.nomineeName.localeCompare(b.nomineeName)
      }
      // Fallback to ID if name is missing
      return a.id.localeCompare(b.id)
    })
  }, [nominations])

  // Get unique service lines from nominations
  const serviceLines = useMemo(() => {
    const lines = new Set<string>()
    sortedNominations.forEach((nomination) => {
      const serviceLine = nomination.serviceLine || nomination.nomineeServiceLine
      if (serviceLine) {
        lines.add(serviceLine)
      }
    })
    return Array.from(lines)
  }, [sortedNominations])

  // Filter nominations by service line if a filter is selected
  const filteredNominations = useMemo(() => {
    if (!serviceLineFilter) return sortedNominations

    return sortedNominations.filter((nomination) => {
      const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine
      return nominationServiceLine === serviceLineFilter
    })
  }, [sortedNominations, serviceLineFilter])

  // Get nominations that have been scored
  const scoredNominations = useMemo(() => {
    return filteredNominations.filter((nomination) => averageScores[nomination.id] !== undefined)
  }, [filteredNominations, averageScores])

  // Get nominations that haven't been scored by any judge
  const unScoredNominations = useMemo(() => {
    return filteredNominations.filter((nomination) => averageScores[nomination.id] === undefined)
  }, [filteredNominations, averageScores])

  // Load scores and judges when component mounts
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // In a real app, these would be API calls
        const scoresObj = getAllScores(eventId)
        const eventJudgeIds = getJudgesForEvent(eventId)
        const eventJudges = mockUsers.filter((user) => eventJudgeIds.includes(user.id))

        // Get detailed scores with individual criteria
        const detailed = getDetailedScores(eventId)
        console.log(detailed)
        setDetailedScores(detailed)

        // Calculate average scores for each nomination
        const avgScores: Record<string, number> = {}
        Object.entries(detailed).forEach(([nominationId, scores]) => {
          // Find the nomination to get its service line
          const nomination = nominations.find((nom) => nom.id === nominationId)
          if (!nomination) return

          const nomineeServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""

          // Get judge service lines
          const judgeServiceLines: Record<string, string> = {}
          scores.forEach((score) => {
            const judge = mockUsers.find((user) => user.id === score.judgeId)
            if (judge && judge.serviceLine) {
              judgeServiceLines[score.judgeId] = judge.serviceLine
            }
          })

          // Calculate the final score using the imported function
          avgScores[nominationId] = calculateFinalScore(scores, nomineeServiceLine, judgeServiceLines)
        })

        setAllScores(scoresObj)
        setAverageScores(avgScores)
        setJudges(eventJudges)
      } catch (error) {
        console.error("Error fetching scoring data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [eventId, nominations])

  // Format service line for display
  const formatServiceLine = (line: string | string[] | undefined | null) => {
    if (!line) return "Unknown"

    // Handle array of service lines
    if (Array.isArray(line)) {
      if (line.length === 0) return "Unknown"

      return line
        .map((serviceLine) => {
          if (typeof serviceLine !== "string") return "Unknown"

          return serviceLine
            .split("-")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ")
        })
        .join(", ")
    }

    // Handle string service line (for backward compatibility)
    if (typeof line === "string") {
      return line
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
    }

    return "Unknown"
  }

  // Format score for display
  const formatScore = (score: number) => {
    return (Math.round(score * 10) / 10).toFixed(1)
  }

  if (!isPresentationStage) {
    return (
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Scoring is only available during the presentation stage</AlertTitle>
        <AlertDescription>Judges can score nominations once the event enters the presentation stage.</AlertDescription>
      </Alert>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div className="animate-pulse text-center">
          <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
          <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
        </div>
      </div>
    )
  }

  // If we have no nominations at all, show a specific message
  if (nominations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Scoring Overview</CardTitle>
          <CardDescription>View and analyze scores from all judges.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>No nominations found</AlertTitle>
            <AlertDescription>
              There are no nominations available for this award event. Please check back later.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>Scoring Overview</CardTitle>
          <CardDescription>View and analyze scores from all judges.</CardDescription>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
              {serviceLineFilter && <span className="ml-1">: {formatServiceLine(serviceLineFilter)}</span>}
              <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Filter by Service Line</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem
                onClick={() => setServiceLineFilter(null)}
                className={!serviceLineFilter ? "bg-accent" : ""}
              >
                All Service Lines
              </DropdownMenuItem>
              {serviceLines.map((line) => (
                <DropdownMenuItem
                  key={line}
                  onClick={() => setServiceLineFilter(line)}
                  className={serviceLineFilter === line ? "bg-accent" : ""}
                >
                  {formatServiceLine(line)}
                </DropdownMenuItem>
              ))}
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-medium">Scoring Progress</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {scoredNominations.length} of {filteredNominations.length} nominations have been scored
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="bg-muted w-40 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-primary h-full"
                  style={{
                    width: `${filteredNominations.length ? (scoredNominations.length / filteredNominations.length) * 100 : 0}%`,
                  }}
                ></div>
              </div>
              <span className="text-sm font-medium">
                {filteredNominations.length
                  ? Math.round((scoredNominations.length / filteredNominations.length) * 100)
                  : 0}
                %
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="rounded-full bg-blue-100 dark:bg-blue-900/20 p-3">
                  <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Judges</p>
                  <p className="text-2xl font-bold">{judges.length}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="rounded-full bg-green-100 dark:bg-green-900/20 p-3">
                  <BarChart2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Score</p>
                  <p className="text-2xl font-bold">
                    {Object.values(averageScores).length > 0
                      ? formatScore(
                          Object.values(averageScores).reduce((acc, score) => acc + score, 0) /
                            Object.values(averageScores).length,
                        )
                      : "N/A"}
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="rounded-full bg-amber-100 dark:bg-amber-900/20 p-3">
                  <Star className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Highest Score</p>
                  <p className="text-2xl font-bold">
                    {Object.values(averageScores).length > 0
                      ? formatScore(Math.max(...Object.values(averageScores)))
                      : "N/A"}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full mt-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Nominations ({filteredNominations.length})</TabsTrigger>
            <TabsTrigger value="scored">Scored ({scoredNominations.length})</TabsTrigger>
            <TabsTrigger value="unscored">Unscored ({unScoredNominations.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4 mt-4">
            {filteredNominations.length > 0 ? (
              filteredNominations.map((nomination, index) => (
                <NominationScoreCard
                  key={nomination.id}
                  nomination={nomination}
                  averageScore={averageScores[nomination.id]}
                  judgeCount={allScores[nomination.id] ? Object.keys(allScores[nomination.id]).length : 0}
                  judges={judges}
                  judgeScores={allScores[nomination.id] || {}}
                  detailedScores={detailedScores[nomination.id] || []}
                  index={index}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">No nominations found.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="scored" className="space-y-4 mt-4">
            {scoredNominations.length > 0 ? (
              scoredNominations.map((nomination, index) => (
                <NominationScoreCard
                  key={nomination.id}
                  nomination={nomination}
                  averageScore={averageScores[nomination.id]}
                  judgeCount={allScores[nomination.id] ? Object.keys(allScores[nomination.id]).length : 0}
                  judges={judges}
                  judgeScores={allScores[nomination.id] || {}}
                  detailedScores={detailedScores[nomination.id] || []}
                  index={index}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">No scored nominations found.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="unscored" className="space-y-4 mt-4">
            {unScoredNominations.length > 0 ? (
              unScoredNominations.map((nomination, index) => (
                <NominationScoreCard
                  key={nomination.id}
                  nomination={nomination}
                  averageScore={undefined}
                  judgeCount={0}
                  judges={judges}
                  judgeScores={{}}
                  detailedScores={[]}
                  index={index}
                />
              ))
            ) : (
              <div className="text-center py-8">
                <Info className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-2 text-muted-foreground">All nominations have been scored.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

interface NominationScoreCardProps {
  nomination: Nomination
  averageScore?: number
  judgeCount: number
  judges: Judge[]
  judgeScores: Record<string, number>
  detailedScores: Score[]
  index: number
}

// Helper function to identify outlier scores (top 2 and bottom 2)
// Returns an object with arrays for top and bottom outliers
function getOutlierScores(scores: Score[]): { top: string[]; bottom: string[] } {
  if (scores.length < 5) return { top: [], bottom: [] } // Need at least 5 scores to remove 4 outliers

  // Sort scores by their weighted value
  const sortedScores = [...scores]
    .map((score) => {
      const weightedScore =
        score.criteria.accomplishments * 0.7 + score.criteria.presentation * 0.2 + score.criteria.values * 0.1
      return { ...score, weightedScore }
    })
    .sort((a, b) => a.weightedScore - b.weightedScore)

  // Get the judgeIds of the bottom 2 and top 2 scores
  return {
    bottom: sortedScores.slice(0, 2).map((score) => score.judgeId),
    top: sortedScores.slice(sortedScores.length - 2).map((score) => score.judgeId),
  }
}

function NominationScoreCard({
  nomination,
  averageScore,
  judgeCount,
  judges,
  judgeScores,
  detailedScores,
  index,
}: NominationScoreCardProps) {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [selectedDistribution, setSelectedDistribution] = useState<
    "overall" | "accomplishments" | "presentation" | "values"
  >("overall")

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const awardTypes: Record<string, string> = {
      "star-of-agile": "Star of Agile",
      "star-of-customer-service": "Star of Customer Service",
      "star-of-engagement": "Star of Engagement",
      "star-of-innovation": "Star of Innovation",
      "star-of-leadership": "Star of Leadership",
      "all-star-team": "All-Star Team",
    }
    return awardTypes[awardType] || awardType
  }

  const hasScores = judgeCount > 0
  const nominationServiceLine = nomination.serviceLine || nomination.nomineeServiceLine || ""

  // Get judge details by ID
  const getJudgeById = (judgeId: string): User | undefined => {
    // Simply find the user by ID without checking roles
    return mockUsers.find((user) => user.id === judgeId)

    // Or if we want to check for judge role properly:
    // return mockUsers.find((user) =>
    //   user.id === judgeId &&
    //   user.roles?.some(role => role.id === "judge" || role.id === "head-judge")
    // )
  }

  // Format service line for display
  const formatServiceLineCard = (line: string | string[] | undefined | null) => {
    if (!line) return "Unknown"

    // Handle array of service lines
    if (Array.isArray(line)) {
      if (line.length === 0) return "Unknown"

      return line
        .map((serviceLine) => {
          if (typeof serviceLine !== "string") return "Unknown"

          return serviceLine
            .split("-")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ")
        })
        .join(", ")
    }

    // Handle string service line (for backward compatibility)
    if (typeof line === "string") {
      return line
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
    }

    return "Unknown"
  }

  // Format score for display
  const formatScoreCard = (score: number) => {
    // Ensure score is properly rounded to 1 decimal place
    return (Math.round(score * 10) / 10).toFixed(1)
  }

  // Function to extract and process criterion-specific scores
  const getCriterionDistributions = useMemo(() => {
    if (!detailedScores.length)
      return {
        accomplishments: [0, 0, 0, 0, 0],
        presentation: [0, 0, 0, 0, 0],
        values: [0, 0, 0, 0, 0],
      }

    // Initialize counters for each rating (1-5) for each criterion
    const distributions = {
      accomplishments: [0, 0, 0, 0, 0],
      presentation: [0, 0, 0, 0, 0],
      values: [0, 0, 0, 0, 0],
    }

    // Process each score
    detailedScores.forEach((score) => {
      if (!score.criteria) return

      // Map 0-10 scores to 0-4 index using the correct ranges
      // 5 stars (index 4): 9-10
      // 4 stars (index 3): 7-8.9
      // 3 stars (index 2): 5-6.9
      // 2 stars (index 1): 3-4.9
      // 1 star (index 0): 0-2.9
      const getScoreIndex = (score) => {
        if (score >= 9) return 4
        if (score >= 7) return 3
        if (score >= 5) return 2
        if (score >= 3) return 1
        return 0
      }

      const accomplishmentsRating = getScoreIndex(score.criteria.accomplishments)
      const presentationRating = getScoreIndex(score.criteria.presentation)
      const valuesRating = getScoreIndex(score.criteria.values)

      // Increment the appropriate counters
      distributions.accomplishments[accomplishmentsRating]++
      distributions.presentation[presentationRating]++
      distributions.values[valuesRating]++
    })

    return distributions
  }, [detailedScores])

  // Function to get the appropriate distribution based on selected criterion
  const getDistributionData = () => {
    if (selectedDistribution === "overall") {
      // Use correct mapping for overall scores
      return [5, 4, 3, 2, 1].map((rating, index) => {
        const count = Object.values(judgeScores).filter((score) => {
          if (rating === 5) return score >= 9
          if (rating === 4) return score >= 7 && score < 9
          if (rating === 3) return score >= 5 && score < 7
          if (rating === 2) return score >= 3 && score < 5
          return score < 3
        }).length
        return { rating, count }
      })
    } else {
      // Use criterion-specific distribution
      // Note: We need to reverse the array since our UI shows 5 to 1
      const criterionCounts = getCriterionDistributions[selectedDistribution] || [0, 0, 0, 0, 0]
      return [5, 4, 3, 2, 1].map((rating, index) => {
        return { rating, count: criterionCounts[4 - index] }
      })
    }
  }

  // Dynamic title and description based on selected criterion
  const getDistributionTitle = () => {
    switch (selectedDistribution) {
      case "accomplishments":
        return "Accomplishments Scores (70%)"
      case "presentation":
        return "Presentation Scores (20%)"
      case "values":
        return "Values Scores (10%)"
      default:
        return "Overall Score Distribution"
    }
  }

  const getDistributionDescription = () => {
    if (selectedDistribution === "overall") {
      return "Based on weighted criteria: 70% Accomplishments, 20% Presentation, 10% Values"
    } else {
      return `Showing raw ${selectedDistribution} scores before weighting`
    }
  }

  // Color coding for different criteria
  const getProgressBarColors = () => {
    switch (selectedDistribution) {
      case "accomplishments":
        return "bg-blue-100 dark:bg-blue-900/20 [&>div]:bg-blue-600 dark:[&>div]:bg-blue-400"
      case "presentation":
        return "bg-green-100 dark:bg-green-900/20 [&>div]:bg-green-600 dark:[&>div]:bg-green-400"
      case "values":
        return "bg-amber-100 dark:bg-amber-900/20 [&>div]:bg-amber-600 dark:[&>div]:bg-amber-400"
      default:
        return ""
    }
  }

  const getTotalCount = () => {
    let total = 0
    getDistributionData().forEach((item) => {
      total += item.count
    })
    return total
  }

  return (
    <div className={cn("rounded-lg border p-4", hasScores ? "border-primary/20 bg-primary/5" : "")}>
      <div className="flex items-start gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm font-medium">
            {index + 1}
          </div>
          <Avatar className="h-12 w-12">
            <AvatarImage
              src={nomination.nominee?.avatar || "/placeholder.svg?height=40&width=40"}
              alt={nomination.nominee?.name || "Unknown"}
            />
            <AvatarFallback>{nomination.nominee?.initials || "??"}</AvatarFallback>
          </Avatar>
        </div>

        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <h3 className="font-medium">
                {nomination.title ||
                  `${getAwardTypeDisplay(nomination.awardType)} - ${nomination.nominee?.name || "Unknown"}`}
              </h3>
              <p className="text-sm">
                <span className="text-muted-foreground">Nominee: </span>
                {nomination.nominee?.name || "Unknown"}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                <span className="font-medium">Service Line: </span>
                {formatServiceLineCard(nominationServiceLine || "Unknown")}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <Badge variant="secondary" className="whitespace-nowrap">
                {nomination.nominationType === "individual" ? "Individual" : "Team"}
              </Badge>
            </div>
          </div>

          <div className="mt-3">
            <p className="text-sm font-medium mb-1">Nomination Summary:</p>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {nomination.nominationSummary || nomination.justification || "No nomination summary provided"}
            </p>
          </div>

          <div className="mt-4 border-t pt-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={cn(
                        "h-5 w-5",
                        averageScore !== undefined && averageScore >= star * 2 - 1
                          ? "fill-primary text-primary"
                          : "fill-muted text-muted-foreground",
                      )}
                    />
                  ))}
                </div>
                <div>
                  <span className="text-lg font-bold">
                    {averageScore !== undefined ? formatScoreCard(averageScore) : "N/A"}
                  </span>
                  <span className="text-sm text-muted-foreground ml-2">({judgeCount} judges)</span>
                </div>
              </div>

              <Drawer open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
                <DrawerTrigger asChild>
                  <Button variant="outline" size="sm" disabled={!hasScores}>
                    <BarChart2 className="mr-2 h-4 w-4" />
                    View Score Breakdown
                  </Button>
                </DrawerTrigger>
                <DrawerContent>
                  <div className="mx-auto w-full max-w-sm">
                    <DrawerHeader>
                      <DrawerTitle>Score Breakdown</DrawerTitle>
                      <DrawerDescription>Individual scores from each judge for this nomination.</DrawerDescription>
                    </DrawerHeader>

                    <div className="p-4 pb-0">
                      <div className="space-y-4">
                        <div className="pb-3 border-b">
                          <h3 className="font-medium">{nomination.nominee?.name || "Unknown"}</h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            <span className="font-medium">Service Line: </span>
                            {formatServiceLineCard(nominationServiceLine || "Unknown")}
                          </p>
                          <p className="text-sm text-muted-foreground mt-1">
                            <span className="font-medium">Award Type: </span>
                            {getAwardTypeDisplay(nomination.awardType)}
                          </p>
                        </div>

                        {/* Judge scores */}
                        <div className="space-y-3">
                          <h4 className="text-sm font-medium">Judge Scores</h4>

                          {/* Legend for outlier scores */}
                          <div className="text-xs text-muted-foreground bg-muted/30 p-2 rounded-md">
                            <p className="font-medium mb-1">Scoring Process:</p>
                            <p>
                              The top 2 highest scores{" "}
                              <span className="inline-flex items-center text-blue-500">
                                <TrendingUp className="h-3 w-3 mr-1" /> (blue)
                              </span>{" "}
                              and bottom 2 lowest scores{" "}
                              <span className="inline-flex items-center text-red-500">
                                <TrendingDown className="h-3 w-3 mr-1" /> (red)
                              </span>{" "}
                              are excluded from the final calculation to remove outliers.
                            </p>
                          </div>

                          {(() => {
                            // Get outlier score IDs
                            const outliers = getOutlierScores(detailedScores)

                            return detailedScores.length > 0
                              ? detailedScores.map((score) => {
                                  const judge = getJudgeById(score.judgeId)
                                  if (!judge) return null

                                  // Check if this score is an outlier
                                  const isTopOutlier = outliers.top.includes(score.judgeId)
                                  const isBottomOutlier = outliers.bottom.includes(score.judgeId)
                                  const isOutlier = isTopOutlier || isBottomOutlier

                                  // Calculate weighted score
                                  const weightedScore =
                                    score.criteria.accomplishments * 0.7 +
                                    score.criteria.presentation * 0.2 +
                                    score.criteria.values * 0.1

                                  return (
                                    <div key={score.judgeId} className="flex items-center gap-3 p-3 rounded-lg border">
                                      <Avatar className="h-10 w-10">
                                        <AvatarImage src={judge.avatar} alt={judge.name} />
                                        <AvatarFallback>{judge.initials}</AvatarFallback>
                                      </Avatar>
                                      <div className="flex-1">
                                        <div className="flex justify-between items-center">
                                          <div>
                                            <p className="font-medium flex items-center">
                                              {judge.name}
                                              {score.comments && (
                                                <TooltipProvider>
                                                  <Tooltip>
                                                    <TooltipTrigger asChild>
                                                      <span className="inline-flex ml-1 cursor-help">
                                                        <MessageCircle className="h-3 w-3 text-muted-foreground" />
                                                      </span>
                                                    </TooltipTrigger>
                                                    <TooltipContent>
                                                      <p className="max-w-xs">{score.comments}</p>
                                                    </TooltipContent>
                                                  </Tooltip>
                                                </TooltipProvider>
                                              )}
                                            </p>
                                            <p className="text-xs text-muted-foreground">
                                              {formatServiceLineCard(judge.serviceLine)}
                                            </p>
                                          </div>
                                          <div className="flex items-center gap-2">
                                            <div className="flex">
                                              {[1, 2, 3, 4, 5].map((star) => (
                                                <Star
                                                  key={star}
                                                  className={cn(
                                                    "h-4 w-4",
                                                    judgeScores[score.judgeId] >= star * 2 - 1
                                                      ? "fill-primary text-primary"
                                                      : "fill-muted text-muted-foreground",
                                                  )}
                                                />
                                              ))}
                                            </div>
                                            <span
                                              className={cn(
                                                "font-bold",
                                                isTopOutlier && "line-through text-blue-500",
                                                isBottomOutlier && "line-through text-red-500",
                                              )}
                                              title={
                                                isTopOutlier
                                                  ? "This high score is excluded from the final calculation"
                                                  : isBottomOutlier
                                                    ? "This low score is excluded from the final calculation"
                                                    : ""
                                              }
                                            >
                                              {formatScoreCard(weightedScore)}
                                            </span>
                                            {isTopOutlier && <TrendingUp className="h-3 w-3 ml-1 text-blue-500" />}
                                            {isBottomOutlier && <TrendingDown className="h-3 w-3 ml-1 text-red-500" />}
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  )
                                })
                              : Object.entries(judgeScores).map(([judgeId, score]) => {
                                  const judge = getJudgeById(judgeId)
                                  if (!judge) return null

                                  return (
                                    <div key={judgeId} className="flex items-center gap-3 p-3 rounded-lg border">
                                      <Avatar className="h-10 w-10">
                                        <AvatarImage src={judge.avatar} alt={judge.name} />
                                        <AvatarFallback>{judge.initials}</AvatarFallback>
                                      </Avatar>
                                      <div className="flex-1">
                                        <div className="flex justify-between items-center">
                                          <div>
                                            <p className="font-medium flex items-center">{judge.name}</p>
                                            <p className="text-xs text-muted-foreground">
                                              {formatServiceLineCard(judge.serviceLine)}
                                            </p>
                                          </div>
                                          <div className="flex items-center gap-2">
                                            <div className="flex">
                                              {[1, 2, 3, 4, 5].map((star) => (
                                                <Star
                                                  key={star}
                                                  className={cn(
                                                    "h-4 w-4",
                                                    score >= star * 2 - 1
                                                      ? "fill-primary text-primary"
                                                      : "fill-muted text-muted-foreground",
                                                  )}
                                                />
                                              ))}
                                            </div>
                                            <span className="font-bold">{formatScoreCard(score)}</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  )
                                })
                          })()}
                        </div>

                        {/* Average score */}
                        {hasScores && (
                          <div className="mt-6 pt-4 border-t">
                            <div className="flex justify-between items-center">
                              <p className="font-medium">Average Score</p>
                              <div className="flex items-center gap-2">
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={cn(
                                        "h-5 w-5",
                                        averageScore !== undefined && averageScore >= star * 2 - 1
                                          ? "fill-primary text-primary"
                                          : "fill-muted text-muted-foreground",
                                      )}
                                    />
                                  ))}
                                </div>
                                <span className="font-bold text-lg">
                                  {averageScore !== undefined ? formatScoreCard(averageScore) : "N/A"}
                                </span>
                              </div>
                            </div>

                            {/* Score distribution */}
                            <div className="mt-4">
                              <div className="flex justify-between items-center mb-2">
                                <p className="text-sm font-medium">{getDistributionTitle()}</p>
                              </div>

                              {/* Distribution selector tabs */}
                              <div className="flex space-x-1 mb-3 bg-muted/20 p-1 rounded-md">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={cn(
                                    "text-xs rounded-sm flex-1",
                                    selectedDistribution === "overall" && "bg-background shadow-sm",
                                  )}
                                  onClick={() => setSelectedDistribution("overall")}
                                >
                                  Overall
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={cn(
                                    "text-xs rounded-sm flex-1",
                                    selectedDistribution === "accomplishments" && "bg-background shadow-sm",
                                  )}
                                  onClick={() => setSelectedDistribution("accomplishments")}
                                >
                                  Accomplishments
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={cn(
                                    "text-xs rounded-sm flex-1",
                                    selectedDistribution === "presentation" && "bg-background shadow-sm",
                                  )}
                                  onClick={() => setSelectedDistribution("presentation")}
                                >
                                  Presentation
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={cn(
                                    "text-xs rounded-sm flex-1",
                                    selectedDistribution === "values" && "bg-background shadow-sm",
                                  )}
                                  onClick={() => setSelectedDistribution("values")}
                                >
                                  Values
                                </Button>
                              </div>

                              <p className="text-xs text-muted-foreground mt-1 mb-3">{getDistributionDescription()}</p>

                              <div className="space-y-2">
                                {getDistributionData().map(({ rating, count }) => {
                                  const totalCount = getTotalCount()
                                  const percentage = totalCount > 0 ? (count / totalCount) * 100 : 0

                                  return (
                                    <div key={rating} className="flex items-center gap-2">
                                      <span className="text-sm w-6">{rating}</span>
                                      <Progress
                                        value={percentage}
                                        className={cn("h-2 flex-1", getProgressBarColors())}
                                      />
                                      <span className="text-sm w-8">{count}</span>
                                    </div>
                                  )
                                })}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Scoring Process Information */}
                        <div className="mt-4 p-3 rounded-lg border bg-muted/20">
                          <p className="text-sm font-medium">Scoring Process</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Scores from judges in the same service line as the nominee are excluded from the average
                            calculation.
                          </p>
                        </div>
                      </div>
                    </div>

                    <DrawerFooter>
                      <DrawerClose asChild>
                        <Button variant="outline">Close</Button>
                      </DrawerClose>
                    </DrawerFooter>
                  </div>
                </DrawerContent>
              </Drawer>
            </div>

            <div className="mt-3">
              <p className="text-xs text-muted-foreground">
                {hasScores
                  ? `${judgeCount} of ${judges.length} judges have scored this nomination.`
                  : "No judges have scored this nomination yet."}
              </p>
              <Progress value={(judgeCount / judges.length) * 100} className="h-1 mt-1" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

