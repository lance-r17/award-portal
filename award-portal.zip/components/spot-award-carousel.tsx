"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { AwardEvent } from "@/types/award-events"
import { getCurrentStageLabel } from "@/data/award-events"

interface SpotAwardCarouselProps {
  events: AwardEvent[]
  onEventSelect: (eventId: string) => void
}

export function SpotAwardCarousel({ events, onEventSelect }: SpotAwardCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  // Auto-advance the carousel
  useEffect(() => {
    if (!autoplay || events.length <= 1) return

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % events.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [autoplay, events.length])

  // Pause autoplay when user interacts with carousel
  const handleManualNavigation = (index: number) => {
    setCurrentIndex(index)
    setAutoplay(false)

    // Resume autoplay after 10 seconds of inactivity
    setTimeout(() => setAutoplay(true), 10000)
  }

  const nextSlide = () => {
    handleManualNavigation((currentIndex + 1) % events.length)
  }

  const prevSlide = () => {
    handleManualNavigation((currentIndex - 1 + events.length) % events.length)
  }

  if (events.length === 0) {
    return null
  }

  const currentEvent = events[currentIndex]
  const stageLabel = getCurrentStageLabel(currentEvent.currentStage)

  return (
    <div className="relative">
      <div className="overflow-hidden rounded-lg border">
        <div className="relative">
          {/* Carousel content */}
          <div
            className="transition-all duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            <Card className="border-0 shadow-none">
              <CardHeader className="pb-2 bg-muted/30">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{currentEvent.title}</CardTitle>
                    <CardDescription>{currentEvent.description}</CardDescription>
                  </div>
                  <Badge variant="default">{stageLabel}</Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex flex-col md:flex-row gap-4 items-center">
                    <div className="flex-1">
                      <h3 className="text-lg font-medium mb-2">Current Theme: {currentEvent.theme}</h3>
                      <p className="text-muted-foreground">
                        Quarter: <span className="font-medium">{currentEvent.quarter}</span>
                      </p>
                      <p className="mt-4">
                        {currentEvent.currentStage === "nomination" &&
                          "Submit your nominations for outstanding colleagues!"}
                        {currentEvent.currentStage === "presentation" &&
                          "Nominees are presenting their achievements to the committee."}
                        {currentEvent.currentStage === "result" &&
                          "Results have been announced! Check out the winners."}
                      </p>
                    </div>
                    <div className="flex-shrink-0 w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">
                          {currentEvent.currentStage === "nomination" && "Nominate"}
                          {currentEvent.currentStage === "presentation" && "Present"}
                          {currentEvent.currentStage === "result" && "Results"}
                        </div>
                        <div className="text-xs text-muted-foreground">Current Stage</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/30 flex justify-between">
                <div className="text-sm text-muted-foreground">
                  Created on {currentEvent.createdAt.toLocaleDateString()}
                </div>
                <Button onClick={() => onEventSelect(currentEvent.id)}>View Details</Button>
              </CardFooter>
            </Card>
          </div>

          {/* Navigation buttons */}
          {events.length > 1 && (
            <>
              <Button
                variant="outline"
                size="icon"
                className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur-sm"
                onClick={prevSlide}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur-sm"
                onClick={nextSlide}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </>
          )}
        </div>

        {/* Carousel indicators */}
        {events.length > 1 && (
          <div className="flex justify-center gap-2 p-2 bg-muted/20">
            {events.map((_, index) => (
              <button
                key={index}
                className={`h-2 w-2 rounded-full transition-all ${
                  index === currentIndex ? "bg-primary w-4" : "bg-muted"
                }`}
                onClick={() => handleManualNavigation(index)}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

