"use client"

import React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { UserRound, ChevronDown, Crown, Scale, Trophy, Briefcase, Send, Star, EyeOff } from "lucide-react"
import { getCurrentUser } from "@/data/mock-users"

const roles = [
  { id: "facilitator", name: "Facilitator", icon: Crown },
  { id: "judge", name: "Judge", icon: Scale },
  { id: "head-judge", name: "Head Judge", icon: Trophy },
  { id: "domain-manager", name: "Domain Manager", icon: Briefcase },
  { id: "nominator", name: "Nominator", icon: Send },
  { id: "nominee", name: "Nominee", icon: Star },
  { id: "anonymous", name: "Anonymous", icon: EyeOff },
]

export function RoleSwitcher() {
  const [selectedRole, setSelectedRole] = useState<string | null>(null)
  const [user, setUser] = useState<any>(null)

  // Initialize user and selected role
  useEffect(() => {
    try {
      // Get the current user directly instead of using the context
      const currentUser = getCurrentUser()
      setUser(currentUser)

      // Initialize selected role from localStorage or default to current user role
      const storedRole = localStorage.getItem("selectedRole")
      if (storedRole) {
        setSelectedRole(storedRole)
      } else if (currentUser?.roles && currentUser.roles.length > 0) {
        setSelectedRole(currentUser.roles[0])
      }
    } catch (error) {
      console.error("Error initializing RoleSwitcher:", error)
    }
  }, [])

  const handleRoleChange = (roleId: string) => {
    console.log("Switching to role:", roleId)
    localStorage.setItem("selectedRole", roleId)
    setSelectedRole(roleId)

    // Dispatch a custom event to notify about role change
    const event = new CustomEvent("roleChanged", { detail: { role: roleId } })
    window.dispatchEvent(event)

    // Update the user directly
    setUser(getCurrentUser())
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="h-8 gap-1">
          {selectedRole ? (
            React.createElement(roles.find((r) => r.id === selectedRole)?.icon || UserRound, { className: "h-4 w-4" })
          ) : (
            <UserRound className="h-4 w-4" />
          )}
          <span>Role: {roles.find((r) => r.id === selectedRole)?.name || "Select Role"}</span>
          <ChevronDown className="h-4 w-4 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {roles.map((role) => (
          <DropdownMenuItem
            key={role.id}
            onClick={() => handleRoleChange(role.id)}
            className={selectedRole === role.id ? "bg-muted" : ""}
          >
            {React.createElement(role.icon, { className: "h-4 w-4 mr-2" })}
            {role.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

