import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { getInitials } from "@/lib/utils"
import type { Nomination } from "@/types"
import { Trophy } from "lucide-react"
import Link from "next/link"

const NomineeCard = ({ nomination }: { nomination: Nomination }) => {
  const isWinner = nomination.status === "awarded"

  return (
    <Link href={`/awards/spot-awards/${nomination.eventId}/noms/${nomination.id}`}>
      <Card className="h-full overflow-hidden transition-all hover:shadow-md">
        <CardContent className="p-0">
          <div className="flex items-center gap-4 p-4">
            <div className="relative">
              <Avatar className="h-16 w-16">
                <AvatarImage
                  src={nomination.nominee.image || "/placeholder.svg?height=64&width=64"}
                  alt={nomination.nominee.name}
                />
                <AvatarFallback>{getInitials(nomination.nominee.name)}</AvatarFallback>
              </Avatar>
              {isWinner && (
                <div className="absolute -right-1 -top-1 rounded-full bg-primary p-1 text-primary-foreground">
                  <Trophy className="h-3 w-3" />
                </div>
              )}
            </div>
            <div>
              <h3 className="font-medium">{nomination.nominee.name}</h3>
              <p className="text-sm text-muted-foreground">{nomination.awardType}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

export default function RewardWallVariant({ nominations }: { nominations: Nomination[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
      {nominations.map((nomination) => (
        <NomineeCard key={nomination.id} nomination={nomination} />
      ))}
    </div>
  )
}

