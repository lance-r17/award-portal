"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
 Dialog,
 DialogContent,
 DialogDescription,
 DialogFooter,
 DialogHeader,
 DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search } from 'lucide-react'
import { useUsers } from "@/hooks/use-users" // Import the hook
import type { User } from "@/types/users"

interface SelectedUser extends User {
 isHeadJudge: boolean
}

interface AddToJudgePoolDialogProps {
 open: boolean
 onOpenChange: (open: boolean) => void
 onAdd: (users: SelectedUser[]) => void
}

// Mock function to get organization levels - in a real app, this would come from an API
const getOrganizationLevels = () => [
  "Technology",
  "Finance",
  "Marketing",
  "HR",
  "Sales",
  "Operations",
  "Legal",
  "Research",
]

export function AddToJudgePoolDialog({ open, onOpenChange, onAdd }: AddToJudgePoolDialogProps) {
 const [selectedUsers, setSelectedUsers] = useState<SelectedUser[]>([])
 const [searchQuery, setSearchQuery] = useState("")
 const organizationLevels = getOrganizationLevels()

 // Use the useUsers hook to fetch users
 const { data: eligibleUsers, isLoading, isError, error } = useUsers({ search: searchQuery })

 const handleUserSelect = (user: User, isSelected: boolean) => {
   if (isSelected) {
     setSelectedUsers([
       ...selectedUsers,
       {
         ...user,
         isHeadJudge: false,
       },
     ])
   } else {
     setSelectedUsers(selectedUsers.filter((u) => u.id !== user.id))
   }
 }

 const handleOrgLevelChange = (userId: string, newOrgLevel: string) => {
   setSelectedUsers(
     selectedUsers.map((user) => (user.id === userId ? { ...user, organizationLevel2: newOrgLevel } : user)),
   )
 }

 const handleHeadJudgeToggle = (userId: string, isHeadJudge: boolean) => {
   setSelectedUsers(selectedUsers.map((user) => (user.id === userId ? { ...user, isHeadJudge } : user)))
 }

 const handleSubmit = () => {
   onAdd(selectedUsers)
   onOpenChange(false)
   setSelectedUsers([])
   setSearchQuery("")
 }

 const filteredUsers = (eligibleUsers?.users || []).filter(
   (user) =>
     user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
     user.email.toLowerCase().includes(searchQuery.toLowerCase()),
 )

 const isUserSelected = (userId: string) => selectedUsers.some((user) => user.id === userId)

 return (
   <Dialog open={open} onOpenChange={onOpenChange}>
     <DialogContent className="sm:max-w-[600px]">
       <DialogHeader>
         <DialogTitle>Add to Judge Pool</DialogTitle>
         <DialogDescription>Select users to add to the judge pool.</DialogDescription>
       </DialogHeader>

       <div className="space-y-4 py-2">
         <div className="space-y-2">
           <Label htmlFor="search-users">Search Users</Label>
           <div className="relative">
             <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
             <Input
               id="search-users"
               placeholder="Search users..."
               className="pl-8"
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
             />
           </div>
         </div>

         <div className="max-h-60 space-y-2 overflow-y-auto rounded-md border p-2">
           {isLoading ? (
             <div className="py-2 text-center text-sm text-muted-foreground">Loading users...</div>
           ) : isError && error instanceof Error ? (
             <div className="py-2 text-center text-sm text-muted-foreground">Error loading users</div>
           ) : filteredUsers.length === 0 ? (
             <div className="py-2 text-center text-sm text-muted-foreground">No users found</div>
           ) : (
             filteredUsers.map((user) => (
               <div key={user.id} className="flex items-center space-x-2 rounded-md p-2 hover:bg-muted">
                 <Checkbox
                   id={`user-${user.id}`}
                   checked={isUserSelected(user.id)}
                   onCheckedChange={(checked) => handleUserSelect(user, !!checked)}
                 />
                 <Avatar className="h-8 w-8">
                   <AvatarImage src={user.avatar} alt={user.name} />
                   <AvatarFallback>{user.initials}</AvatarFallback>
                 </Avatar>
                 <div className="flex-1">
                   <Label htmlFor={`user-${user.id}`} className="cursor-pointer font-medium">
                     {user.name}
                   </Label>
                   <div className="text-sm text-muted-foreground">{user.email}</div>
                 </div>
                 <div className="text-sm text-muted-foreground">
                   <span className="rounded-md bg-muted px-2 py-1 text-xs">{user.organizationLevel2}</span>
                 </div>
               </div>
             ))
           )}
         </div>

         {selectedUsers.length > 0 && (
           <div className="space-y-2">
             <Label>Selected Users ({selectedUsers.length})</Label>
             <Table>
               <TableHeader>
                 <TableRow>
                   <TableHead>Name</TableHead>
                   <TableHead>Organization Level</TableHead>
                   <TableHead>Head Judge</TableHead>
                 </TableRow>
               </TableHeader>
               <TableBody>
                 {selectedUsers.map((user) => (
                   <TableRow key={user.id}>
                     <TableCell className="font-medium">{user.name}</TableCell>
                     <TableCell>
                       <Select
                         value={user.organizationLevel2}
                         onValueChange={(value) => handleOrgLevelChange(user.id, value)}
                       >
                         <SelectTrigger className="w-full">
                           <SelectValue placeholder="Select organization" />
                         </SelectTrigger>
                         <SelectContent>
                           {organizationLevels.map((org) => (
                             <SelectItem key={org} value={org}>
                               {org}
                             </SelectItem>
                           ))}
                         </SelectContent>
                       </Select>
                     </TableCell>
                     <TableCell>
                       <Checkbox
                         checked={user.isHeadJudge}
                         onCheckedChange={(checked) => handleHeadJudgeToggle(user.id, !!checked)}
                       />
                     </TableCell>
                   </TableRow>
                 ))}
               </TableBody>
             </Table>
           </div>
         )}
       </div>

       <DialogFooter>
         <Button variant="outline" onClick={() => onOpenChange(false)}>
           Cancel
         </Button>
         <Button onClick={handleSubmit} disabled={selectedUsers.length === 0}>
           Add Users
         </Button>
       </DialogFooter>
     </DialogContent>
   </Dialog>
 )
}

