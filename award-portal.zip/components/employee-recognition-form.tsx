"use client"

import { useState } from "react"
import { Check, ChevronsUpDown } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"

const employees = [
  { label: "Sarah Johnson", value: "sarah-johnson" },
  { label: "Michael Chen", value: "michael-chen" },
  { label: "Emily Rodriguez", value: "emily-rodriguez" },
  { label: "David Kim", value: "david-kim" },
  { label: "Jessica Patel", value: "jessica-patel" },
  { label: "James Wilson", value: "james-wilson" },
  { label: "Olivia Martinez", value: "olivia-martinez" },
  { label: "Daniel Thompson", value: "daniel-thompson" },
]

const recognitionTypes = [
  { label: "Outstanding Performance", value: "performance" },
  { label: "Team Collaboration", value: "collaboration" },
  { label: "Innovation", value: "innovation" },
  { label: "Customer Service", value: "customer-service" },
  { label: "Leadership", value: "leadership" },
  { label: "Going Above & Beyond", value: "above-beyond" },
]

const formSchema = z.object({
  employee: z.string({
    required_error: "Please select an employee to recognize.",
  }),
  recognitionType: z.string({
    required_error: "Please select a recognition type.",
  }),
  message: z
    .string()
    .min(10, {
      message: "Recognition message must be at least 10 characters.",
    })
    .max(500, {
      message: "Recognition message must not exceed 500 characters.",
    }),
})

export function EmployeeRecognitionForm() {
  const [employeeOpen, setEmployeeOpen] = useState(false)
  const [recognitionTypeOpen, setRecognitionTypeOpen] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      message: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    toast({
      title: "Recognition submitted!",
      description: "Your recognition has been sent successfully.",
    })
    form.reset()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recognize a Colleague</CardTitle>
        <CardDescription>Give recognition to someone who has done exceptional work.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="employee"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Employee</FormLabel>
                  <Popover open={employeeOpen} onOpenChange={setEmployeeOpen}>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={employeeOpen}
                          className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                        >
                          {field.value
                            ? employees.find((employee) => employee.value === field.value)?.label
                            : "Select employee"}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search employee..." />
                        <CommandList>
                          <CommandEmpty>No employee found.</CommandEmpty>
                          <CommandGroup>
                            {employees.map((employee) => (
                              <CommandItem
                                key={employee.value}
                                value={employee.value}
                                onSelect={(value) => {
                                  form.setValue("employee", value)
                                  setEmployeeOpen(false)
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    employee.value === field.value ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                {employee.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="recognitionType"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Recognition Type</FormLabel>
                  <Popover open={recognitionTypeOpen} onOpenChange={setRecognitionTypeOpen}>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={recognitionTypeOpen}
                          className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                        >
                          {field.value
                            ? recognitionTypes.find((type) => type.value === field.value)?.label
                            : "Select recognition type"}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0">
                      <Command>
                        <CommandInput placeholder="Search recognition type..." />
                        <CommandList>
                          <CommandEmpty>No recognition type found.</CommandEmpty>
                          <CommandGroup>
                            {recognitionTypes.map((type) => (
                              <CommandItem
                                key={type.value}
                                value={type.value}
                                onSelect={(value) => {
                                  form.setValue("recognitionType", value)
                                  setRecognitionTypeOpen(false)
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    type.value === field.value ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                {type.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recognition Message</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe why you're recognizing this person..."
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>Be specific about their contribution and impact.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full">
              Submit Recognition
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}

