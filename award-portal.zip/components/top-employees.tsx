import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface TopEmployeesProps {
  className?: string
}

const topEmployees = [
  {
    name: "Emily Rodriguez",
    department: "Marketing",
    recognitions: 42,
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "ER",
  },
  {
    name: "Michael Chen",
    department: "Engineering",
    recognitions: 38,
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MC",
  },
  {
    name: "Jessica Patel",
    department: "Customer Support",
    recognitions: 35,
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JP",
  },
  {
    name: "David Kim",
    department: "Product",
    recognitions: 31,
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "DK",
  },
  {
    name: "Sarah Johnson",
    department: "Sales",
    recognitions: 29,
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SJ",
  },
]

export function TopEmployees({ className }: TopEmployeesProps) {
  return (
    <Card className={cn("h-full", className)}>
      <CardHeader>
        <CardTitle>Top Recognized Employees</CardTitle>
        <CardDescription>Employees with the most recognitions this quarter.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {topEmployees.map((employee, index) => (
            <div key={employee.name} className="flex items-center gap-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-sm font-medium">
                {index + 1}
              </div>
              <Avatar>
                <AvatarImage src={employee.avatar} alt={employee.name} />
                <AvatarFallback>{employee.initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium leading-none">{employee.name}</p>
                <p className="text-xs text-muted-foreground">{employee.department}</p>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-sm font-medium">{employee.recognitions}</span>
                <span className="text-xs text-muted-foreground">recognitions</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

