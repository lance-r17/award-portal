import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const recognitions = [
  {
    id: 1,
    recipient: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
    },
    sender: {
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
    },
    type: "Outstanding Performance",
    message:
      "Sarah went above and beyond to deliver the project ahead of schedule. Her attention to detail and commitment to quality were exceptional.",
    date: "2 hours ago",
  },
  {
    id: 2,
    recipient: {
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
    },
    sender: {
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
    },
    type: "Team Collaboration",
    message:
      "David has been an incredible team player, always willing to help others and share his knowledge. His collaborative spirit makes our team stronger.",
    date: "Yesterday",
  },
  {
    id: 3,
    recipient: {
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
    },
    sender: {
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
    },
    type: "Innovation",
    message:
      "Jessica's innovative solution to our client's problem saved us countless hours and improved our overall process. Her creativity is inspiring.",
    date: "3 days ago",
  },
]

export function RecentRecognitions() {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Recent Recognitions</CardTitle>
        <CardDescription>Latest acknowledgments across the organization.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {recognitions.map((recognition) => (
            <div key={recognition.id} className="space-y-2">
              <div className="flex items-start gap-4">
                <Avatar>
                  <AvatarImage src={recognition.recipient.avatar} alt={recognition.recipient.name} />
                  <AvatarFallback>{recognition.recipient.initials}</AvatarFallback>
                </Avatar>
                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">{recognition.recipient.name}</p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <span>Recognized by {recognition.sender.name}</span>
                        <span>•</span>
                        <span>{recognition.date}</span>
                      </div>
                    </div>
                    <Badge variant="outline">{recognition.type}</Badge>
                  </div>
                  <p className="text-sm">{recognition.message}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

