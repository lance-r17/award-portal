import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface NominationSubmittedEmailProps {
  nominatorName: string
  nomineeName: string
  awardType: string
  eventName: string
  nominationDate: string
  previewUrl: string
}

export default function NominationSubmittedEmail({
  nominatorName,
  nomineeName,
  awardType,
  eventName,
  nominationDate,
  previewUrl,
}: NominationSubmittedEmailProps) {
  return (
    <BaseEmail previewText={`Your nomination for ${nomineeName} has been submitted`}>
      <Heading className="text-xl font-bold text-center my-6">Nomination Submitted</Heading>
      <Section>
        <Text className="text-base">Hi {nominatorName},</Text>
        <Text className="text-base">
          Your nomination for <strong>{nomineeName}</strong> for the <strong>{awardType}</strong> in{" "}
          <strong>{eventName}</strong> has been successfully submitted on {nominationDate}.
        </Text>
        <Text className="text-base">
          Thank you for recognizing the outstanding contributions of your colleagues. Your nomination will be reviewed
          by our panel of judges.
        </Text>
        <Text className="text-base">You can view the status of your nomination by clicking the button below.</Text>
        <Button className="bg-blue-600 text-white font-bold py-2 px-4 rounded" href={previewUrl}>
          View Nomination
        </Button>
      </Section>
    </BaseEmail>
  )
}
