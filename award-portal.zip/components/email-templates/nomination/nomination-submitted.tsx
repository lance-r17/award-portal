import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface NominationSubmittedEmailProps {
  nominatorName: string
  nomineeName: string
  awardType: string
  eventName: string
  nominationDate: string
  previewUrl: string
}

export const NominationSubmittedEmail = ({
  nominatorName,
  nomineeName,
  awardType,
  eventName,
  nominationDate,
  previewUrl,
}: NominationSubmittedEmailProps) => {
  return (
    <BaseEmail previewText={`Your nomination for ${nomineeName} has been submitted`}>
      <Heading className="text-2xl font-bold text-gray-800">Nomination Submitted</Heading>
      <Section>
        <Text className="text-gray-700">Hi {nominatorName},</Text>
        <Text className="text-gray-700">
          Your nomination for <strong>{nomineeName}</strong> for the <strong>{awardType}</strong> in{" "}
          <strong>{eventName}</strong> has been successfully submitted on {nominationDate}.
        </Text>
        <Text className="text-gray-700">
          Thank you for recognizing your colleague's outstanding contributions. The nomination will now go through the
          review process.
        </Text>
        <Button className="rounded bg-blue-600 px-4 py-2 font-semibold text-white" href={previewUrl}>
          View Nomination
        </Button>
      </Section>
    </BaseEmail>
  )
}

export default NominationSubmittedEmail

