import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface NominationReceivedEmailProps {
  nomineeName: string
  nominatorName: string
  awardType: string
  eventName: string
  nominationDate: string
  previewUrl: string
}

export default function NominationReceivedEmail({
  nomineeName,
  nominatorName,
  awardType,
  eventName,
  nominationDate,
  previewUrl,
}: NominationReceivedEmailProps) {
  return (
    <BaseEmail previewText={`You've been nominated for a ${awardType}`}>
      <Heading className="text-xl font-bold text-center my-6">You've Been Nominated!</Heading>
      <Section>
        <Text className="text-base">Congratulations {nomineeName}!</Text>
        <Text className="text-base">
          We're pleased to inform you that <strong>{nominatorName}</strong> has nominated you for a{" "}
          <strong>{awardType}</strong> in <strong>{eventName}</strong> on {nominationDate}.
        </Text>
        <Text className="text-base">
          This nomination recognizes your outstanding contributions and the positive impact you've made. The nomination
          will be reviewed by our panel of judges.
        </Text>
        <Text className="text-base">You can view the details of your nomination by clicking the button below.</Text>
        <Button className="bg-blue-600 text-white font-bold py-2 px-4 rounded" href={previewUrl}>
          View Nomination
        </Button>
      </Section>
    </BaseEmail>
  )
}
