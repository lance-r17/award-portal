import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface NominationReceivedEmailProps {
  nomineeName: string
  nominatorName: string
  awardType: string
  eventName: string
  nominationDate: string
  previewUrl: string
}

export const NominationReceivedEmail = ({
  nomineeName,
  nominatorName,
  awardType,
  eventName,
  nominationDate,
  previewUrl,
}: NominationReceivedEmailProps) => {
  return (
    <BaseEmail previewText={`You've been nominated for a ${awardType}`}>
      <Heading className="text-2xl font-bold text-gray-800">You've Been Nominated!</Heading>
      <Section>
        <Text className="text-gray-700">Hi {nomineeName},</Text>
        <Text className="text-gray-700">
          Congratulations! <strong>{nominatorName}</strong> has nominated you for a <strong>{awardType}</strong> in{" "}
          <strong>{eventName}</strong> on {nominationDate}.
        </Text>
        <Text className="text-gray-700">
          This recognition highlights your valuable contributions and the positive impact you've made.
        </Text>
        <Button className="rounded bg-blue-600 px-4 py-2 font-semibold text-white" href={previewUrl}>
          View Nomination
        </Button>
      </Section>
    </BaseEmail>
  )
}

export default NominationReceivedEmail

