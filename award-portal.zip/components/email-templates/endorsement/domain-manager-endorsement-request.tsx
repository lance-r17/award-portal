import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface DomainManagerEndorsementRequestEmailProps {
  managerName: string
  nomineeName: string
  nominatorName: string
  awardType: string
  eventName: string
  nominationDate: string
  justificationPreview: string
  endorsementUrl: string
  deadline: string
}

export default function DomainManagerEndorsementRequestEmail({
  managerName = "Domain Manager",
  nomineeName = "John Doe",
  nominatorName = "Jane Smith",
  awardType = "Spot Award",
  eventName = "Q2 Recognition Event",
  nominationDate = "June 15, 2023",
  justificationPreview = "This employee has demonstrated exceptional performance...",
  endorsementUrl = "#",
  deadline = "June 22, 2023",
}: DomainManagerEndorsementRequestEmailProps) {
  return (
    <BaseEmail previewText={`Endorsement Request: ${nomineeName} has been nominated for a ${awardType}`}>
      <Heading className="text-xl font-bold text-center my-6">Endorsement Request</Heading>
      <Section>
        <Text className="text-base">Hello {managerName},</Text>
        <Text className="text-base">
          <strong>{nominatorName}</strong> has nominated <strong>{nomineeName}</strong> for a{" "}
          <strong>{awardType}</strong> in <strong>{eventName}</strong> on {nominationDate}.
        </Text>
        <Text className="text-base">
          As their domain manager, your endorsement is required for this nomination to proceed to the judging phase.
        </Text>
        <Text className="text-base font-medium">Nomination Justification Preview:</Text>
        <Text className="text-base italic px-4 py-2 bg-gray-100">"{justificationPreview}..."</Text>
        <Text className="text-base">
          Please review the complete nomination and provide your endorsement by <strong>{deadline}</strong>.
        </Text>
        <Button
          href={endorsementUrl}
          style={{
            backgroundColor: "#2563eb",
            color: "#ffffff",
            fontWeight: "bold",
            padding: "12px 16px",
            borderRadius: "4px",
          }}
        >
          Review & Endorse Nomination
        </Button>
      </Section>
    </BaseEmail>
  )
}
