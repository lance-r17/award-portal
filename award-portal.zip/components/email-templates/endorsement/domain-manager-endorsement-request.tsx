import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface DomainManagerEndorsementRequestEmailProps {
  managerName: string
  nomineeName: string
  nominatorName: string
  awardType: string
  eventName: string
  nominationDate: string
  justificationPreview: string
  endorsementUrl: string
  deadline: string
}

export default function DomainManagerEndorsementRequestEmail({
  managerName,
  nomineeName,
  nominatorName,
  awardType,
  eventName,
  nominationDate,
  justificationPreview,
  endorsementUrl,
  deadline,
}: DomainManagerEndorsementRequestEmailProps) {
  return (
    <BaseEmail previewText={`Endorsement Request: ${nomineeName} has been nominated for a ${awardType}`}>
      <Heading className="text-xl font-bold text-center my-6">Endorsement Request</Heading>
      <Section>
        <Text className="text-base">Hello {managerName},</Text>
        <Text className="text-base">
          <strong>{nominatorName}</strong> has nominated <strong>{nomineeName}</strong> for a{" "}
          <strong>{awardType}</strong> in <strong>{eventName}</strong> on {nominationDate}.
        </Text>
        <Text className="text-base">
          As their domain manager, your endorsement is required for this nomination to proceed to the judging phase.
        </Text>
        <Text className="text-base font-medium">Nomination Justification Preview:</Text>
        <Text className="text-base italic px-4 py-2 bg-gray-100">"{justificationPreview}..."</Text>
        <Text className="text-base">
          Please review the complete nomination and provide your endorsement by <strong>{deadline}</strong>.
        </Text>
        <Button className="bg-blue-600 text-white font-bold py-2 px-4 rounded" href={endorsementUrl}>
          Review & Endorse Nomination
        </Button>
      </Section>
    </BaseEmail>
  )
}

