import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface CommentNotificationEmailProps {
  recipientName: string
  commenterName: string
  nominationTitle: string
  commentPreview: string
  commentDate: string
  viewCommentUrl: string
}

export const CommentNotificationEmail = ({
  recipientName,
  commenterName,
  nominationTitle,
  commentPreview,
  commentDate,
  viewCommentUrl,
}: CommentNotificationEmailProps) => {
  return (
    <BaseEmail previewText={`${commenterName} commented on a nomination`}>
      <Heading className="text-2xl font-bold text-gray-800">New Comment</Heading>
      <Section>
        <Text className="text-gray-700">Hi {recipientName},</Text>
        <Text className="text-gray-700">
          <strong>{commenterName}</strong> has commented on the nomination "{nominationTitle}" on {commentDate}.
        </Text>
        <Section className="my-4 rounded border-l-4 border-gray-300 bg-gray-50 p-4">
          <Text className="italic text-gray-600">"{commentPreview}"</Text>
        </Section>
        <Button className="rounded bg-blue-600 px-4 py-2 font-semibold text-white" href={viewCommentUrl}>
          View Comment
        </Button>
      </Section>
    </BaseEmail>
  )
}

export default CommentNotificationEmail

