import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface CommentNotificationEmailProps {
  recipientName: string
  commenterName: string
  nominationTitle: string
  commentPreview: string
  commentDate: string
  viewCommentUrl: string
}

export default function CommentNotificationEmail({
  recipientName,
  commenterName,
  nominationTitle,
  commentPreview,
  commentDate,
  viewCommentUrl,
}: CommentNotificationEmailProps) {
  return (
    <BaseEmail previewText={`${commenterName} commented on a nomination`}>
      <Heading className="text-xl font-bold text-center my-6">New Comment on Nomination</Heading>
      <Section>
        <Text className="text-base">Hi {recipientName},</Text>
        <Text className="text-base">
          <strong>{commenterName}</strong> has commented on the nomination "<strong>{nominationTitle}</strong>" on{" "}
          {commentDate}.
        </Text>
        <Text className="text-base italic border-l-4 border-gray-300 pl-4 my-4">"{commentPreview}"</Text>
        <Text className="text-base">Click the button below to view the full comment and respond if needed.</Text>
        <Button className="bg-blue-600 text-white font-bold py-2 px-4 rounded" href={viewCommentUrl}>
          View Comment
        </Button>
      </Section>
    </BaseEmail>
  )
}
