import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface WinnerAnnouncementEmailProps {
  recipientName: string
  winnerName: string
  awardType: string
  eventName: string
  announcementDate: string
  celebrationDetails?: string
  viewDetailsUrl: string
}

export const WinnerAnnouncementEmail = ({
  recipientName,
  winnerName,
  awardType,
  eventName,
  announcementDate,
  celebrationDetails,
  viewDetailsUrl,
}: WinnerAnnouncementEmailProps) => {
  return (
    <BaseEmail previewText={`${winnerName} has won the ${awardType} in ${eventName}`}>
      <Heading className="text-2xl font-bold text-gray-800">Award Winner Announcement</Heading>
      <Section>
        <Text className="text-gray-700">Hi {recipientName},</Text>
        <Text className="text-gray-700">
          We are pleased to announce that <strong>{winnerName}</strong> has been selected as the winner of the{" "}
          <strong>{awardType}</strong> in <strong>{eventName}</strong> on {announcementDate}.
        </Text>
        {celebrationDetails && <Text className="text-gray-700">{celebrationDetails}</Text>}
        <Text className="text-gray-700 mb-4">
          Please join us in congratulating them on this well-deserved recognition!
        </Text>
        <Button className="rounded bg-blue-600 px-4 py-2 font-semibold text-white" href={viewDetailsUrl}>
          View Details
        </Button>
      </Section>
    </BaseEmail>
  )
}

export default WinnerAnnouncementEmail

