import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface WinnerAnnouncementEmailProps {
  recipientName: string
  winnerName: string
  awardType: string
  eventName: string
  announcementDate: string
  celebrationDetails: string
  viewDetailsUrl: string
}

export default function WinnerAnnouncementEmail({
  recipientName,
  winnerName,
  awardType,
  eventName,
  announcementDate,
  celebrationDetails,
  viewDetailsUrl,
}: WinnerAnnouncementEmailProps) {
  return (
    <BaseEmail previewText={`${winnerName} has won the ${awardType}`}>
      <Heading className="text-xl font-bold text-center my-6">Award Winner Announcement</Heading>
      <Section>
        <Text className="text-base">Dear {recipientName},</Text>
        <Text className="text-base">
          We are delighted to announce that <strong>{winnerName}</strong> has been selected as the winner of the{" "}
          <strong>{awardType}</strong> in <strong>{eventName}</strong> on {announcementDate}.
        </Text>
        <Text className="text-base">
          This recognition celebrates their exceptional contributions and dedication to excellence.
        </Text>
        <Text className="text-base">{celebrationDetails}</Text>
        <Text className="text-base">
          Please join us in congratulating {winnerName} on this well-deserved achievement!
        </Text>
        <Button className="bg-blue-600 text-white font-bold py-2 px-4 rounded" href={viewDetailsUrl}>
          View Details
        </Button>
      </Section>
    </BaseEmail>
  )
}
