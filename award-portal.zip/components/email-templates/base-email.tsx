import { Body, Container, Head, Html, Preview, Section, Tailwind, Text } from "@react-email/components"
import type { ReactNode } from "react"

interface BaseEmailProps {
  previewText: string
  children: ReactNode
}

export const BaseEmail = ({ previewText, children }: BaseEmailProps) => {
  return (
    <Html>
      <Head />
      <Preview>{previewText}</Preview>
      <Tailwind>
        <Body className="bg-gray-100 font-sans">
          <Container className="mx-auto my-8 max-w-[600px] rounded bg-white p-8">
            <Section className="mb-6 border-b border-gray-200 pb-4">
              <img src="https://v0.dev/placeholder.svg?height=60&width=200" alt="Spot Award Logo" className="h-10" />
            </Section>
            {children}
            <Section className="mt-8 border-t border-gray-200 pt-4 text-center text-xs text-gray-500">
              <Text>© {new Date().getFullYear()} Your Company. All rights reserved.</Text>
              <Text>This email was sent to you because you are part of the Spot Award program.</Text>
            </Section>
          </Container>
        </Body>
      </Tailwind>
    </Html>
  )
}
