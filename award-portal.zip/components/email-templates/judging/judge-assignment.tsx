import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface JudgeAssignmentEmailProps {
  judgeName: string
  eventName: string
  awardType: string
  nominationCount: number
  deadline: string
  judgingUrl: string
}

export const JudgeAssignmentEmail = ({
  judgeName,
  eventName,
  awardType,
  nominationCount,
  deadline,
  judgingUrl,
}: JudgeAssignmentEmailProps) => {
  return (
    <BaseEmail previewText={`You've been assigned as a judge for ${eventName}`}>
      <Heading className="text-2xl font-bold text-gray-800">Judge Assignment</Heading>
      <Section>
        <Text className="text-gray-700">Hi {judgeName},</Text>
        <Text className="text-gray-700">
          You have been assigned as a judge for the <strong>{awardType}</strong> in <strong>{eventName}</strong>.
        </Text>
        <Text className="text-gray-700">
          There are <strong>{nominationCount} nominations</strong> waiting for your review. Please complete your scoring
          by <strong>{deadline}</strong>.
        </Text>
        <Text className="text-gray-700 mb-4">
          Your expertise and fair assessment are crucial to recognizing deserving colleagues.
        </Text>
        <Button className="rounded bg-blue-600 px-4 py-2 font-semibold text-white" href={judgingUrl}>
          Start Judging
        </Button>
      </Section>
    </BaseEmail>
  )
}

export default JudgeAssignmentEmail

