import { Button, Heading, Section, Text } from "@react-email/components"
import { BaseEmail } from "../base-email"

export interface JudgeAssignmentEmailProps {
  judgeName: string
  eventName: string
  awardType: string
  nominationCount: number
  deadline: string
  judgingUrl: string
}

export default function JudgeAssignmentEmail({
  judgeName,
  eventName,
  awardType,
  nominationCount,
  deadline,
  judgingUrl,
}: JudgeAssignmentEmailProps) {
  return (
    <BaseEmail previewText={`You've been assigned as a judge for ${eventName}`}>
      <Heading className="text-xl font-bold text-center my-6">Judge Assignment</Heading>
      <Section>
        <Text className="text-base">Hello {judgeName},</Text>
        <Text className="text-base">
          You have been assigned as a judge for the <strong>{awardType}</strong> in <strong>{eventName}</strong>.
        </Text>
        <Text className="text-base">
          There are <strong>{nominationCount} nominations</strong> that require your evaluation. Please complete your
          judging by <strong>{deadline}</strong>.
        </Text>
        <Text className="text-base">
          Your expertise and fair assessment are crucial to our recognition process. Thank you for your contribution to
          making our award program a success.
        </Text>
        <Button className="bg-blue-600 text-white font-bold py-2 px-4 rounded" href={judgingUrl}>
          Start Judging
        </Button>
      </Section>
    </BaseEmail>
  )
}

