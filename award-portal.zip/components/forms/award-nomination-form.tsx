"use client"

// components/forms/award-nomination-form.tsx
// This is a new file, so we'll create the entire component here.

import type React from "react"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface AwardNominationFormProps {
  formData: any // Replace 'any' with a more specific type if possible
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void
  errors: any // Replace 'any' with a more specific type if possible
}

const AwardNominationForm: React.FC<AwardNominationFormProps> = ({ formData, handleChange, errors }) => {
  return (
    <form className="space-y-4">
      {/* Example fields - replace with your actual form fields */}
      <div>
        <Label htmlFor="nominatorName">Your Name</Label>
        <input
          type="text"
          id="nominatorName"
          name="nominatorName"
          value={formData.nominatorName}
          onChange={handleChange}
          className="w-full border rounded px-3 py-2"
          required
        />
        {errors.nominatorName && <p className="text-sm text-destructive">{errors.nominatorName}</p>}
      </div>

      <div>
        <Label htmlFor="nomineeName">Nominee's Name</Label>
        <input
          type="text"
          id="nomineeName"
          name="nomineeName"
          value={formData.nomineeName}
          onChange={handleChange}
          className="w-full border rounded px-3 py-2"
          required
        />
        {errors.nomineeName && <p className="text-sm text-destructive">{errors.nomineeName}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="nominationSummary">Nomination Summary</Label>

        {/* Always visible instructions */}
        <div className="bg-muted/50 rounded p-2 text-sm text-muted-foreground mb-1">
          <p className="font-medium mb-1">Tips for a great nomination:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Describe specific achievements and their impact</li>
            <li>Include measurable results when possible</li>
            <li>Explain how they went above and beyond</li>
            <li>Keep it concise and focused on key contributions</li>
          </ul>
        </div>

        <Textarea
          id="nominationSummary"
          name="nominationSummary"
          value={formData.nominationSummary}
          onChange={handleChange}
          placeholder="Summarize why this person deserves recognition..."
          className="min-h-[150px]"
          required
        />
        {errors.nominationSummary && <p className="text-sm text-destructive">{errors.nominationSummary}</p>}
      </div>

      {/* Add more form fields here */}

      {/* Example submit button */}
      <div>
        <button type="submit" className="bg-primary text-primary-foreground rounded px-4 py-2">
          Submit Nomination
        </button>
      </div>
    </form>
  )
}

export default AwardNominationForm
