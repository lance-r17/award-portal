import type { AwardEvent } from "@/types/award-events"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CalendarDays, ChevronRight, Clock, Trophy, FileText, Zap, Award } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { getCurrentStageLabel, getStageTimeRemaining } from "@/data/award-events"
import { cn } from "@/lib/utils"

interface AwardEventCardProps {
  event: AwardEvent
  currentUser?: {
    id: string
    name: string
    role?: string
  }
}

export function AwardEventCard({
  event,
  currentUser = { id: "current-user", name: "Current User" },
}: AwardEventCardProps) {
  const stageLabel = getCurrentStageLabel(event.currentStage)
  const timeRemaining = getStageTimeRemaining(event)

  const isCreatorOrFacilitator =
    event.createdBy?.id === currentUser.id || event.facilitators?.some((f) => f.id === currentUser.id)

  // Only show draft events to creators and facilitators
  if (event.status === "draft" && !isCreatorOrFacilitator) {
    return null
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{event.title}</CardTitle>
            <CardDescription>{event.description}</CardDescription>
          </div>
          <div className="flex flex-col gap-1 items-end">
            <Badge
              variant={event.type === "spot" ? "default" : "secondary"}
              className="h-6 w-6 rounded-full p-0 flex items-center justify-center"
              title={event.type === "spot" ? "Spot Award" : "Recognition Award"}
            >
              {event.type === "spot" ? <Zap className="h-3.5 w-3.5" /> : <Award className="h-3.5 w-3.5" />}
            </Badge>
            {event.status === "draft" && (
              <Badge variant="outline" className="border-dashed">
                <FileText className="mr-1 h-3 w-3" />
                Draft
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="space-y-3">
          {event.theme && (
            <div className="flex items-center gap-2 text-sm">
              <Trophy className="h-4 w-4 text-muted-foreground" />
              <span>
                Theme: <span className="font-medium">{event.theme}</span>
              </span>
            </div>
          )}
          <div className="flex items-center gap-2 text-sm">
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
            <span>
              Quarter: <span className="font-medium">{event.quarter}</span>
            </span>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span>
                Current Stage: <span className="font-medium">{stageLabel}</span>
              </span>
            </div>
            <div className="ml-6 text-xs text-muted-foreground">{timeRemaining}</div>
          </div>

          <div className="mt-2 pt-2 border-t">
            <div className="flex justify-between items-center">
              <div className="flex gap-2">
                <div
                  className={`h-2 w-2 rounded-full ${event.currentStage === "nomination" ? "bg-primary" : "bg-muted"}`}
                ></div>
                <div
                  className={`h-2 w-2 rounded-full ${event.currentStage === "presentation" ? "bg-primary" : "bg-muted"}`}
                ></div>
                <div
                  className={`h-2 w-2 rounded-full ${event.currentStage === "result" ? "bg-primary" : "bg-muted"}`}
                ></div>
              </div>
              <div className="text-xs text-muted-foreground">
                {event.currentStage === "nomination" &&
                  `Nominations close: ${format(event.stages.nomination.endDate, "MMM d, yyyy")}`}
                {event.currentStage === "presentation" &&
                  `Presentations end: ${format(event.stages.presentation.endDate, "MMM d, yyyy")}`}
                {event.currentStage === "result" &&
                  `Results announced: ${format(event.stages.result.endDate, "MMM d, yyyy")}`}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button
          asChild
          className={cn("w-full", event.status === "draft" && "bg-muted text-muted-foreground hover:bg-muted/80")}
        >
          <Link href={`/awards/${event.type}/${event.id}`}>
            {event.status === "draft" ? (
              <>Edit Draft</>
            ) : (
              <>
                {event.currentStage === "nomination" && "Submit Nomination"}
                {event.currentStage === "presentation" && "View Presentations"}
                {event.currentStage === "result" && "View Results"}
              </>
            )}
            <ChevronRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

