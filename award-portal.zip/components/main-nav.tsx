import type React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { RoleSwitcher } from "@/components/role-switcher"
import { useUser } from "@/contexts/user-context"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

export function MainNav({ className, ...props }: React.HTMLAttributes<HTMLElement>) {
  const { user } = useUser()

  return (
    <nav className={cn("flex items-center space-x-4 lg:space-x-6", className)} {...props}>
      <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
        Dashboard
      </Link>
      <Link href="/awards" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
        Awards
      </Link>
      <Link
        href="/awards/spot-awards"
        className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
      >
        Spot Awards
      </Link>
      <Link
        href="/awards/annual-awards"
        className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
      >
        Annual Awards
      </Link>
      <div className="ml-auto flex items-center">
        <RoleSwitcher />
        {user && (
          <>
            <Avatar>
              <AvatarImage src={user?.avatar} alt={user?.name} />
              <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <span className="ml-2 hidden md:inline-block">{user?.name}</span>
          </>
        )}
      </div>
    </nav>
  )
}
