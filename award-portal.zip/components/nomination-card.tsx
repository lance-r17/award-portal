"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import type { Nomination } from "@/types/nominations"
import { CalendarDays, Users } from "lucide-react"

interface NominationCardProps {
  nomination: Nomination
  onClick: () => void
}

export function NominationCard({ nomination, onClick }: NominationCardProps) {
  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const awardTypes: Record<string, string> = {
      "star-of-agile": "Star of Agile",
      "star-of-customer-service": "Star of Customer Service",
      "star-of-engagement": "Star of Engagement",
      "star-of-innovation": "Star of Innovation",
      "star-of-leadership": "Star of Leadership",
      "all-star-team": "All-Star Team",
    }
    return awardTypes[awardType] || awardType
  }

  return (
    <Card className="h-full cursor-pointer transition-all hover:border-primary hover:shadow-sm" onClick={onClick}>
      <CardContent className="p-5">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Badge variant="outline">{getAwardTypeDisplay(nomination.awardType)}</Badge>
            <Badge variant={nomination.nominationType === "individual" ? "default" : "secondary"}>
              {nomination.nominationType === "individual" ? "Individual" : "Team"}
            </Badge>
          </div>

          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
              <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{nomination.nominee.name}</p>
              <p className="text-sm text-muted-foreground">{nomination.nominee.department}</p>
            </div>
          </div>

          {nomination.nominationType === "team" && nomination.team && (
            <div className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">
                Team Members:{" "}
                {Array.isArray(nomination.team.members)
                  ? nomination.team.members.length
                  : typeof nomination.team.members === "string"
                    ? nomination.team.members.split(",").length
                    : 0}
              </span>
            </div>
          )}

          <div className="line-clamp-3 text-sm">{nomination.justification}</div>
        </div>
      </CardContent>

      <CardFooter className="border-t px-5 py-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-3 w-3" />
          <span>Nominated on {nomination.createdAt.toLocaleDateString()}</span>
        </div>
      </CardFooter>
    </Card>
  )
}

