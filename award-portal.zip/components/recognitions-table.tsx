"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { format } from "date-fns"
import { Copy, Download, MoreHorizontal, Printer, Share2 } from "lucide-react"
import { useState } from "react"

// Sample data for the table
const recognitionsData = [
  {
    id: "REC-001",
    recipient: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Marketing",
    },
    sender: {
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Engineering",
    },
    type: "Outstanding Performance",
    message:
      "Sarah went above and beyond to deliver the project ahead of schedule. Her attention to detail and commitment to quality were exceptional. The client was extremely impressed with her work and has already requested her for future projects.",
    date: new Date("2023-06-15T10:30:00"),
    status: "Approved",
  },
  {
    id: "REC-002",
    recipient: {
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Product",
    },
    sender: {
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
      department: "Marketing",
    },
    type: "Team Collaboration",
    message:
      "David has been an incredible team player, always willing to help others and share his knowledge. His collaborative spirit makes our team stronger. He stayed late multiple days to help the new team members get up to speed on our processes.",
    date: new Date("2023-06-14T14:45:00"),
    status: "Approved",
  },
  {
    id: "REC-003",
    recipient: {
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Customer Support",
    },
    sender: {
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Sales",
    },
    type: "Innovation",
    message:
      "Jessica's innovative solution to our client's problem saved us countless hours and improved our overall process. Her creativity is inspiring. The new workflow she designed has been implemented across all customer support teams.",
    date: new Date("2023-06-12T09:15:00"),
    status: "Approved",
  },
  {
    id: "REC-004",
    recipient: {
      name: "Olivia Martinez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "OM",
      department: "Engineering",
    },
    sender: {
      name: "Daniel Thompson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DT",
      department: "Product",
    },
    type: "Leadership",
    message:
      "Olivia stepped up as a leader during our recent project crisis. She organized the team, delegated tasks effectively, and kept everyone motivated. We wouldn't have met our deadline without her leadership.",
    date: new Date("2023-06-10T16:20:00"),
    status: "Approved",
  },
  {
    id: "REC-005",
    recipient: {
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Engineering",
    },
    sender: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Marketing",
    },
    type: "Going Above & Beyond",
    message:
      "Michael worked through the weekend to fix a critical bug that was affecting our customers. His dedication to ensuring a smooth user experience is commendable. The fix was deployed without any downtime to our services.",
    date: new Date("2023-06-08T11:05:00"),
    status: "Approved",
  },
  {
    id: "REC-006",
    recipient: {
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
      department: "Marketing",
    },
    sender: {
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Product",
    },
    type: "Customer Service",
    message:
      "Emily went out of her way to address a customer's concerns, spending hours on the phone to ensure they were satisfied. Her patience and empathy turned a potentially negative situation into a positive one.",
    date: new Date("2023-06-05T13:40:00"),
    status: "Pending",
  },
  {
    id: "REC-007",
    recipient: {
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Sales",
    },
    sender: {
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Customer Support",
    },
    type: "Outstanding Performance",
    message:
      "James closed our biggest deal of the quarter. His persistence and relationship-building skills are truly impressive. This deal will significantly impact our revenue targets for the year.",
    date: new Date("2023-06-03T15:55:00"),
    status: "Approved",
  },
]

export function RecognitionsTable() {
  const [selectedRecognition, setSelectedRecognition] = useState<(typeof recognitionsData)[0] | null>(null)

  return (
    <Card>
      <CardHeader>
        <CardTitle>All Recognitions</CardTitle>
        <CardDescription>A complete list of employee recognitions across the organization.</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Recipient</TableHead>
              <TableHead>Sender</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {recognitionsData.map((recognition) => (
              <TableRow key={recognition.id}>
                <TableCell className="font-medium">{recognition.id}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={recognition.recipient.avatar} alt={recognition.recipient.name} />
                      <AvatarFallback>{recognition.recipient.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{recognition.recipient.name}</p>
                      <p className="text-xs text-muted-foreground">{recognition.recipient.department}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={recognition.sender.avatar} alt={recognition.sender.name} />
                      <AvatarFallback>{recognition.sender.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{recognition.sender.name}</p>
                      <p className="text-xs text-muted-foreground">{recognition.sender.department}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{recognition.type}</Badge>
                </TableCell>
                <TableCell>{format(recognition.date, "MMM d, yyyy")}</TableCell>
                <TableCell>
                  <Badge variant={recognition.status === "Approved" ? "default" : "secondary"}>
                    {recognition.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Dialog>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DialogTrigger asChild>
                          <DropdownMenuItem onClick={() => setSelectedRecognition(recognition)}>
                            View details
                          </DropdownMenuItem>
                        </DialogTrigger>
                        <DropdownMenuItem>
                          <Share2 className="mr-2 h-4 w-4" />
                          Share
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Copy className="mr-2 h-4 w-4" />
                          Copy ID
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          Export
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Printer className="mr-2 h-4 w-4" />
                          Print
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    {selectedRecognition && (
                      <DialogContent className="sm:max-w-[525px]">
                        <DialogHeader>
                          <DialogTitle>Recognition Details</DialogTitle>
                          <DialogDescription>
                            {selectedRecognition.id} • {format(selectedRecognition.date, "MMMM d, yyyy 'at' h:mm a")}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarImage
                                  src={selectedRecognition.recipient.avatar}
                                  alt={selectedRecognition.recipient.name}
                                />
                                <AvatarFallback>{selectedRecognition.recipient.initials}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{selectedRecognition.recipient.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {selectedRecognition.recipient.department}
                                </p>
                              </div>
                            </div>
                            <Badge variant="outline">{selectedRecognition.type}</Badge>
                          </div>
                          <div className="rounded-lg border p-4">
                            <p className="text-sm">{selectedRecognition.message}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <p className="text-sm text-muted-foreground">Recognized by:</p>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage
                                  src={selectedRecognition.sender.avatar}
                                  alt={selectedRecognition.sender.name}
                                />
                                <AvatarFallback>{selectedRecognition.sender.initials}</AvatarFallback>
                              </Avatar>
                              <p className="text-sm font-medium">{selectedRecognition.sender.name}</p>
                            </div>
                          </div>
                          <div className="flex justify-between">
                            <Badge variant={selectedRecognition.status === "Approved" ? "default" : "secondary"}>
                              {selectedRecognition.status}
                            </Badge>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline">
                                <Share2 className="mr-2 h-4 w-4" />
                                Share
                              </Button>
                              <Button size="sm">
                                <Download className="mr-2 h-4 w-4" />
                                Export
                              </Button>
                            </div>
                          </div>
                        </div>
                      </DialogContent>
                    )}
                  </Dialog>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
      <CardFooter className="flex items-center justify-between border-t p-4">
        <div className="text-sm text-muted-foreground">
          Showing <strong>7</strong> of <strong>42</strong> recognitions
        </div>
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious href="#" />
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#" isActive>
                1
              </PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">2</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink href="#">3</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationEllipsis />
            </PaginationItem>
            <PaginationItem>
              <PaginationNext href="#" />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </CardFooter>
    </Card>
  )
}

