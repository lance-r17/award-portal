"use client"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"
import { zodResolver } from "@hookform/resolvers/zod"
import { format } from "date-fns"
import { CalendarIcon, Check, ChevronsUpDown, Search } from "lucide-react"
import { useForm } from "react-hook-form"
import * as z from "zod"

const departments = [
  { label: "All Departments", value: "all" },
  { label: "Engineering", value: "engineering" },
  { label: "Marketing", value: "marketing" },
  { label: "Sales", value: "sales" },
  { label: "Customer Support", value: "support" },
  { label: "Product", value: "product" },
  { label: "Human Resources", value: "hr" },
  { label: "Finance", value: "finance" },
]

const recognitionTypes = [
  { label: "All Types", value: "all" },
  { label: "Outstanding Performance", value: "performance" },
  { label: "Team Collaboration", value: "collaboration" },
  { label: "Innovation", value: "innovation" },
  { label: "Customer Service", value: "customer-service" },
  { label: "Leadership", value: "leadership" },
  { label: "Going Above & Beyond", value: "above-beyond" },
]

const formSchema = z.object({
  search: z.string().optional(),
  department: z.string().default("all"),
  type: z.string().default("all"),
  dateRange: z
    .object({
      from: z.date().optional(),
      to: z.date().optional(),
    })
    .optional(),
  employee: z.string().optional(),
})

type FormValues = z.infer<typeof formSchema>

const employees = [
  { label: "All Employees", value: "all" },
  { label: "Sarah Johnson", value: "sarah-johnson" },
  { label: "Michael Chen", value: "michael-chen" },
  { label: "Emily Rodriguez", value: "emily-rodriguez" },
  { label: "David Kim", value: "david-kim" },
  { label: "Jessica Patel", value: "jessica-patel" },
  { label: "James Wilson", value: "james-wilson" },
  { label: "Olivia Martinez", value: "olivia-martinez" },
  { label: "Daniel Thompson", value: "daniel-thompson" },
]

export function RecognitionsFilter() {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      search: "",
      department: "all",
      type: "all",
      employee: "all",
    },
  })

  function onSubmit(data: FormValues) {
    console.log("Filter applied:", data)
    // In a real app, this would update the table data
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="flex flex-col gap-4 rounded-lg border p-4 md:flex-row">
          <FormField
            control={form.control}
            name="search"
            render={({ field }) => (
              <FormItem className="flex-1">
                <FormControl>
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Search recognitions..." className="pl-8" {...field} />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="department"
            render={({ field }) => (
              <FormItem className="w-full md:w-[180px]">
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Department" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {departments.map((department) => (
                      <SelectItem key={department.value} value={department.value}>
                        {department.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem className="w-full md:w-[200px]">
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Recognition Type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {recognitionTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="dateRange"
            render={({ field }) => (
              <FormItem className="w-full md:w-[240px]">
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !field.value && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {field.value?.from ? (
                          field.value.to ? (
                            <>
                              {format(field.value.from, "LLL dd, y")} - {format(field.value.to, "LLL dd, y")}
                            </>
                          ) : (
                            format(field.value.from, "LLL dd, y")
                          )
                        ) : (
                          <span>Date Range</span>
                        )}
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="range" selected={field.value} onSelect={field.onChange} initialFocus />
                  </PopoverContent>
                </Popover>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="employee"
            render={({ field }) => (
              <FormItem className="w-full md:w-[220px]">
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        role="combobox"
                        className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                      >
                        {field.value
                          ? employees.find((employee) => employee.value === field.value)?.label
                          : "Select employee"}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-[220px] p-0">
                    <Command>
                      <CommandInput placeholder="Search employee..." />
                      <CommandList>
                        <CommandEmpty>No employee found.</CommandEmpty>
                        <CommandGroup>
                          {employees.map((employee) => (
                            <CommandItem
                              key={employee.value}
                              value={employee.value}
                              onSelect={(value) => {
                                form.setValue("employee", value)
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  employee.value === field.value ? "opacity-100" : "opacity-0",
                                )}
                              />
                              {employee.label}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full md:w-auto">
            Apply Filters
          </Button>
        </div>
      </form>
    </Form>
  )
}

