import { Button } from "@/components/ui/button"
import {
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import { formatDate } from "@/lib/utils"
import { Award, Clock, User, Users, Building2 } from "lucide-react"
import type { Nomination } from "@/types/nomination"
import { Badge } from "./ui/badge"
import { Card, CardContent } from "./ui/card"
import { Separator } from "./ui/separator"

interface NominationDrawerProps {
  nomination: Nomination
}

export function NominationDrawer({ nomination }: NominationDrawerProps) {
  return (
    <DrawerContent>
      <DrawerHeader>
        <DrawerTitle className="text-2xl font-bold">Nomination Details</DrawerTitle>
        <DrawerDescription>Created on {formatDate(nomination.createdAt)}</DrawerDescription>
      </DrawerHeader>
      <div className="p-4 space-y-6">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            <span className="font-semibold">Award Type:</span>
            <Badge variant="outline">{nomination.awardType}</Badge>
          </div>
          <div className="flex items-center gap-2">
            <User className="h-5 w-5" />
            <span className="font-semibold">Nominee:</span>
            <span>{nomination.nomineeName}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            <span className="font-semibold">Nominator:</span>
            <span>{nomination.nominatorName}</span>
          </div>
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            <span className="font-semibold">Department:</span>
            <span>{nomination.department}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            <span className="font-semibold">Status:</span>
            <Badge>{nomination.status}</Badge>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Nomination Summary</h3>
          <p className="text-sm text-muted-foreground whitespace-pre-wrap">{nomination.nominationSummary}</p>
        </div>

        <Separator />

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Benefits and Outcomes</h3>

          {nomination.benefitAndOutcome.tangibleMetrics.length > 0 && (
            <Card>
              <CardContent className="p-4 space-y-4">
                <h4 className="font-medium">Tangible Metrics</h4>
                <div className="grid gap-3">
                  {nomination.benefitAndOutcome.tangibleMetrics.map((metric, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm capitalize">{metric.type.replace(/([A-Z])/g, " $1").trim()}:</span>
                      <Badge variant="secondary">
                        {metric.value} {metric.unit}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {nomination.benefitAndOutcome.intangibleJustifications.length > 0 && (
            <Card>
              <CardContent className="p-4 space-y-4">
                <h4 className="font-medium">Intangible Benefits</h4>
                <div className="grid gap-4">
                  {nomination.benefitAndOutcome.intangibleJustifications.map((benefit, index) => (
                    <div key={index} className="space-y-2">
                      <div className="font-medium text-sm capitalize">
                        {benefit.type === "other" ? benefit.otherType : benefit.type.replace(/([A-Z])/g, " $1").trim()}
                      </div>
                      <p className="text-sm text-muted-foreground">{benefit.justification}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <DrawerFooter>
        <DrawerClose asChild>
          <Button variant="outline">Close</Button>
        </DrawerClose>
      </DrawerFooter>
    </DrawerContent>
  )
}
