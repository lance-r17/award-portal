"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import { Separator } from "@/components/ui/separator"
import type { Nomination } from "@/types/nominations"
import { CalendarDays, ExternalLink, ThumbsUp, Users, Edit, X } from "lucide-react"

interface NominationDrawerProps {
  nomination: Nomination | null
  open: boolean
  onOpenChange: (open: boolean) => void
  canEdit?: boolean
  onEdit?: () => void
}

export function NominationDrawer({ nomination, open, onOpenChange, canEdit = false, onEdit }: NominationDrawerProps) {
  if (!nomination) return null

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const awardTypes: Record<string, string> = {
      "star-of-agile": "Star of Agile",
      "star-of-customer-service": "Star of Customer Service",
      "star-of-engagement": "Star of Engagement",
      "star-of-innovation": "Star of Innovation",
      "star-of-leadership": "Star of Leadership",
      "all-star-team": "All-Star Team",
    }
    return awardTypes[awardType] || awardType
  }

  // Get presenter information if available
  const presenter = nomination.presenter || (nomination.nominationType === "team" ? nomination.nominee : null)

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh]">
        <div className="mx-auto w-full max-w-3xl">
          <DrawerHeader className="flex justify-between items-start">
            <div>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="px-3 py-1 text-base">
                  {getAwardTypeDisplay(nomination.awardType)}
                </Badge>
                <Badge variant={nomination.nominationType === "individual" ? "default" : "secondary"}>
                  {nomination.nominationType === "individual" ? "Individual" : "Team"}
                </Badge>
              </div>
              <DrawerTitle className="mt-4 text-2xl">{nomination.nominee.name}</DrawerTitle>
              <DrawerDescription>
                {nomination.nominee.department} • Nomination ID: {nomination.id}
              </DrawerDescription>
            </div>
            <div className="flex gap-2">
              {canEdit && (
                <Button variant="outline" size="icon" onClick={onEdit}>
                  <Edit className="h-4 w-4" />
                  <span className="sr-only">Edit</span>
                </Button>
              )}
              <DrawerClose asChild>
                <Button variant="ghost" size="icon">
                  <X className="h-4 w-4" />
                  <span className="sr-only">Close</span>
                </Button>
              </DrawerClose>
            </div>
          </DrawerHeader>

          <div className="p-4 pb-0 overflow-y-auto max-h-[calc(90vh-10rem)]">
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
                    <AvatarFallback>{nomination.nominee.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{nomination.nominee.name}</p>
                    <p className="text-sm text-muted-foreground">{nomination.nominee.department}</p>
                  </div>
                </div>

                <div className="sm:ml-auto flex items-center gap-2 text-sm">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <span>Nominated on {nomination.createdAt.toLocaleDateString()}</span>
                </div>
              </div>

              {nomination.nominationType === "team" && (
                <>
                  {/* Team Members */}
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <h3 className="font-medium">Team Members</h3>
                    </div>
                    <p className="text-sm">
                      {Array.isArray(nomination.team?.members)
                        ? nomination.team.members
                            .map((m) => {
                              // If it's an ID, try to find the employee name
                              const employee =
                                typeof m === "string" && m.includes("-")
                                  ? { name: m } // Default to using the ID as name
                                  : { name: m }
                              return employee.name
                            })
                            .join(", ")
                        : nomination.team?.members || "No team members listed"}
                    </p>
                  </div>
                </>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
                {/* Display presenter for team nominations */}
                {nomination.nominationType === "team" && presenter && presenter.id !== nomination.nominee.id ? (
                  <>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={presenter.avatar} alt={presenter.name} />
                        <AvatarFallback>{presenter.initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">Presenter: {presenter.name}</p>
                        <p className="text-xs text-muted-foreground">{presenter.department}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={nomination.nominator.avatar} alt={nomination.nominator.name} />
                        <AvatarFallback>{nomination.nominator.initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">Nominated by: {nomination.nominator.name}</p>
                        <p className="text-xs text-muted-foreground">{nomination.nominator.department}</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={nomination.nominator.avatar} alt={nomination.nominator.name} />
                      <AvatarFallback>{nomination.nominator.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Nominated by: {nomination.nominator.name}</p>
                      <p className="text-xs text-muted-foreground">{nomination.nominator.department}</p>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Justification</h3>
                <p className="text-sm whitespace-pre-line">{nomination.justification}</p>
              </div>

              <div>
                <h3 className="font-medium mb-2">Impact</h3>
                <p className="text-sm whitespace-pre-line">{nomination.impact}</p>
              </div>

              {nomination.supportingInfo && (
                <div>
                  <h3 className="font-medium mb-2">Supporting Information</h3>
                  <a
                    href={nomination.supportingInfo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary flex items-center gap-1 hover:underline"
                  >
                    <ExternalLink className="h-3 w-3" />
                    {nomination.supportingInfo}
                  </a>
                </div>
              )}

              <div>
                <h3 className="font-medium mb-2">Service Line</h3>
                <p className="text-sm capitalize">{nomination.serviceLine.replace(/-/g, " ")}</p>
              </div>
            </div>
          </div>

          <DrawerFooter>
            <Button className="w-full">
              <ThumbsUp className="mr-2 h-4 w-4" />
              Endorse Nomination
            </Button>
            <DrawerClose asChild>
              <Button variant="outline">Close</Button>
            </DrawerClose>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  )
}

