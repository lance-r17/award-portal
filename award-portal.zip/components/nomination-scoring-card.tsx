import type React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Nomination } from "@/types/nominations"
import { type Score, calculateWeightedScore, calculateFinalScore } from "@/types/judges"
import { getJudgeById } from "@/data/mock-judges"
import { getAllScoresNew } from "@/data/mock-scores"

interface NominationScoringCardProps {
  nomination: Nomination
}

export const NominationScoringCard: React.FC<NominationScoringCardProps> = ({ nomination }) => {
  const judgeScores = getAllScoresNew().filter((score) => score.nominationId === nomination.id)

  const getJudgeName = (judgeId: string) => {
    const judge = getJudgeById(judgeId)
    return judge ? `${judge.firstName} ${judge.lastName}` : "Unknown Judge"
  }

  const getOutlierScoreIds = (scores: Score[]) => {
    if (!scores || scores.length <= 4) return []

    // Sort scores by weighted score
    const sortedScores = [...scores].sort((a, b) => {
      const scoreA = calculateWeightedScore(a.criteria)
      const scoreB = calculateWeightedScore(b.criteria)
      return scoreA - scoreB
    })

    // Get the IDs of the bottom 2 and top 2 scores
    const outlierIds = [
      ...sortedScores.slice(0, 2), // Bottom 2
      ...sortedScores.slice(sortedScores.length - 2), // Top 2
    ].map((score) => score.judgeId)

    return outlierIds
  }

  const finalScore = calculateFinalScore(judgeScores)
  const outlierIds = getOutlierScoreIds(judgeScores)

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-bold">{nomination.nomineeName}</CardTitle>
          <Badge variant="outline" className="ml-2">
            {nomination.category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold mb-2">Nomination Details</h3>
            <p className="text-sm text-gray-600">{nomination.description}</p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-2">Judge Scores</h3>
            <div className="space-y-1">
              {judgeScores.map((score) => (
                <div
                  key={score.judgeId}
                  className={`flex justify-between items-center p-2 border-b ${
                    outlierIds.includes(score.judgeId) ? "line-through text-gray-500" : ""
                  }`}
                >
                  <span>{getJudgeName(score.judgeId)}</span>
                  <span>{calculateWeightedScore(score.criteria).toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-2">Final Score</h3>
            <div className="text-2xl font-bold text-center">{finalScore.toFixed(2)}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
