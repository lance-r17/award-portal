import { Card, CardContent } from "@/components/ui/card"
import type { Nomination } from "@/lib/types"
import Image from "next/image"
import Link from "next/link"
import { Trophy } from "lucide-react"

interface RewardWallProps {
  nominations: Nomination[]
}

const RewardWall = ({ nominations }: RewardWallProps) => {
  return (
    <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
      {nominations.map((nomination) => (
        <NomineeCard key={nomination.id} nomination={nomination} />
      ))}
    </div>
  )
}

const NomineeCard = ({ nomination }: { nomination: Nomination }) => {
  const isWinner = nomination.status === "awarded"

  return (
    <Link href={`/awards/spot-awards/${nomination.eventId}/noms/${nomination.id}`}>
      <Card className="h-full overflow-hidden transition-all hover:shadow-md">
        <CardContent className="p-0">
          <div className="relative">
            <div className="aspect-square overflow-hidden bg-muted">
              <Image
                src={nomination.nominee.image || "/placeholder.svg?height=300&width=300"}
                alt={nomination.nominee.name}
                width={300}
                height={300}
                className="h-full w-full object-cover"
              />
            </div>
            {isWinner && (
              <div className="absolute right-2 top-2 rounded-full bg-primary p-1 text-primary-foreground">
                <Trophy className="h-4 w-4" />
              </div>
            )}
          </div>
          <div className="p-4">
            <h3 className="font-medium">{nomination.nominee.name}</h3>
            <p className="text-sm text-muted-foreground">{nomination.awardType}</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

export default RewardWall
