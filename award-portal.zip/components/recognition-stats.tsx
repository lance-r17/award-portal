import type React from "react"
import { Award, TrendingUp, Trophy, Users } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface RecognitionStatsProps {
  className?: string
}

export function RecognitionStats({ className }: RecognitionStatsProps) {
  return (
    <Card className={cn("col-span-2", className)}>
      <CardHeader>
        <CardTitle>Recognition Statistics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Recognitions"
            value="1,248"
            description="+12% from last month"
            trend="up"
            icon={Award}
          />
          <StatsCard title="Active Employees" value="342" description="98% participation rate" icon={Users} />
          <StatsCard title="Top Department" value="Engineering" description="287 recognitions" icon={Trophy} />
          <StatsCard
            title="Monthly Growth"
            value="24%"
            description="Recognition activity"
            trend="up"
            icon={TrendingUp}
          />
        </div>
      </CardContent>
    </Card>
  )
}

interface StatsCardProps {
  title: string
  value: string
  description: string
  trend?: "up" | "down"
  icon: React.ComponentType<{ className?: string }>
}

function StatsCard({ title, value, description, trend, icon: Icon }: StatsCardProps) {
  return (
    <div className="rounded-lg border bg-card p-4 text-card-foreground shadow-sm">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">{title}</p>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="mt-2">
        <p className="text-2xl font-bold">{value}</p>
        <p
          className={cn(
            "text-xs",
            trend === "up" && "text-green-500",
            trend === "down" && "text-red-500",
            !trend && "text-muted-foreground",
          )}
        >
          {description}
        </p>
      </div>
    </div>
  )
}

