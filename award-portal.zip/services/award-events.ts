import { createServerSupabaseClient } from "@/lib/supabase"
import type { AwardEvent } from "@/types/award-events"

// Map from our application AwardEvent type to Supabase schema
function mapEventToSupabase(event: AwardEvent) {
  return {
    id: event.id,
    title: event.title,
    description: event.description || null,
    organization_level2: event.organizationLevel2,
    start_date: event.startDate,
    end_date: event.endDate,
    nomination_deadline: event.nominationDeadline,
    endorsement_deadline: event.endorsementDeadline || null,
    judging_deadline: event.judgingDeadline || null,
    status: event.status,
    created_by: event.createdBy,
  }
}

// Map from Supabase schema to our application AwardEvent type
function mapSupabaseToEvent(data: any): AwardEvent {
  return {
    id: data.id,
    title: data.title,
    description: data.description || "",
    organizationLevel2: data.organization_level2 || "cto", // Default to "cto" if not provided
    startDate: data.start_date,
    endDate: data.end_date,
    nominationDeadline: data.nomination_deadline,
    endorsementDeadline: data.endorsement_deadline || "",
    judgingDeadline: data.judging_deadline || "",
    status: data.status,
    createdAt: data.created_at,
    updatedAt: data.updated_at || "",
    createdBy: data.created_by,
  }
}

export async function getAwardEvents() {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("award_events").select("*").order("start_date", { ascending: false })

    if (error) throw error

    return data.map(mapSupabaseToEvent)
  } catch (error) {
    console.error("Error fetching award events:", error)
    throw error
  }
}

export async function getAwardEventById(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("award_events").select("*").eq("id", id).single()

    if (error) throw error

    return mapSupabaseToEvent(data)
  } catch (error) {
    console.error(`Error fetching award event with ID ${id}:`, error)
    throw error
  }
}

export async function createAwardEvent(event: Omit<AwardEvent, "id" | "createdAt" | "updatedAt">) {
  const supabase = createServerSupabaseClient()

  try {
    const newEvent = {
      ...mapEventToSupabase(event as AwardEvent),
      created_at: new Date().toISOString(),
    }

    // Remove id if it exists to let Supabase generate one
    delete newEvent.id

    const { data, error } = await supabase.from("award_events").insert(newEvent).select()

    if (error) throw error

    return data[0] ? mapSupabaseToEvent(data[0]) : null
  } catch (error) {
    console.error("Error creating award event:", error)
    throw error
  }
}

export async function updateAwardEvent(id: string, updates: Partial<AwardEvent>) {
  const supabase = createServerSupabaseClient()

  try {
    // Convert our app's event model to Supabase's schema
    const supabaseUpdates: any = {}

    if (updates.title) supabaseUpdates.title = updates.title
    if ("description" in updates) supabaseUpdates.description = updates.description
    if (updates.organizationLevel2) supabaseUpdates.organization_level2 = updates.organizationLevel2
    if (updates.startDate) supabaseUpdates.start_date = updates.startDate
    if (updates.endDate) supabaseUpdates.end_date = updates.endDate
    if (updates.nominationDeadline) supabaseUpdates.nomination_deadline = updates.nominationDeadline
    if ("endorsementDeadline" in updates) supabaseUpdates.endorsement_deadline = updates.endorsementDeadline
    if ("judgingDeadline" in updates) supabaseUpdates.judging_deadline = updates.judgingDeadline
    if (updates.status) supabaseUpdates.status = updates.status

    supabaseUpdates.updated_at = new Date().toISOString()

    const { data, error } = await supabase.from("award_events").update(supabaseUpdates).eq("id", id).select()

    if (error) throw error

    return data[0] ? mapSupabaseToEvent(data[0]) : null
  } catch (error) {
    console.error(`Error updating award event with ID ${id}:`, error)
    throw error
  }
}

export async function deleteAwardEvent(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from("award_events").delete().eq("id", id)

    if (error) throw error

    return true
  } catch (error) {
    console.error(`Error deleting award event with ID ${id}:`, error)
    throw error
  }
}

