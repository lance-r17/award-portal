import { createServerSupabaseClient } from "@/lib/supabase"
import type { Endorsement } from "@/types/comment"
import { incrementEndorsementCount } from "./nominations"

// Map from our application Endorsement type to Supabase schema
function mapEndorsementToSupabase(endorsement: Endorsement) {
  return {
    id: endorsement.id,
    nomination_id: endorsement.nominationId,
    user_id: endorsement.userId,
    comment: endorsement.comment,
    is_domain_manager: endorsement.isDomainManager || false,
  }
}

// Map from Supabase schema to our application Endorsement type
function mapSupabaseToEndorsement(data: any): Endorsement {
  return {
    id: data.id,
    nominationId: data.nomination_id,
    userId: data.user_id,
    comment: data.comment,
    isDomainManager: data.is_domain_manager,
    createdAt: data.created_at,
  }
}

export async function getEndorsements(nominationId: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase
      .from("endorsements")
      .select("*")
      .eq("nomination_id", nominationId)
      .order("created_at", { ascending: false })

    if (error) throw error

    return data.map(mapSupabaseToEndorsement)
  } catch (error) {
    console.error(`Error fetching endorsements for nomination ${nominationId}:`, error)
    throw error
  }
}

export async function createEndorsement(endorsement: Omit<Endorsement, "id" | "createdAt">) {
  const supabase = createServerSupabaseClient()

  try {
    const newEndorsement = {
      ...mapEndorsementToSupabase(endorsement as Endorsement),
      created_at: new Date().toISOString(),
    }

    // Remove id if it exists to let Supabase generate one
    delete newEndorsement.id

    const { data, error } = await supabase.from("endorsements").insert(newEndorsement).select()

    if (error) throw error

    // Also increment the endorsement count on the nomination
    await incrementEndorsementCount(endorsement.nominationId)

    return data[0] ? mapSupabaseToEndorsement(data[0]) : null
  } catch (error) {
    console.error("Error creating endorsement:", error)
    throw error
  }
}

export async function deleteEndorsement(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from("endorsements").delete().eq("id", id)

    if (error) throw error

    return true
  } catch (error) {
    console.error(`Error deleting endorsement with ID ${id}:`, error)
    throw error
  }
}
