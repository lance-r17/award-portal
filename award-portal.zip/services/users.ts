import { createServerSupabaseClient } from "@/lib/supabase"
import type { User } from "@/types/user"

// Map from our application User type to Supabase schema
function mapUserToSupabase(user: User) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
    initials: user.initials,
    service_line: user.serviceLine,
    title: user.title || null,
    bio: user.bio || null,
    is_domain_manager: user.role?.isDomainManager || false,
    is_judge: user.role?.isJudge || false,
    is_head_judge: user.role?.isHeadJudge || false,
    is_facilitator: user.role?.isFacilitator || false,
    is_in_judge_pool: user.isInJudgePool || false,
    is_nominee: user.isNominee || false,
    is_nominator: user.isNominator || false,
  }
}

// Map from Supabase schema to our application User type
function mapSupabaseToUser(data: any): User {
  return {
    id: data.id,
    name: data.name,
    email: data.email,
    avatar: data.avatar,
    initials: data.initials,
    serviceLine: data.service_line,
    title: data.title || undefined,
    bio: data.bio || undefined,
    role: {
      isDomainManager: data.is_domain_manager,
      isJudge: data.is_judge,
      isHeadJudge: data.is_head_judge,
      isFacilitator: data.is_facilitator,
    },
    isInJudgePool: data.is_in_judge_pool,
    isNominee: data.is_nominee,
    isNominator: data.is_nominator,
    roles: [], // This would need to be populated based on the role fields
  }
}

export async function getUsers() {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("users").select("*")

    if (error) throw error

    return data.map(mapSupabaseToUser)
  } catch (error) {
    console.error("Error fetching users:", error)
    throw error
  }
}

export async function getUserById(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("users").select("*").eq("id", id).single()

    if (error) throw error

    return mapSupabaseToUser(data)
  } catch (error) {
    console.error(`Error fetching user with ID ${id}:`, error)
    throw error
  }
}

export async function createUser(user: User) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("users").insert(mapUserToSupabase(user)).select()

    if (error) throw error

    return data[0] ? mapSupabaseToUser(data[0]) : null
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}

export async function updateUser(id: string, updates: Partial<User>) {
  const supabase = createServerSupabaseClient()

  try {
    // Convert our app's user model to Supabase's schema
    const supabaseUpdates: any = {}

    if (updates.name) supabaseUpdates.name = updates.name
    if (updates.email) supabaseUpdates.email = updates.email
    if (updates.avatar) supabaseUpdates.avatar = updates.avatar
    if (updates.initials) supabaseUpdates.initials = updates.initials
    if (updates.serviceLine) supabaseUpdates.service_line = updates.serviceLine
    if ("title" in updates) supabaseUpdates.title = updates.title
    if ("bio" in updates) supabaseUpdates.bio = updates.bio

    // Handle role updates
    if (updates.role) {
      if ("isDomainManager" in updates.role) supabaseUpdates.is_domain_manager = updates.role.isDomainManager
      if ("isJudge" in updates.role) supabaseUpdates.is_judge = updates.role.isJudge
      if ("isHeadJudge" in updates.role) supabaseUpdates.is_head_judge = updates.role.isHeadJudge
      if ("isFacilitator" in updates.role) supabaseUpdates.is_facilitator = updates.role.isFacilitator
    }

    if ("isInJudgePool" in updates) supabaseUpdates.is_in_judge_pool = updates.isInJudgePool
    if ("isNominee" in updates) supabaseUpdates.is_nominee = updates.isNominee
    if ("isNominator" in updates) supabaseUpdates.is_nominator = updates.isNominator

    supabaseUpdates.updated_at = new Date().toISOString()

    const { data, error } = await supabase.from("users").update(supabaseUpdates).eq("id", id).select()

    if (error) throw error

    return data[0] ? mapSupabaseToUser(data[0]) : null
  } catch (error) {
    console.error(`Error updating user with ID ${id}:`, error)
    throw error
  }
}

export async function deleteUser(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from("users").delete().eq("id", id)

    if (error) throw error

    return true
  } catch (error) {
    console.error(`Error deleting user with ID ${id}:`, error)
    throw error
  }
}

export async function getDomainManagers(serviceLine?: string) {
  const supabase = createServerSupabaseClient()

  try {
    let query = supabase.from("users").select("*").eq("is_domain_manager", true)

    if (serviceLine) {
      query = query.eq("service_line", serviceLine)
    }

    const { data, error } = await query

    if (error) throw error

    return data.map(mapSupabaseToUser)
  } catch (error) {
    console.error("Error fetching domain managers:", error)
    throw error
  }
}

export async function getJudgePool() {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("users").select("*").eq("is_in_judge_pool", true)

    if (error) throw error

    return data.map(mapSupabaseToUser)
  } catch (error) {
    console.error("Error fetching judge pool:", error)
    throw error
  }
}

