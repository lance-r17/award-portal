//import nodemailer from "nodemailer"
import { renderAsync } from "@react-email/render"
import NominationSubmittedEmail from "@/components/email-templates/nomination/nomination-submitted"
import NominationReceivedEmail from "@/components/email-templates/nomination/nomination-received"
import JudgeAssignmentEmail from "@/components/email-templates/judging/judge-assignment"
import WinnerAnnouncementEmail from "@/components/email-templates/events/winner-announcement"
import CommentNotificationEmail from "@/components/email-templates/system/comment-notification"
import DomainManagerEndorsementRequestEmail from "@/components/email-templates/endorsement/domain-manager-endorsement-request"

// Create a Nodemailer transporter
/*
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: process.env.SMTP_SECURE === "true",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
})
*/

// Helper function to send emails (modified to log instead of send)
async function sendEmail({
  to,
  subject,
  html,
  text,
}: {
  to: string | string[]
  subject: string
  html: string
  text: string
}) {
  try {
    // Log email details instead of sending
    console.log("========== EMAIL WOULD BE SENT ==========")
    console.log(`To: ${Array.isArray(to) ? to.join(", ") : to}`)
    console.log(`Subject: ${subject}`)
    console.log(`Text content: ${text}`)
    console.log("HTML content available but not logged")
    console.log("========================================")

    // Return success response to maintain application flow
    return {
      success: true,
      data: {
        messageId: `mock-email-${Date.now()}`,
        envelope: { from: "noreply@example.com", to },
      },
    }

    /* Original implementation:
    const result = await transporter.sendMail({
      from: `"Spot Awards" <${process.env.SMTP_FROM}>`,
      to,
      subject,
      html,
      text,
    })

    return { success: true, data: result }
    */
  } catch (error) {
    console.error("Error in email logging:", error)
    return { success: false, error }
  }
}

// Nomination Submitted Email
export async function sendNominationSubmittedEmail(
  to: string,
  data: {
    nominatorName: string
    nomineeName: string
    awardType: string
    eventName: string
    nominationDate: string
    previewUrl: string
  },
) {
  const html = await renderAsync(NominationSubmittedEmail(data))
  const text = `Hi ${data.nominatorName}, Your nomination for ${data.nomineeName} for the ${data.awardType} in ${data.eventName} has been successfully submitted on ${data.nominationDate}.`

  return sendEmail({
    to,
    subject: `Your nomination for ${data.nomineeName} has been submitted`,
    html,
    text,
  })
}

// Nomination Received Email
export async function sendNominationReceivedEmail(
  to: string,
  data: {
    nomineeName: string
    nominatorName: string
    awardType: string
    eventName: string
    nominationDate: string
    previewUrl: string
  },
) {
  const html = await renderAsync(NominationReceivedEmail(data))
  const text = `Congratulations ${data.nomineeName}! You've been nominated for a ${data.awardType} by ${data.nominatorName} in ${data.eventName} on ${data.nominationDate}.`

  return sendEmail({
    to,
    subject: `You've been nominated for a ${data.awardType}`,
    html,
    text,
  })
}

// Judge Assignment Email
export async function sendJudgeAssignmentEmail(
  to: string,
  data: {
    judgeName: string
    eventName: string
    awardType: string
    nominationCount: number
    deadline: string
    judgingUrl: string
  },
) {
  const html = await renderAsync(JudgeAssignmentEmail(data))
  const text = `Hello ${data.judgeName}, You have been assigned as a judge for the ${data.awardType} in ${data.eventName}. There are ${data.nominationCount} nominations that require your evaluation. Please complete your judging by ${data.deadline}.`

  return sendEmail({
    to,
    subject: `You've been assigned as a judge for ${data.eventName}`,
    html,
    text,
  })
}

// Winner Announcement Email
export async function sendWinnerAnnouncementEmail(
  to: string | string[],
  data: {
    recipientName: string
    winnerName: string
    awardType: string
    eventName: string
    announcementDate: string
    celebrationDetails: string
    viewDetailsUrl: string
  },
) {
  const html = await renderAsync(WinnerAnnouncementEmail(data))
  const text = `Dear ${data.recipientName}, We are delighted to announce that ${data.winnerName} has been selected as the winner of the ${data.awardType} in ${data.eventName} on ${data.announcementDate}. ${data.celebrationDetails}`

  return sendEmail({
    to,
    subject: `${data.winnerName} has won the ${data.awardType}`,
    html,
    text,
  })
}

// Comment Notification Email
export async function sendCommentNotificationEmail(
  to: string,
  data: {
    recipientName: string
    commenterName: string
    nominationTitle: string
    commentPreview: string
    commentDate: string
    viewCommentUrl: string
  },
) {
  const html = await renderAsync(CommentNotificationEmail(data))
  const text = `Hi ${data.recipientName}, ${data.commenterName} has commented on the nomination "${data.nominationTitle}" on ${data.commentDate}: "${data.commentPreview}"`

  return sendEmail({
    to,
    subject: `${data.commenterName} commented on a nomination`,
    html,
    text,
  })
}

// Domain Manager Endorsement Request Email
export async function sendDomainManagerEndorsementRequestEmail(
  to: string,
  data: {
    managerName: string
    nomineeName: string
    nominatorName: string
    awardType: string
    eventName: string
    nominationDate: string
    justificationPreview: string
    endorsementUrl: string
    deadline: string
  },
) {
  const html = await renderAsync(DomainManagerEndorsementRequestEmail(data))
  const text = `Hello ${data.managerName}, ${data.nominatorName} has nominated ${data.nomineeName} for a ${data.awardType} in ${data.eventName} on ${data.nominationDate}. As their domain manager, your endorsement is required. Please review the complete nomination and provide your endorsement by ${data.deadline}.`

  return sendEmail({
    to,
    subject: `Endorsement Required: ${data.nomineeName}'s ${data.awardType} Nomination`,
    html,
    text,
  })
}
