import nodemailer from "nodemailer"
import { render } from "@react-email/render"
import NominationSubmittedEmail from "@/components/email-templates/nomination/nomination-submitted"
import NominationReceivedEmail from "@/components/email-templates/nomination/nomination-received"
import JudgeAssignmentEmail from "@/components/email-templates/judging/judge-assignment"
import WinnerAnnouncementEmail from "@/components/email-templates/events/winner-announcement"
import CommentNotificationEmail from "@/components/email-templates/system/comment-notification"

// Create a Nodemailer transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: process.env.SMTP_SECURE === "true",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
})

// Helper function to send emails
async function sendEmail({
  to,
  subject,
  html,
  text,
}: {
  to: string | string[]
  subject: string
  html: string
  text?: string
}) {
  try {
    const result = await transporter.sendMail({
      from: `"Spot Awards" <${process.env.SMTP_FROM || "awards@yourcompany.com"}>`,
      to,
      subject,
      html,
      text,
    })

    return { success: true, messageId: result.messageId }
  } catch (error) {
    console.error("Failed to send email:", error)
    return { success: false, error }
  }
}

// Email sending functions for different notification types
export async function sendNominationSubmittedEmail(to: string, data: Parameters<typeof NominationSubmittedEmail>[0]) {
  const html = render(NominationSubmittedEmail(data))
  const subject = `Your nomination for ${data.nomineeName} has been submitted`

  return sendEmail({ to, subject, html })
}

export async function sendNominationReceivedEmail(to: string, data: Parameters<typeof NominationReceivedEmail>[0]) {
  const html = render(NominationReceivedEmail(data))
  const subject = `You've been nominated for a ${data.awardType}`

  return sendEmail({ to, subject, html })
}

export async function sendJudgeAssignmentEmail(to: string, data: Parameters<typeof JudgeAssignmentEmail>[0]) {
  const html = render(JudgeAssignmentEmail(data))
  const subject = `Judge Assignment: ${data.eventName}`

  return sendEmail({ to, subject, html })
}

export async function sendWinnerAnnouncementEmail(
  to: string | string[],
  data: Parameters<typeof WinnerAnnouncementEmail>[0],
) {
  const html = render(WinnerAnnouncementEmail(data))
  const subject = `Winner Announcement: ${data.eventName}`

  return sendEmail({ to, subject, html })
}

export async function sendCommentNotificationEmail(to: string, data: Parameters<typeof CommentNotificationEmail>[0]) {
  const html = render(CommentNotificationEmail(data))
  const subject = `New Comment on ${data.nominationTitle}`

  return sendEmail({ to, subject, html })
}

// For testing in development
export function getEmailTransporter() {
  return transporter
}

