import { createServerSupabaseClient } from "@/lib/supabase"
import type { Score } from "@/types/judges"

// Map from our application Score type to Supabase schema
function mapScoreToSupabase(score: Score) {
  return {
    id: score.id,
    nomination_id: score.nominationId,
    judge_id: score.judgeId,
    score: score.score,
    comments: score.comments || null,
  }
}

// Map from Supabase schema to our application Score type
function mapSupabaseToScore(data: any): Score {
  return {
    id: data.id,
    nominationId: data.nomination_id,
    judgeId: data.judge_id,
    score: data.score,
    comments: data.comments || "",
    createdAt: data.created_at,
    updatedAt: data.updated_at || "",
  }
}

export async function getScores(nominationId: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("scores").select("*").eq("nomination_id", nominationId)

    if (error) throw error

    return data.map(mapSupabaseToScore)
  } catch (error) {
    console.error(`Error fetching scores for nomination ${nominationId}:`, error)
    throw error
  }
}

export async function getScoreById(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("scores").select("*").eq("id", id).single()

    if (error) throw error

    return mapSupabaseToScore(data)
  } catch (error) {
    console.error(`Error fetching score with ID ${id}:`, error)
    throw error
  }
}

export async function createScore(score: Omit<Score, "id" | "createdAt" | "updatedAt">) {
  const supabase = createServerSupabaseClient()

  try {
    const newScore = {
      ...mapScoreToSupabase(score as Score),
      created_at: new Date().toISOString(),
    }

    // Remove id if it exists to let Supabase generate one
    delete newScore.id

    const { data, error } = await supabase.from("scores").insert(newScore).select()

    if (error) throw error

    return data[0] ? mapSupabaseToScore(data[0]) : null
  } catch (error) {
    console.error("Error creating score:", error)
    throw error
  }
}

export async function updateScore(id: string, updates: Partial<Score>) {
  const supabase = createServerSupabaseClient()

  try {
    // Convert our app's score model to Supabase's schema
    const supabaseUpdates: any = {}

    if (updates.nominationId) supabaseUpdates.nomination_id = updates.nominationId
    if (updates.judgeId) supabaseUpdates.judge_id = updates.judgeId
    if ("score" in updates) supabaseUpdates.score = updates.score
    if ("comments" in updates) supabaseUpdates.comments = updates.comments

    supabaseUpdates.updated_at = new Date().toISOString()

    const { data, error } = await supabase.from("scores").update(supabaseUpdates).eq("id", id).select()

    if (error) throw error

    return data[0] ? mapSupabaseToScore(data[0]) : null
  } catch (error) {
    console.error(`Error updating score with ID ${id}:`, error)
    throw error
  }
}

export async function deleteScore(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from("scores").delete().eq("id", id)

    if (error) throw error

    return true
  } catch (error) {
    console.error(`Error deleting score with ID ${id}:`, error)
    throw error
  }
}

