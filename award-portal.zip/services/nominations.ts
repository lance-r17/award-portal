import { createServerSupabaseClient } from "@/lib/supabase"
import type { Nomination } from "@/types/nomination"

// Map from our application Nomination type to Supabase schema
function mapNominationToSupabase(nomination: Nomination) {
  return {
    id: nomination.id,
    event_id: nomination.eventId,
    nominee_id: nomination.nomineeId,
    nominator_id: nomination.nominatorId,
    presenter_id: nomination.presenterId || null,
    team_members: nomination.teamMembers || null,
    award_type: nomination.awardType,
    service_line: Array.isArray(nomination.serviceLine) ? nomination.serviceLine : [nomination.serviceLine],
    title: nomination.title,
    summary: nomination.summary,
    impact: nomination.impact,
    endorsement_count: nomination.endorsementCount || 0,
    score: nomination.score || null,
    status: nomination.status,
  }
}

// Map from Supabase schema to our application Nomination type
function mapSupabaseToNomination(data: any): Nomination {
  return {
    id: data.id,
    eventId: data.event_id,
    nomineeId: data.nominee_id,
    nominatorId: data.nominator_id,
    presenterId: data.presenter_id || "",
    teamMembers: data.team_members || [],
    awardType: data.award_type,
    serviceLine: data.service_line,
    title: data.title,
    summary: data.summary,
    impact: data.impact,
    endorsementCount: data.endorsement_count || 0,
    score: data.score || 0,
    status: data.status,
    createdAt: data.created_at,
    updatedAt: data.updated_at || "",
  }
}

export async function getNominations(eventId?: string) {
  const supabase = createServerSupabaseClient()

  try {
    let query = supabase.from("nominations").select("*")

    if (eventId) {
      query = query.eq("event_id", eventId)
    }

    const { data, error } = await query

    if (error) throw error

    return data.map(mapSupabaseToNomination)
  } catch (error) {
    console.error("Error fetching nominations:", error)
    throw error
  }
}

export async function getNominationById(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.from("nominations").select("*").eq("id", id).single()

    if (error) throw error

    return mapSupabaseToNomination(data)
  } catch (error) {
    console.error(`Error fetching nomination with ID ${id}:`, error)
    throw error
  }
}

export async function createNomination(nomination: Omit<Nomination, "id" | "createdAt" | "updatedAt">) {
  const supabase = createServerSupabaseClient()

  try {
    const newNomination = {
      ...mapNominationToSupabase(nomination as Nomination),
      created_at: new Date().toISOString(),
    }

    // Remove id if it exists to let Supabase generate one
    delete newNomination.id

    const { data, error } = await supabase.from("nominations").insert(newNomination).select()

    if (error) throw error

    return data[0] ? mapSupabaseToNomination(data[0]) : null
  } catch (error) {
    console.error("Error creating nomination:", error)
    throw error
  }
}

export async function updateNomination(id: string, updates: Partial<Nomination>) {
  const supabase = createServerSupabaseClient()

  try {
    // Convert our app's nomination model to Supabase's schema
    const supabaseUpdates: any = {}

    if (updates.eventId) supabaseUpdates.event_id = updates.eventId
    if (updates.nomineeId) supabaseUpdates.nominee_id = updates.nomineeId
    if (updates.nominatorId) supabaseUpdates.nominator_id = updates.nominatorId
    if ("presenterId" in updates) supabaseUpdates.presenter_id = updates.presenterId
    if ("teamMembers" in updates) supabaseUpdates.team_members = updates.teamMembers
    if (updates.awardType) supabaseUpdates.award_type = updates.awardType
    if (updates.serviceLine) {
      supabaseUpdates.service_line = Array.isArray(updates.serviceLine) ? updates.serviceLine : [updates.serviceLine]
    }
    if (updates.title) supabaseUpdates.title = updates.title
    if (updates.summary) supabaseUpdates.summary = updates.summary
    if (updates.impact) supabaseUpdates.impact = updates.impact
    if ("endorsementCount" in updates) supabaseUpdates.endorsement_count = updates.endorsementCount
    if ("score" in updates) supabaseUpdates.score = updates.score
    if (updates.status) supabaseUpdates.status = updates.status

    supabaseUpdates.updated_at = new Date().toISOString()

    const { data, error } = await supabase.from("nominations").update(supabaseUpdates).eq("id", id).select()

    if (error) throw error

    return data[0] ? mapSupabaseToNomination(data[0]) : null
  } catch (error) {
    console.error(`Error updating nomination with ID ${id}:`, error)
    throw error
  }
}

export async function deleteNomination(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from("nominations").delete().eq("id", id)

    if (error) throw error

    return true
  } catch (error) {
    console.error(`Error deleting nomination with ID ${id}:`, error)
    throw error
  }
}

export async function incrementEndorsementCount(id: string) {
  const supabase = createServerSupabaseClient()

  try {
    // First get the current count
    const { data: nomination, error: fetchError } = await supabase
      .from("nominations")
      .select("endorsement_count")
      .eq("id", id)
      .single()

    if (fetchError) throw fetchError

    const currentCount = nomination.endorsement_count || 0

    // Then update with the incremented count
    const { data, error: updateError } = await supabase
      .from("nominations")
      .update({
        endorsement_count: currentCount + 1,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()

    if (updateError) throw updateError

    return data[0] ? mapSupabaseToNomination(data[0]) : null
  } catch (error) {
    console.error(`Error incrementing endorsement count for nomination ${id}:`, error)
    throw error
  }
}

