// Middleware disabled to allow the application to run without authentication
// This file is intentionally left empty to prevent authentication redirects
