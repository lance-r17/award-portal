export interface ServiceLine {
  label: string
  value: string
}

export const serviceLines: ServiceLine[] = [
  { label: "Technology", value: "technology" },
  { label: "Cloud Services", value: "cloud-services" },
  { label: "Data Analytics", value: "data-analytics" },
  { label: "Cybersecurity", value: "cybersecurity" },
  { label: "Enterprise Solutions", value: "enterprise-solutions" },
  { label: "Customer Experience", value: "customer-experience" },
  { label: "Financial Services", value: "financial-services" },
  { label: "Healthcare Solutions", value: "healthcare-solutions" },
]

export function getServiceLines(): ServiceLine[] {
  return serviceLines
}

