export const employees = [
  { label: "Sarah Johnson", value: "sarah-johnson" },
  { label: "Michael Chen", value: "michael-chen" },
  { label: "Emily Rodriguez", value: "emily-rodriguez" },
  { label: "David Kim", value: "david-kim" },
  { label: "Jessica Patel", value: "jessica-patel" },
  { label: "James Wilson", value: "james-wilson" },
  { label: "Olivia Martinez", value: "olivia-martinez" },
  { label: "Daniel Thompson", value: "daniel-thompson" },
]

export const teams = [
  { label: "Engineering Team", value: "engineering-team" },
  { label: "Marketing Team", value: "marketing-team" },
  { label: "Product Team", value: "product-team" },
  { label: "Customer Support Team", value: "customer-support-team" },
  { label: "Sales Team", value: "sales-team" },
  { label: "Design Team", value: "design-team" },
  { label: "Finance Team", value: "finance-team" },
  { label: "HR Team", value: "hr-team" },
]

