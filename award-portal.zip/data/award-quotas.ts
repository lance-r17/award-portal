import type { AwardQuota } from "@/components/award/award-quotas"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"

// In-memory storage for award quotas
// In a real application, this would be stored in a database
const awardQuotasStore: Record<string, AwardQuota[]> = {}

// Get award quotas for an event
export function getAwardQuotas(eventId: string): AwardQuota[] | null {
  // For spot-q4-2024, let's ensure we have quotas set
  if (eventId === "spot-q4-2024" && !awardQuotasStore[eventId]) {
    // Set default quotas for Q4 2024
    const defaultQuotas = getDefaultAwardQuotas()
    awardQuotasStore[eventId] = defaultQuotas
  }

  return awardQuotasStore[eventId] || null
}

// Save award quotas for an event
export function saveAwardQuotas(eventId: string, quotas: AwardQuota[]): void {
  awardQuotasStore[eventId] = [...quotas]
}

// Get default award quotas
export function getDefaultAwardQuotas(): AwardQuota[] {
  return [...spotIndividualAwardTypes, ...spotTeamAwardTypes].map((awardType) => ({
    awardTypeId: awardType.id,
    quota: 2, // Default quota of 2 winners per award type
  }))
}

// Get quota for a specific award type in an event
export function getQuotaForAwardType(eventId: string, awardTypeId: string): number {
  const quotas = getAwardQuotas(eventId)
  if (!quotas) return 2 // Default quota if not set

  const quotaEntry = quotas.find((q) => q.awardTypeId === awardTypeId)
  return quotaEntry ? quotaEntry.quota : 2 // Default quota if not found
}

