import type { AwardQuota } from "@/components/award/award-quotas"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"
import { getAwardEventById } from "@/data/award-events"

// Get award quotas for an event
export function getAwardQuotas(eventId: string): AwardQuota[] | null {
  const event = getAwardEventById(eventId)

  if (!event) return null

  // If the event has quotas defined, convert them to AwardQuota format
  if (event.quotas) {
    return Object.entries(event.quotas).map(([awardTypeId, quota]) => ({
      awardTypeId,
      quota: quota as number,
    }))
  }

  // If no quotas are defined, return default quotas
  return getDefaultAwardQuotas()
}

// Save award quotas for an event
export function saveAwardQuotas(eventId: string, quotas: AwardQuota[]): void {
  const event = getAwardEventById(eventId)

  if (!event) return

  // Convert AwardQuota array to object format for storage in event
  const quotasObject: Record<string, number> = {}
  quotas.forEach((quota) => {
    quotasObject[quota.awardTypeId] = quota.quota
  })

  // Update the event's quotas
  event.quotas = quotasObject
}

// Get default award quotas
export function getDefaultAwardQuotas(): AwardQuota[] {
  return [...spotIndividualAwardTypes, ...spotTeamAwardTypes].map((awardType) => ({
    awardTypeId: awardType.id,
    quota: 2, // Default quota of 2 winners per award type
  }))
}

// Get quota for a specific award type in an event
export function getQuotaForAwardType(eventId: string, awardTypeId: string): number {
  const event = getAwardEventById(eventId)

  if (!event || !event.quotas) return 2 // Default quota if not set

  return event.quotas[awardTypeId] || 2 // Default quota if not found
}
