import type { User } from "@/types/user"
import { awardEvents } from "./award-events"
import { mockUsers } from "./mock-users"

// Add any missing types or functions here
type EventJudges = Record<string, string[]>

// Helper function to get judges from the mock users
const getJudgesFromPool = (): User[] => {
  return mockUsers.filter((user) => user.isInJudgePool)
}

// Helper function to randomly assign judges to an event
const assignJudgesToEvent = (judges: User[], count: number): string[] => {
  const shuffled = [...judges].sort(() => 0.5 - Math.random())
  return shuffled.slice(0, count).map((judge) => judge.id)
}

// Generate sample data
const generateSampleEventJudges = (): Record<string, string[]> => {
  const judges = getJudgesFromPool()
  const eventJudges: Record<string, string[]> = {}

  awardEvents.forEach((event) => {
    const judgeCount = Math.floor(Math.random() * 2) + 3 // Assign 3-4 judges per event
    eventJudges[event.id] = assignJudgesToEvent(judges, judgeCount)
  })

  return eventJudges
}

// Generate the sample data
export const eventJudges: Record<string, string[]> = generateSampleEventJudges()

export function getJudgesForEvent(eventId: string): string[] {
  return eventJudges[eventId] || []
}

export function assignJudgeToEvent(judgeId: string, eventId: string): void {
  if (!eventJudges[eventId]) {
    eventJudges[eventId] = []
  }
  if (!eventJudges[eventId].includes(judgeId)) {
    eventJudges[eventId].push(judgeId)
  }
}

export function removeJudgeFromEvent(judgeId: string, eventId: string): void {
  if (eventJudges[eventId]) {
    eventJudges[eventId] = eventJudges[eventId].filter((id) => id !== judgeId)
  }
}

export function isUserJudgeForEvent(userId: string, eventId: string): boolean {
  return eventJudges[eventId]?.includes(userId) || false
}

export function isUserFacilitatorForEvent(userId: string, eventId: string): boolean {
  const event = awardEvents.find((e) => e.id === eventId)
  if (!event) return false

  return event.facilitators?.some((facilitator) => facilitator.id === userId) || false
}

// Helper function to get judge names for an event (useful for displaying judge names)
export function getJudgeNamesForEvent(eventId: string): string[] {
  const judgeIds = getJudgesForEvent(eventId)
  return judgeIds.map((id) => {
    const judge = mockUsers.find((user) => user.id === id)
    return judge ? judge.name : "Unknown Judge"
  })
}

// Log the generated sample data for verification
console.log("Sample Event Judges:", eventJudges)

