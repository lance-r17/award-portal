import { mockUsers } from "./mock-users"
import { getAwardEventById } from "./award-events"
import { EventJudge } from "@/types/judges"

export const eventJudges: EventJudge[] = [
  // Spot Q1 2025 Judges
  { eventId: "spot-q1-2025", judgeId: "alex-morgan", isHeadJudge: true },
  { eventId: "spot-q1-2025", judgeId: "jordan-lee" },
  { eventId: "spot-q1-2025", judgeId: "casey-smith" },
  { eventId: "spot-q1-2025", judgeId: "jamie-taylor" },
  { eventId: "spot-q1-2025", judgeId: "quinn-martinez" },

  // Recognition Q1 2025 Judges
  { eventId: "recognition-q1-2025", judgeId: "alex-morgan", isHeadJudge: true },
  { eventId: "recognition-q1-2025", judgeId: "jordan-lee" },
  { eventId: "recognition-q1-2025", judgeId: "avery-williams" },

  // Spot Q4 2024 Judges
  { eventId: "spot-q4-2024", judgeId: "alex-morgan", isHeadJudge: true },
  { eventId: "spot-q4-2024", judgeId: "jordan-lee" },
  { eventId: "spot-q4-2024", judgeId: "casey-smith" },
  { eventId: "spot-q4-2024", judgeId: "jamie-taylor" },
  { eventId: "spot-q4-2024", judgeId: "avery-williams" },
  { eventId: "spot-q4-2024", judgeId: "riley-cooper" },

  // Recognition Q4 2024 Judges
  { eventId: "recognition-q4-2024", judgeId: "jordan-lee", isHeadJudge: true },
  { eventId: "recognition-q4-2024", judgeId: "alex-morgan" },
  { eventId: "recognition-q4-2024", judgeId: "taylor-johnson" },
]

// Helper functions
export function getJudgesForEvent(eventId: string): string[] {
  return eventJudges.filter((judge) => judge.eventId === eventId).map((judge) => judge.judgeId)
}

export function getHeadJudgeForEvent(eventId: string): string | undefined {
  const headJudge = eventJudges.find((judge) => judge.eventId === eventId && judge.isHeadJudge)
  return headJudge?.judgeId
}

export function isUserJudgeForEvent(userId: string, eventId: string): boolean {
  return eventJudges.some((judge) => judge.eventId === eventId && judge.judgeId === userId)
}

export function isUserHeadJudgeForEvent(userId: string, eventId: string): boolean {
  return eventJudges.some((judge) => judge.eventId === eventId && judge.judgeId === userId && judge.isHeadJudge)
}

export function isUserFacilitatorForEvent(userId: string, eventId: string): boolean {
  // Get the event from the award events data
  const event = getAwardEventById(eventId)
  if (!event) return false

  // Check if the user is a facilitator for the event
  return event.facilitators?.some((f: any) => f.id === userId) || false
}

export function getJudgeDetailsForEvent(eventId: string) {
  const judgeIds = getJudgesForEvent(eventId)
  const headJudgeId = getHeadJudgeForEvent(eventId)

  return judgeIds.map((judgeId) => {
    const user = mockUsers.find((u) => u.id === judgeId)
    return {
      id: judgeId,
      name: user?.name || "Unknown Judge",
      avatar: user?.avatar || "/placeholder.svg?height=40&width=40",
      initials: user?.initials || "??",
      email: user?.email || "",
      isHeadJudge: judgeId === headJudgeId,
    }
  })
}

export function assignJudgeToEvent(judgeId: string, eventId: string): void {
  // Check if the judge is already assigned to the event
  if (!isUserJudgeForEvent(judgeId, eventId)) {
    eventJudges.push({
      eventId,
      judgeId,
      isHeadJudge: false, // New judges are not head judges by default
    })
  }
}

export function removeJudgeFromEvent(judgeId: string, eventId: string): void {
  // Find the index of the judge in the eventJudges array
  const index = eventJudges.findIndex((judge) => judge.eventId === eventId && judge.judgeId === judgeId)

  // If found, remove the judge from the array
  if (index !== -1) {
    eventJudges.splice(index, 1)
  }
}

