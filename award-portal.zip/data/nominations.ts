import type { Nomination } from "@/types/nominations"
import { mockUsers } from "./mock-users"

// Existing nominations
const existingNominations: Nomination[] = [
  {
    id: "nom-001",
    eventId: "spot-q1-2025",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "emily-rodriguez") || {
      id: "emily-rodriguez",
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
      department: "Engineering",
    },
    nominator: mockUsers.find((u) => u.id === "michael-chen") || {
      id: "michael-chen",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Product",
    },
    serviceLine: ["cloud-services"],
    domainManagers: ["alex-morgan", "jordan-lee"],
    nominationSummary:
      "Emily has been instrumental in implementing agile methodologies across our team. She established a new sprint planning process that increased our velocity by 30% and reduced planning overhead. Her daily stand-ups are focused and effective, keeping the team aligned and unblocking issues quickly.\n\nThanks to Emily's agile leadership, we delivered our last project two weeks ahead of schedule. The client specifically mentioned how impressed they were with our iterative approach and responsiveness to their feedback.",
    justification:
      "Emily has been instrumental in implementing agile methodologies across our team. She established a new sprint planning process that increased our velocity by 30% and reduced planning overhead. Her daily stand-ups are focused and effective, keeping the team aligned and unblocking issues quickly.",
    impact:
      "Thanks to Emily's agile leadership, we delivered our last project two weeks ahead of schedule. The client specifically mentioned how impressed they were with our iterative approach and responsiveness to their feedback.",
    supportingInfo: "https://company.sharepoint.com/sites/agile-transformation/documents/emily-case-study.pdf",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2025-03-10T09:15:00Z"),
      comments: "Emily has consistently demonstrated exceptional agile leadership. Fully endorse this nomination.",
    },
    createdAt: new Date("2025-03-05T10:30:00Z"),
    updatedAt: new Date("2025-03-07T14:15:00Z"),
    votes: [
      { userId: "alex-morgan", userName: "Alex Morgan", timestamp: new Date() },
      { userId: "jordan-lee", userName: "Jordan Lee", timestamp: new Date() },
      { userId: "casey-smith", userName: "Casey Smith", timestamp: new Date() },
    ],
    comments: [
      {
        id: "comment-1",
        userId: "alex-morgan",
        userName: "Alex Morgan",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "AM",
        text: "Great work, Emily! Your agile leadership has truly transformed our team.",
        timestamp: new Date(),
      },
      {
        id: "comment-2",
        userId: "jordan-lee",
        userName: "Jordan Lee",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "JL",
        text: "I agree, Emily's contributions have been invaluable. Well deserved!",
        timestamp: new Date(),
      },
    ],
  },
  {
    id: "nom-002",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "david-kim") || {
      id: "david-kim",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Customer Support",
    },
    nominator: mockUsers.find((u) => u.id === "jessica-patel") || {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    serviceLine: ["customer-experience"],
    domainManagers: ["casey-smith", "avery-williams"],
    nominationSummary:
      "David went above and beyond for a customer who was experiencing critical issues with our platform. He stayed on a call for over 4 hours, working through dinner time, to ensure the customer's system was back online. He then followed up the next day to make sure everything was still working properly.\n\nThe customer was so impressed with David's dedication that they upgraded their subscription to our premium tier. They also mentioned David specifically in their renewal discussion as a key reason for continuing with our service.",
    justification:
      "David went above and beyond for a customer who was experiencing critical issues with our platform. He stayed on a call for over 4 hours, working through dinner time, to ensure the customer's system was back online. He then followed up the next day to make sure everything was still working properly.",
    impact:
      "The customer was so impressed with David's dedication that they upgraded their subscription to our premium tier. They also mentioned David specifically in their renewal discussion as a key reason for continuing with our service.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "avery-williams",
      endorsedAt: new Date("2025-03-12T14:30:00Z"),
      comments: "David's dedication to customer satisfaction is exemplary. Strong endorsement.",
    },
    createdAt: new Date("2025-03-08T09:45:00Z"),
    updatedAt: new Date("2025-03-10T11:20:00Z"),
    votes: [
      { userId: "quinn-martinez", userName: "Quinn Martinez", timestamp: new Date() },
      { userId: "riley-thompson", userName: "Riley Thompson", timestamp: new Date() },
    ],
    comments: [
      {
        id: "comment-3",
        userId: "quinn-martinez",
        userName: "Quinn Martinez",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "QM",
        text: "David, your commitment to our customers is truly inspiring!",
        timestamp: new Date(),
      },
    ],
  },
  {
    id: "nom-003",
    eventId: "spot-q1-2025",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "sarah-johnson") || {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: mockUsers.find((u) => u.id === "james-wilson") || {
      id: "james-wilson",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Product",
    },
    serviceLine: ["digital-transformation"],
    domainManagers: ["alex-morgan"],
    nominationSummary:
      "Sarah developed an innovative solution to our data processing bottleneck. She designed and implemented a new caching layer that reduced our API response times by 70%. Her solution was elegant, well-documented, and implemented with minimal disruption to existing systems.\n\nThe performance improvements from Sarah's innovation have directly impacted our user experience metrics. We've seen a 25% increase in user engagement and a 15% reduction in bounce rates since implementing her solution.",
    justification:
      "Sarah developed an innovative solution to our data processing bottleneck. She designed and implemented a new caching layer that reduced our API response times by 70%. Her solution was elegant, well-documented, and implemented with minimal disruption to existing systems.",
    impact:
      "The performance improvements from Sarah's innovation have directly impacted our user experience metrics. We've seen a 25% increase in user engagement and a 15% reduction in bounce rates since implementing her solution.",
    supportingInfo: "https://github.com/company/project/pull/1234",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2025-03-15T10:45:00Z"),
      comments: "Sarah's innovation has transformed our platform performance. Enthusiastically endorsed.",
    },
    createdAt: new Date("2025-03-12T14:30:00Z"),
    updatedAt: new Date("2025-03-14T10:45:00Z"),
  },
  {
    id: "nom-004",
    eventId: "spot-q1-2025",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "michael-chen") || {
      id: "michael-chen",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Product",
    },
    nominator: mockUsers.find((u) => u.id === "olivia-martinez") || {
      id: "olivia-martinez",
      name: "Olivia Martinez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "OM",
      department: "Engineering",
    },
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["jordan-lee", "taylor-johnson"],
    nominationSummary:
      "Michael stepped up as a leader during our recent project crisis when our team lead was unexpectedly out for two weeks. He organized the team, reprioritized tasks, and maintained clear communication with stakeholders. His calm demeanor and decisive action kept the project on track during a challenging time.\n\nThanks to Michael's leadership, we not only met our deadline but delivered all critical features. The client specifically praised our team's professionalism and resilience during the transition.",
    justification:
      "Michael stepped up as a leader during our recent project crisis when our team lead was unexpectedly out for two weeks. He organized the team, reprioritized tasks, and maintained clear communication with stakeholders. His calm demeanor and decisive action kept the project on track during a challenging time.",
    impact:
      "Thanks to Michael's leadership, we not only met our deadline but delivered all critical features. The client specifically praised our team's professionalism and resilience during the transition.",
    status: "approved",
    endorsement: {
      status: "pending",
      comments: "Awaiting domain manager review.",
    },
    createdAt: new Date("2025-03-15T11:20:00Z"),
    updatedAt: new Date("2025-03-17T09:30:00Z"),
  },
  {
    id: "nom-005",
    eventId: "spot-q1-2025",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jessica-patel") || {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    nominator: mockUsers.find((u) => u.id === "david-kim") || {
      id: "david-kim",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Customer Support",
    },
    serviceLine: ["customer-experience"],
    domainManagers: ["avery-williams"],
    nominationSummary:
      "Jessica has been a driving force for team morale and engagement. She organized virtual coffee chats, created a team recognition channel, and started a monthly 'lunch and learn' series. Her positive attitude is contagious, and she consistently goes out of her way to make new team members feel welcome.\n\nOur team's engagement survey scores have increased by 18% since Jessica implemented these initiatives. We've also seen improved cross-department collaboration and knowledge sharing.",
    justification:
      "Jessica has been a driving force for team morale and engagement. She organized virtual coffee chats, created a team recognition channel, and started a monthly 'lunch and learn' series. Her positive attitude is contagious, and she consistently goes out of her way to make new team members feel welcome.",
    impact:
      "Our team's engagement survey scores have increased by 18% since Jessica implemented these initiatives. We've also seen improved cross-department collaboration and knowledge sharing.",
    status: "approved",
    endorsement: {
      status: "pending",
      comments: "Under review by domain manager.",
    },
    createdAt: new Date("2025-03-18T15:45:00Z"),
    updatedAt: new Date("2025-03-20T13:10:00Z"),
  },
  {
    id: "nom-006",
    eventId: "spot-q1-2025",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "platform-team",
      name: "Platform Engineering Team",
      members: ["sarah-johnson", "michael-chen", "emily-rodriguez", "david-kim", "james-wilson"],
    },
    nominee: {
      id: "platform-team",
      name: "Platform Engineering Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "PT",
      department: "Engineering",
    },
    presenter: mockUsers.find((u) => u.id === "sarah-johnson") || {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: mockUsers.find((u) => u.id === "jessica-patel") || {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    serviceLine: ["digital-transformation", "cloud-services", "enterprise-solutions"],
    domainManagers: ["alex-morgan", "jordan-lee"],
    nominationSummary:
      "The Platform Engineering Team worked tirelessly to redesign our core infrastructure to support our growing customer base. They collaborated effectively across multiple time zones, maintained clear documentation, and supported each other through technical challenges. Their work exemplifies true teamwork and technical excellence.\n\nThe platform improvements have resulted in 99.99% uptime (up from 99.9%), 40% faster deployments, and the ability to handle 3x our previous peak load. These improvements directly support our company's growth targets for the year.",
    justification:
      "The Platform Engineering Team worked tirelessly to redesign our core infrastructure to support our growing customer base. They collaborated effectively across multiple time zones, maintained clear documentation, and supported each other through technical challenges. Their work exemplifies true teamwork and technical excellence.",
    impact:
      "The platform improvements have resulted in 99.99% uptime (up from 99.9%), 40% faster deployments, and the ability to handle 3x our previous peak load. These improvements directly support our company's growth targets for the year.",
    supportingInfo: "https://company.confluence.com/platform-redesign-project",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2025-03-25T09:20:00Z"),
      comments:
        "This team has delivered exceptional results. Their collaboration and technical excellence deserve recognition.",
    },
    createdAt: new Date("2025-03-22T10:15:00Z"),
    updatedAt: new Date("2025-03-24T14:30:00Z"),
  },
  {
    id: "nom-007",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "james-wilson") || {
      id: "james-wilson",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Product",
    },
    nominator: mockUsers.find((u) => u.id === "sarah-johnson") || {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["taylor-johnson", "quinn-martinez"],
    nominationSummary:
      "James has redefined what customer-centric product development looks like. He established a customer feedback loop that directly informs our product roadmap. He personally conducted over 30 customer interviews to understand pain points and needs, then translated those insights into clear product requirements.\n\nFeatures prioritized through James's customer feedback process have seen 3x higher adoption rates than our previous releases. Customer satisfaction scores for the product have increased from 7.2 to 8.9 out of 10.",
    justification:
      "James has redefined what customer-centric product development looks like. He established a customer feedback loop that directly informs our product roadmap. He personally conducted over 30 customer interviews to understand pain points and needs, then translated those insights into clear product requirements.",
    impact:
      "Features prioritized through James's customer feedback process have seen 3x higher adoption rates than our previous releases. Customer satisfaction scores for the product have increased from 7.2 to 8.9 out of 10.",
    status: "approved",
    endorsement: {
      status: "rejected",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2025-03-28T16:45:00Z"),
      comments:
        "While James has done good work, I believe this nomination would be more appropriate for a future award cycle after the current project is completed.",
    },
    createdAt: new Date("2025-03-25T13:40:00Z"),
    updatedAt: new Date("2025-03-27T11:15:00Z"),
  },
]

// Generate sample nominations for Q4 2024 Spot Awards
const q4_2024_nominations: Nomination[] = [
  // Star of Agile - 5 candidates
  {
    id: "nom-q4-2024-001",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "emily-rodriguez") || mockUsers[0],
    nominator: mockUsers.find((u) => u.id === "alex-morgan") || mockUsers[1],
    serviceLine: ["technology"],
    domainManagers: ["alex-morgan", "samantha-lee"],
    nominationSummary:
      "Emily led the successful implementation of agile methodologies across three major projects, resulting in a 25% increase in delivery speed and improved client satisfaction.\n\nThe agile transformation led by Emily has become a benchmark for other teams, leading to company-wide adoption of these practices.",
    justification:
      "Emily led the successful implementation of agile methodologies across three major projects, resulting in a 25% increase in delivery speed and improved client satisfaction.",
    impact:
      "The agile transformation led by Emily has become a benchmark for other teams, leading to company-wide adoption of these practices.",
    status: "awarded", // First winner for star-of-agile
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-11-20T14:30:00Z"),
      comments: "Emily's leadership in agile practices has been transformative. Strongly endorse.",
    },
    createdAt: new Date("2024-10-25T09:15:00Z"),
    updatedAt: new Date("2024-11-20T14:30:00Z"),
  },
  {
    id: "nom-q4-2024-001a",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[5],
    nominator: mockUsers.find((u) => u.id === "taylor-johnson") || mockUsers[7],
    serviceLine: ["digital-transformation"],
    domainManagers: ["alex-morgan", "casey-smith"],
    nominationSummary:
      "Jordan implemented a revolutionary sprint planning approach that increased team velocity by 40%. Their daily stand-ups are models of efficiency, and they've trained three other teams on effective agile ceremonies.\n\nProjects under Jordan's agile leadership have consistently delivered on time or early, with a 30% reduction in defects and significantly higher stakeholder satisfaction scores.",
    justification:
      "Jordan implemented a revolutionary sprint planning approach that increased team velocity by 40%. Their daily stand-ups are models of efficiency, and they've trained three other teams on effective agile ceremonies.",
    impact:
      "Projects under Jordan's agile leadership have consistently delivered on time or early, with a 30% reduction in defects and significantly higher stakeholder satisfaction scores.",
    status: "awarded", // Second winner for star-of-agile
    endorsement: {
      status: "endorsed",
      endorsedBy: "casey-smith",
      endorsedAt: new Date("2024-11-18T11:20:00Z"),
      comments: "Jordan has transformed how we approach agile. Their impact extends beyond their immediate team.",
    },
    createdAt: new Date("2024-10-22T13:45:00Z"),
    updatedAt: new Date("2024-11-18T11:20:00Z"),
  },
  {
    id: "nom-q4-2024-001b",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jamie-taylor") || mockUsers[8],
    nominator: mockUsers.find((u) => u.id === "quinn-martinez") || mockUsers[9],
    serviceLine: ["cloud-services"],
    domainManagers: ["jordan-lee", "alex-morgan"],
    nominationSummary:
      "Jamie created an innovative agile framework specifically tailored for cloud migration projects. Their approach combines elements of Scrum and Kanban to optimize for the unique challenges of cloud transitions.\n\nJamie's agile framework reduced cloud migration timelines by 35% and has been adopted by four other teams. Client feedback specifically mentions the transparency and predictability of our delivery process.",
    justification:
      "Jamie created an innovative agile framework specifically tailored for cloud migration projects. Their approach combines elements of Scrum and Kanban to optimize for the unique challenges of cloud transitions.",
    impact:
      "Jamie's agile framework reduced cloud migration timelines by 35% and has been adopted by four other teams. Client feedback specifically mentions the transparency and predictability of our delivery process.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-19T09:30:00Z"),
      comments: "Jamie's innovative approach to agile for cloud projects deserves recognition. Full endorsement.",
    },
    createdAt: new Date("2024-10-24T10:15:00Z"),
    updatedAt: new Date("2024-11-19T09:30:00Z"),
  },
  {
    id: "nom-q4-2024-001c",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "riley-thompson") || mockUsers[10],
    nominator: mockUsers.find((u) => u.id === "casey-smith") || mockUsers[11],
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["taylor-johnson", "alex-morgan"],
    nominationSummary:
      "Riley transformed our enterprise client engagements by implementing agile practices in traditionally waterfall environments. They developed a hybrid approach that eases clients into agile while maintaining governance requirements.\n\nRiley's approach has been implemented with three enterprise clients, resulting in 28% faster delivery cycles and significantly improved client satisfaction scores from 6.8 to 9.2 out of 10.",
    justification:
      "Riley transformed our enterprise client engagements by implementing agile practices in traditionally waterfall environments. They developed a hybrid approach that eases clients into agile while maintaining governance requirements.",
    impact:
      "Riley's approach has been implemented with three enterprise clients, resulting in 28% faster delivery cycles and significantly improved client satisfaction scores from 6.8 to 9.2 out of 10.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2024-11-21T14:15:00Z"),
      comments: "Riley's ability to bring agile to enterprise clients has opened new opportunities for our business.",
    },
    createdAt: new Date("2024-10-26T08:30:00Z"),
    updatedAt: new Date("2024-11-21T14:15:00Z"),
  },
  {
    id: "nom-q4-2024-001d",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "avery-williams") || mockUsers[12],
    nominator: mockUsers.find((u) => u.id === "chris-patel") || mockUsers[13],
    serviceLine: ["customer-experience"],
    domainManagers: ["casey-smith", "quinn-martinez"],
    nominationSummary:
      "Avery pioneered the use of agile methodologies in our UX research and design processes. They created a framework that allows for rapid user testing and iteration while maintaining design quality.\n\nProducts developed using Avery's agile UX approach have seen a 45% increase in user satisfaction metrics and a 30% reduction in post-launch design changes.",
    justification:
      "Avery pioneered the use of agile methodologies in our UX research and design processes. They created a framework that allows for rapid user testing and iteration while maintaining design quality.",
    impact:
      "Products developed using Avery's agile UX approach have seen a 45% increase in user satisfaction metrics and a 30% reduction in post-launch design changes.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "quinn-martinez",
      endorsedAt: new Date("2024-11-22T10:45:00Z"),
      comments: "Avery's innovation in applying agile to UX processes has significantly improved our product quality.",
    },
    createdAt: new Date("2024-10-27T11:30:00Z"),
    updatedAt: new Date("2024-11-22T10:45:00Z"),
  },

  // Star of Customer Service - 5 candidates
  {
    id: "nom-q4-2024-002",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "david-kim") || mockUsers[2],
    nominator: mockUsers.find((u) => u.id === "avery-williams") || mockUsers[3],
    serviceLine: ["customer-experience"],
    domainManagers: ["avery-williams", "riley-thompson"],
    nominationSummary:
      "David went above and beyond in resolving a critical issue for our largest client, working through the weekend to ensure minimal disruption to their operations.\n\nDavid's dedication not only saved the client relationship but also led to a contract renewal worth $2 million.",
    justification:
      "David went above and beyond in resolving a critical issue for our largest client, working through the weekend to ensure minimal disruption to their operations.",
    impact:
      "David's dedication not only saved the client relationship but also led to a contract renewal worth $2 million.",
    status: "awarded", // First winner for star-of-customer-service
    endorsement: {
      status: "endorsed",
      endorsedBy: "avery-williams",
      endorsedAt: new Date("2024-11-22T10:45:00Z"),
      comments: "David's commitment to customer satisfaction is exemplary. Fully endorse this nomination.",
    },
    createdAt: new Date("2024-10-28T11:30:00Z"),
    updatedAt: new Date("2024-11-22T10:45:00Z"),
  },
  {
    id: "nom-q4-2024-002a",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "olivia-martinez") || mockUsers[14],
    nominator: mockUsers.find((u) => u.id === "michael-chen") || mockUsers[15],
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["taylor-johnson", "casey-smith"],
    nominationSummary:
      "Olivia created a proactive customer success program that identifies potential issues before they impact clients. She personally reached out to 15 at-risk accounts and developed customized success plans for each.\n\nOlivia's program reduced customer churn by 40% this quarter and increased our Net Promoter Score from 32 to 58. Three clients specifically mentioned her by name in their renewal discussions.",
    justification:
      "Olivia created a proactive customer success program that identifies potential issues before they impact clients. She personally reached out to 15 at-risk accounts and developed customized success plans for each.",
    impact:
      "Olivia's program reduced customer churn by 40% this quarter and increased our Net Promoter Score from 32 to 58. Three clients specifically mentioned her by name in their renewal discussions.",
    status: "awarded", // Second winner for star-of-customer-service
    endorsement: {
      status: "endorsed",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2024-11-23T09:15:00Z"),
      comments: "Olivia's proactive approach to customer success has transformed our retention metrics.",
    },
    createdAt: new Date("2024-10-29T14:20:00Z"),
    updatedAt: new Date("2024-11-23T09:15:00Z"),
  },
  {
    id: "nom-q4-2024-002b",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "alex-rodriguez") || mockUsers[16],
    nominator: mockUsers.find((u) => u.id === "jamie-taylor") || mockUsers[8],
    serviceLine: ["cloud-services"],
    domainManagers: ["jordan-lee", "quinn-martinez"],
    nominationSummary:
      "Alex developed a comprehensive onboarding experience for new cloud services clients that reduced time-to-value from 45 days to just 12 days. They personally guided 8 enterprise clients through this new process.\n\nAlex's onboarding improvements have resulted in a 70% increase in feature adoption within the first month and significantly higher customer satisfaction scores for new clients.",
    justification:
      "Alex developed a comprehensive onboarding experience for new cloud services clients that reduced time-to-value from 45 days to just 12 days. They personally guided 8 enterprise clients through this new process.",
    impact:
      "Alex's onboarding improvements have resulted in a 70% increase in feature adoption within the first month and significantly higher customer satisfaction scores for new clients.",
    status: "awarded", // Third winner for star-of-customer-service
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-24T11:30:00Z"),
      comments: "Alex's customer-centric approach to onboarding has set a new standard for our cloud services.",
    },
    createdAt: new Date("2024-10-30T09:45:00Z"),
    updatedAt: new Date("2024-11-24T11:30:00Z"),
  },
  {
    id: "nom-q4-2024-002c",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "samantha-lee") || mockUsers[17],
    nominator: mockUsers.find((u) => u.id === "riley-thompson") || mockUsers[10],
    serviceLine: ["technology"],
    domainManagers: ["alex-morgan", "casey-smith"],
    nominationSummary:
      "Samantha implemented a 24/7 support model for our critical infrastructure clients. She personally trained the support team and took on-call rotations to ensure a smooth transition to the new model.\n\nSamantha's support model has reduced average response time from 4 hours to 15 minutes and resolution time by 60%. Client satisfaction with support has increased from 7.5 to 9.8 out of 10.",
    justification:
      "Samantha implemented a 24/7 support model for our critical infrastructure clients. She personally trained the support team and took on-call rotations to ensure a smooth transition to the new model.",
    impact:
      "Samantha's support model has reduced average response time from 4 hours to 15 minutes and resolution time by 60%. Client satisfaction with support has increased from 7.5 to 9.8 out of 10.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-11-25T13:45:00Z"),
      comments:
        "Samantha's dedication to customer support excellence has significantly enhanced our service reputation.",
    },
    createdAt: new Date("2024-10-31T15:30:00Z"),
    updatedAt: new Date("2024-11-25T13:45:00Z"),
  },
  {
    id: "nom-q4-2024-002d",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "chris-patel") || mockUsers[13],
    nominator: mockUsers.find((u) => u.id === "avery-williams") || mockUsers[12],
    serviceLine: ["customer-experience"],
    domainManagers: ["quinn-martinez", "riley-thompson"],
    nominationSummary:
      "Chris redesigned our customer feedback process to capture more actionable insights. They personally conducted 30 customer interviews and created a framework for translating feedback into product improvements.\n\nChris's feedback framework has directly influenced our product roadmap, with 8 of the top 10 requested features now in development. Customer satisfaction with our responsiveness has increased by 45%.",
    justification:
      "Chris redesigned our customer feedback process to capture more actionable insights. They personally conducted 30 customer interviews and created a framework for translating feedback into product improvements.",
    impact:
      "Chris's feedback framework has directly influenced our product roadmap, with 8 of the top 10 requested features now in development. Customer satisfaction with our responsiveness has increased by 45%.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "quinn-martinez",
      endorsedAt: new Date("2024-11-26T10:15:00Z"),
      comments:
        "Chris's systematic approach to customer feedback has transformed how we prioritize product development.",
    },
    createdAt: new Date("2024-11-01T12:45:00Z"),
    updatedAt: new Date("2024-11-26T10:15:00Z"),
  },

  // Star of Innovation - 5 candidates
  {
    id: "nom-q4-2024-003",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "sarah-johnson") || mockUsers[4],
    nominator: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[5],
    serviceLine: ["cloud-services"],
    domainManagers: ["jordan-lee", "chris-patel"],
    nominationSummary:
      "Sarah developed a novel cloud optimization algorithm that reduced our clients' cloud costs by an average of 30%, while maintaining or improving performance.\n\nSarah's innovation has been implemented for 5 major clients, resulting in a total cost saving of $500,000 per month and strengthening our position as a leader in cloud optimization.",
    justification:
      "Sarah developed a novel cloud optimization algorithm that reduced our clients' cloud costs by an average of 30%, while maintaining or improving performance.",
    impact:
      "Sarah's innovation has been implemented for 5 major clients, resulting in a total cost saving of $500,000 per month and strengthening our position as a leader in cloud optimization.",
    status: "awarded", // First winner for star-of-innovation
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-25T09:20:00Z"),
      comments: "Sarah's innovative solution has set a new standard in cloud optimization. Strongly endorse.",
    },
    createdAt: new Date("2024-11-01T14:45:00Z"),
    updatedAt: new Date("2024-11-25T09:20:00Z"),
  },
  {
    id: "nom-q4-2024-003a",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "michael-chen") || mockUsers[15],
    nominator: mockUsers.find((u) => u.id === "emily-rodriguez") || mockUsers[0],
    serviceLine: ["technology"],
    domainManagers: ["alex-morgan", "samantha-lee"],
    nominationSummary:
      "Michael created a machine learning model that predicts potential system failures 72 hours before they occur, allowing for proactive maintenance and zero downtime for critical systems.\n\nMichael's predictive maintenance system has prevented an estimated 15 major outages this quarter, saving approximately $2.3 million in potential downtime costs and significantly enhancing our reliability reputation.",
    justification:
      "Michael created a machine learning model that predicts potential system failures 72 hours before they occur, allowing for proactive maintenance and zero downtime for critical systems.",
    impact:
      "Michael's predictive maintenance system has prevented an estimated 15 major outages this quarter, saving approximately $2.3 million in potential downtime costs and significantly enhancing our reliability reputation.",
    status: "awarded", // Second winner for star-of-innovation
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-11-26T11:30:00Z"),
      comments: "Michael's innovative application of ML to system reliability is groundbreaking. Strong endorsement.",
    },
    createdAt: new Date("2024-11-02T09:15:00Z"),
    updatedAt: new Date("2024-11-26T11:30:00Z"),
  },
  {
    id: "nom-q4-2024-003b",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "james-wilson") || mockUsers[18],
    nominator: mockUsers.find((u) => u.id === "sarah-johnson") || mockUsers[4],
    serviceLine: ["digital-transformation"],
    domainManagers: ["jordan-lee", "taylor-johnson"],
    nominationSummary:
      "James developed a revolutionary approach to API security that uses dynamic token validation and contextual authentication, significantly enhancing security without impacting performance.\n\nJames's API security framework has been implemented across our platform, reducing security incidents by 85% while maintaining sub-100ms response times. Three clients have specifically cited our enhanced security as a reason for choosing our services.",
    justification:
      "James developed a revolutionary approach to API security that uses dynamic token validation and contextual authentication, significantly enhancing security without impacting performance.",
    impact:
      "James's API security framework has been implemented across our platform, reducing security incidents by 85% while maintaining sub-100ms response times. Three clients have specifically cited our enhanced security as a reason for choosing our services.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2024-11-27T14:45:00Z"),
      comments:
        "James's innovation in API security addresses a critical industry challenge. Enthusiastically endorsed.",
    },
    createdAt: new Date("2024-11-03T13:30:00Z"),
    updatedAt: new Date("2024-11-27T14:45:00Z"),
  },
  {
    id: "nom-q4-2024-003c",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jessica-patel") || mockUsers[19],
    nominator: mockUsers.find((u) => u.id === "david-kim") || mockUsers[2],
    serviceLine: ["customer-experience"],
    domainManagers: ["avery-williams", "quinn-martinez"],
    nominationSummary:
      "Jessica created an AI-powered customer intent prediction system that analyzes customer behavior patterns to anticipate needs and personalize experiences in real-time.\n\nJessica's AI system has increased conversion rates by 35% and customer satisfaction scores by 28%. The personalized experience has been cited in customer feedback as a key differentiator from competitors.",
    justification:
      "Jessica created an AI-powered customer intent prediction system that analyzes customer behavior patterns to anticipate needs and personalize experiences in real-time.",
    impact:
      "Jessica's AI system has increased conversion rates by 35% and customer satisfaction scores by 28%. The personalized experience has been cited in customer feedback as a key differentiator from competitors.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "quinn-martinez",
      endorsedAt: new Date("2024-11-28T10:15:00Z"),
      comments: "Jessica's innovative application of AI to customer experience is transformative. Fully endorsed.",
    },
    createdAt: new Date("2024-11-04T11:45:00Z"),
    updatedAt: new Date("2024-11-28T10:15:00Z"),
  },
  {
    id: "nom-q4-2024-003d",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "taylor-johnson") || mockUsers[7],
    nominator: mockUsers.find((u) => u.id === "riley-thompson") || mockUsers[10],
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["casey-smith", "jordan-lee"],
    nominationSummary:
      "Taylor developed a blockchain-based solution for supply chain transparency that provides immutable tracking and verification for enterprise clients in regulated industries.\n\nTaylor's blockchain solution has been adopted by two Fortune 500 clients, reducing compliance reporting time by 70% and enabling real-time visibility into their supply chains. The solution has generated $1.8M in new revenue this quarter.",
    justification:
      "Taylor developed a blockchain-based solution for supply chain transparency that provides immutable tracking and verification for enterprise clients in regulated industries.",
    impact:
      "Taylor's blockchain solution has been adopted by two Fortune 500 clients, reducing compliance reporting time by 70% and enabling real-time visibility into their supply chains. The solution has generated $1.8M in new revenue this quarter.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "casey-smith",
      endorsedAt: new Date("2024-11-29T15:30:00Z"),
      comments:
        "Taylor's innovative application of blockchain technology solves a significant industry challenge. Strongly endorsed.",
    },
    createdAt: new Date("2024-11-05T14:30:00Z"),
    updatedAt: new Date("2024-11-29T15:30:00Z"),
  },

  // Star of Leadership - 5 candidates
  {
    id: "nom-q4-2024-004a",
    eventId: "spot-q4-2024",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "alex-morgan") || mockUsers[1],
    nominator: mockUsers.find((u) => u.id === "emily-rodriguez") || mockUsers[0],
    serviceLine: ["technology"],
    domainManagers: ["casey-smith", "taylor-johnson"],
    nominationSummary:
      "Alex demonstrated exceptional leadership during our major platform migration, guiding a cross-functional team of 25 people through a complex transition with zero downtime. They created a detailed risk mitigation plan and personally led daily coordination meetings.\n\nUnder Alex's leadership, the migration was completed two weeks ahead of schedule, with 100% feature parity and no customer-facing issues. The approach has been documented as a best practice for future migrations.",
    justification:
      "Alex demonstrated exceptional leadership during our major platform migration, guiding a cross-functional team of 25 people through a complex transition with zero downtime. They created a detailed risk mitigation plan and personally led daily coordination meetings.",
    impact:
      "Under Alex's leadership, the migration was completed two weeks ahead of schedule, with 100% feature parity and no customer-facing issues. The approach has been documented as a best practice for future migrations.",
    status: "awarded", // First winner for star-of-leadership
    endorsement: {
      status: "endorsed",
      endorsedBy: "casey-smith",
      endorsedAt: new Date("2024-11-22T13:45:00Z"),
      comments:
        "Alex's leadership during this critical migration was exemplary. Their calm, methodical approach ensured success.",
    },
    createdAt: new Date("2024-10-28T09:30:00Z"),
    updatedAt: new Date("2024-11-22T13:45:00Z"),
  },
  {
    id: "nom-q4-2024-004b",
    eventId: "spot-q4-2024",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "casey-smith") || mockUsers[11],
    nominator: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[5],
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["taylor-johnson", "quinn-martinez"],
    nominationSummary:
      "Casey led the turnaround of a troubled client relationship by rebuilding trust, restructuring the delivery team, and implementing transparent communication processes. They personally met with client executives weekly and took ownership of resolving historical issues.\n\nCasey's leadership transformed a client that was considering termination into one of our strongest partnerships. The client has since increased their contract value by 40% and provided referrals to two new enterprise clients.",
    justification:
      "Casey led the turnaround of a troubled client relationship by rebuilding trust, restructuring the delivery team, and implementing transparent communication processes. They personally met with client executives weekly and took ownership of resolving historical issues.",
    impact:
      "Casey's leadership transformed a client that was considering termination into one of our strongest partnerships. The client has since increased their contract value by 40% and provided referrals to two new enterprise clients.",
    status: "awarded", // Second winner for star-of-leadership
    endorsement: {
      status: "endorsed",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2024-11-23T10:30:00Z"),
      comments: "Casey's ability to turn around challenging situations demonstrates true leadership excellence.",
    },
    createdAt: new Date("2024-10-29T11:45:00Z"),
    updatedAt: new Date("2024-11-23T10:30:00Z"),
  },
  {
    id: "nom-q4-2024-004c",
    eventId: "spot-q4-2024",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "quinn-martinez") || mockUsers[9],
    nominator: mockUsers.find((u) => u.id === "avery-williams") || mockUsers[12],
    serviceLine: ["customer-experience"],
    domainManagers: ["riley-thompson", "jordan-lee"],
    nominationSummary:
      "Quinn led our company's first diversity and inclusion initiative, creating mentorship programs, inclusive hiring practices, and educational resources. They built a cross-departmental team of champions and secured executive sponsorship for long-term sustainability.\n\nUnder Quinn's leadership, we've seen a 35% increase in diverse hiring, 28% improvement in inclusion survey scores, and significantly higher retention rates among underrepresented groups. Their framework has been recognized as an industry best practice.",
    justification:
      "Quinn led our company's first diversity and inclusion initiative, creating mentorship programs, inclusive hiring practices, and educational resources. They built a cross-departmental team of champions and secured executive sponsorship for long-term sustainability.",
    impact:
      "Under Quinn's leadership, we've seen a 35% increase in diverse hiring, 28% improvement in inclusion survey scores, and significantly higher retention rates among underrepresented groups. Their framework has been recognized as an industry best practice.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "riley-thompson",
      endorsedAt: new Date("2024-11-24T14:15:00Z"),
      comments:
        "Quinn's leadership in this critical initiative has created lasting positive change in our organization.",
    },
    createdAt: new Date("2024-10-30T13:30:00Z"),
    updatedAt: new Date("2024-11-24T14:15:00Z"),
  },
  {
    id: "nom-q4-2024-004d",
    eventId: "spot-q4-2024",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "riley-thompson") || mockUsers[10],
    nominator: mockUsers.find((u) => u.id === "chris-patel") || mockUsers[13],
    serviceLine: ["digital-transformation"],
    domainManagers: ["alex-morgan", "casey-smith"],
    nominationSummary:
      "Riley led our organization through a major strategic pivot, realigning teams and resources to focus on emerging market opportunities. They facilitated collaborative planning sessions, created clear transition plans, and personally coached team leaders through the change.\n\nRiley's leadership enabled a smooth transition that has resulted in three new service offerings, 22% revenue growth in targeted segments, and significantly improved employee satisfaction despite the organizational changes.",
    justification:
      "Riley led our organization through a major strategic pivot, realigning teams and resources to focus on emerging market opportunities. They facilitated collaborative planning sessions, created clear transition plans, and personally coached team leaders through the change.",
    impact:
      "Riley's leadership enabled a smooth transition that has resulted in three new service offerings, 22% revenue growth in targeted segments, and significantly improved employee satisfaction despite the organizational changes.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-11-25T09:45:00Z"),
      comments: "Riley's strategic leadership during this pivotal transition has positioned us for future success.",
    },
    createdAt: new Date("2024-10-31T10:15:00Z"),
    updatedAt: new Date("2024-11-25T09:45:00Z"),
  },
  {
    id: "nom-q4-2024-004e",
    eventId: "spot-q4-2024",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[5],
    nominator: mockUsers.find((u) => u.id === "sarah-johnson") || mockUsers[4],
    serviceLine: ["cloud-services"],
    domainManagers: ["taylor-johnson", "quinn-martinez"],
    nominationSummary:
      "Jordan led our cloud center of excellence, establishing governance frameworks, training programs, and technical standards. They built a team of cloud architects who serve as internal consultants and mentors across the organization.\n\nUnder Jordan's leadership, our cloud adoption has accelerated by 65%, cloud-related incidents have decreased by 40%, and we've achieved significant cost optimizations. Their team has enabled five major client migrations with zero downtime.",
    justification:
      "Jordan led our cloud center of excellence, establishing governance frameworks, training programs, and technical standards. They built a team of cloud architects who serve as internal consultants and mentors across the organization.",
    impact:
      "Under Jordan's leadership, our cloud adoption has accelerated by 65%, cloud-related incidents have decreased by 40%, and we've achieved significant cost optimizations. Their team has enabled five major client migrations with zero downtime.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2024-11-26T11:30:00Z"),
      comments: "Jordan's technical leadership has established our cloud practice as a center of excellence.",
    },
    createdAt: new Date("2024-11-01T15:45:00Z"),
    updatedAt: new Date("2024-11-26T11:30:00Z"),
  },

  // Star of Engagement - 5 candidates
  {
    id: "nom-q4-2024-005a",
    eventId: "spot-q4-2024",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jessica-patel") || mockUsers[19],
    nominator: mockUsers.find((u) => u.id === "david-kim") || mockUsers[2],
    serviceLine: ["customer-experience"],
    domainManagers: ["avery-williams", "riley-thompson"],
    nominationSummary:
      "Jessica revitalized our company culture by creating a comprehensive engagement program including virtual coffee chats, skill-sharing sessions, and team recognition initiatives. She personally facilitated weekly connection events and created a mentorship program.\n\nJessica's initiatives have increased employee engagement scores by 32%, reduced turnover by 25%, and significantly improved cross-team collaboration. New hires specifically mention our culture as a reason for joining.",
    justification:
      "Jessica revitalized our company culture by creating a comprehensive engagement program including virtual coffee chats, skill-sharing sessions, and team recognition initiatives. She personally facilitated weekly connection events and created a mentorship program.",
    impact:
      "Jessica's initiatives have increased employee engagement scores by 32%, reduced turnover by 25%, and significantly improved cross-team collaboration. New hires specifically mention our culture as a reason for joining.",
    status: "awarded", // First winner for star-of-engagement
    endorsement: {
      status: "endorsed",
      endorsedBy: "avery-williams",
      endorsedAt: new Date("2024-11-22T14:30:00Z"),
      comments: "Jessica's passion for creating a positive work environment has transformed our culture.",
    },
    createdAt: new Date("2024-10-28T13:15:00Z"),
    updatedAt: new Date("2024-11-22T14:30:00Z"),
  },
  {
    id: "nom-q4-2024-005b",
    eventId: "spot-q4-2024",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "chris-patel") || mockUsers[13],
    nominator: mockUsers.find((u) => u.id === "quinn-martinez") || mockUsers[9],
    serviceLine: ["digital-transformation"],
    domainManagers: ["jordan-lee", "casey-smith"],
    nominationSummary:
      "Chris created an innovative knowledge-sharing platform that connects experts across the organization. They organized monthly learning festivals, created a technical blog series, and personally mentored 12 junior team members.\n\nChris's knowledge initiatives have accelerated onboarding by 40%, improved solution quality through cross-pollination of ideas, and created a vibrant learning culture that has been cited in employee satisfaction surveys.",
    justification:
      "Chris created an innovative knowledge-sharing platform that connects experts across the organization. They organized monthly learning festivals, created a technical blog series, and personally mentored 12 junior team members.",
    impact:
      "Chris's knowledge initiatives have accelerated onboarding by 40%, improved solution quality through cross-pollination of ideas, and created a vibrant learning culture that has been cited in employee satisfaction surveys.",
    status: "awarded", // Second winner for star-of-engagement
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-23T11:45:00Z"),
      comments:
        "Chris's commitment to knowledge sharing and engagement has created lasting value for our organization.",
    },
    createdAt: new Date("2024-10-29T10:30:00Z"),
    updatedAt: new Date("2024-11-23T11:45:00Z"),
  },
  {
    id: "nom-q4-2024-005c",
    eventId: "spot-q4-2024",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "olivia-martinez") || mockUsers[14],
    nominator: mockUsers.find((u) => u.id === "michael-chen") || mockUsers[15],
    serviceLine: ["technology"],
    domainManagers: ["alex-morgan", "taylor-johnson"],
    nominationSummary:
      "Olivia launched a wellness and work-life balance initiative that includes flexible work arrangements, mental health resources, and team-building activities. She created a peer support network and organized monthly wellness challenges.\n\nOlivia's wellness program has reduced burnout-related leave by 45%, increased reported work-life satisfaction by 38%, and improved team cohesion scores. The program has become a model for other offices globally.",
    justification:
      "Olivia launched a wellness and work-life balance initiative that includes flexible work arrangements, mental health resources, and team-building activities. She created a peer support network and organized monthly wellness challenges.",
    impact:
      "Olivia's wellness program has reduced burnout-related leave by 45%, increased reported work-life satisfaction by 38%, and improved team cohesion scores. The program has become a model for other offices globally.",
    status: "awarded", // Third winner for star-of-engagement
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-11-24T13:30:00Z"),
      comments:
        "Olivia's focus on holistic employee wellbeing has created a more sustainable and productive work environment.",
    },
    createdAt: new Date("2024-10-30T14:45:00Z"),
    updatedAt: new Date("2024-11-24T13:30:00Z"),
  },
  {
    id: "nom-q4-2024-005d",
    eventId: "spot-q4-2024",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "jamie-taylor") || mockUsers[8],
    nominator: mockUsers.find((u) => u.id === "riley-thompson") || mockUsers[10],
    serviceLine: ["enterprise-solutions"],
    domainManagers: ["casey-smith", "quinn-martinez"],
    nominationSummary:
      "Jamie created a cross-functional innovation lab that brings together diverse perspectives to solve complex client challenges. They facilitated design thinking workshops, created collaboration spaces, and established an ideas marketplace.\n\nJamie's innovation lab has generated 15 new solution concepts, three of which have been developed into client offerings. Participants report significantly higher engagement and cross-team collaboration has increased by 60%.",
    justification:
      "Jamie created a cross-functional innovation lab that brings together diverse perspectives to solve complex client challenges. They facilitated design thinking workshops, created collaboration spaces, and established an ideas marketplace.",
    impact:
      "Jamie's innovation lab has generated 15 new solution concepts, three of which have been developed into client offerings. Participants report significantly higher engagement and cross-team collaboration has increased by 60%.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "casey-smith",
      endorsedAt: new Date("2024-11-25T10:15:00Z"),
      comments: "Jamie's ability to foster collaboration and innovation has created tangible business value.",
    },
    createdAt: new Date("2024-10-31T09:30:00Z"),
    updatedAt: new Date("2024-11-25T10:15:00Z"),
  },
  {
    id: "nom-q4-2024-005e",
    eventId: "spot-q4-2024",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "samantha-lee") || mockUsers[17],
    nominator: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[5],
    serviceLine: ["cloud-services"],
    domainManagers: ["taylor-johnson", "alex-morgan"],
    nominationSummary:
      "Samantha established a community of practice for cloud professionals that includes regular knowledge sharing sessions, certification study groups, and hands-on labs. She personally mentored 20 team members through cloud certifications.\n\nSamantha's community has increased certified cloud professionals by 85%, improved solution quality through shared best practices, and created a supportive learning environment that has been cited in retention interviews.",
    justification:
      "Samantha established a community of practice for cloud professionals that includes regular knowledge sharing sessions, certification study groups, and hands-on labs. She personally mentored 20 team members through cloud certifications.",
    impact:
      "Samantha's community has increased certified cloud professionals by 85%, improved solution quality through shared best practices, and created a supportive learning environment that has been cited in retention interviews.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2024-11-26T14:45:00Z"),
      comments: "Samantha's leadership in building our cloud community has significantly enhanced our capabilities.",
    },
    createdAt: new Date("2024-11-01T11:15:00Z"),
    updatedAt: new Date("2024-11-26T14:45:00Z"),
  },

  // All-Star Team - 4 teams
  {
    id: "nom-q4-2024-004",
    eventId: "spot-q4-2024",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "cloud-optimization-team",
      name: "Cloud Optimization Team",
      members: ["sarah-johnson", "michael-chen", "alex-rodriguez", "jamie-taylor", "chris-patel"],
    },
    nominee: {
      id: "cloud-optimization-team",
      name: "Cloud Optimization Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "COT",
      department: "Cloud Services",
    },
    presenter: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[6],
    serviceLine: ["cloud-services"],
    domainManagers: ["jordan-lee", "alex-morgan"],
    nominationSummary:
      "The Cloud Optimization Team has consistently delivered innovative solutions, resulting in significant cost savings and performance improvements for our clients.\n\nTheir collective efforts have led to a 40% increase in client satisfaction scores and a 25% growth in our cloud services revenue this quarter.",
    justification:
      "The Cloud Optimization Team has consistently delivered innovative solutions, resulting in significant cost savings and performance improvements for our clients.",
    impact:
      "Their collective efforts have led to a 40% increase in client satisfaction scores and a 25% growth in our cloud services revenue this quarter.",
    status: "awarded", // First winner for all-star-team
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-28T11:15:00Z"),
      comments: "This team's synergy and results are outstanding. Wholeheartedly endorse their nomination.",
    },
    createdAt: new Date("2024-11-05T10:30:00Z"),
    updatedAt: new Date("2024-11-28T11:15:00Z"),
  },
  {
    id: "nom-q4-2024-006a",
    eventId: "spot-q4-2024",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "digital-transformation-team",
      name: "Digital Transformation Team",
      members: ["emily-rodriguez", "david-kim", "olivia-martinez", "quinn-martinez", "riley-thompson"],
    },
    nominee: {
      id: "digital-transformation-team",
      name: "Digital Transformation Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DTT",
      department: "Digital Transformation",
    },
    presenter: {
      id: "emily-rodriguez",
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
      department: "Engineering",
    },
    nominator: mockUsers.find((u) => u.id === "alex-morgan") || mockUsers[1],
    serviceLine: ["digital-transformation"],
    domainManagers: ["casey-smith", "taylor-johnson"],
    nominationSummary:
      "The Digital Transformation Team successfully modernized a legacy financial system for a Fortune 500 client, migrating from mainframe to cloud-native architecture while maintaining business continuity and enhancing functionality.\n\nThe team's work reduced operating costs by 65%, increased system performance by 300%, and enabled rapid feature development that was impossible in the legacy environment. The client has since engaged us for three additional transformation projects.",
    justification:
      "The Digital Transformation Team successfully modernized a legacy financial system for a Fortune 500 client, migrating from mainframe to cloud-native architecture while maintaining business continuity and enhancing functionality.",
    impact:
      "The team's work reduced operating costs by 65%, increased system performance by 300%, and enabled rapid feature development that was impossible in the legacy environment. The client has since engaged us for three additional transformation projects.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "casey-smith",
      endorsedAt: new Date("2024-11-23T09:45:00Z"),
      comments:
        "This team exemplifies technical excellence and client focus. Their work has become a case study for successful digital transformation.",
    },
    createdAt: new Date("2024-10-29T14:30:00Z"),
    updatedAt: new Date("2024-11-23T09:45:00Z"),
  },
  {
    id: "nom-q4-2024-006b",
    eventId: "spot-q4-2024",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "customer-experience-team",
      name: "Customer Experience Team",
      members: ["jessica-patel", "chris-patel", "avery-williams", "samantha-lee", "james-wilson"],
    },
    nominee: {
      id: "customer-experience-team",
      name: "Customer Experience Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "CET",
      department: "Customer Experience",
    },
    presenter: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    nominator: mockUsers.find((u) => u.id === "riley-thompson") || mockUsers[10],
    serviceLine: ["customer-experience"],
    domainManagers: ["quinn-martinez", "avery-williams"],
    nominationSummary:
      "The Customer Experience Team redesigned our client onboarding journey, creating a seamless, personalized experience that combines high-touch service with digital self-service options. They conducted extensive user research and iteratively refined the approach based on feedback.\n\nThe team's work has reduced onboarding time from 45 days to 12 days, increased feature adoption by 70% in the first month, and improved new client satisfaction scores from 7.2 to 9.5 out of 10. The approach has been rolled out globally.",
    justification:
      "The Customer Experience Team redesigned our client onboarding journey, creating a seamless, personalized experience that combines high-touch service with digital self-service options. They conducted extensive user research and iteratively refined the approach based on feedback.",
    impact:
      "The team's work has reduced onboarding time from 45 days to 12 days, increased feature adoption by 70% in the first month, and improved new client satisfaction scores from 7.2 to 9.5 out of 10. The approach has been rolled out globally.",
    status: "approved", // Not awarded (quota already filled)
    endorsement: {
      status: "endorsed",
      endorsedBy: "quinn-martinez",
      endorsedAt: new Date("2024-11-25T13:30:00Z"),
      comments:
        "This team's human-centered approach to customer experience has set a new standard for our organization.",
    },
    createdAt: new Date("2024-10-31T11:45:00Z"),
    updatedAt: new Date("2024-11-25T13:30:00Z"),
  },
]

// Combine existing nominations with new Q4 2024 nominations
export const nominations: Nomination[] = [...existingNominations, ...q4_2024_nominations]

// Sample nominations for other events with awarded status
const sampleNominations: Nomination[] = [
  {
    id: "nom1",
    eventId: "event1",
    nomineeId: "user2",
    nominatorId: "user1",
    awardType: "innovation",
    justification:
      "Sarah developed a new process that reduced our project delivery time by 30%. Her innovative approach to problem-solving has transformed how our team works. She consistently thinks outside the box and encourages others to do the same. The impact of her innovation has been felt across multiple departments.",
    nominationSummary:
      "Sarah developed a new process that reduced our project delivery time by 30%. Her innovative approach to problem-solving has transformed how our team works. She consistently thinks outside the box and encourages others to do the same. The impact of her innovation has been felt across multiple departments.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "John Smith",
      endorsedAt: new Date("2024-03-10T14:30:00Z"),
      comments: "Strongly agree with this nomination. Sarah's innovation has been transformative.",
    },
    comments: [
      {
        id: "comment1",
        userId: "user3",
        text: "I've seen firsthand how Sarah's innovation has improved our workflow. Well deserved!",
        timestamp: new Date("2024-03-12T09:15:00Z"),
      },
      {
        id: "comment2",
        userId: "user4",
        text: "Congratulations Sarah! Your creative thinking is an inspiration to us all.",
        timestamp: new Date("2024-03-12T11:45:00Z"),
      },
    ],
    createdAt: new Date("2024-03-05T10:00:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom2",
    eventId: "event1",
    nomineeId: "user3",
    nominatorId: "user4",
    awardType: "teamwork",
    justification:
      "Michael consistently puts the team's success above his own. He volunteered to help three different teams meet their deadlines last quarter, working extra hours and providing valuable insights. His collaborative spirit and willingness to share knowledge has made him an invaluable team member.",
    nominationSummary:
      "Michael consistently puts the team's success above his own. He volunteered to help three different teams meet their deadlines last quarter, working extra hours and providing valuable insights. His collaborative spirit and willingness to share knowledge has made him an invaluable team member.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Emily Johnson",
      endorsedAt: new Date("2024-03-11T16:45:00Z"),
      comments: "Michael exemplifies what teamwork should look like. Fully support this nomination.",
    },
    comments: [
      {
        id: "comment3",
        userId: "user1",
        text: "Michael helped my team tremendously. He deserves this recognition!",
        timestamp: new Date("2024-03-13T10:30:00Z"),
      },
    ],
    createdAt: new Date("2024-03-06T14:20:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom3",
    eventId: "event1",
    nomineeId: "user5",
    nominatorId: "user6",
    awardType: "leadership",
    justification:
      "David stepped up during a critical project phase when our team lead was on medical leave. He organized daily stand-ups, reprioritized tasks, and kept stakeholders informed. His calm demeanor and clear communication prevented what could have been a project failure.",
    nominationSummary:
      "David stepped up during a critical project phase when our team lead was on medical leave. He organized daily stand-ups, reprioritized tasks, and kept stakeholders informed. His calm demeanor and clear communication prevented what could have been a project failure.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Robert Chen",
      endorsedAt: new Date("2024-03-12T11:20:00Z"),
      comments: "David showed exceptional leadership skills. He has my full endorsement.",
    },
    comments: [],
    createdAt: new Date("2024-03-07T09:45:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom4",
    eventId: "event1",
    nomineeId: "user7",
    nominatorId: "user8",
    awardType: "excellence",
    justification:
      "Jennifer consistently delivers work of the highest quality. Her attention to detail and commitment to excellence has raised the bar for our entire department. She recently completed a complex analysis that identified $200K in potential savings, which was praised by senior leadership.",
    nominationSummary:
      "Jennifer consistently delivers work of the highest quality. Her attention to detail and commitment to excellence has raised the bar for our entire department. She recently completed a complex analysis that identified $200K in potential savings, which was praised by senior leadership.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Patricia Wong",
      endorsedAt: new Date("2024-03-13T15:10:00Z"),
      comments: "Jennifer's work is always exceptional. This nomination is well-deserved.",
    },
    comments: [
      {
        id: "comment4",
        userId: "user9",
        text: "Jennifer's analysis was incredibly thorough. I'm using it as a template for my team now.",
        timestamp: new Date("2024-03-14T13:25:00Z"),
      },
    ],
    createdAt: new Date("2024-03-08T11:30:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom5",
    eventId: "event1",
    nomineeId: "user10",
    nominatorId: "user11",
    awardType: "innovation",
    justification:
      "Carlos developed a new automated testing framework that reduced QA time by 40%. His innovative approach has been adopted by multiple teams and has significantly improved our product quality while reducing time-to-market.",
    nominationSummary:
      "Carlos developed a new automated testing framework that reduced QA time by 40%. His innovative approach has been adopted by multiple teams and has significantly improved our product quality while reducing time-to-market.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Michelle Lee",
      endorsedAt: new Date("2024-03-14T10:05:00Z"),
      comments: "Carlos's framework is a game-changer. Strong endorsement from the QA department.",
    },
    comments: [],
    createdAt: new Date("2024-03-09T16:15:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom6",
    eventId: "event2",
    nomineeId: "user12",
    nominatorId: "user13",
    awardType: "teamwork",
    justification:
      "Priya organized cross-functional workshops that broke down silos between engineering and product teams. Her initiative has led to better collaboration, fewer misunderstandings, and more efficient product development cycles.",
    nominationSummary:
      "Priya organized cross-functional workshops that broke down silos between engineering and product teams. Her initiative has led to better collaboration, fewer misunderstandings, and more efficient product development cycles.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Daniel Kim",
      endorsedAt: new Date("2023-12-10T09:30:00Z"),
      comments: "Priya's workshops have made a significant difference in how our teams work together.",
    },
    comments: [],
    createdAt: new Date("2023-12-05T13:45:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom7",
    eventId: "event2",
    nomineeId: "user14",
    nominatorId: "user15",
    awardType: "leadership",
    justification:
      "Thomas led our team through a challenging system migration with minimal disruption to users. His clear vision, detailed planning, and ability to anticipate problems made what could have been a chaotic process into a smooth transition.",
    nominationSummary:
      "Thomas led our team through a challenging system migration with minimal disruption to users. His clear vision, detailed planning, and ability to anticipate problems made what could have been a chaotic process into a smooth transition.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Sarah Johnson",
      endorsedAt: new Date("2023-12-11T14:20:00Z"),
      comments: "Thomas's leadership during the migration was exemplary. Fully endorsed.",
    },
    comments: [],
    createdAt: new Date("2023-12-06T10:10:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom8",
    eventId: "event2",
    nomineeId: "user16",
    nominatorId: "user17",
    awardType: "excellence",
    justification:
      "Aisha consistently delivers projects ahead of schedule and under budget without compromising quality. Her recent work on the customer portal redesign received exceptional feedback from users and has increased customer satisfaction scores by 15%.",
    nominationSummary:
      "Aisha consistently delivers projects ahead of schedule and under budget without compromising quality. Her recent work on the customer portal redesign received exceptional feedback from users and has increased customer satisfaction scores by 15%.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "James Wilson",
      endorsedAt: new Date("2023-12-12T11:05:00Z"),
      comments: "Aisha's work on the portal redesign was outstanding. Strong endorsement.",
    },
    comments: [],
    createdAt: new Date("2023-12-07T15:30:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom9",
    eventId: "event3",
    nomineeId: "user18",
    nominatorId: "user19",
    awardType: "innovation",
    justification:
      "Ryan developed a machine learning algorithm that improved our recommendation engine accuracy by 25%. This innovation has directly contributed to a 10% increase in user engagement and a 5% increase in conversion rates.",
    nominationSummary:
      "Ryan developed a machine learning algorithm that improved our recommendation engine accuracy by 25%. This innovation has directly contributed to a 10% increase in user engagement and a 5% increase in conversion rates.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Lisa Chen",
      endorsedAt: new Date("2023-09-10T13:40:00Z"),
      comments: "Ryan's algorithm has had a measurable impact on our business metrics. Strongly endorsed.",
    },
    comments: [],
    createdAt: new Date("2023-09-05T09:20:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom10",
    eventId: "event3",
    nomineeId: "user20",
    nominatorId: "user1",
    awardType: "teamwork",
    justification:
      "Sophia facilitated collaboration between our US and APAC teams, creating documentation and processes that bridged the time zone gap. Her efforts have resulted in 24-hour productivity and better knowledge sharing across global teams.",
    nominationSummary:
      "Sophia facilitated collaboration between our US and APAC teams, creating documentation and processes that bridged the time zone gap. Her efforts have resulted in 24-hour productivity and better knowledge sharing across global teams.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "John Smith",
      endorsedAt: new Date("2023-09-11T10:15:00Z"),
      comments: "Sophia's work has transformed how our global teams collaborate. Full endorsement.",
    },
    comments: [],
    createdAt: new Date("2023-09-06T14:50:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom11",
    eventId: "event4",
    nomineeId: "user3",
    nominatorId: "user5",
    awardType: "leadership",
    justification:
      "Michael mentored five junior developers over the past quarter, creating personalized development plans and providing regular feedback. All five have shown significant improvement and two have been promoted as a result of his guidance.",
    nominationSummary:
      "Michael mentored five junior developers over the past quarter, creating personalized development plans and providing regular feedback. All five have shown significant improvement and two have been promoted as a result of his guidance.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Robert Chen",
      endorsedAt: new Date("2023-06-10T15:30:00Z"),
      comments: "Michael's mentorship has had a profound impact on our junior developers. Strongly endorsed.",
    },
    comments: [],
    createdAt: new Date("2023-06-05T11:25:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
  {
    id: "nom12",
    eventId: "event4",
    nomineeId: "user7",
    nominatorId: "user9",
    awardType: "excellence",
    justification:
      "Jennifer led a security audit that identified and remediated 12 critical vulnerabilities before they could be exploited. Her thorough approach and attention to detail potentially saved the company from a significant data breach.",
    nominationSummary:
      "Jennifer led a security audit that identified and remediated 12 critical vulnerabilities before they could be exploited. Her thorough approach and attention to detail potentially saved the company from a significant data breach.",
    impact: "",
    status: "awarded", // Updated to awarded based on quota
    endorsement: {
      status: "endorsed",
      endorsedBy: "Patricia Wong",
      endorsedAt: new Date("2023-06-11T09:45:00Z"),
      comments: "Jennifer's security audit was exceptionally thorough. This nomination has my full support.",
    },
    comments: [],
    createdAt: new Date("2023-06-06T13:10:00Z"),
    updatedAt: new Date(),
    votes: [],
    nominationType: "individual",
    domainManagers: [],
    serviceLine: [""],
  },
]

// Combine all nominations
export const allNominations: Nomination[] = [...nominations, ...sampleNominations]

// Helper functions
export function getNominationsByEventId(eventId: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId)
}

export function getNominationById(id: string): Nomination | undefined {
  return nominations.find((nomination) => nomination.id === id)
}

export function getNominationsByAwardType(eventId: string, awardType: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId && nomination.awardType === awardType)
}

export function getNominationsByNominationType(eventId: string, nominationType: "individual" | "team"): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.nominationType === nominationType,
  )
}

// New helper functions for endorsements
export function getEndorsedNominations(eventId: string): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.endorsement?.status === "endorsed",
  )
}

export function getPendingEndorsementNominations(eventId: string): Nomination[] {
  return nominations.filter(
    (nomination) =>
      nomination.eventId === eventId && (!nomination.endorsement || nomination.endorsement.status === "pending"),
  )
}

export function getRejectedEndorsementNominations(eventId: string): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.endorsement?.status === "rejected",
  )
}

// Function to check if a user is a domain manager for a nomination
export function isUserDomainManagerForNomination(userId: string, nomination: Nomination): boolean {
  return nomination.domainManagers.includes(userId)
}

// Function to endorse a nomination
export function endorseNomination(
  nominationId: string,
  userId: string,
  action: "endorse" | "reject",
  comments?: string,
): Nomination | null {
  const nominationIndex = nominations.findIndex((n) => n.id === nominationId)
  if (nominationIndex === -1) return null

  const nomination = nominations[nominationIndex]

  // Check if user is a domain manager for this nomination
  if (!isUserDomainManagerForNomination(userId, nomination)) return null

  // Check if nomination is already endorsed or rejected
  if (nomination.endorsement?.status === "endorsed" || nomination.endorsement?.status === "rejected") {
    return null
  }

  // Update the nomination with endorsement information
  const updatedNomination = {
    ...nomination,
    endorsement: {
      status: action === "endorse" ? "endorsed" : "rejected",
      endorsedBy: userId,
      endorsedAt: new Date(),
      comments: comments || (action === "endorse" ? "Endorsed by domain manager." : "Rejected by domain manager."),
    },
    updatedAt: new Date(),
  }

  // In a real app, this would update the database
  // For this mock, we'll update the array
  nominations[nominationIndex] = updatedNomination

  return updatedNomination
}

// Add functions to handle votes and comments

// Function to add a vote to a nomination
export function addVoteToNomination(nominationId: string, userId: string, userName: string): Nomination | null {
  const nominationIndex = nominations.findIndex((n) => n.id === nominationId)
  if (nominationIndex === -1) return null

  const nomination = nominations[nominationIndex]

  // Check if user has already voted
  if (nomination.votes?.some((vote) => vote.userId === userId)) {
    return nomination // User already voted
  }

  // Initialize votes array if it doesn't exist
  const votes = nomination.votes || []

  // Add the new vote
  const updatedNomination = {
    ...nomination,
    votes: [
      ...votes,
      {
        userId,
        userName,
        timestamp: new Date(),
      },
    ],
    updatedAt: new Date(),
  }

  // In a real app, this would update the database
  // For this mock, we'll update the array
  nominations[nominationIndex] = updatedNomination

  return updatedNomination
}

// Function to add a comment to a nomination
export function addCommentToNomination(
  nominationId: string,
  userId: string,
  userName: string,
  userAvatar: string,
  userInitials: string,
  text: string,
): Nomination | null {
  const nominationIndex = nominations.findIndex((n) => n.id === nominationId)
  if (nominationIndex === -1) return null

  const nomination = nominations[nominationIndex]

  // Initialize comments array if it doesn't exist
  const comments = nomination.comments || []

  // Add the new comment
  const updatedNomination = {
    ...nomination,
    comments: [
      ...comments,
      {
        id: `comment-${Date.now()}-${userId}`,
        userId,
        userName,
        userAvatar,
        userInitials,
        text,
        timestamp: new Date(),
      },
    ],
    updatedAt: new Date(),
  }

  // In a real app, this would update the database
  // For this mock, we'll update the array
  nominations[nominationIndex] = updatedNomination

  return updatedNomination
}

// Add a new helper function to get winning nominations for an event
export function getWinningNominationsForEvent(eventId: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId && nomination.status === "awarded")
}

