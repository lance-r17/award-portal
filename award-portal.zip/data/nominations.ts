import type { Nomination } from "@/types/nominations"
import { mockUsers } from "./mock-users"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "./award-types"

// Existing nominations
const existingNominations: Nomination[] = [
  {
    id: "nom-001",
    eventId: "spot-q1-2025",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: {
      id: "emily-rodriguez",
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
      department: "Engineering",
    },
    nominator: {
      id: "michael-chen",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Product",
    },
    serviceLine: "cloud-services",
    domainManagers: ["alex-morgan", "jordan-lee"],
    justification:
      "Emily has been instrumental in implementing agile methodologies across our team. She established a new sprint planning process that increased our velocity by 30% and reduced planning overhead. Her daily stand-ups are focused and effective, keeping the team aligned and unblocking issues quickly.",
    impact:
      "Thanks to Emily's agile leadership, we delivered our last project two weeks ahead of schedule. The client specifically mentioned how impressed they were with our iterative approach and responsiveness to their feedback.",
    supportingInfo: "https://company.sharepoint.com/sites/agile-transformation/documents/emily-case-study.pdf",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2025-03-10T09:15:00Z"),
      comments: "Emily has consistently demonstrated exceptional agile leadership. Fully endorse this nomination.",
    },
    createdAt: new Date("2025-03-05T10:30:00Z"),
    updatedAt: new Date("2025-03-07T14:15:00Z"),
  },
  {
    id: "nom-002",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: {
      id: "david-kim",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Customer Support",
    },
    nominator: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    serviceLine: "customer-experience",
    domainManagers: ["casey-smith", "avery-williams"],
    justification:
      "David went above and beyond for a customer who was experiencing critical issues with our platform. He stayed on a call for over 4 hours, working through dinner time, to ensure the customer's system was back online. He then followed up the next day to make sure everything was still working properly.",
    impact:
      "The customer was so impressed with David's dedication that they upgraded their subscription to our premium tier. They also mentioned David specifically in their renewal discussion as a key reason for continuing with our service.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "avery-williams",
      endorsedAt: new Date("2025-03-12T14:30:00Z"),
      comments: "David's dedication to customer satisfaction is exemplary. Strong endorsement.",
    },
    createdAt: new Date("2025-03-08T09:45:00Z"),
    updatedAt: new Date("2025-03-10T11:20:00Z"),
  },
  {
    id: "nom-003",
    eventId: "spot-q1-2025",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: {
      id: "james-wilson",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Product",
    },
    serviceLine: "digital-transformation",
    domainManagers: ["alex-morgan"],
    justification:
      "Sarah developed an innovative solution to our data processing bottleneck. She designed and implemented a new caching layer that reduced our API response times by 70%. Her solution was elegant, well-documented, and implemented with minimal disruption to existing systems.",
    impact:
      "The performance improvements from Sarah's innovation have directly impacted our user experience metrics. We've seen a 25% increase in user engagement and a 15% reduction in bounce rates since implementing her solution.",
    supportingInfo: "https://github.com/company/project/pull/1234",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2025-03-15T10:45:00Z"),
      comments: "Sarah's innovation has transformed our platform performance. Enthusiastically endorsed.",
    },
    createdAt: new Date("2025-03-12T14:30:00Z"),
    updatedAt: new Date("2025-03-14T10:45:00Z"),
  },
  {
    id: "nom-004",
    eventId: "spot-q1-2025",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: {
      id: "michael-chen",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Product",
    },
    nominator: {
      id: "olivia-martinez",
      name: "Olivia Martinez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "OM",
      department: "Engineering",
    },
    serviceLine: "enterprise-solutions",
    domainManagers: ["jordan-lee", "taylor-johnson"],
    justification:
      "Michael stepped up as a leader during our recent project crisis when our team lead was unexpectedly out for two weeks. He organized the team, reprioritized tasks, and maintained clear communication with stakeholders. His calm demeanor and decisive action kept the project on track during a challenging time.",
    impact:
      "Thanks to Michael's leadership, we not only met our deadline but delivered all critical features. The client specifically praised our team's professionalism and resilience during the transition.",
    status: "approved",
    endorsement: {
      status: "pending",
      comments: "Awaiting domain manager review.",
    },
    createdAt: new Date("2025-03-15T11:20:00Z"),
    updatedAt: new Date("2025-03-17T09:30:00Z"),
  },
  {
    id: "nom-005",
    eventId: "spot-q1-2025",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    nominator: {
      id: "david-kim",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Customer Support",
    },
    serviceLine: "customer-experience",
    domainManagers: ["avery-williams"],
    justification:
      "Jessica has been a driving force for team morale and engagement. She organized virtual coffee chats, created a team recognition channel, and started a monthly 'lunch and learn' series. Her positive attitude is contagious, and she consistently goes out of her way to make new team members feel welcome.",
    impact:
      "Our team's engagement survey scores have increased by 18% since Jessica implemented these initiatives. We've also seen improved cross-department collaboration and knowledge sharing.",
    status: "approved",
    endorsement: {
      status: "pending",
      comments: "Under review by domain manager.",
    },
    createdAt: new Date("2025-03-18T15:45:00Z"),
    updatedAt: new Date("2025-03-20T13:10:00Z"),
  },
  {
    id: "nom-006",
    eventId: "spot-q1-2025",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "platform-team",
      name: "Platform Engineering Team",
      members: ["sarah-johnson", "michael-chen", "emily-rodriguez", "david-kim", "james-wilson"],
    },
    nominee: {
      id: "platform-team",
      name: "Platform Engineering Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "PT",
      department: "Engineering",
    },
    presenter: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    serviceLine: "digital-transformation",
    domainManagers: ["alex-morgan", "jordan-lee"],
    justification:
      "The Platform Engineering Team worked tirelessly to redesign our core infrastructure to support our growing customer base. They collaborated effectively across multiple time zones, maintained clear documentation, and supported each other through technical challenges. Their work exemplifies true teamwork and technical excellence.",
    impact:
      "The platform improvements have resulted in 99.99% uptime (up from 99.9%), 40% faster deployments, and the ability to handle 3x our previous peak load. These improvements directly support our company's growth targets for the year.",
    supportingInfo: "https://company.confluence.com/platform-redesign-project",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2025-03-25T09:20:00Z"),
      comments:
        "This team has delivered exceptional results. Their collaboration and technical excellence deserve recognition.",
    },
    createdAt: new Date("2025-03-22T10:15:00Z"),
    updatedAt: new Date("2025-03-24T14:30:00Z"),
  },
  {
    id: "nom-007",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: {
      id: "james-wilson",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Product",
    },
    nominator: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    serviceLine: "enterprise-solutions",
    domainManagers: ["taylor-johnson", "quinn-martinez"],
    justification:
      "James has redefined what customer-centric product development looks like. He established a customer feedback loop that directly informs our product roadmap. He personally conducted over 30 customer interviews to understand pain points and needs, then translated those insights into clear product requirements.",
    impact:
      "Features prioritized through James's customer feedback process have seen 3x higher adoption rates than our previous releases. Customer satisfaction scores for the product have increased from 7.2 to 8.9 out of 10.",
    status: "approved",
    endorsement: {
      status: "rejected",
      endorsedBy: "taylor-johnson",
      endorsedAt: new Date("2025-03-28T16:45:00Z"),
      comments:
        "While James has done good work, I believe this nomination would be more appropriate for a future award cycle after the current project is completed.",
    },
    createdAt: new Date("2025-03-25T13:40:00Z"),
    updatedAt: new Date("2025-03-27T11:15:00Z"),
  },
]

// Generate sample nominations for Q4 2024 Spot Awards
const q4_2024_nominations: Nomination[] = [
  {
    id: "nom-q4-2024-001",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "emily-rodriguez") || mockUsers[0],
    nominator: mockUsers.find((u) => u.id === "alex-morgan") || mockUsers[1],
    serviceLine: "technology",
    domainManagers: ["alex-morgan", "samantha-lee"],
    justification:
      "Emily led the successful implementation of agile methodologies across three major projects, resulting in a 25% increase in delivery speed and improved client satisfaction.",
    impact:
      "The agile transformation led by Emily has become a benchmark for other teams, leading to company-wide adoption of these practices.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-11-20T14:30:00Z"),
      comments: "Emily's leadership in agile practices has been transformative. Strongly endorse.",
    },
    createdAt: new Date("2024-10-25T09:15:00Z"),
    updatedAt: new Date("2024-11-20T14:30:00Z"),
  },
  {
    id: "nom-q4-2024-002",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "david-kim") || mockUsers[2],
    nominator: mockUsers.find((u) => u.id === "avery-williams") || mockUsers[3],
    serviceLine: "customer-experience",
    domainManagers: ["avery-williams", "riley-thompson"],
    justification:
      "David went above and beyond in resolving a critical issue for our largest client, working through the weekend to ensure minimal disruption to their operations.",
    impact:
      "David's dedication not only saved the client relationship but also led to a contract renewal worth $2 million.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "avery-williams",
      endorsedAt: new Date("2024-11-22T10:45:00Z"),
      comments: "David's commitment to customer satisfaction is exemplary. Fully endorse this nomination.",
    },
    createdAt: new Date("2024-10-28T11:30:00Z"),
    updatedAt: new Date("2024-11-22T10:45:00Z"),
  },
  {
    id: "nom-q4-2024-003",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: mockUsers.find((u) => u.id === "sarah-johnson") || mockUsers[4],
    nominator: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[5],
    serviceLine: "cloud-services",
    domainManagers: ["jordan-lee", "chris-patel"],
    justification:
      "Sarah developed a novel cloud optimization algorithm that reduced our clients' cloud costs by an average of 30%, while maintaining or improving performance.",
    impact:
      "Sarah's innovation has been implemented for 5 major clients, resulting in a total cost saving of $500,000 per month and strengthening our position as a leader in cloud optimization.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-25T09:20:00Z"),
      comments: "Sarah's innovative solution has set a new standard in cloud optimization. Strongly endorse.",
    },
    createdAt: new Date("2024-11-01T14:45:00Z"),
    updatedAt: new Date("2024-11-25T09:20:00Z"),
  },
  {
    id: "nom-q4-2024-004",
    eventId: "spot-q4-2024",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "cloud-optimization-team",
      name: "Cloud Optimization Team",
      members: ["sarah-johnson", "michael-chen", "alex-rodriguez", "jamie-taylor", "chris-patel"],
    },
    nominee: {
      id: "cloud-optimization-team",
      name: "Cloud Optimization Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "COT",
      department: "Cloud Services",
    },
    nominator: mockUsers.find((u) => u.id === "jordan-lee") || mockUsers[6],
    serviceLine: "cloud-services",
    domainManagers: ["jordan-lee", "alex-morgan"],
    justification:
      "The Cloud Optimization Team has consistently delivered innovative solutions, resulting in significant cost savings and performance improvements for our clients.",
    impact:
      "Their collective efforts have led to a 40% increase in client satisfaction scores and a 25% growth in our cloud services revenue this quarter.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-11-28T11:15:00Z"),
      comments: "This team's synergy and results are outstanding. Wholeheartedly endorse their nomination.",
    },
    createdAt: new Date("2024-11-05T10:30:00Z"),
    updatedAt: new Date("2024-11-28T11:15:00Z"),
  },
]

// Combine existing nominations with new Q4 2024 nominations
export const nominations: Nomination[] = [...existingNominations, ...q4_2024_nominations]

// Helper functions
export function getNominationsByEventId(eventId: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId)
}

export function getNominationById(id: string): Nomination | undefined {
  return nominations.find((nomination) => nomination.id === id)
}

export function getNominationsByAwardType(eventId: string, awardType: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId && nomination.awardType === awardType)
}

export function getNominationsByNominationType(eventId: string, nominationType: "individual" | "team"): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.nominationType === nominationType,
  )
}

// New helper functions for endorsements
export function getEndorsedNominations(eventId: string): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.endorsement?.status === "endorsed",
  )
}

export function getPendingEndorsementNominations(eventId: string): Nomination[] {
  return nominations.filter(
    (nomination) =>
      nomination.eventId === eventId && (!nomination.endorsement || nomination.endorsement.status === "pending"),
  )
}

export function getRejectedEndorsementNominations(eventId: string): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.endorsement?.status === "rejected",
  )
}

// Function to check if a user is a domain manager for a nomination
export function isUserDomainManagerForNomination(userId: string, nomination: Nomination): boolean {
  return nomination.domainManagers.includes(userId)
}

// Function to endorse a nomination
export function endorseNomination(
  nominationId: string,
  userId: string,
  action: "endorse" | "reject",
  comments?: string,
): Nomination | null {
  const nominationIndex = nominations.findIndex((n) => n.id === nominationId)
  if (nominationIndex === -1) return null

  const nomination = nominations[nominationIndex]

  // Check if user is a domain manager for this nomination
  if (!isUserDomainManagerForNomination(userId, nomination)) return null

  // Check if nomination is already endorsed or rejected
  if (nomination.endorsement?.status === "endorsed" || nomination.endorsement?.status === "rejected") {
    return null
  }

  // Update the nomination with endorsement information
  const updatedNomination = {
    ...nomination,
    endorsement: {
      status: action === "endorse" ? "endorsed" : "rejected",
      endorsedBy: userId,
      endorsedAt: new Date(),
      comments: comments || (action === "endorse" ? "Endorsed by domain manager." : "Rejected by domain manager."),
    },
    updatedAt: new Date(),
  }

  // In a real app, this would update the database
  // For this mock, we'll update the array
  nominations[nominationIndex] = updatedNomination

  return updatedNomination
}

// Add a new helper function to get winning nominations for an event
export function getWinningNominationsForEvent(eventId: string): Nomination[] {
  const eventNominations = getNominationsByEventId(eventId)
  const winningNominations: Nomination[] = []

  // For each award type, find the nomination with the highest average score
  const awardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes]
  awardTypes.forEach((awardType) => {
    const nominationsForType = eventNominations.filter((nom) => nom.awardType === awardType.id)
    if (nominationsForType.length > 0) {
      // In a real app, you would calculate the average score from judges' scores
      // For this example, we'll just pick the first nomination as the winner
      winningNominations.push(nominationsForType[0])
    }
  })

  return winningNominations
}

