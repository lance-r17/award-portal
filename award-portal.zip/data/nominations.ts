import type { Nomination } from "@/types/nominations"

// Sample nominations data
export const nominations: Nomination[] = [
  {
    id: "nom-001",
    eventId: "spot-q1-2025",
    awardType: "star-of-agile",
    nominationType: "individual",
    nominee: {
      id: "emily-rodriguez",
      name: "Emily Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "ER",
      department: "Engineering",
    },
    nominator: {
      id: "michael-chen",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Product",
    },
    serviceLine: "cloud-services",
    domainManagers: ["alex-morgan", "jordan-lee"],
    justification:
      "Emily has been instrumental in implementing agile methodologies across our team. She established a new sprint planning process that increased our velocity by 30% and reduced planning overhead. Her daily stand-ups are focused and effective, keeping the team aligned and unblocking issues quickly.",
    impact:
      "Thanks to Emily's agile leadership, we delivered our last project two weeks ahead of schedule. The client specifically mentioned how impressed they were with our iterative approach and responsiveness to their feedback.",
    supportingInfo: "https://company.sharepoint.com/sites/agile-transformation/documents/emily-case-study.pdf",
    status: "approved",
    createdAt: new Date("2025-03-05T10:30:00Z"),
    updatedAt: new Date("2025-03-07T14:15:00Z"),
  },
  {
    id: "nom-002",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: {
      id: "david-kim",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Customer Support",
    },
    nominator: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    serviceLine: "customer-experience",
    domainManagers: ["casey-smith", "avery-williams"],
    justification:
      "David went above and beyond for a customer who was experiencing critical issues with our platform. He stayed on a call for over 4 hours, working through dinner time, to ensure the customer's system was back online. He then followed up the next day to make sure everything was still working properly.",
    impact:
      "The customer was so impressed with David's dedication that they upgraded their subscription to our premium tier. They also mentioned David specifically in their renewal discussion as a key reason for continuing with our service.",
    status: "approved",
    createdAt: new Date("2025-03-08T09:45:00Z"),
    updatedAt: new Date("2025-03-10T11:20:00Z"),
  },
  {
    id: "nom-003",
    eventId: "spot-q1-2025",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nominee: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: {
      id: "james-wilson",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Product",
    },
    serviceLine: "digital-transformation",
    domainManagers: ["alex-morgan"],
    justification:
      "Sarah developed an innovative solution to our data processing bottleneck. She designed and implemented a new caching layer that reduced our API response times by 70%. Her solution was elegant, well-documented, and implemented with minimal disruption to existing systems.",
    impact:
      "The performance improvements from Sarah's innovation have directly impacted our user experience metrics. We've seen a 25% increase in user engagement and a 15% reduction in bounce rates since implementing her solution.",
    supportingInfo: "https://github.com/company/project/pull/1234",
    status: "approved",
    createdAt: new Date("2025-03-12T14:30:00Z"),
    updatedAt: new Date("2025-03-14T10:45:00Z"),
  },
  {
    id: "nom-004",
    eventId: "spot-q1-2025",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nominee: {
      id: "michael-chen",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MC",
      department: "Product",
    },
    nominator: {
      id: "olivia-martinez",
      name: "Olivia Martinez",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "OM",
      department: "Engineering",
    },
    serviceLine: "enterprise-solutions",
    domainManagers: ["jordan-lee", "taylor-johnson"],
    justification:
      "Michael stepped up as a leader during our recent project crisis when our team lead was unexpectedly out for two weeks. He organized the team, reprioritized tasks, and maintained clear communication with stakeholders. His calm demeanor and decisive action kept the project on track during a challenging time.",
    impact:
      "Thanks to Michael's leadership, we not only met our deadline but delivered all critical features. The client specifically praised our team's professionalism and resilience during the transition.",
    status: "approved",
    createdAt: new Date("2025-03-15T11:20:00Z"),
    updatedAt: new Date("2025-03-17T09:30:00Z"),
  },
  {
    id: "nom-005",
    eventId: "spot-q1-2025",
    awardType: "star-of-engagement",
    nominationType: "individual",
    nominee: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    nominator: {
      id: "david-kim",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "DK",
      department: "Customer Support",
    },
    serviceLine: "customer-experience",
    domainManagers: ["avery-williams"],
    justification:
      "Jessica has been a driving force for team morale and engagement. She organized virtual coffee chats, created a team recognition channel, and started a monthly 'lunch and learn' series. Her positive attitude is contagious, and she consistently goes out of her way to make new team members feel welcome.",
    impact:
      "Our team's engagement survey scores have increased by 18% since Jessica implemented these initiatives. We've also seen improved cross-department collaboration and knowledge sharing.",
    status: "approved",
    createdAt: new Date("2025-03-18T15:45:00Z"),
    updatedAt: new Date("2025-03-20T13:10:00Z"),
  },
  {
    id: "nom-006",
    eventId: "spot-q1-2025",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "platform-team",
      name: "Platform Engineering Team",
      members: ["sarah-johnson", "michael-chen", "emily-rodriguez", "david-kim", "james-wilson"],
    },
    nominee: {
      id: "platform-team",
      name: "Platform Engineering Team",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "PT",
      department: "Engineering",
    },
    presenter: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    nominator: {
      id: "jessica-patel",
      name: "Jessica Patel",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JP",
      department: "Sales",
    },
    serviceLine: "digital-transformation",
    domainManagers: ["alex-morgan", "jordan-lee"],
    justification:
      "The Platform Engineering Team worked tirelessly to redesign our core infrastructure to support our growing customer base. They collaborated effectively across multiple time zones, maintained clear documentation, and supported each other through technical challenges. Their work exemplifies true teamwork and technical excellence.",
    impact:
      "The platform improvements have resulted in 99.99% uptime (up from 99.9%), 40% faster deployments, and the ability to handle 3x our previous peak load. These improvements directly support our company's growth targets for the year.",
    supportingInfo: "https://company.confluence.com/platform-redesign-project",
    status: "approved",
    createdAt: new Date("2025-03-22T10:15:00Z"),
    updatedAt: new Date("2025-03-24T14:30:00Z"),
  },
  {
    id: "nom-007",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nominee: {
      id: "james-wilson",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      department: "Product",
    },
    nominator: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      department: "Engineering",
    },
    serviceLine: "enterprise-solutions",
    domainManagers: ["taylor-johnson", "quinn-martinez"],
    justification:
      "James has redefined what customer-centric product development looks like. He established a customer feedback loop that directly informs our product roadmap. He personally conducted over 30 customer interviews to understand pain points and needs, then translated those insights into clear product requirements.",
    impact:
      "Features prioritized through James's customer feedback process have seen 3x higher adoption rates than our previous releases. Customer satisfaction scores for the product have increased from 7.2 to 8.9 out of 10.",
    status: "approved",
    createdAt: new Date("2025-03-25T13:40:00Z"),
    updatedAt: new Date("2025-03-27T11:15:00Z"),
  },
]

// Helper functions
export function getNominationsByEventId(eventId: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId)
}

export function getNominationById(id: string): Nomination | undefined {
  return nominations.find((nomination) => nomination.id === id)
}

export function getNominationsByAwardType(eventId: string, awardType: string): Nomination[] {
  return nominations.filter((nomination) => nomination.eventId === eventId && nomination.awardType === awardType)
}

export function getNominationsByNominationType(eventId: string, nominationType: "individual" | "team"): Nomination[] {
  return nominations.filter(
    (nomination) => nomination.eventId === eventId && nomination.nominationType === nominationType,
  )
}

