import type { AwardType } from "@/types/award-types"

export const teamAwardType: AwardType = {
  id: "all-star-team",
  title: "All-Star Team",
  description: "For teams that demonstrate exceptional collaboration, innovation, and results.",
  icon: "user",
  color: "bg-purple-100 dark:bg-purple-900",
  iconColor: "text-purple-600 dark:text-purple-400",
  criteria: [
    "Demonstrated exceptional teamwork and collaboration",
    "Achieved significant results through collective effort",
    "Overcame challenges through innovative problem-solving",
    "Consistently delivered high-quality work as a unit",
  ],
  reward: "Team celebration event and recognition at company meeting",
  isTeamAward: true, // This is a team award
}

export const spotIndividualAwardTypes = [
  {
    id: "star-of-agile",
    title: "Star of Agile",
    description: "For individuals who exemplify agile principles and drive process improvements.",
    icon: "compass",
    color: "bg-blue-100 dark:bg-blue-900",
    iconColor: "text-blue-600 dark:text-blue-400",
    criteria: [
      "Consistently applies agile methodologies to improve workflows",
      "Facilitates effective sprint planning and retrospectives",
      "Removes obstacles to help the team deliver efficiently",
      "Promotes continuous improvement and adaptation",
    ],
    reward: "$150 gift card and recognition certificate",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "star-of-customer-service",
    title: "Star of Customer Service",
    description: "For individuals who provide exceptional service and support to customers.",
    icon: "headphones",
    color: "bg-green-100 dark:bg-green-900",
    iconColor: "text-green-600 dark:text-green-400",
    criteria: [
      "Consistently exceeds customer expectations",
      "Resolves complex customer issues with patience and empathy",
      "Receives outstanding customer feedback and testimonials",
      "Goes above and beyond to ensure customer satisfaction",
    ],
    reward: "$150 gift card and recognition certificate",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "star-of-engagement",
    title: "Star of Engagement",
    description: "For individuals who foster a positive work environment and team spirit.",
    icon: "heart",
    color: "bg-red-100 dark:bg-red-900",
    iconColor: "text-red-600 dark:text-red-400",
    criteria: [
      "Actively promotes team morale and positive culture",
      "Organizes team-building activities and celebrations",
      "Supports colleagues during challenging times",
      "Contributes to an inclusive and collaborative atmosphere",
    ],
    reward: "$150 gift card and recognition certificate",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "star-of-innovation",
    title: "Star of Innovation",
    description: "For individuals who develop creative solutions and drive innovation.",
    icon: "lightbulb",
    color: "bg-amber-100 dark:bg-amber-900",
    iconColor: "text-amber-600 dark:text-amber-400",
    criteria: [
      "Develops innovative solutions to complex problems",
      "Introduces new ideas that improve processes or products",
      "Thinks outside the box to overcome challenges",
      "Encourages and supports innovation from others",
    ],
    reward: "$150 gift card and recognition certificate",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "star-of-leadership",
    title: "Star of Leadership",
    description: "For individuals who demonstrate exceptional leadership qualities.",
    icon: "sparkles",
    color: "bg-indigo-100 dark:bg-indigo-900",
    iconColor: "text-indigo-600 dark:text-indigo-400",
    criteria: [
      "Inspires and motivates team members to achieve their best",
      "Provides clear direction and guidance during challenging times",
      "Takes ownership of problems and leads by example",
      "Develops and mentors others effectively",
    ],
    reward: "$150 gift card and recognition certificate",
    isTeamAward: false, // This is an individual award
  },
]

export const spotTeamAwardTypes = [teamAwardType]

export const recognitionAwardTypes = [
  {
    id: "excellence",
    title: "Excellence Award",
    description: "For consistently delivering exceptional results and maintaining high standards.",
    icon: "award",
    color: "bg-yellow-100 dark:bg-yellow-900",
    iconColor: "text-yellow-600 dark:text-yellow-400",
    criteria: [
      "Consistently exceeds performance expectations",
      "Delivers high-quality work that sets standards for others",
      "Demonstrates mastery in their field of expertise",
      "Achieves significant results that impact the business",
    ],
    reward: "$500 bonus and recognition at quarterly town hall",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "leadership",
    title: "Leadership Award",
    description: "For exemplary leadership that inspires and motivates others to achieve their best.",
    icon: "users",
    color: "bg-blue-100 dark:bg-blue-900",
    iconColor: "text-blue-600 dark:text-blue-400",
    criteria: [
      "Inspires and motivates team members to achieve their best",
      "Provides clear direction and guidance during challenging times",
      "Develops team members' skills and supports their growth",
      "Creates an inclusive environment where everyone can contribute",
    ],
    reward: "$750 bonus and leadership development opportunity",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "innovation",
    title: "Innovation Award",
    description: "For developing creative solutions that drive significant improvements or new opportunities.",
    icon: "lightbulb",
    color: "bg-purple-100 dark:bg-purple-900",
    iconColor: "text-purple-600 dark:text-purple-400",
    criteria: [
      "Develops innovative solutions to complex problems",
      "Creates new processes or products that benefit the company",
      "Challenges conventional thinking and explores new approaches",
      "Implements changes that result in significant improvements",
    ],
    reward: "$750 bonus and innovation workshop participation",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "values-champion",
    title: "Values Champion",
    description: "For consistently demonstrating and promoting company values in all actions.",
    icon: "heart",
    color: "bg-red-100 dark:bg-red-900",
    iconColor: "text-red-600 dark:text-red-400",
    criteria: [
      "Consistently demonstrates company values in daily actions",
      "Serves as a role model for others in upholding company culture",
      "Makes decisions that reflect company values, even when difficult",
      "Promotes and reinforces values among team members",
    ],
    reward: "$500 bonus and feature in company newsletter",
    isTeamAward: false, // This is an individual award
  },
  {
    id: "impact",
    title: "Impact Award",
    description: "For contributions that have a significant positive impact on business results.",
    icon: "sparkles",
    color: "bg-green-100 dark:bg-green-900",
    iconColor: "text-green-600 dark:text-green-400",
    criteria: [
      "Delivers work that significantly impacts business results",
      "Implements changes that lead to measurable improvements",
      "Contributes to achieving important company objectives",
      "Creates value that extends beyond their immediate responsibilities",
    ],
    reward: "$1,000 bonus and recognition at annual company event",
    isTeamAward: false, // This is an individual award
  },
]

export const allAwardTypes = [...spotIndividualAwardTypes, ...spotTeamAwardTypes, ...recognitionAwardTypes]

export const getAwardTypeDisplay = (awardType: string) => {
  const awardTypes: Record<string, string> = {
    "star-of-agile": "Star of Agile",
    "star-of-customer-service": "Star of Customer Service",
    "star-of-engagement": "Star of Engagement",
    "star-of-innovation": "Star of Innovation",
    "star-of-leadership": "Star of Leadership",
    "all-star-team": "All-Star Team",
    excellence: "Excellence Award",
    leadership: "Leadership Award",
    innovation: "Innovation Award",
    "values-champion": "Values Champion",
    impact: "Impact Award",
  }
  return awardTypes[awardType] || awardType
}

