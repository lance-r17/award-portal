import type { Nomination } from "@/types/nominations"
import { mockUsers } from "./mock-users"
import { nominations } from "./nominations"
import { getQuotaForAwardType } from "@/data/award-quotas"

export interface Score {
  nominationId: string
  judgeId: string
  criteria: {
    [key: string]: number
  }
  averageScore: number
  comments: string
}

// Replace the q4_2024_scores array with this expanded version
const q4_2024_scores: Score[] = [
  // Star of Agile scores
  {
    nominationId: "nom-q4-2024-001",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.5,
      innovation: 4.0,
      execution: 4.5,
    },
    averageScore: 4.33,
    comments: "Emily's agile leadership has had a significant positive impact on our delivery capabilities.",
  },
  {
    nominationId: "nom-q4-2024-001",
    judgeId: "jordan-lee",
    criteria: {
      impact: 4.0,
      innovation: 4.5,
      execution: 4.5,
    },
    averageScore: 4.33,
    comments: "The agile transformation led by Emily is impressive and has far-reaching benefits.",
  },
  {
    nominationId: "nom-q4-2024-001",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.5,
      innovation: 4.0,
      execution: 4.0,
    },
    averageScore: 4.17,
    comments: "Emily's work has set a new standard for agile implementation across the company.",
  },
  {
    nominationId: "nom-q4-2024-001a",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.8,
      innovation: 4.2,
      execution: 4.7,
    },
    averageScore: 4.57,
    comments: "Jordan's sprint planning approach has transformed team productivity.",
  },
  {
    nominationId: "nom-q4-2024-001a",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.9,
      innovation: 4.5,
      execution: 4.8,
    },
    averageScore: 4.73,
    comments: "Jordan's agile leadership is exceptional and has created measurable business impact.",
  },
  {
    nominationId: "nom-q4-2024-001a",
    judgeId: "taylor-johnson",
    criteria: {
      impact: 4.7,
      innovation: 4.3,
      execution: 4.6,
    },
    averageScore: 4.53,
    comments: "The consistency and quality of Jordan's agile implementation is outstanding.",
  },
  {
    nominationId: "nom-q4-2024-001b",
    judgeId: "jordan-lee",
    criteria: {
      impact: 4.6,
      innovation: 4.8,
      execution: 4.4,
    },
    averageScore: 4.6,
    comments: "Jamie's innovative agile framework for cloud migrations is groundbreaking.",
  },
  {
    nominationId: "nom-q4-2024-001b",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.5,
      innovation: 4.7,
      execution: 4.3,
    },
    averageScore: 4.5,
    comments: "The adaptability of Jamie's approach to different cloud scenarios is impressive.",
  },
  {
    nominationId: "nom-q4-2024-001b",
    judgeId: "quinn-martinez",
    criteria: {
      impact: 4.4,
      innovation: 4.9,
      execution: 4.2,
    },
    averageScore: 4.5,
    comments: "Jamie's framework represents true innovation in applying agile to specialized contexts.",
  },
  {
    nominationId: "nom-q4-2024-001c",
    judgeId: "taylor-johnson",
    criteria: {
      impact: 4.7,
      innovation: 4.3,
      execution: 4.5,
    },
    averageScore: 4.5,
    comments: "Riley's hybrid approach for enterprise clients is exactly what the industry needs.",
  },
  {
    nominationId: "nom-q4-2024-001c",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.6,
      innovation: 4.2,
      execution: 4.4,
    },
    averageScore: 4.4,
    comments: "The client satisfaction improvements from Riley's approach are substantial.",
  },
  {
    nominationId: "nom-q4-2024-001c",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.5,
      innovation: 4.1,
      execution: 4.3,
    },
    averageScore: 4.3,
    comments: "Riley has found an effective balance between agile principles and enterprise requirements.",
  },
  {
    nominationId: "nom-q4-2024-001d",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.4,
      innovation: 4.7,
      execution: 4.3,
    },
    averageScore: 4.47,
    comments: "Avery's application of agile to UX processes is innovative and effective.",
  },
  {
    nominationId: "nom-q4-2024-001d",
    judgeId: "quinn-martinez",
    criteria: {
      impact: 4.5,
      innovation: 4.8,
      execution: 4.4,
    },
    averageScore: 4.57,
    comments: "The user satisfaction metrics from Avery's approach speak for themselves.",
  },
  {
    nominationId: "nom-q4-2024-001d",
    judgeId: "riley-thompson",
    criteria: {
      impact: 4.3,
      innovation: 4.6,
      execution: 4.2,
    },
    averageScore: 4.37,
    comments: "Avery has successfully adapted agile principles to the unique needs of UX work.",
  },

  // Star of Customer Service scores
  {
    nominationId: "nom-q4-2024-002",
    judgeId: "jamie-taylor",
    criteria: {
      customerFocus: 5.0,
      problemSolving: 4.5,
      goingAboveAndBeyond: 4.5,
    },
    averageScore: 4.67,
    comments: "David's dedication to customer satisfaction is truly exemplary.",
  },
  {
    nominationId: "nom-q4-2024-002",
    judgeId: "avery-williams",
    criteria: {
      customerFocus: 4.5,
      problemSolving: 4.5,
      goingAboveAndBeyond: 5.0,
    },
    averageScore: 4.67,
    comments: "David's efforts not only solved the immediate issue but strengthened the client relationship.",
  },
  {
    nominationId: "nom-q4-2024-002",
    judgeId: "jordan-lee",
    criteria: {
      customerFocus: 4.5,
      problemSolving: 4.0,
      goingAboveAndBeyond: 4.5,
    },
    averageScore: 4.33,
    comments: "David's commitment to customer service is commendable and aligns perfectly with our values.",
  },
  {
    nominationId: "nom-q4-2024-002a",
    judgeId: "taylor-johnson",
    criteria: {
      customerFocus: 4.8,
      problemSolving: 4.6,
      goingAboveAndBeyond: 4.7,
    },
    averageScore: 4.7,
    comments: "Olivia's proactive approach to customer success is transformative.",
  },
  {
    nominationId: "nom-q4-2024-002a",
    judgeId: "casey-smith",
    criteria: {
      customerFocus: 4.9,
      problemSolving: 4.5,
      goingAboveAndBeyond: 4.8,
    },
    averageScore: 4.73,
    comments: "The NPS improvement from Olivia's program demonstrates real business impact.",
  },
  {
    nominationId: "nom-q4-2024-002a",
    judgeId: "michael-chen",
    criteria: {
      customerFocus: 4.7,
      problemSolving: 4.4,
      goingAboveAndBeyond: 4.6,
    },
    averageScore: 4.57,
    comments: "Olivia's ability to identify at-risk accounts before issues arise is remarkable.",
  },
  {
    nominationId: "nom-q4-2024-002b",
    judgeId: "jordan-lee",
    criteria: {
      customerFocus: 4.7,
      problemSolving: 4.5,
      goingAboveAndBeyond: 4.6,
    },
    averageScore: 4.6,
    comments: "Alex's onboarding improvements have significantly enhanced the client experience.",
  },
  {
    nominationId: "nom-q4-2024-002b",
    judgeId: "quinn-martinez",
    criteria: {
      customerFocus: 4.8,
      problemSolving: 4.4,
      goingAboveAndBeyond: 4.5,
    },
    averageScore: 4.57,
    comments: "The reduction in time-to-value is a game-changer for our cloud services clients.",
  },
  {
    nominationId: "nom-q4-2024-002b",
    judgeId: "jamie-taylor",
    criteria: {
      customerFocus: 4.6,
      problemSolving: 4.3,
      goingAboveAndBeyond: 4.7,
    },
    averageScore: 4.53,
    comments:
      "Alex's personal guidance of enterprise clients through the onboarding process demonstrates exceptional commitment.",
  },
  {
    nominationId: "nom-q4-2024-002c",
    judgeId: "alex-morgan",
    criteria: {
      customerFocus: 4.9,
      problemSolving: 4.7,
      goingAboveAndBeyond: 4.8,
    },
    averageScore: 4.8,
    comments: "Samantha's 24/7 support model has transformed our service reputation.",
  },
  {
    nominationId: "nom-q4-2024-002c",
    judgeId: "casey-smith",
    criteria: {
      customerFocus: 4.8,
      problemSolving: 4.6,
      goingAboveAndBeyond: 4.9,
    },
    averageScore: 4.77,
    comments: "Taking personal on-call rotations demonstrates Samantha's exceptional commitment to customer service.",
  },
  {
    nominationId: "nom-q4-2024-002c",
    judgeId: "riley-thompson",
    criteria: {
      customerFocus: 4.7,
      problemSolving: 4.5,
      goingAboveAndBeyond: 4.8,
    },
    averageScore: 4.67,
    comments:
      "The dramatic improvement in response and resolution times speaks to the effectiveness of Samantha's approach.",
  },
  {
    nominationId: "nom-q4-2024-002d",
    judgeId: "quinn-martinez",
    criteria: {
      customerFocus: 4.6,
      problemSolving: 4.8,
      goingAboveAndBeyond: 4.5,
    },
    averageScore: 4.63,
    comments: "Chris's customer feedback framework has transformed how we prioritize product development.",
  },
  {
    nominationId: "nom-q4-2024-002d",
    judgeId: "avery-williams",
    criteria: {
      customerFocus: 4.7,
      problemSolving: 4.9,
      goingAboveAndBeyond: 4.6,
    },
    averageScore: 4.73,
    comments: "The depth of customer interviews conducted by Chris demonstrates exceptional commitment.",
  },
  {
    nominationId: "nom-q4-2024-002d",
    judgeId: "riley-thompson",
    criteria: {
      customerFocus: 4.5,
      problemSolving: 4.7,
      goingAboveAndBeyond: 4.4,
    },
    averageScore: 4.53,
    comments: "Chris has created a systematic approach to turning customer feedback into actionable insights.",
  },

  // Star of Innovation scores
  {
    nominationId: "nom-q4-2024-003",
    judgeId: "alex-morgan",
    criteria: {
      innovation: 5.0,
      impact: 4.5,
      technicalExcellence: 4.5,
    },
    averageScore: 4.67,
    comments: "Sarah's cloud optimization algorithm is a game-changer for our clients.",
  },
  {
    nominationId: "nom-q4-2024-003",
    judgeId: "quinn-martinez",
    criteria: {
      innovation: 4.5,
      impact: 5.0,
      technicalExcellence: 4.5,
    },
    averageScore: 4.67,
    comments: "The cost savings and performance improvements from Sarah's work are truly impressive.",
  },
  {
    nominationId: "nom-q4-2024-003",
    judgeId: "taylor-johnson",
    criteria: {
      innovation: 4.5,
      impact: 4.5,
      technicalExcellence: 4.5,
    },
    averageScore: 4.5,
    comments: "Sarah's innovation demonstrates both technical excellence and business acumen.",
  },
  {
    nominationId: "nom-q4-2024-003a",
    judgeId: "alex-morgan",
    criteria: {
      innovation: 4.8,
      impact: 4.9,
      technicalExcellence: 4.7,
    },
    averageScore: 4.8,
    comments: "Michael's predictive maintenance system is revolutionary for system reliability.",
  },
  {
    nominationId: "nom-q4-2024-003a",
    judgeId: "samantha-lee",
    criteria: {
      innovation: 4.9,
      impact: 4.8,
      technicalExcellence: 4.8,
    },
    averageScore: 4.83,
    comments: "The application of machine learning to predict system failures is both innovative and highly impactful.",
  },
  {
    nominationId: "nom-q4-2024-003a",
    judgeId: "emily-rodriguez",
    criteria: {
      innovation: 4.7,
      impact: 4.7,
      technicalExcellence: 4.6,
    },
    averageScore: 4.67,
    comments: "Michael's solution represents a perfect blend of cutting-edge technology and practical business value.",
  },
  {
    nominationId: "nom-q4-2024-003b",
    judgeId: "taylor-johnson",
    criteria: {
      innovation: 4.7,
      impact: 4.6,
      technicalExcellence: 4.8,
    },
    averageScore: 4.7,
    comments: "James's API security framework addresses a critical industry challenge in an innovative way.",
  },
  {
    nominationId: "nom-q4-2024-003b",
    judgeId: "jordan-lee",
    criteria: {
      innovation: 4.8,
      impact: 4.5,
      technicalExcellence: 4.9,
    },
    averageScore: 4.73,
    comments: "The technical sophistication of James's solution while maintaining performance is remarkable.",
  },
  {
    nominationId: "nom-q4-2024-003b",
    judgeId: "sarah-johnson",
    criteria: {
      innovation: 4.6,
      impact: 4.4,
      technicalExcellence: 4.7,
    },
    averageScore: 4.57,
    comments:
      "James has created a solution that significantly enhances security without the usual performance tradeoffs.",
  },
  {
    nominationId: "nom-q4-2024-003c",
    judgeId: "quinn-martinez",
    criteria: {
      innovation: 4.9,
      impact: 4.7,
      technicalExcellence: 4.8,
    },
    averageScore: 4.8,
    comments: "Jessica's AI-powered customer intent prediction system is truly innovative.",
  },
  {
    nominationId: "nom-q4-2024-003c",
    judgeId: "avery-williams",
    criteria: {
      innovation: 4.8,
      impact: 4.6,
      technicalExcellence: 4.7,
    },
    averageScore: 4.7,
    comments:
      "The real-time personalization capabilities of Jessica's system represent a significant competitive advantage.",
  },
  {
    nominationId: "nom-q4-2024-003c",
    judgeId: "david-kim",
    criteria: {
      innovation: 4.7,
      impact: 4.5,
      technicalExcellence: 4.6,
    },
    averageScore: 4.6,
    comments: "Jessica's solution demonstrates how AI can be applied to create tangible business value.",
  },
  {
    nominationId: "nom-q4-2024-003d",
    judgeId: "casey-smith",
    criteria: {
      innovation: 4.6,
      impact: 4.8,
      technicalExcellence: 4.7,
    },
    averageScore: 4.7,
    comments: "Taylor's blockchain solution for supply chain transparency addresses a significant industry challenge.",
  },
  {
    nominationId: "nom-q4-2024-003d",
    judgeId: "jordan-lee",
    criteria: {
      innovation: 4.5,
      impact: 4.9,
      technicalExcellence: 4.6,
    },
    averageScore: 4.67,
    comments: "The revenue generation from Taylor's solution demonstrates its market value.",
  },
  {
    nominationId: "nom-q4-2024-003d",
    judgeId: "riley-thompson",
    criteria: {
      innovation: 4.4,
      impact: 4.7,
      technicalExcellence: 4.5,
    },
    averageScore: 4.53,
    comments:
      "Taylor has successfully applied blockchain technology to solve real business problems in regulated industries.",
  },

  // Star of Leadership scores
  {
    nominationId: "nom-q4-2024-004a",
    judgeId: "casey-smith",
    criteria: {
      vision: 4.8,
      execution: 4.9,
      teamDevelopment: 4.7,
    },
    averageScore: 4.8,
    comments: "Alex's leadership during the platform migration demonstrated exceptional planning and execution.",
  },
  {
    nominationId: "nom-q4-2024-004a",
    judgeId: "taylor-johnson",
    criteria: {
      vision: 4.7,
      execution: 4.8,
      teamDevelopment: 4.6,
    },
    averageScore: 4.7,
    comments: "The risk mitigation strategy developed by Alex was comprehensive and effective.",
  },
  {
    nominationId: "nom-q4-2024-004a",
    judgeId: "emily-rodriguez",
    criteria: {
      vision: 4.6,
      execution: 4.7,
      teamDevelopment: 4.5,
    },
    averageScore: 4.6,
    comments: "Alex's calm leadership during a complex transition kept the team focused and productive.",
  },
  {
    nominationId: "nom-q4-2024-004b",
    judgeId: "taylor-johnson",
    criteria: {
      vision: 4.9,
      execution: 4.8,
      teamDevelopment: 4.7,
    },
    averageScore: 4.8,
    comments: "Casey's ability to rebuild trust with a challenging client is remarkable.",
  },
  {
    nominationId: "nom-q4-2024-004b",
    judgeId: "quinn-martinez",
    criteria: {
      vision: 4.8,
      execution: 4.7,
      teamDevelopment: 4.6,
    },
    averageScore: 4.7,
    comments:
      "The transformation of the client relationship under Casey's leadership has created significant business value.",
  },
  {
    nominationId: "nom-q4-2024-004b",
    judgeId: "jordan-lee",
    criteria: {
      vision: 4.7,
      execution: 4.6,
      teamDevelopment: 4.5,
    },
    averageScore: 4.6,
    comments: "Casey's transparent communication approach has become a model for client relationship management.",
  },
  {
    nominationId: "nom-q4-2024-004c",
    judgeId: "riley-thompson",
    criteria: {
      vision: 4.8,
      execution: 4.7,
      teamDevelopment: 4.9,
    },
    averageScore: 4.8,
    comments: "Quinn's leadership in diversity and inclusion has created lasting positive change.",
  },
  {
    nominationId: "nom-q4-2024-004c",
    judgeId: "jordan-lee",
    criteria: {
      vision: 4.7,
      execution: 4.6,
      teamDevelopment: 4.8,
    },
    averageScore: 4.7,
    comments: "The comprehensive approach Quinn took to building a more inclusive organization is exemplary.",
  },
  {
    nominationId: "nom-q4-2024-004c",
    judgeId: "avery-williams",
    criteria: {
      vision: 4.6,
      execution: 4.5,
      teamDevelopment: 4.7,
    },
    averageScore: 4.6,
    comments:
      "Quinn's ability to secure executive sponsorship and build a sustainable program demonstrates true leadership.",
  },
  {
    nominationId: "nom-q4-2024-004d",
    judgeId: "alex-morgan",
    criteria: {
      vision: 4.9,
      execution: 4.8,
      teamDevelopment: 4.7,
    },
    averageScore: 4.8,
    comments: "Riley's leadership during our strategic pivot was exceptional in both vision and execution.",
  },
  {
    nominationId: "nom-q4-2024-004d",
    judgeId: "casey-smith",
    criteria: {
      vision: 4.8,
      execution: 4.7,
      teamDevelopment: 4.6,
    },
    averageScore: 4.7,
    comments: "The collaborative planning approach Riley used ensured buy-in across the organization.",
  },
  {
    nominationId: "nom-q4-2024-004d",
    judgeId: "chris-patel",
    criteria: {
      vision: 4.7,
      execution: 4.6,
      teamDevelopment: 4.5,
    },
    averageScore: 4.6,
    comments: "Riley's personal coaching of team leaders through the change process was critical to our success.",
  },
  {
    nominationId: "nom-q4-2024-004e",
    judgeId: "taylor-johnson",
    criteria: {
      vision: 4.8,
      execution: 4.7,
      teamDevelopment: 4.9,
    },
    averageScore: 4.8,
    comments: "Jordan's cloud center of excellence has established new standards for our organization.",
  },
  {
    nominationId: "nom-q4-2024-004e",
    judgeId: "quinn-martinez",
    criteria: {
      vision: 4.7,
      execution: 4.6,
      teamDevelopment: 4.8,
    },
    averageScore: 4.7,
    comments: "The governance frameworks and training programs Jordan established have created lasting value.",
  },
  {
    nominationId: "nom-q4-2024-004e",
    judgeId: "sarah-johnson",
    criteria: {
      vision: 4.6,
      execution: 4.5,
      teamDevelopment: 4.7,
    },
    averageScore: 4.6,
    comments: "Jordan's leadership has accelerated our cloud adoption while maintaining security and efficiency.",
  },

  // Star of Engagement scores
  {
    nominationId: "nom-q4-2024-005a",
    judgeId: "avery-williams",
    criteria: {
      impact: 4.9,
      innovation: 4.8,
      sustainability: 4.7,
    },
    averageScore: 4.8,
    comments: "Jessica's engagement initiatives have transformed our company culture.",
  },
  {
    nominationId: "nom-q4-2024-005a",
    judgeId: "riley-thompson",
    criteria: {
      impact: 4.8,
      innovation: 4.7,
      sustainability: 4.6,
    },
    averageScore: 4.7,
    comments: "The measurable improvements in engagement scores demonstrate the effectiveness of Jessica's approach.",
  },
  {
    nominationId: "nom-q4-2024-005a",
    judgeId: "david-kim",
    criteria: {
      impact: 4.7,
      innovation: 4.6,
      sustainability: 4.5,
    },
    averageScore: 4.6,
    comments: "Jessica's personal facilitation of connection events demonstrates her commitment to building community.",
  },
  {
    nominationId: "nom-q4-2024-005b",
    judgeId: "jordan-lee",
    criteria: {
      impact: 4.8,
      innovation: 4.9,
      sustainability: 4.7,
    },
    averageScore: 4.8,
    comments: "Chris's knowledge-sharing platform has created a vibrant learning culture.",
  },
  {
    nominationId: "nom-q4-2024-005b",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.7,
      innovation: 4.8,
      sustainability: 4.6,
    },
    averageScore: 4.7,
    comments: "The learning festivals organized by Chris have become a highlight of our organizational calendar.",
  },
  {
    nominationId: "nom-q4-2024-005b",
    judgeId: "quinn-martinez",
    criteria: {
      impact: 4.6,
      innovation: 4.7,
      sustainability: 4.5,
    },
    averageScore: 4.6,
    comments: "Chris's personal mentorship of junior team members demonstrates their commitment to developing others.",
  },
  {
    nominationId: "nom-q4-2024-005c",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.9,
      innovation: 4.7,
      sustainability: 4.8,
    },
    averageScore: 4.8,
    comments: "Olivia's wellness initiative has created a more sustainable and productive work environment.",
  },
  {
    nominationId: "nom-q4-2024-005c",
    judgeId: "taylor-johnson",
    criteria: {
      impact: 4.8,
      innovation: 4.6,
      sustainability: 4.7,
    },
    averageScore: 4.7,
    comments: "The reduction in burnout-related leave demonstrates the tangible impact of Olivia's program.",
  },
  {
    nominationId: "nom-q4-2024-005c",
    judgeId: "michael-chen",
    criteria: {
      impact: 4.7,
      innovation: 4.5,
      sustainability: 4.6,
    },
    averageScore: 4.6,
    comments: "Olivia's holistic approach to employee wellbeing addresses both personal and professional needs.",
  },
  {
    nominationId: "nom-q4-2024-005d",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.7,
      innovation: 4.9,
      sustainability: 4.6,
    },
    averageScore: 4.73,
    comments: "Jamie's innovation lab has fostered collaboration and creativity across the organization.",
  },
  {
    nominationId: "nom-q4-2024-005d",
    judgeId: "quinn-martinez",
    criteria: {
      impact: 4.6,
      innovation: 4.8,
      sustainability: 4.5,
    },
    averageScore: 4.63,
    comments: "The ideas marketplace created by Jamie has democratized innovation within our company.",
  },
  {
    nominationId: "nom-q4-2024-005d",
    judgeId: "riley-thompson",
    criteria: {
      impact: 4.5,
      innovation: 4.7,
      sustainability: 4.4,
    },
    averageScore: 4.53,
    comments: "Jamie's design thinking workshops have equipped teams with new problem-solving approaches.",
  },
  {
    nominationId: "nom-q4-2024-005e",
    judgeId: "taylor-johnson",
    criteria: {
      impact: 4.8,
      innovation: 4.6,
      sustainability: 4.9,
    },
    averageScore: 4.77,
    comments: "Samantha's cloud community of practice has significantly enhanced our technical capabilities.",
  },
  {
    nominationId: "nom-q4-2024-005e",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.7,
      innovation: 4.5,
      sustainability: 4.8,
    },
    averageScore: 4.67,
    comments: "The certification study groups organized by Samantha have created measurable skill improvements.",
  },
  {
    nominationId: "nom-q4-2024-005e",
    judgeId: "jordan-lee",
    criteria: {
      impact: 4.6,
      innovation: 4.4,
      sustainability: 4.7,
    },
    averageScore: 4.57,
    comments:
      "Samantha's personal mentorship of 20 team members demonstrates exceptional commitment to others' growth.",
  },

  // All-Star Team scores
  {
    nominationId: "nom-q4-2024-004",
    judgeId: "alex-morgan",
    criteria: {
      teamwork: 4.5,
      impact: 5.0,
      innovation: 4.5,
    },
    averageScore: 4.67,
    comments: "The Cloud Optimization Team's collaborative efforts have yielded outstanding results.",
  },
  {
    nominationId: "nom-q4-2024-004",
    judgeId: "jamie-taylor",
    criteria: {
      teamwork: 5.0,
      impact: 4.5,
      innovation: 4.5,
    },
    averageScore: 4.67,
    comments: "This team's synergy and ability to deliver innovative solutions is exemplary.",
  },
  {
    nominationId: "nom-q4-2024-004",
    judgeId: "riley-thompson",
    criteria: {
      teamwork: 4.5,
      impact: 4.5,
      innovation: 5.0,
    },
    averageScore: 4.67,
    comments: "The Cloud Optimization Team has set a new benchmark for collaborative innovation.",
  },
  {
    nominationId: "nom-q4-2024-006a",
    judgeId: "casey-smith",
    criteria: {
      teamwork: 4.9,
      impact: 4.8,
      innovation: 4.7,
    },
    averageScore: 4.8,
    comments: "The Digital Transformation Team's work on the legacy financial system modernization is exceptional.",
  },
  {
    nominationId: "nom-q4-2024-006a",
    judgeId: "taylor-johnson",
    criteria: {
      teamwork: 4.8,
      impact: 4.7,
      innovation: 4.6,
    },
    averageScore: 4.7,
    comments:
      "This team's ability to maintain business continuity during a complex migration demonstrates exceptional skill.",
  },
  {
    nominationId: "nom-q4-2024-006a",
    judgeId: "alex-morgan",
    criteria: {
      teamwork: 4.7,
      impact: 4.6,
      innovation: 4.5,
    },
    averageScore: 4.6,
    comments: "The cost reduction and performance improvements achieved by this team are remarkable.",
  },
  {
    nominationId: "nom-q4-2024-006b",
    judgeId: "quinn-martinez",
    criteria: {
      teamwork: 4.8,
      impact: 4.9,
      innovation: 4.7,
    },
    averageScore: 4.8,
    comments: "The Customer Experience Team's redesign of our client onboarding journey is transformative.",
  },
  {
    nominationId: "nom-q4-2024-006b",
    judgeId: "avery-williams",
    criteria: {
      teamwork: 4.7,
      impact: 4.8,
      innovation: 4.6,
    },
    averageScore: 4.7,
    comments: "This team's human-centered approach to customer experience has set a new standard.",
  },
  {
    nominationId: "nom-q4-2024-006b",
    judgeId: "riley-thompson",
    criteria: {
      teamwork: 4.6,
      impact: 4.7,
      innovation: 4.5,
    },
    averageScore: 4.6,
    comments: "The dramatic improvement in onboarding time and satisfaction scores demonstrates this team's impact.",
  },
  {
    nominationId: "nom-q4-2024-006c",
    judgeId: "alex-morgan",
    criteria: {
      teamwork: 4.9,
      impact: 4.8,
      innovation: 4.7,
    },
    averageScore: 4.8,
    comments:
      "The Security Excellence Team's comprehensive transformation program has significantly enhanced our risk posture.",
  },
  {
    nominationId: "nom-q4-2024-006c",
    judgeId: "taylor-johnson",
    criteria: {
      teamwork: 4.8,
      impact: 4.7,
      innovation: 4.6,
    },
    averageScore: 4.7,
    comments: "This team's zero-trust architecture implementation is both innovative and effective.",
  },
  {
    nominationId: "nom-q4-2024-006c",
    judgeId: "casey-smith",
    criteria: {
      teamwork: 4.7,
      impact: 4.6,
      innovation: 4.5,
    },
    averageScore: 4.6,
    comments: "The security-first culture created by this team has become a competitive differentiator.",
  },
]

// Combine with any existing scores
export const scores: Score[] = [
  // ... (keep any existing scores)
  ...q4_2024_scores,
]

// Helper function to get scores for a specific nomination
export function getScoresForNomination(nominationId: string): Score[] {
  return scores.filter((score) => score.nominationId === nominationId)
}

// Helper function to calculate average score for a nomination
export function getAverageScoreForNomination(nominationId: string): number {
  const nominationScores = getScoresForNomination(nominationId)
  if (nominationScores.length === 0) return 0
  const totalScore = nominationScores.reduce((sum, score) => sum + score.averageScore, 0)
  return totalScore / nominationScores.length
}

// Helper function to get winning nominations for an event
export function getWinningNominationsForEvent(eventId: string): Nomination[] {
  const eventNominations = nominations.filter((nom) => nom.eventId === eventId)
  const winningNominations: Nomination[] = []

  // Group nominations by award type
  const nominationsByAwardType = eventNominations.reduce(
    (acc, nom) => {
      if (!acc[nom.awardType]) acc[nom.awardType] = []
      acc[nom.awardType].push(nom)
      return acc
    },
    {} as Record<string, Nomination[]>,
  )

  // For each award type, find the top N nominations based on quota
  Object.entries(nominationsByAwardType).forEach(([awardType, nominations]) => {
    if (nominations.length > 0) {
      // Get the quota for this award type (default is 2)
      const quota = getQuotaForAwardType(eventId, awardType)

      // Sort nominations by average score (descending)
      const sortedNominations = [...nominations].sort((a, b) => {
        const scoreA = getAverageScoreForNomination(a.id)
        const scoreB = getAverageScoreForNomination(b.id)
        return scoreB - scoreA
      })

      // Take the top N nominations based on quota
      const winners = sortedNominations.slice(0, quota)
      winningNominations.push(...winners)
    }
  })

  return winningNominations
}

// Helper function to get all judges for an event
export function getJudgesForEvent(eventId: string): string[] {
  const eventScores = scores.filter((score) => {
    const nomination = nominations.find((nom) => nom.id === score.nominationId)
    return nomination && nomination.eventId === eventId
  })
  return [...new Set(eventScores.map((score) => score.judgeId))]
}

// Helper function to get judge names for an event
export function getJudgeNamesForEvent(eventId: string): string[] {
  const judgeIds = getJudgesForEvent(eventId)
  return judgeIds.map((id) => {
    const user = mockUsers.find((u) => u.id === id)
    return user ? user.name : "Unknown Judge"
  })
}

// Mock function to get all scores for all nominations - in a real app, this would be an API call
export const getAllScores = (eventId: string): Record<string, Record<string, number>> => {
  const eventNominations = nominations.filter((nom) => nom.eventId === eventId)
  const eventScores: Record<string, Record<string, number>> = {}

  eventNominations.forEach((nomination) => {
    const nominationScores = getScoresForNomination(nomination.id)
    eventScores[nomination.id] = {}
    nominationScores.forEach((score) => {
      eventScores[nomination.id][score.judgeId] = score.averageScore
    })
  })

  return eventScores
}

// Mock function to get scores for a judge - in a real app, this would be an API call
export const getJudgeScores = (judgeId: string, eventId: string): Record<string, number> => {
  const eventNominations = nominations.filter((nom) => nom.eventId === eventId)
  const judgeScores: Record<string, number> = {}

  eventNominations.forEach((nomination) => {
    const nominationScores = getScoresForNomination(nomination.id)
    const judgeScore = nominationScores.find((score) => score.judgeId === judgeId)
    if (judgeScore) {
      judgeScores[nomination.id] = judgeScore.averageScore
    }
  })

  return judgeScores
}

// Mock function to save a score - in a real app, this would be an API call
export const saveScore = async (judgeId: string, nominationId: string, score: number): Promise<boolean> => {
  // This would be an API call to your backend
  console.log(`Saving score ${score} for nomination ${nominationId} by judge ${judgeId}`)
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  // Return success
  return true
}

