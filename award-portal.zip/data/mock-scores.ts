import type { Nomination } from "@/types/nominations"
import { mockUsers } from "./mock-users"
import { nominations } from "./nominations"

export interface Score {
  nominationId: string
  judgeId: string
  criteria: {
    [key: string]: number
  }
  averageScore: number
  comments: string
}

// Generate sample scores for Q4 2024 Spot Awards
const q4_2024_scores: Score[] = [
  {
    nominationId: "nom-q4-2024-001",
    judgeId: "alex-morgan",
    criteria: {
      impact: 4.5,
      innovation: 4.0,
      execution: 4.5,
    },
    averageScore: 4.33,
    comments: "Emily's agile leadership has had a significant positive impact on our delivery capabilities.",
  },
  {
    nominationId: "nom-q4-2024-001",
    judgeId: "jordan-lee",
    criteria: {
      impact: 4.0,
      innovation: 4.5,
      execution: 4.5,
    },
    averageScore: 4.33,
    comments: "The agile transformation led by Emily is impressive and has far-reaching benefits.",
  },
  {
    nominationId: "nom-q4-2024-001",
    judgeId: "casey-smith",
    criteria: {
      impact: 4.5,
      innovation: 4.0,
      execution: 4.0,
    },
    averageScore: 4.17,
    comments: "Emily's work has set a new standard for agile implementation across the company.",
  },
  {
    nominationId: "nom-q4-2024-002",
    judgeId: "jamie-taylor",
    criteria: {
      customerFocus: 5.0,
      problemSolving: 4.5,
      goingAboveAndBeyond: 4.5,
    },
    averageScore: 4.67,
    comments: "David's dedication to customer satisfaction is truly exemplary.",
  },
  {
    nominationId: "nom-q4-2024-002",
    judgeId: "avery-williams",
    criteria: {
      customerFocus: 4.5,
      problemSolving: 4.5,
      goingAboveAndBeyond: 5.0,
    },
    averageScore: 4.67,
    comments: "David's efforts not only solved the immediate issue but strengthened the client relationship.",
  },
  {
    nominationId: "nom-q4-2024-002",
    judgeId: "jordan-lee",
    criteria: {
      customerFocus: 4.5,
      problemSolving: 4.0,
      goingAboveAndBeyond: 4.5,
    },
    averageScore: 4.33,
    comments: "David's commitment to customer service is commendable and aligns perfectly with our values.",
  },
  {
    nominationId: "nom-q4-2024-003",
    judgeId: "alex-morgan",
    criteria: {
      innovation: 5.0,
      impact: 4.5,
      technicalExcellence: 4.5,
    },
    averageScore: 4.67,
    comments: "Sarah's cloud optimization algorithm is a game-changer for our clients.",
  },
  {
    nominationId: "nom-q4-2024-003",
    judgeId: "quinn-martine",
    criteria: {
      innovation: 4.5,
      impact: 5.0,
      technicalExcellence: 4.5,
    },
    averageScore: 4.67,
    comments: "The cost savings and performance improvements from Sarah's work are truly impressive.",
  },
  {
    nominationId: "nom-q4-2024-003",
    judgeId: "taylor-swift",
    criteria: {
      innovation: 4.5,
      impact: 4.5,
      technicalExcellence: 4.5,
    },
    averageScore: 4.5,
    comments: "Sarah's innovation demonstrates both technical excellence and business acumen.",
  },
  {
    nominationId: "nom-q4-2024-004",
    judgeId: "alex-morgan",
    criteria: {
      teamwork: 4.5,
      impact: 5.0,
      innovation: 4.5,
    },
    averageScore: 4.67,
    comments: "The Cloud Optimization Team's collaborative efforts have yielded outstanding results.",
  },
  {
    nominationId: "nom-q4-2024-004",
    judgeId: "jamie-taylor",
    criteria: {
      teamwork: 5.0,
      impact: 4.5,
      innovation: 4.5,
    },
    averageScore: 4.67,
    comments: "This team's synergy and ability to deliver innovative solutions is exemplary.",
  },
  {
    nominationId: "nom-q4-2024-004",
    judgeId: "riley-cooper",
    criteria: {
      teamwork: 4.5,
      impact: 4.5,
      innovation: 5.0,
    },
    averageScore: 4.67,
    comments: "The Cloud Optimization Team has set a new benchmark for collaborative innovation.",
  },
]

// Combine with any existing scores
export const scores: Score[] = [
  // ... (keep any existing scores)
  ...q4_2024_scores,
]

// Helper function to get scores for a specific nomination
export function getScoresForNomination(nominationId: string): Score[] {
  return scores.filter((score) => score.nominationId === nominationId)
}

// Helper function to calculate average score for a nomination
export function getAverageScoreForNomination(nominationId: string): number {
  const nominationScores = getScoresForNomination(nominationId)
  if (nominationScores.length === 0) return 0
  const totalScore = nominationScores.reduce((sum, score) => sum + score.averageScore, 0)
  return totalScore / nominationScores.length
}

// Helper function to get winning nominations for an event
export function getWinningNominationsForEvent(eventId: string): Nomination[] {
  const eventNominations = nominations.filter((nom) => nom.eventId === eventId)
  const winningNominations: Nomination[] = []

  // Group nominations by award type
  const nominationsByAwardType = eventNominations.reduce(
    (acc, nom) => {
      if (!acc[nom.awardType]) acc[nom.awardType] = []
      acc[nom.awardType].push(nom)
      return acc
    },
    {} as Record<string, Nomination[]>,
  )

  // For each award type, find the nomination with the highest average score
  Object.values(nominationsByAwardType).forEach((nominations) => {
    if (nominations.length > 0) {
      const winner = nominations.reduce((highest, current) => {
        const currentScore = getAverageScoreForNomination(current.id)
        const highestScore = getAverageScoreForNomination(highest.id)
        return currentScore > highestScore ? current : highest
      })
      winningNominations.push(winner)
    }
  })

  return winningNominations
}

// Helper function to get all judges for an event
export function getJudgesForEvent(eventId: string): string[] {
  const eventScores = scores.filter((score) => {
    const nomination = nominations.find((nom) => nom.id === score.nominationId)
    return nomination && nomination.eventId === eventId
  })
  return [...new Set(eventScores.map((score) => score.judgeId))]
}

// Helper function to get judge names for an event
export function getJudgeNamesForEvent(eventId: string): string[] {
  const judgeIds = getJudgesForEvent(eventId)
  return judgeIds.map((id) => {
    const user = mockUsers.find((u) => u.id === id)
    return user ? user.name : "Unknown Judge"
  })
}

// Mock function to get all scores for all nominations - in a real app, this would be an API call
export const getAllScores = (eventId: string): Record<string, Record<string, number>> => {
  const eventNominations = nominations.filter((nom) => nom.eventId === eventId)
  const eventScores: Record<string, Record<string, number>> = {}

  eventNominations.forEach((nomination) => {
    const nominationScores = getScoresForNomination(nomination.id)
    eventScores[nomination.id] = {}
    nominationScores.forEach((score) => {
      eventScores[nomination.id][score.judgeId] = score.averageScore
    })
  })

  return eventScores
}

// Mock function to get scores for a judge - in a real app, this would be an API call
export const getJudgeScores = (judgeId: string, eventId: string): Record<string, number> => {
  const eventNominations = nominations.filter((nom) => nom.eventId === eventId)
  const judgeScores: Record<string, number> = {}

  eventNominations.forEach((nomination) => {
    const nominationScores = getScoresForNomination(nomination.id)
    const judgeScore = nominationScores.find((score) => score.judgeId === judgeId)
    if (judgeScore) {
      judgeScores[nomination.id] = judgeScore.averageScore
    }
  })

  return judgeScores
}

// Mock function to save a score - in a real app, this would be an API call
export const saveScore = async (judgeId: string, nominationId: string, score: number): Promise<boolean> => {
  // This would be an API call to your backend
  console.log(`Saving score ${score} for nomination ${nominationId} by judge ${judgeId}`)
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  // Return success
  return true
}

