import type { Nomination } from "@/types/nomination"

export const sampleNominations: Nomination[] = [
  {
    id: "1",
    nomineeId: "emp123",
    nomineeName: "Sarah Chen",
    nominatorId: "emp456",
    nominatorName: "Michael Johnson",
    awardType: "INNOVATION_AWARD",
    nominationType: "individual",
    nominationSummary: "Led the development of a new automated testing framework that reduced testing time by 60%",
    department: "Engineering",
    createdAt: new Date("2024-03-15").toISOString(),
    status: "APPROVED",
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "costSaving",
          value: 150000,
          unit: "USD",
        },
        {
          type: "timeSaving",
          value: 40,
          unit: "hours per release",
        },
        {
          type: "customerSatisfaction",
          value: 95,
          unit: "NPS",
        },
      ],
      intangibleJustifications: [
        {
          type: "internalAudit",
          justification: "Improved code quality led to passing all internal audits with zero findings",
        },
        {
          type: "riskAvoidance",
          justification:
            "Automated testing reduced the risk of production bugs by catching 95% of issues before deployment",
        },
        {
          type: "regulatoryCompliance",
          justification: "New testing framework ensures compliance with security requirements",
        },
      ],
    },
  },
  {
    id: "2",
    nomineeId: "emp789",
    nomineeName: "David Martinez",
    nominatorId: "emp101",
    nominatorName: "Lisa Wong",
    awardType: "CUSTOMER_EXCELLENCE",
    nominationType: "individual",
    nominationSummary: "Implemented a new customer onboarding process that transformed our client experience",
    department: "Customer Success",
    createdAt: new Date("2024-03-14").toISOString(),
    status: "APPROVED",
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 15,
          unit: "days reduced in onboarding",
        },
        {
          type: "customerSatisfaction",
          value: 30,
          unit: "NPS points increase",
        },
      ],
      intangibleJustifications: [
        {
          type: "regulatoryCompliance",
          justification: "New onboarding process ensures complete compliance documentation collection",
        },
        {
          type: "other",
          justification: "Created a new standard for customer onboarding that has been adopted globally",
          otherType: "Process Innovation",
        },
      ],
    },
  },
  {
    id: "3",
    nomineeId: "team101",
    nomineeName: "Sustainability Team",
    nominatorId: "emp303",
    nominatorName: "Rachel Kim",
    awardType: "LEADERSHIP_EXCELLENCE",
    nominationType: "team",
    nominationSummary: "Spearheaded a cross-functional initiative to improve workplace sustainability",
    department: "Operations",
    createdAt: new Date("2024-03-13").toISOString(),
    status: "APPROVED",
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "costSaving",
          value: 75000,
          unit: "USD annually",
        },
        {
          type: "timeSaving",
          value: 100,
          unit: "hours monthly",
        },
      ],
      intangibleJustifications: [
        {
          type: "internalAudit",
          justification: "Passed environmental compliance audit with highest score in company history",
        },
        {
          type: "riskAvoidance",
          justification: "Proactive sustainability measures reduced environmental compliance risks",
        },
        {
          type: "other",
          justification: "Program received local government recognition for environmental leadership",
          otherType: "Community Impact",
        },
      ],
    },
  },
]

