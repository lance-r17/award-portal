/**
 * Maps a role name to a specific user ID in the mock users data
 */
export function getUserIdForRole(role: string): string {
  switch (role) {
    case "facilitator":
      return "alex-morgan"
    case "judge":
      return "jordan-lee"
    case "head-judge":
      return "casey-smith"
    case "domain-manager":
      return "taylor-swift"
    case "nominator":
      return "jamie-taylor"
    case "nominee":
      return "avery-williams"
    case "anonymous":
      return "anonymous"
    default:
      return "alex-morgan"
  }
}

// Role management functions
export function getCurrentRole(): string {
  if (typeof window !== "undefined") {
    return localStorage.getItem("currentRole") || "facilitator"
  }
  return "facilitator" // Default role for server-side rendering
}

export function setCurrentRole(role: string): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("currentRole", role)
    // Dispatch a custom event to notify other components
    const event = new CustomEvent("roleChanged", { detail: { role } })
    window.dispatchEvent(event)
  }
}

