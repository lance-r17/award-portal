export const formatServiceLine = (line: string) => {
  if (!line) return "Unknown"
  return line
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
}

