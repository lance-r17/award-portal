export interface User {
  id: string
  name: string
  email: string
  avatar: string
  initials: string
  serviceLine: string
  title?: string
  bio?: string
  role?: {
    isDomainManager?: boolean
  }
  isInJudgePool?: boolean
}

export const mockUsers: User[] = [
  // Technology
  {
    id: "alex-morgan",
    name: "Alex Morgan",
    email: "alex.morgan@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AM",
    serviceLine: "technology",
    title: "Chief Technology Officer",
    bio: "20+ years experience in technology leadership and innovation",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "samantha-lee",
    name: "Samantha Lee",
    email: "samantha.lee@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SL",
    serviceLine: "technology",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "jane-smith",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JS",
    serviceLine: "technology",
    isInJudgePool: false,
  },

  // Cloud Services
  {
    id: "jordan-lee",
    name: "Jordan Lee",
    email: "jordan.lee@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JL",
    serviceLine: "cloud-services",
    title: "Cloud Architecture Director",
    bio: "Expert in cloud migration and infrastructure optimization",
    role: { isDomainManager: false },
    isInJudgePool: true,
  },
  {
    id: "chris-patel",
    name: "Chris Patel",
    email: "chris.patel@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CP",
    serviceLine: "cloud-services",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "taylor-johnson",
    name: "Taylor Johnson",
    email: "taylor.johnson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TJ",
    serviceLine: "cloud-services",
    isInJudgePool: false,
  },

  // Data Analytics
  {
    id: "casey-smith",
    name: "Casey Smith",
    email: "casey.smith@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CS",
    serviceLine: "data-analytics",
    title: "Data Science Lead",
    bio: "Pioneering advanced analytics and machine learning solutions",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "morgan-zhang",
    name: "Morgan Zhang",
    email: "morgan.zhang@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MZ",
    serviceLine: "data-analytics",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "alex-rodriguez",
    name: "Alex Rodriguez",
    email: "alex.rodriguez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AR",
    serviceLine: "data-analytics",
    isInJudgePool: false,
  },

  // Cybersecurity
  {
    id: "taylor-swift",
    name: "Taylor Swift",
    email: "taylor.swift@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TS",
    serviceLine: "cybersecurity",
    title: "Security Operations Lead",
    bio: "Expert in enterprise security and risk management",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "jordan-nguyen",
    name: "Jordan Nguyen",
    email: "jordan.nguyen@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JN",
    serviceLine: "cybersecurity",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "sam-jackson",
    name: "Sam Jackson",
    email: "sam.jackson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SJ",
    serviceLine: "cybersecurity",
    isInJudgePool: false,
  },

  // Enterprise Solutions
  {
    id: "jamie-taylor",
    name: "Jamie Taylor",
    email: "jamie.taylor@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JT",
    serviceLine: "enterprise-solutions",
    title: "Enterprise Architecture Manager",
    bio: "Specializing in large-scale system integration and optimization",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "alex-kim",
    name: "Alex Kim",
    email: "alex.kim@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AK",
    serviceLine: "enterprise-solutions",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "charlie-garcia",
    name: "Charlie Garcia",
    email: "charlie.garcia@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CG",
    serviceLine: "enterprise-solutions",
    isInJudgePool: false,
  },

  // Customer Experience
  {
    id: "avery-williams",
    name: "Avery Williams",
    email: "avery.williams@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AW",
    serviceLine: "customer-experience",
    title: "Customer Success Director",
    bio: "Driving customer-centric strategies and improving satisfaction metrics",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "riley-thompson",
    name: "Riley Thompson",
    email: "riley.thompson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "RT",
    serviceLine: "customer-experience",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "jordan-brown",
    name: "Jordan Brown",
    email: "jordan.brown@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JB",
    serviceLine: "customer-experience",
    isInJudgePool: false,
  },

  // Financial Services
  {
    id: "quinn-martinez",
    name: "Quinn Martinez",
    email: "quinn.martinez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "QM",
    serviceLine: "financial-services",
    title: "FinTech Innovation Lead",
    bio: "Spearheading digital transformation in financial services",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "casey-wong",
    name: "Casey Wong",
    email: "casey.wong@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CW",
    serviceLine: "financial-services",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "taylor-davis",
    name: "Taylor Davis",
    email: "taylor.davis@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TD",
    serviceLine: "financial-services",
    isInJudgePool: false,
  },

  // Healthcare Solutions
  {
    id: "riley-cooper",
    name: "Riley Cooper",
    email: "riley.cooper@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "RC",
    serviceLine: "healthcare-solutions",
    title: "Healthcare Tech Innovations Director",
    bio: "Leading the integration of cutting-edge technology in healthcare",
    role: { isDomainManager: true },
    isInJudgePool: true,
  },
  {
    id: "morgan-patel",
    name: "Morgan Patel",
    email: "morgan.patel@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MP",
    serviceLine: "healthcare-solutions",
    role: { isDomainManager: true },
    isInJudgePool: false,
  },
  {
    id: "alex-foster",
    name: "Alex Foster",
    email: "alex.foster@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AF",
    serviceLine: "healthcare-solutions",
    isInJudgePool: false,
  },
  // Add David Kim
  {
    id: "david-kim",
    name: "David Kim",
    email: "david.kim@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "DK",
    serviceLine: "technology",
    title: "Software Engineer",
    bio: "Passionate about creating innovative solutions and mentoring junior developers",
    isInJudgePool: false,
  },
]

export const getDomainManagers = (serviceLine?: string): User[] => {
  return mockUsers.filter((user) => user.role?.isDomainManager && (!serviceLine || user.serviceLine === serviceLine))
}

export const isUserDomainManager = (userId: string): boolean => {
  const user = mockUsers.find((u) => u.id === userId)
  return user?.role?.isDomainManager || false
}

export const getJudgePool = (): User[] => {
  return mockUsers.filter((user) => user.isInJudgePool)
}

export const getCurrentUser = () => {
  // In a real app, this would come from authentication
  return mockUsers.find((u) => u.id === "alex-morgan") || mockUsers[0]
}

