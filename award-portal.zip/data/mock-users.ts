"use client"

import { User } from "@/types/user"

// Mock functions for demonstration purposes.  Replace with actual implementations.
const getCurrentRole = () => {
  // Replace with actual logic to determine the current role
  return "domain_manager" // Example role
}

const getUserIdForRole = (role) => {
  // Replace with actual logic to retrieve user ID based on role
  switch (role) {
    case "domain_manager":
      return "alex-morgan"
    case "judge":
      return "jordan-lee"
    default:
      return "alex-morgan" // Default user ID
  }
}

export const mockUsers = [
  // Technology
  {
    id: "alex-morgan",
    name: "Alex Morgan",
    email: "alex.morgan@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AM",
    serviceLine: "technology",
    title: "Chief Technology Officer",
    bio: "20+ years experience in technology leadership and innovation",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager"],
  },
  {
    id: "samantha-lee",
    name: "Samantha Lee",
    email: "samantha.lee@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SL",
    serviceLine: "technology",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "jane-smith",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JS",
    serviceLine: "technology",
    isInJudgePool: false,
    roles: ["nominee"],
  },

  // Cloud Services
  {
    id: "jordan-lee",
    name: "Jordan Lee",
    email: "jordan.lee@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JL",
    serviceLine: "cloud-services",
    title: "Cloud Architecture Director",
    bio: "Expert in cloud migration and infrastructure optimization",
    role: { isDomainManager: false },
    isInJudgePool: true,
    roles: ["judge"],
  },
  {
    id: "chris-patel",
    name: "Chris Patel",
    email: "chris.patel@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CP",
    serviceLine: "cloud-services",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "taylor-johnson",
    name: "Taylor Johnson",
    email: "taylor.johnson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TJ",
    serviceLine: "cloud-services",
    isInJudgePool: false,
    roles: ["nominator"],
  },

  // Data Analytics
  {
    id: "casey-smith",
    name: "Casey Smith",
    email: "casey.smith@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CS",
    serviceLine: "data-analytics",
    title: "Data Science Lead",
    bio: "Pioneering advanced analytics and machine learning solutions",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager", "head-judge"],
  },
  {
    id: "morgan-zhang",
    name: "Morgan Zhang",
    email: "morgan.zhang@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MZ",
    serviceLine: "data-analytics",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "alex-rodriguez",
    name: "Alex Rodriguez",
    email: "alex.rodriguez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AR",
    serviceLine: "data-analytics",
    isInJudgePool: false,
    roles: [],
  },

  // Cybersecurity
  {
    id: "taylor-swift",
    name: "Taylor Swift",
    email: "taylor.swift@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TS",
    serviceLine: "cybersecurity",
    title: "Security Operations Lead",
    bio: "Expert in enterprise security and risk management",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager", "facilitator"],
  },
  {
    id: "jordan-nguyen",
    name: "Jordan Nguyen",
    email: "jordan.nguyen@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JN",
    serviceLine: "cybersecurity",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "sam-jackson",
    name: "Sam Jackson",
    email: "sam.jackson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SJ",
    serviceLine: "cybersecurity",
    isInJudgePool: false,
    roles: [],
  },

  // Enterprise Solutions
  {
    id: "jamie-taylor",
    name: "Jamie Taylor",
    email: "jamie.taylor@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JT",
    serviceLine: "enterprise-solutions",
    title: "Enterprise Architecture Manager",
    bio: "Specializing in large-scale system integration and optimization",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager"],
  },
  {
    id: "alex-kim",
    name: "Alex Kim",
    email: "alex.kim@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AK",
    serviceLine: "enterprise-solutions",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "charlie-garcia",
    name: "Charlie Garcia",
    email: "charlie.garcia@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CG",
    serviceLine: "enterprise-solutions",
    isInJudgePool: false,
    roles: [],
  },

  // Customer Experience
  {
    id: "avery-williams",
    name: "Avery Williams",
    email: "avery.williams@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AW",
    serviceLine: "customer-experience",
    title: "Customer Success Director",
    bio: "Driving customer-centric strategies and improving satisfaction metrics",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager"],
  },
  {
    id: "riley-thompson",
    name: "Riley Thompson",
    email: "riley.thompson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "RT",
    serviceLine: "customer-experience",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "jordan-brown",
    name: "Jordan Brown",
    email: "jordan.brown@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JB",
    serviceLine: "customer-experience",
    isInJudgePool: false,
    roles: [],
  },

  // Financial Services
  {
    id: "quinn-martinez",
    name: "Quinn Martinez",
    email: "quinn.martinez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "QM",
    serviceLine: "financial-services",
    title: "FinTech Innovation Lead",
    bio: "Spearheading digital transformation in financial services",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager"],
  },
  {
    id: "casey-wong",
    name: "Casey Wong",
    email: "casey.wong@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "CW",
    serviceLine: "financial-services",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "taylor-davis",
    name: 'Taylor Davis",',
    email: "taylor.davis@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TD",
    serviceLine: "financial-services",
    isInJudgePool: false,
    roles: [],
  },

  // Healthcare Solutions
  {
    id: "riley-cooper",
    name: "Riley Cooper",
    email: "riley.cooper@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "RC",
    serviceLine: "healthcare-solutions",
    title: "Healthcare Tech Innovations Director",
    bio: "Leading the integration of cutting-edge technology in healthcare",
    role: { isDomainManager: true },
    isInJudgePool: true,
    roles: ["domain-manager"],
  },
  {
    id: "morgan-patel",
    name: "Morgan Patel",
    email: "morgan.patel@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MP",
    serviceLine: "healthcare-solutions",
    role: { isDomainManager: true },
    isInJudgePool: false,
    roles: ["domain-manager"],
  },
  {
    id: "alex-foster",
    name: "Alex Foster",
    email: "alex.foster@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AF",
    serviceLine: "healthcare-solutions",
    isInJudgePool: false,
    roles: [],
  },
  // Add David Kim
  {
    id: "david-kim",
    name: "David Kim",
    email: "david.kim@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "DK",
    serviceLine: "technology",
    title: "Software Engineer",
    bio: "Passionate about creating innovative solutions and mentoring junior developers",
    isInJudgePool: false,
    roles: [],
  },
  // Add Emily Rodriguez
  {
    id: "emily-rodriguez",
    name: "Emily Rodriguez",
    email: "emily.rodriguez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "ER",
    serviceLine: "technology",
    title: "Agile Coach",
    bio: "Experienced agile practitioner with expertise in Scrum and Kanban methodologies",
    isInJudgePool: false,
    roles: [],
  },
  // Add Michael Chen
  {
    id: "michael-chen",
    name: "Michael Chen",
    email: "michael.chen@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MC",
    serviceLine: "technology",
    title: "Product Manager",
    bio: "Product leader with a focus on user-centered design and data-driven decision making",
    isInJudgePool: false,
    roles: [],
  },
  // Add Sarah Johnson
  {
    id: "sarah-johnson",
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SJ",
    serviceLine: "cloud-services",
    title: "Cloud Solutions Architect",
    bio: "Expert in designing scalable and resilient cloud architectures",
    isInJudgePool: false,
    roles: [],
  },
  // Add James Wilson
  {
    id: "james-wilson",
    name: "James Wilson",
    email: "james.wilson@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JW",
    serviceLine: "enterprise-solutions",
    title: "Product Development Lead",
    bio: "Specializing in customer-centric product development and market research",
    isInJudgePool: false,
    roles: [],
  },
  // Add Jessica Patel
  {
    id: "jessica-patel",
    name: "Jessica Patel",
    email: "jessica.patel@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JP",
    serviceLine: "customer-experience",
    title: "Customer Success Manager",
    bio: "Dedicated to creating exceptional customer experiences and building lasting relationships",
    isInJudgePool: false,
    roles: [],
  },
  // Add Olivia Martinez
  {
    id: "olivia-martinez",
    name: "Olivia Martinez",
    email: "olivia.martinez@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "OM",
    serviceLine: "enterprise-solutions",
    title: "Customer Success Specialist",
    bio: "Focused on proactive customer engagement and relationship management",
    isInJudgePool: false,
    roles: [],
  },
]

export const getDomainManagers = (serviceLine) => {
  return mockUsers.filter((user) => user.role?.isDomainManager && (!serviceLine || user.serviceLine === serviceLine))
}

export const isUserDomainManager = (userId) => {
  const user = mockUsers.find((u) => u.id === userId)
  return user?.role?.isDomainManager || false
}

export const getJudgePool = () => {
  return mockUsers.filter((user) => user.isInJudgePool)
}

export function getCurrentUser(): User | null {
  try {
    // Get the selected role from localStorage
    const selectedRole = localStorage.getItem("selectedRole")
    console.log("getCurrentUser: Selected role from localStorage:", selectedRole)

    // Default user (Jane Doe)
    let user = mockUsers[0]

    if (selectedRole) {
      switch (selectedRole) {
        case "facilitator":
          // Return Taylor Swift who is most involved as a facilitator in award events
          user = mockUsers.find((u) => u.id === "jane-smith") || user
          break
        case "judge":
          // Find a user with judge role
          user = mockUsers.find((u) => u.roles?.includes("judge") && !u.roles.includes("head-judge")) || user
          break
        case "head-judge":
          // Find a user with head-judge role
          user = mockUsers.find((u) => u.id === "alex-morgan") || user
          break
        case "domain-manager":
          // Find a user with domain-manager role
          user = mockUsers.find((u) => u.id === "avery-williams") || user
          break
        case "nominator":
          // Return a user who is only a nominator
          user = mockUsers.find((u) => u.id === "jessica-patel") || user
          break
        case "nominee":
          // Find a user who is only a nominee without other roles
          user = user = mockUsers.find((u) => u.id === "emily-rodriguez") || user
          break
        case "anonymous":
          // Return a user with minimal permissions
          user = {
            id: "anonymous",
            name: "Anonymous User",
            email: "anonymous@example.com",
            avatar: "/placeholder.svg?height=40&width=40",
            initials: "AU",
            serviceLine: "Unknown",
            isInJudgePool: false,
            roles: ["viewer"],
          }
          break
      }
    }

    console.log("getCurrentUser: Returning user:", user)
    return user
  } catch (error) {
    console.error("Error in getCurrentUser:", error)
    return null
  }
}

