import type { AwardEvent } from "@/types/award-events"

// Define the AwardEventStage type
type AwardEventStage = "nomination" | "presentation" | "result"

// Sample award events data
export const awardEvents: AwardEvent[] = [
  {
    id: "spot-q1-2023",
    title: "Q1 2023 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions during Q1 2023",
    quarter: "Q1 2023",
    theme: "Innovation & Collaboration",
    currentStage: "nomination",
    stages: {
      nomination: {
        startDate: new Date("2023-03-15T00:00:00Z"),
        endDate: new Date("2023-03-31T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2023-04-01T00:00:00Z"),
        endDate: new Date("2023-04-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2023-04-16T00:00:00Z"),
        endDate: new Date("2023-04-30T23:59:59Z"),
      },
    },
    isActive: false,
    createdBy: "John Doe",
    createdAt: new Date("2023-03-10T00:00:00Z"),
  },
  {
    id: "spot-q2-2023",
    title: "Q2 2023 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions during Q2 2023",
    quarter: "Q2 2023",
    theme: "Customer Excellence",
    currentStage: "result",
    stages: {
      nomination: {
        startDate: new Date("2023-06-15T00:00:00Z"),
        endDate: new Date("2023-06-30T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2023-07-01T00:00:00Z"),
        endDate: new Date("2023-07-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2023-07-16T00:00:00Z"),
        endDate: new Date("2023-07-31T23:59:59Z"),
      },
    },
    isActive: false,
    createdBy: "John Doe",
    createdAt: new Date("2023-06-10T00:00:00Z"),
  },
  {
    id: "spot-q3-2023",
    title: "Q3 2023 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions during Q3 2023",
    quarter: "Q3 2023",
    theme: "Operational Excellence",
    currentStage: "presentation",
    stages: {
      nomination: {
        startDate: new Date("2023-09-15T00:00:00Z"),
        endDate: new Date("2023-09-30T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2023-10-01T00:00:00Z"),
        endDate: new Date("2023-10-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2023-10-16T00:00:00Z"),
        endDate: new Date("2023-10-31T23:59:59Z"),
      },
    },
    isActive: false,
    createdBy: "John Doe",
    createdAt: new Date("2023-09-10T00:00:00Z"),
  },
  {
    id: "spot-q1-2025",
    title: "Q1 2025 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions during Q1 2025",
    quarter: "Q1 2025",
    theme: "Digital Transformation",
    currentStage: "nomination",
    stages: {
      nomination: {
        startDate: new Date("2025-03-01T00:00:00Z"),
        endDate: new Date("2025-03-31T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2025-04-01T00:00:00Z"),
        endDate: new Date("2025-01-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2025-04-16T00:00:00Z"),
        endDate: new Date("2025-04-30T23:59:59Z"),
      },
    },
    isActive: true,
    createdBy: "John Doe",
    createdAt: new Date("2024-12-10T00:00:00Z"),
  },
  {
    id: "recognition-2023",
    title: "Annual Recognition Awards 2023",
    type: "recognition",
    description: "Annual awards recognizing significant achievements throughout 2023",
    quarter: "Annual 2023",
    theme: "Excellence & Leadership",
    currentStage: "nomination",
    stages: {
      nomination: {
        startDate: new Date("2023-11-01T00:00:00Z"),
        endDate: new Date("2023-12-15T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2023-12-16T00:00:00Z"),
        endDate: new Date("2024-01-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2024-01-16T00:00:00Z"),
        endDate: new Date("2024-01-31T23:59:59Z"),
      },
    },
    isActive: true,
    createdBy: "John Doe",
    createdAt: new Date("2023-10-25T00:00:00Z"),
  },
]

// Helper functions to work with award events
export function getActiveAwardEvents(): AwardEvent[] {
  return awardEvents.filter((event) => event.isActive)
}

export function getActiveAwardEventsByType(type: "spot" | "recognition"): AwardEvent[] {
  return awardEvents.filter((event) => event.isActive && event.type === type)
}

export function getAwardEventById(id: string): AwardEvent | undefined {
  return awardEvents.find((event) => event.id === id)
}

export function isNominationPeriodActive(eventId: string): boolean {
  const event = getAwardEventById(eventId)
  if (!event || !event.isActive) return false

  const now = new Date()
  const { startDate, endDate } = event.stages.nomination

  return now >= startDate && now <= endDate
}

export function getCurrentStageLabel(stage: AwardEventStage): string {
  switch (stage) {
    case "nomination":
      return "Nomination Stage"
    case "presentation":
      return "Presentation Stage"
    case "result":
      return "Results Announced"
    default:
      return "Unknown Stage"
  }
}

export function getStageTimeRemaining(event: AwardEvent): string {
  const now = new Date()
  const currentStageEndDate = event.stages[event.currentStage].endDate

  if (now > currentStageEndDate) {
    return "Stage completed"
  }

  const diffTime = Math.abs(currentStageEndDate.getTime() - now.getTime())
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

  return diffDays === 1 ? "1 day remaining" : `${diffDays} days remaining`
}

