import type { AwardEvent, AwardEventStage, AwardEventType } from "@/types/award-events"
import { mockUsers } from "./mock-users"

// Sample award events data
export const awardEvents: AwardEvent[] = [
  {
    id: "spot-q1-2025",
    title: "Q1 2025 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions in the first quarter of 2025.",
    quarter: "Q1 2025",
    theme: "Innovation & Excellence",
    currentStage: "nomination",
    status: "published",
    stages: {
      nomination: {
        startDate: new Date("2025-01-15T00:00:00Z"),
        endDate: new Date("2025-03-31T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2025-04-01T00:00:00Z"),
        endDate: new Date("2025-04-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2025-04-16T00:00:00Z"),
        endDate: new Date("2025-04-30T23:59:59Z"),
      },
    },
    isActive: true,
    createdBy: {
      id: "admin-user",
      name: "Admin User",
    },
    facilitators: [
      mockUsers.find((user) => user.id === "jane-smith"),
      mockUsers.find((user) => user.id === "alex-morgan"),
    ].filter(Boolean) as any[],
    createdAt: new Date("2025-01-01T10:00:00Z"),
    updatedAt: new Date("2025-01-10T14:30:00Z"),
    publishedAt: new Date("2025-01-12T09:00:00Z"),
    quotas: {
      "star-of-agile": 3,
      "star-of-customer-service": 2,
      "star-of-innovation": 3,
      "star-of-leadership": 2,
      "star-of-engagement": 2,
      "all-star-team": 1,
    },
  },
  {
    id: "recognition-q1-2025",
    title: "Q1 2025 Recognition Awards",
    type: "recognition",
    description: "Formal recognition for significant achievements in Q1 2025.",
    quarter: "Q1 2025",
    theme: "Leadership & Impact",
    currentStage: "nomination",
    status: "published",
    stages: {
      nomination: {
        startDate: new Date("2025-01-15T00:00:00Z"),
        endDate: new Date("2025-03-31T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2025-04-01T00:00:00Z"),
        endDate: new Date("2025-04-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2025-04-16T00:00:00Z"),
        endDate: new Date("2025-04-30T23:59:59Z"),
      },
    },
    isActive: true,
    createdBy: {
      id: "admin-user",
      name: "Admin User",
    },
    facilitators: [mockUsers.find((user) => user.id === "jordan-lee")].filter(Boolean) as any[],
    createdAt: new Date("2025-01-05T11:30:00Z"),
    updatedAt: new Date("2025-01-08T16:45:00Z"),
    publishedAt: new Date("2025-01-10T10:15:00Z"),
    quotas: {
      excellence: 2,
      leadership: 2,
      innovation: 3,
      "values-champion": 2,
      impact: 1,
    },
  },
  {
    id: "spot-q4-2024",
    title: "Q4 2024 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions in the fourth quarter of 2024.",
    quarter: "Q4 2024",
    theme: "Customer Excellence",
    currentStage: "result",
    status: "published",
    stages: {
      nomination: {
        startDate: new Date("2024-10-15T00:00:00Z"),
        endDate: new Date("2024-11-15T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2024-11-16T00:00:00Z"),
        endDate: new Date("2024-12-01T23:59:59Z"),
      },
      result: {
        startDate: new Date("2024-12-02T00:00:00Z"),
        endDate: new Date("2024-12-15T23:59:59Z"),
      },
    },
    isActive: false,
    createdBy: {
      id: "admin-user",
      name: "Admin User",
    },
    facilitators: [mockUsers.find((user) => user.id === "jane-smith")].filter(Boolean) as any[],
    createdAt: new Date("2024-10-01T09:00:00Z"),
    updatedAt: new Date("2024-10-05T13:20:00Z"),
    publishedAt: new Date("2024-10-10T11:00:00Z"),
    quotas: {
      "star-of-agile": 2,
      "star-of-customer-service": 3,
      "star-of-innovation": 2,
      "star-of-leadership": 2,
      "star-of-engagement": 3,
      "all-star-team": 1,
    },
  },
  {
    id: "recognition-q4-2024",
    title: "Q4 2024 Recognition Awards",
    type: "recognition",
    description: "Formal recognition for significant achievements in Q4 2024.",
    quarter: "Q4 2024",
    theme: "Innovation & Collaboration",
    currentStage: "result",
    status: "published",
    stages: {
      nomination: {
        startDate: new Date("2024-10-15T00:00:00Z"),
        endDate: new Date("2024-11-30T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2024-12-01T00:00:00Z"),
        endDate: new Date("2024-12-15T23:59:59Z"),
      },
      result: {
        startDate: new Date("2024-12-16T00:00:00Z"),
        endDate: new Date("2024-12-31T23:59:59Z"),
      },
    },
    isActive: false,
    createdBy: {
      id: "admin-user",
      name: "Admin User",
    },
    facilitators: [mockUsers.find((user) => user.id === "alex-morgan")].filter(Boolean) as any[],
    createdAt: new Date("2024-10-05T14:00:00Z"),
    updatedAt: new Date("2024-10-10T09:30:00Z"),
    publishedAt: new Date("2024-10-12T10:45:00Z"),
    quotas: {
      excellence: 3,
      leadership: 2,
      innovation: 2,
      "values-champion": 3,
      impact: 1,
    },
  },
  {
    id: "spot-q2-2025-draft",
    title: "Q2 2025 Spot Awards",
    type: "spot",
    description: "Recognizing outstanding contributions in the second quarter of 2025.",
    quarter: "Q2 2025",
    theme: "Agility & Resilience",
    currentStage: "nomination",
    status: "draft",
    stages: {
      nomination: {
        startDate: new Date("2025-04-15T00:00:00Z"),
        endDate: new Date("2025-05-15T23:59:59Z"),
      },
      presentation: {
        startDate: new Date("2025-05-16T00:00:00Z"),
        endDate: new Date("2025-06-01T23:59:59Z"),
      },
      result: {
        startDate: new Date("2025-06-02T00:00:00Z"),
        endDate: new Date("2025-06-15T23:59:59Z"),
      },
    },
    isActive: false,
    createdBy: {
      id: "current-user",
      name: "Current User",
    },
    facilitators: [
      mockUsers.find((user) => user.id === "jane-smith"),
    ].filter(Boolean) as any[],
    createdAt: new Date("2025-03-20T11:00:00Z"),
    updatedAt: new Date("2025-03-20T11:00:00Z"),
    quotas: {
      "star-of-agile": 2,
      "star-of-customer-service": 2,
      "star-of-innovation": 3,
      "star-of-leadership": 3,
      "star-of-engagement": 2,
      "all-star-team": 1,
    },
  },
]

// Helper functions to work with award events
export function getAwardEventById(id: string): AwardEvent | undefined {
  return awardEvents.find((event) => event.id === id)
}

export function getAwardEventsByType(type: AwardEventType): AwardEvent[] {
  return awardEvents.filter((event) => event.type === type)
}

export function getActiveAwardEvents(): AwardEvent[] {
  return awardEvents.filter((event) => event.isActive)
}

export function getActiveAwardEventsByType(type: AwardEventType): AwardEvent[] {
  return awardEvents.filter((event) => event.type === type && event.isActive)
}

export function isNominationPeriodActive(eventId: string): boolean {
  const event = getAwardEventById(eventId)
  if (!event) return false

  const now = new Date()
  return (
    event.currentStage === "nomination" &&
    now >= event.stages.nomination.startDate &&
    now <= event.stages.nomination.endDate
  )
}

// Add this function if it doesn't already exist
export function canEditEvent(event: AwardEvent, userId: string): boolean {
  // Only creators and facilitators can edit events
  return event.createdBy.id === userId || event.facilitators?.some((f) => f.id === userId) || false
}

// Add these helper functions if they don't already exist

export function getCurrentStageLabel(stage: AwardEventStage): string {
  switch (stage) {
    case "nomination":
      return "Nomination Stage"
    case "presentation":
      return "Presentation Stage"
    case "result":
      return "Results Announced"
    default:
      return "Unknown Stage"
  }
}

export function getStageTimeRemaining(event: AwardEvent): string {
  const now = new Date()
  const currentStageEndDate = event.stages[event.currentStage].endDate

  if (now > currentStageEndDate) {
    return "Stage completed"
  }

  const diffTime = Math.abs(currentStageEndDate.getTime() - now.getTime())
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

  return diffDays === 1 ? "1 day remaining" : `${diffDays} days remaining`
}

