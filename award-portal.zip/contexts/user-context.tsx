"use client"

import { createContext, useContext, useState, useEffect, type ReactNode, useCallback } from "react"
import { getCurrentUser } from "@/data/mock-users"
import type { User } from "@/types/user"

interface UserContextType {
  user: User | null
  loading: boolean
  refreshUser: () => void
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const loadUser = () => {
    try {
      setLoading(true)
      const currentUser = getCurrentUser()
      console.log("UserContext: Loaded user", currentUser)
      setUser(currentUser)
    } catch (error) {
      console.error("Error loading user:", error)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  // Load user on initial mount
  useEffect(() => {
    loadUser()
  }, [])

  const refreshUser = useCallback(() => {
    console.log("UserContext: Manually refreshing user data")
    setUser(getCurrentUser())
  }, [])

  return <UserContext.Provider value={{ user, loading, refreshUser }}>{children}</UserContext.Provider>
}

export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}

