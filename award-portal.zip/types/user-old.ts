export type User = {
  id: string
  name: string
  email: string
  department: string
  role: string
  avatar?: string
}

