export interface Judge {
  id: string
  name: string
  email: string
  avatar?: string
  initials?: string
  serviceLine?: string
}

export interface Score {
  judgeId: string
  nominationId: string
  criteria: {
    accomplishments: number
    presentation: number
    values: number
    [key: string]: number // Keep this for backward compatibility
  }
  // averageScore field is removed as requested
  comments: string
}

// Define the weights for each criteria
export const CRITERIA_WEIGHTS = {
  accomplishments: 0.7, // 70%
  presentation: 0.2, // 20%
  values: 0.1, // 10%
}

// Calculate weighted score based on criteria
export function calculateWeightedScore(criteriaScores: {
  accomplishments: number
  presentation: number
  values: number
}): number {
  return (
    criteriaScores.accomplishments * CRITERIA_WEIGHTS.accomplishments +
    criteriaScores.presentation * CRITERIA_WEIGHTS.presentation +
    criteriaScores.values * CRITERIA_WEIGHTS.values
  )
}

// Calculate final score by removing outliers and judges from same service line
export function calculateFinalScore(
  scores: Score[],
  nomineeServiceLine: string,
  judgeServiceLines: Record<string, string>,
): number {
  // Filter out judges from the same service line
  const eligibleScores = scores.filter((score) => {
    const judgeServiceLine = judgeServiceLines[score.judgeId]
    return judgeServiceLine !== nomineeServiceLine
  })

  if (eligibleScores.length === 0) {
    return 0
  }

  // Calculate weighted scores for each eligible score
  const weightedScores = eligibleScores.map((score) => ({
    ...score,
    weightedScore: calculateWeightedScore(score.criteria),
  }))

  // Sort by weighted score
  weightedScores.sort((a, b) => a.weightedScore - b.weightedScore)

  // Remove top 2 and bottom 2 scores if we have enough scores
  let filteredScores = [...weightedScores]
  if (filteredScores.length > 4) {
    // Remove bottom 2
    filteredScores = filteredScores.slice(2)
    // Remove top 2
    filteredScores = filteredScores.slice(0, filteredScores.length - 2)
  }

  // Calculate average of remaining scores
  const sum = filteredScores.reduce((acc, score) => acc + score.weightedScore, 0)
  return filteredScores.length > 0 ? sum / filteredScores.length : 0
}

// Function to remove outlier scores (top 2 and bottom 2)
export function removeOutlierScores(scores: Score[]): Score[] {
  if (scores.length <= 4) {
    return scores
  }

  // Calculate weighted scores
  const scoresWithWeighted = scores.map((score) => ({
    ...score,
    weightedScore: calculateWeightedScore(score.criteria),
  }))

  // Sort by weighted score
  scoresWithWeighted.sort((a, b) => a.weightedScore - b.weightedScore)

  // Remove bottom 2 and top 2 scores
  return scoresWithWeighted.slice(2, scoresWithWeighted.length - 2)
}

