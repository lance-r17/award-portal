import type { User } from "@/types/users"

// Sample judges for events
interface EventJudge {
  eventId: string
  judgeId: string
  judge?: User
  isHeadJudge?: boolean
}

export interface Score {
  nominationId: string
  judgeId: string
  criteria: {
    [key: string]: number
  }
  averageScore: number
  comments: string
}

// Judge pool interface for managing available judges
export interface JudgePool {
  userId: string
  
  organizationLevel2: string
  isHeadJudge: boolean
}

