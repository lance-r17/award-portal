export interface Judge {
  id: string
  name: string
  email: string
  avatar: string
  initials: string
  serviceLine: string
  title: string
  bio: string
}

export interface EventJudge extends Judge {
  eventId: string
  invitedAt: Date
  status: "pending" | "accepted" | "declined"
  invitedBy: {
    id: string
    name: string
  }
}

