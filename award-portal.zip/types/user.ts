export interface User {
  id: string
  name: string
  email: string
  avatar: string
  initials: string
  serviceLine: string
  title?: string
  bio?: string
  role?: {
    isDomainManager?: boolean
    isJudge?: boolean
  }
}

