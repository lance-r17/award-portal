export interface User {
  id: string
  name: string
  email: string
  avatar?: string
  initials?: string
  role?: string
  department?: string
  title?: string
  bio?: string
  status?: string
  serviceLineId?: string
  country?: string
  city?: string
  organization?: {
    level1?: string
    level2?: string
  }
  roles?: any[]
  entityManagerId?: string
  isInJudgePool?: boolean
}

