export interface User {
  id: string
  name: string
  email: string
  avatar: string
  initials: string
  serviceLine: string
  title?: string
  bio?: string
  role?: {
    isDomainManager?: boolean
    isJudge?: boolean
    isHeadJudge?: boolean
    isFacilitator?: boolean
  }
  isInJudgePool?: boolean
  isNominee?: boolean
  isNominator?: boolean
  roles?: string[]
}

