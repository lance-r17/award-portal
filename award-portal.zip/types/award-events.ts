import type { User } from "@/data/mock-users"
import { EventJudge } from "@/types/jud

export type AwardEventStage = "nomination" | "presentation" | "result"

export type AwardEventType = "spot" | "recognition"

export type AwardEventStatus = "draft" | "published"

export interface AwardEvent {
  id: string
  title: string
  type: AwardEventType
  description: string
  quarter: string
  theme?: string
  currentStage: AwardEventStage
  status: AwardEventStatus
  stages: {
    nomination: {
      startDate: Date
      endDate: Date
    }
    presentation: {
      startDate: Date
      endDate: Date
    }
    result: {
      startDate: Date
      endDate: Date
    }
  }
  isActive: boolean
  createdBy: {
    id: string
    name: string
  }
  facilitators?: User[]
  judges?: EventJudge[]
  announcementDate: string
  quotas?: Record<string, number>
  createdAt: Date
  updatedAt?: Date
  publishedAt?: Date
}

