export type AwardEventStage = "nomination" | "presentation" | "result"

export type AwardEventType = "spot" | "recognition"

export interface AwardEvent {
  id: string
  title: string
  type: AwardEventType
  description: string
  quarter: string // e.g., "Q1 2023"
  theme?: string
  currentStage: AwardEventStage
  stages: {
    nomination: {
      startDate: Date
      endDate: Date
    }
    presentation: {
      startDate: Date
      endDate: Date
    }
    result: {
      startDate: Date
      endDate: Date
    }
  }
  isActive: boolean
  createdBy: string
  createdAt: Date
}

