/**
 * Represents a service line in the organization
 */
export interface ServiceLine {
  /**
   * Unique identifier for the service line
   */
  id: string

  /**
   * Name of the service line
   */
  name: string

  /**
   * Organization level 2 that this service line belongs to
   */
  organizationLevel2: string

  /**
   * Optional description of the service line
   */
  description?: string
}

