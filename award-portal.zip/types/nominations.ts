export interface Nomination {
  id: string
  eventId: string
  awardType: string
  nominationType: "individual" | "team"
  nominee: {
    id: string
    name: string
    avatar: string
    initials: string
    department: string
  }
  team?: {
    id?: string
    name?: string
    members?: string[] | string
  }
  presenter?: {
    id: string
    name: string
    avatar: string
    initials: string
    department: string
  }
  nominator: {
    id: string
    name: string
    avatar: string
    initials: string
    department: string
  }
  serviceLine: string[]
  domainManagers: string[]
  nominationSummary: string
  benefitAndOutcome?: BenefitAndOutcome
  justification?: string // Keep for backward compatibility
  impact?: string // Keep for backward compatibility
  supportingInfo?: string
  status: "pending" | "approved" | "rejected"
  endorsement?: {
    status: "pending" | "endorsed" | "rejected"
    endorsedBy?: string
    endorsedAt?: Date
    comments?: string
  }
  // Add votes and comments to the nomination
  votes?: {
    userId: string
    userName: string
    timestamp: Date
  }[]
  comments?: {
    id: string
    userId: string
    userName: string
    userAvatar: string
    userInitials: string
    text: string
    timestamp: Date
  }[]
  createdAt: Date
  updatedAt: Date
}

export interface BenefitAndOutcome {
  tangibleMetrics: TangibleMetric[]
  intangibleJustifications: IntangibleJustification[]
}

export interface TangibleMetric {
  type: "headcountSaving" | "timeSaving" | "costSaving" | "customerSatisfaction"
  value: number
  unit: string
}

export interface IntangibleJustification {
  type: "internalAudit" | "riskAvoidance" | "regulatoryCompliance" | "other"
  justification: string
  otherType?: string
}

