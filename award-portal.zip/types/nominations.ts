export interface Nomination {
  id: string
  eventId: string
  awardType: string
  nominationType: "individual" | "team"
  nominee: {
    id: string
    name: string
    avatar: string
    initials: string
    department: string
  }
  team?: {
    id?: string
    name?: string
    members?: string[] | string
  }
  presenter?: {
    id: string
    name: string
    avatar: string
    initials: string
    department: string
  }
  nominator: {
    id: string
    name: string
    avatar: string
    initials: string
    department: string
  }
  serviceLine: string
  domainManagers: string[]
  justification: string
  impact: string
  supportingInfo?: string
  status: "pending" | "approved" | "rejected"
  endorsement?: {
    status: "pending" | "endorsed" | "rejected"
    endorsedBy?: string
    endorsedAt?: Date
    comments?: string
  }
  // Add votes and comments to the nomination
  votes?: {
    userId: string
    userName: string
    timestamp: Date
  }[]
  comments?: {
    id: string
    userId: string
    userName: string
    userAvatar: string
    userInitials: string
    text: string
    timestamp: Date
  }[]
  createdAt: Date
  updatedAt: Date
}

