// Existing imports if any
import type { User } from "@/data/mock-users"

export type NominationStatus = "draft" | "submitted" | "approved" | "rejected" | "presented" | "awarded"

export type NominationType = "individual" | "team"

export interface NominationImage {
  id: string
  url: string
  filename: string
  contentType: string
  size: number
  createdAt: string
}

export interface TangibleMetric {
  type: "headcountSaving" | "timeSaving" | "costSaving"
  value: number
  unit: string
}

export interface IntangibleJustification {
  type: "customerSatisfaction" | "internalAudit" | "riskAvoidance" | "regulatoryCompliance" | "other"
  justification: string
  otherType?: string
}

export interface BenefitAndOutcome {
  tangibleMetrics: TangibleMetric[]
  intangibleJustifications: IntangibleJustification[]
}

export interface Nominee {
  id: string
  name: string
  email: string
  department?: string
  title?: string
}

export interface Team {
  name: string
  members: string[] | Partial<User>[]
}

export interface Nomination {
  id: string
  eventId: string
  nominationType: NominationType
  nominee?: Nominee
  team?: Team
  presenter?: Nominee
  nominatorId: string
  nominatorName: string
  serviceLine: string | string[]
  domainManagers?: string[]
  awardType: string
  nominationSummary?: string
  justification?: string // Legacy field
  impact?: string // Legacy field
  benefitAndOutcome?: BenefitAndOutcome
  supportingInfo?: string
  status: NominationStatus
  createdAt: string
  updatedAt: string
  images?: NominationImage[] // New field for image attachments
}

