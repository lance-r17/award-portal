export interface TangibleMetric {
  type: "headcountSaving" | "timeSaving" | "costSaving" | "customerSatisfaction"
  value: number
  unit: string
}

export interface IntangibleJustification {
  type: "internalAudit" | "riskAvoidance" | "regulatoryCompliance" | "other"
  justification: string
  otherType?: string
}

export interface BenefitAndOutcome {
  tangibleMetrics: TangibleMetric[]
  intangibleJustifications: IntangibleJustification[]
}

export interface Nomination {
  id: string
  nomineeId: string
  nomineeName: string
  nominatorId: string
  nominatorName: string
  awardType: string
  nominationType: "individual" | "team"
  nominationSummary: string
  department: string
  createdAt: string
  status: string
  benefitAndOutcome: BenefitAndOutcome
  // ... other fields as needed
}

