import type { AwardType } from "./award"
import type { Comment } from "./comment"

export type NominationStatus = "pending" | "endorsed" | "rejected" | "awarded"

export type Nomination = {
  id: string
  eventId: string
  nomineeId: string
  nominatorId: string
  awardType: AwardType
  justification: string
  status: NominationStatus
  endorsement?: {
    endorsedBy: string
    endorsedAt: string
    comments: string
  }
  comments: Comment[]
  createdAt: string
}

