import type { Role } from "./roles"
import type { ServiceLine } from "./service-line"

/**
 * Represents a user in the system
 */
export interface User {
  // Core Required Fields
  id: string
  name: string
  email: string
  avatar: string
  initials: string

  // Role Information
  roles?: Role[] // Array of role objects - not legacy

  // Service Line Information
  serviceLine?: ServiceLine // Reference to ServiceLine object
  serviceLineId?: string // Foreign key to ServiceLine

  // Organization Information
  country?: string
  city?: string
  organization?: {
    level1?: string
    level2?: string
    level3?: string
    level4?: string
    level5?: string
  }
  department?: string

  // Professional Information
  title?: string
  bio?: string
  gcb?: string
  vendor?: string

  // Manager Relationships (Foreign Keys to other Users)
  entityManagerId?: string // Foreign key to another User
  functionalManagerId?: string // Foreign key to another User
}

