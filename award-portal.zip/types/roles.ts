/**
 * Represents a user role in the system
 */
export interface Role {
  /**
   * Unique identifier for the role
   */
  id: string

  /**
   * Display name of the role
   */
  name: string

  /**
   * Detailed description of the role's permissions and responsibilities
   */
  description: string
}

/**
 * Common role types used throughout the application
 */
export enum RoleType {
  ADMIN = "admin",
  FACILITATOR = "facilitator",
  JUDGE = "judge",
  DOMAIN_MANAGER = "domain_manager",
  EMPLOYEE = "employee",
  MANAGER = "manager",
}

/**
 * Predefined system roles with their descriptions
 */
export const SYSTEM_ROLES: Role[] = [
  {
    id: RoleType.ADMIN,
    name: "Administrator",
    description: "Full access to all system features and settings",
  },
  {
    id: RoleType.FACILITATOR,
    name: "Facilitator",
    description: "Manages award events, nominations, and judging processes",
  },
  {
    id: RoleType.JUDGE,
    name: "Judge",
    description: "Reviews and scores nominations for award events",
  },
  {
    id: RoleType.DOMAIN_MANAGER,
    name: "Domain Manager",
    description: "Approves nominations within their domain or service line",
  },
  {
    id: RoleType.EMPLOYEE,
    name: "Employee",
    description: "Standard user who can submit nominations and view public content",
  },
  {
    id: RoleType.MANAGER,
    name: "Manager",
    description: "Manages team members and can endorse their nominations",
  },
]
