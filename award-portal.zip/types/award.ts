export type AwardType = "innovation" | "teamwork" | "leadership" | "excellence"

export type AwardEvent = {
  id: string
  title: string
  description: string
  quarter: string
  nominationStart: string
  nominationEnd: string
  votingStart: string
  votingEnd: string
  announcementDate: string
  quotas: {
    [key in AwardType]: number
  }
}
