export type Comment = {
  id: string
  userId: string
  text: string
  createdAt: string
}
