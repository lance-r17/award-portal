export type User = {
  id: string
  name: string
  email: string
  department: string
  role: string
  avatar?: string
}

export type AwardType = "innovation" | "teamwork" | "leadership" | "excellence"

export type AwardEvent = {
  id: string
  title: string
  description: string
  quarter: string
  nominationStart: string
  nominationEnd: string
  votingStart: string
  votingEnd: string
  announcementDate: string
  quotas: {
    [key in AwardType]: number
  }
}

export type NominationStatus = "pending" | "endorsed" | "rejected" | "awarded"

export type Nomination = {
  id: string
  eventId: string
  nomineeId: string
  nominatorId: string
  awardType: AwardType
  justification: string
  status: NominationStatus
  endorsement?: {
    endorsedBy: string
    endorsedAt: string
    comments: string
  }
  comments: Comment[]
  createdAt: string
}

export type Comment = {
  id: string
  userId: string
  text: string
  createdAt: string
}

