export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string
          email: string
          avatar: string
          initials: string
          service_line: string
          title: string | null
          bio: string | null
          is_domain_manager: boolean
          is_judge: boolean
          is_head_judge: boolean
          is_facilitator: boolean
          is_in_judge_pool: boolean
          is_nominee: boolean
          is_nominator: boolean
          created_at: string
          updated_at: string | null
        }
        Insert: {
          id: string
          name: string
          email: string
          avatar: string
          initials: string
          service_line: string
          title?: string | null
          bio?: string | null
          is_domain_manager?: boolean
          is_judge?: boolean
          is_head_judge?: boolean
          is_facilitator?: boolean
          is_in_judge_pool?: boolean
          is_nominee?: boolean
          is_nominator?: boolean
          created_at?: string
          updated_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          email?: string
          avatar?: string
          initials?: string
          service_line?: string
          title?: string | null
          bio?: string | null
          is_domain_manager?: boolean
          is_judge?: boolean
          is_head_judge?: boolean
          is_facilitator?: boolean
          is_in_judge_pool?: boolean
          is_nominee?: boolean
          is_nominator?: boolean
          created_at?: string
          updated_at?: string | null
        }
      }
      award_events: {
        Row: {
          id: string
          title: string
          description: string | null
          start_date: string
          end_date: string
          nomination_deadline: string
          endorsement_deadline: string | null
          judging_deadline: string | null
          status: string
          created_at: string
          updated_at: string | null
          created_by: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          start_date: string
          end_date: string
          nomination_deadline: string
          endorsement_deadline?: string | null
          judging_deadline?: string | null
          status: string
          created_at?: string
          updated_at?: string | null
          created_by: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          start_date?: string
          end_date?: string
          nomination_deadline?: string
          endorsement_deadline?: string | null
          judging_deadline?: string | null
          status?: string
          created_at?: string
          updated_at?: string | null
          created_by?: string
        }
      }
      nominations: {
        Row: {
          id: string
          event_id: string
          nominee_id: string
          nominator_id: string
          presenter_id: string | null
          team_members: string[] | null
          award_type: string
          service_line: string[]
          title: string
          summary: string
          impact: string
          endorsement_count: number
          score: number | null
          status: string
          created_at: string
          updated_at: string | null
        }
        Insert: {
          id?: string
          event_id: string
          nominee_id: string
          nominator_id: string
          presenter_id?: string | null
          team_members?: string[] | null
          award_type: string
          service_line: string[]
          title: string
          summary: string
          impact: string
          endorsement_count?: number
          score?: number | null
          status?: string
          created_at?: string
          updated_at?: string | null
        }
        Update: {
          id?: string
          event_id?: string
          nominee_id?: string
          nominator_id?: string
          presenter_id?: string | null
          team_members?: string[] | null
          award_type?: string
          service_line?: string[]
          title?: string
          summary?: string
          impact?: string
          endorsement_count?: number
          score?: number | null
          status?: string
          created_at?: string
          updated_at?: string | null
        }
      }
      endorsements: {
        Row: {
          id: string
          nomination_id: string
          user_id: string
          comment: string
          is_domain_manager: boolean
          created_at: string
        }
        Insert: {
          id?: string
          nomination_id: string
          user_id: string
          comment: string
          is_domain_manager: boolean
          created_at?: string
        }
        Update: {
          id?: string
          nomination_id?: string
          user_id?: string
          comment?: string
          is_domain_manager?: boolean
          created_at?: string
        }
      }
      scores: {
        Row: {
          id: string
          nomination_id: string
          judge_id: string
          score: number
          comments: string | null
          created_at: string
          updated_at: string | null
        }
        Insert: {
          id?: string
          nomination_id: string
          judge_id: string
          score: number
          comments?: string | null
          created_at?: string
          updated_at?: string | null
        }
        Update: {
          id?: string
          nomination_id?: string
          judge_id?: string
          score?: number
          comments?: string | null
          created_at?: string
          updated_at?: string | null
        }
      }
      event_judges: {
        Row: {
          id: string
          event_id: string
          user_id: string
          is_head_judge: boolean
          created_at: string
        }
        Insert: {
          id?: string
          event_id: string
          user_id: string
          is_head_judge: boolean
          created_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          user_id?: string
          is_head_judge?: boolean
          created_at?: string
        }
      }
      event_facilitators: {
        Row: {
          id: string
          event_id: string
          user_id: string
          created_at: string
        }
        Insert: {
          id?: string
          event_id: string
          user_id: string
          created_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          user_id?: string
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
