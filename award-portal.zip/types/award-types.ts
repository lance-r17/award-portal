import { AwardEventType } from "@/types/award-events"

export type AwardTypeIcon = "users" | "compass" | "headphones" | "heart" | "lightbulb" | "sparkles"

export interface AwardType {
  id: string
  title: string
  description: string
  icon: AwardTypeIcon
  color: string
  iconColor: string
  criteria: string[]
  reward: string
  awardEventType: AwardEventType
}

