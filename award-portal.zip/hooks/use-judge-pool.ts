import { useQuery } from "@tanstack/react-query"
import { getAllUsers } from "@/data/mock-users" // Assuming this is your mock data source

// Define a type for the judge pool member
interface JudgePoolMember {
  id: string
  name: string
  email: string
  avatar?: string
  initials?: string
  organizationLevel2: string
  isHeadJudge: boolean
}

// Mock function to fetch eligible users - in a real app, this would be an API call
const fetchJudgePool = async () => {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Fetch all users
  const allUsers = getAllUsers()

  // Filter for users in the judge pool
  const judgePool = allUsers.filter((user) => user.isInJudgePool)

  // Map to JudgePoolMember
  const judgePoolMembers: JudgePoolMember[] = judgePool.map((user) => ({
    id: user.id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
    initials: user.initials,
    organizationLevel2: user.organizationLevel2 || "", // Provide a default value
    isHeadJudge: user.role?.isHeadJudge || false, // Assuming you have a role property
  }))

  return judgePoolMembers
}

export function useJudgePool() {
  return useQuery({
    queryKey: ["judgePool"],
    queryFn: fetchJudgePool,
  })
}

