"use client"

import { useState, useEffect } from "react"
import { getCurrentUser } from "@/data/mock-users"
import type { User } from "@/types/users"

export function useCurrentUser() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get the current user based on the role in localStorage
    setUser(getCurrentUser())
    setLoading(false)

    // Function to update user when role changes
    const updateUser = () => {
      setUser(getCurrentUser())
    }

    // Listen for storage events (if role changes in another tab)
    window.addEventListener("storage", updateUser)

    // Listen for our custom roleChanged event
    window.addEventListener("roleChanged", updateUser)

    return () => {
      window.removeEventListener("storage", updateUser)
      window.removeEventListener("roleChanged", updateUser)
    }
  }, [])

  return { user, loading }
}
