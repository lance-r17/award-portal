// import { PrismaClient } from "@prisma/client"
import { SYSTEM_ROLES } from "./data/role"
import { SERVICE_LINES } from "./data/service-line"
import { SAMPLE_USERS } from "./data/user"
import { SAMPLE_AWARD_EVENTS } from "./data/award-event"
import { AWARD_TYPES } from "./data/award-type"
// Add this import for event judges
import { EVENT_JUDGES } from "./data/award-event-judge"
// Add this import at the top with the other imports
import { JUDGE_POOL_DATA } from "./data/judge_pool"
// Add this import at the top with the other imports
import { nominations } from "./data/nomination"

const prisma = new PrismaClient()

/**
 * Seeds the roles table with predefined system roles
 */
async function seedRoles() {
  console.log("Seeding roles...")

  // Optional: Uncomment to clear existing roles before seeding
  // await prisma.role.deleteMany({});

  // Create each role individually to handle the predefined IDs
  const rolePromises = SYSTEM_ROLES.map((role) =>
    prisma.role.upsert({
      where: { id: role.id },
      update: {
        name: role.name,
        description: role.description,
      },
      create: {
        id: role.id,
        name: role.name,
        description: role.description,
      },
    }),
  )

  const roles = await Promise.all(rolePromises)
  console.log(`Seeded ${roles.length} roles`)

  return roles
}

/**
 * Seeds the service lines table
 */
async function seedServiceLines() {
  console.log("Seeding service lines...")

  // Optional: Uncomment to clear existing service lines before seeding
  // await prisma.serviceLine.deleteMany({});

  // Create each service line
  const serviceLinePromises = SERVICE_LINES.map((serviceLine) =>
    prisma.serviceLine.upsert({
      where: { id: serviceLine.id },
      update: {
        name: serviceLine.name,
        organizationLevel2: serviceLine.organizationLevel2,
        description: serviceLine.description,
      },
      create: {
        id: serviceLine.id,
        name: serviceLine.name,
        organizationLevel2: serviceLine.organizationLevel2,
        description: serviceLine.description,
      },
    }),
  )

  const serviceLines = await Promise.all(serviceLinePromises)
  console.log(`Seeded ${serviceLines.length} service lines`)

  return serviceLines
}

/**
 * Seeds the users table and creates user-role relationships
 */
async function seedUsers() {
  console.log("Seeding users...")

  // Optional: Uncomment to clear existing users and user roles before seeding
  // await prisma.userRole.deleteMany({});
  // await prisma.user.deleteMany({});

  // Create each user and their role relationships
  for (const userData of SAMPLE_USERS) {
    const { roles, ...userDataWithoutRoles } = userData

    // Create the user
    const user = await prisma.user.upsert({
      where: { id: userData.id },
      update: {
        ...userDataWithoutRoles,
      },
      create: {
        ...userDataWithoutRoles,
      },
    })

    // If the user has roles, create the user-role relationships
    if (roles && roles.length > 0) {
      // Delete existing role relationships for this user
      await prisma.userRole.deleteMany({
        where: { userId: user.id },
      })

      // Create new role relationships
      for (const roleId of roles) {
        await prisma.userRole.create({
          data: {
            userId: user.id,
            roleId: roleId,
          },
        })
      }
    }

    console.log(`Seeded user: ${user.name}`)
  }

  const userCount = await prisma.user.count()
  console.log(`Seeded ${userCount} users`)
}

/**
 * Seeds the award events table and creates facilitator relationships
 */
async function seedAwardEvents() {
  console.log("Seeding award events...")

  // Optional: Uncomment to clear existing award events before seeding
  // await prisma.awardEventFacilitator.deleteMany({});
  // await prisma.awardEvent.deleteMany({});

  // Create each award event and its facilitator relationships
  for (const eventData of SAMPLE_AWARD_EVENTS) {
    const { facilitatorIds, ...eventDataWithoutFacilitators } = eventData

    // Create the award event
    const awardEvent = await prisma.awardEvent.upsert({
      where: { id: eventData.id },
      update: {
        ...eventDataWithoutFacilitators,
        quotas: eventDataWithoutFacilitators.quotas as any, // Cast to any for JSON field
      },
      create: {
        ...eventDataWithoutFacilitators,
        quotas: eventDataWithoutFacilitators.quotas as any, // Cast to any for JSON field
      },
    })

    // If the event has facilitators, create the event-facilitator relationships
    if (facilitatorIds && facilitatorIds.length > 0) {
      // Delete existing facilitator relationships for this event
      await prisma.awardEventFacilitator.deleteMany({
        where: { awardEventId: awardEvent.id },
      })

      // Create new facilitator relationships
      for (const facilitatorId of facilitatorIds) {
        await prisma.awardEventFacilitator.create({
          data: {
            awardEventId: awardEvent.id,
            facilitatorId: facilitatorId,
          },
        })
      }
    }

    console.log(`Seeded award event: ${awardEvent.title}`)
  }

  const eventCount = await prisma.awardEvent.count()
  console.log(`Seeded ${eventCount} award events`)
}

/**
 * Seeds the award types table
 */
async function seedAwardTypes() {
  console.log("Seeding award types...")

  // Create each award type
  const awardTypePromises = AWARD_TYPES.map((awardType) =>
    prisma.awardType.upsert({
      where: { id: awardType.id },
      update: {
        title: awardType.title,
        description: awardType.description,
        icon: awardType.icon,
        color: awardType.color,
        iconColor: awardType.iconColor,
        criteria: awardType.criteria as any, // Cast to any for JSON field
        reward: awardType.reward,
        awardEventType: awardType.awardEventType,
        isTeamAward: awardType.isTeamAward, // Added new field
      },
      create: {
        id: awardType.id,
        title: awardType.title,
        description: awardType.description,
        icon: awardType.icon,
        color: awardType.color,
        iconColor: awardType.iconColor,
        criteria: awardType.criteria as any, // Cast to any for JSON field
        reward: awardType.reward,
        awardEventType: awardType.awardEventType,
        isTeamAward: awardType.isTeamAward, // Added new field
      },
    }),
  )

  const awardTypes = await Promise.all(awardTypePromises)
  console.log(`Seeded ${awardTypes.length} award types`)

  return awardTypes
}

/**
 * Seeds the award event judges table
 */
async function seedAwardEventJudges() {
  console.log("Seeding award event judges...")

  // Optional: Uncomment to clear existing judges before seeding
  // await prisma.awardEventJudge.deleteMany({});

  // Create each judge relationship
  for (const judgeData of EVENT_JUDGES) {
    await prisma.awardEventJudge.upsert({
      where: {
        awardEventId_judgeId: {
          awardEventId: judgeData.eventId,
          judgeId: judgeData.judgeId,
        },
      },
      update: {
        isHeadJudge: judgeData.isHeadJudge || false,
      },
      create: {
        awardEventId: judgeData.eventId,
        judgeId: judgeData.judgeId,
        isHeadJudge: judgeData.isHeadJudge || false,
      },
    })
  }

  const judgeCount = await prisma.awardEventJudge.count()
  console.log(`Seeded ${judgeCount} award event judges`)
}

// Add this function before the main function
/**
 * Seeds the judge pool table
 */
async function seedJudgePool() {
  console.log("Seeding judge pool...")

  // Optional: Uncomment to clear existing judge pool before seeding
  // await prisma.judgePool.deleteMany({});

  // Create each judge pool entry
  for (const judgePoolData of JUDGE_POOL_DATA) {
    await prisma.judgePool.upsert({
      where: {
        userId_organizationLevel2: {
          userId: judgePoolData.userId,
          organizationLevel2: judgePoolData.organizationLevel2,
        },
      },
      update: {
        isHeadJudge: judgePoolData.isHeadJudge,
      },
      create: {
        userId: judgePoolData.userId,
        organizationLevel2: judgePoolData.organizationLevel2,
        isHeadJudge: judgePoolData.isHeadJudge,
      },
    })
  }

  const judgePoolCount = await prisma.judgePool.count()
  console.log(`Seeded ${judgePoolCount} judge pool entries`)
}

// Add this function before the main function
/**
 * Seeds the nominations table and related entities
 */
async function seedNominations() {
  console.log("Seeding nominations...")

  // Optional: Uncomment to clear existing nominations and related entities before seeding
  // await prisma.nominationImage.deleteMany({});
  // await prisma.comment.deleteMany({});
  // await prisma.vote.deleteMany({});
  // await prisma.endorsement.deleteMany({});
  // await prisma.nominationDomainManager.deleteMany({});
  // await prisma.nominationServiceLine.deleteMany({});
  // await prisma.teamMember.deleteMany({});
  // await prisma.team.deleteMany({});
  // await prisma.nomination.deleteMany({});

  // Create each nomination and related entities
  for (const nominationData of nominations) {
    // First, handle team if it's a team nomination
    let teamId = null
    if (nominationData.nominationType === "team" && nominationData.team) {
      // Create the team
      const team = await prisma.team.upsert({
        where: { id: nominationData.team.id || `team-${nominationData.id}` },
        update: {
          name: nominationData.team.name,
        },
        create: {
          id: nominationData.team.id || `team-${nominationData.id}`,
          name: nominationData.team.name,
        },
      })

      teamId = team.id

      // Create team members
      if (Array.isArray(nominationData.team.members)) {
        for (const member of nominationData.team.members) {
          const memberId = typeof member === "string" ? member : member.id

          // Check if the user exists
          const userExists = await prisma.user.findUnique({
            where: { id: memberId },
          })

          if (userExists) {
            // Create team member relationship
            await prisma.teamMember.upsert({
              where: {
                teamId_userId: {
                  teamId: team.id,
                  userId: memberId,
                },
              },
              update: {},
              create: {
                teamId: team.id,
                userId: memberId,
              },
            })
          }
        }
      }
    }

    // Create the nomination
    const nomination = await prisma.nomination.upsert({
      where: { id: nominationData.id },
      update: {
        eventId: nominationData.eventId,
        nominationType: nominationData.nominationType,
        nomineeId: nominationData.nomineeId || nominationData.nominee?.id || "default-user-id",
        teamId: teamId,
        presenterId: nominationData.presenter?.id,
        nominatorId: nominationData.nominatorId || nominationData.nominator?.id || "default-user-id",
        awardType: nominationData.awardType,
        nominationSummary: nominationData.nominationSummary,
        benefitAndOutcome: nominationData.benefitAndOutcome as any,
        supportingInfo: Array.isArray(nominationData.supportingInfo)
          ? nominationData.supportingInfo
          : nominationData.supportingInfo
            ? [nominationData.supportingInfo]
            : [],
        status: nominationData.status,
      },
      create: {
        id: nominationData.id,
        eventId: nominationData.eventId,
        nominationType: nominationData.nominationType,
        nomineeId: nominationData.nomineeId || nominationData.nominee?.id || "default-user-id",
        teamId: teamId,
        presenterId: nominationData.presenter?.id,
        nominatorId: nominationData.nominatorId || nominationData.nominator?.id || "default-user-id",
        awardType: nominationData.awardType,
        nominationSummary: nominationData.nominationSummary,
        benefitAndOutcome: nominationData.benefitAndOutcome as any,
        supportingInfo: Array.isArray(nominationData.supportingInfo)
          ? nominationData.supportingInfo
          : nominationData.supportingInfo
            ? [nominationData.supportingInfo]
            : [],
        status: nominationData.status,
        createdAt: new Date(nominationData.createdAt) || new Date(),
        updatedAt: new Date(nominationData.updatedAt) || new Date(),
      },
    })

    // Create service line relationships
    if (nominationData.serviceLine) {
      const serviceLines = Array.isArray(nominationData.serviceLine)
        ? nominationData.serviceLine
        : [nominationData.serviceLine]

      for (const serviceLineId of serviceLines) {
        // Check if the service line exists
        const serviceLineExists = await prisma.serviceLine.findUnique({
          where: { id: serviceLineId },
        })

        if (serviceLineExists) {
          await prisma.nominationServiceLine.upsert({
            where: {
              nominationId_serviceLineId: {
                nominationId: nomination.id,
                serviceLineId: serviceLineId,
              },
            },
            update: {},
            create: {
              nominationId: nomination.id,
              serviceLineId: serviceLineId,
            },
          })
        }
      }
    }

    // Create domain manager relationships
    if (nominationData.domainManagers && Array.isArray(nominationData.domainManagers)) {
      for (const managerId of nominationData.domainManagers) {
        const managerIdStr = typeof managerId === "string" ? managerId : managerId.id

        // Check if the user exists
        const userExists = await prisma.user.findUnique({
          where: { id: managerIdStr },
        })

        if (userExists) {
          await prisma.nominationDomainManager.upsert({
            where: {
              nominationId_managerId: {
                nominationId: nomination.id,
                managerId: managerIdStr,
              },
            },
            update: {},
            create: {
              nominationId: nomination.id,
              managerId: managerIdStr,
            },
          })
        }
      }
    }

    // Create endorsement if it exists
    if (nominationData.endorsement) {
      await prisma.endorsement.upsert({
        where: { nominationId: nomination.id },
        update: {
          status: nominationData.endorsement.status,
          endorsedBy: nominationData.endorsement.endorsedBy,
          endorsedAt: nominationData.endorsement.endorsedAt ? new Date(nominationData.endorsement.endorsedAt) : null,
          comments: nominationData.endorsement.comments,
        },
        create: {
          nominationId: nomination.id,
          status: nominationData.endorsement.status,
          endorsedBy: nominationData.endorsement.endorsedBy,
          endorsedAt: nominationData.endorsement.endorsedAt ? new Date(nominationData.endorsement.endorsedAt) : null,
          comments: nominationData.endorsement.comments,
        },
      })
    }

    // Create votes if they exist
    if (nominationData.votes && Array.isArray(nominationData.votes)) {
      for (const vote of nominationData.votes) {
        await prisma.vote.upsert({
          where: {
            nominationId_userId: {
              nominationId: nomination.id,
              userId: vote.userId,
            },
          },
          update: {
            userName: vote.userName,
            timestamp: new Date(vote.timestamp),
          },
          create: {
            nominationId: nomination.id,
            userId: vote.userId,
            userName: vote.userName,
            timestamp: new Date(vote.timestamp),
          },
        })
      }
    }

    // Create comments if they exist
    if (nominationData.comments && Array.isArray(nominationData.comments)) {
      for (const comment of nominationData.comments) {
        await prisma.comment.upsert({
          where: { id: comment.id },
          update: {
            nominationId: nomination.id,
            userId: comment.userId,
            userName: comment.userName,
            userAvatar: comment.userAvatar,
            userInitials: comment.userInitials,
            text: comment.text,
            timestamp: new Date(comment.timestamp),
          },
          create: {
            id: comment.id,
            nominationId: nomination.id,
            userId: comment.userId,
            userName: comment.userName,
            userAvatar: comment.userAvatar,
            userInitials: comment.userInitials,
            text: comment.text,
            timestamp: new Date(comment.timestamp),
          },
        })
      }
    }

    // Create images if they exist
    if (nominationData.images && Array.isArray(nominationData.images)) {
      for (const image of nominationData.images) {
        await prisma.nominationImage.upsert({
          where: { id: image.id },
          update: {
            nominationId: nomination.id,
            url: image.url,
            filename: image.filename || `image-${image.id}`,
            contentType: image.contentType || "image/jpeg",
            size: image.size || 0,
          },
          create: {
            id: image.id,
            nominationId: nomination.id,
            url: image.url,
            filename: image.filename || `image-${image.id}`,
            contentType: image.contentType || "image/jpeg",
            size: image.size || 0,
          },
        })
      }
    }

    console.log(`Seeded nomination: ${nomination.id}`)
  }

  const nominationCount = await prisma.nomination.count()
  console.log(`Seeded ${nominationCount} nominations`)
}

// Update the main function to include the new seed function
async function main() {
  console.log(`Start seeding...`)

  try {
    // Seed in the correct order to handle relationships
    await seedRoles()
    await seedServiceLines()
    await seedUsers()
    await seedAwardEvents()
    await seedAwardTypes()
    await seedAwardEventJudges()
    await seedJudgePool() // Add this line to seed judge pool
    await seedNominations() // Add this line to seed nominations

    console.log(`Seeding finished successfully`)
  } catch (error) {
    console.error("Error during seeding:", error)
    throw error
  }
}

// Execute the seed function
main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })

