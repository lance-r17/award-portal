import { PrismaClient } from "@prisma/client"
import { SYSTEM_ROLES } from "./data/role"

const prisma = new PrismaClient()

/**
 * Seeds the roles table with predefined system roles
 */
async function seedRoles() {
  console.log("Seeding roles...")

  // Optional: Uncomment to clear existing roles before seeding
  // await prisma.role.deleteMany({});

  // Create each role individually to handle the predefined IDs
  const rolePromises = SYSTEM_ROLES.map((role) =>
    prisma.role.upsert({
      where: { id: role.id },
      update: {
        name: role.name,
        description: role.description,
      },
      create: {
        id: role.id,
        name: role.name,
        description: role.description,
      },
    }),
  )

  const roles = await Promise.all(rolePromises)
  console.log(`Seeded ${roles.length} roles`)

  return roles
}

/**
 * Main seed function
 */
async function main() {
  console.log(`Start seeding...`)

  try {
    // Seed roles
    await seedRoles()

    console.log(`Seeding finished successfully`)
  } catch (error) {
    console.error("Error during seeding:", error)
    throw error
  }
}

// Execute the seed function
main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })

