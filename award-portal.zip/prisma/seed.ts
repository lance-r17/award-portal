import { PrismaClient } from "@prisma/client"
import { SYSTEM_ROLES } from "./data/role"
import { SERVICE_LINES } from "./data/service-line"
import { SAMPLE_USERS } from "./data/user"
import { SAMPLE_AWARD_EVENTS } from "./data/award-event"
import { SAMPLE_AWARD_EVENT_JUDGES } from "./data/award-event-judge"

const prisma = new PrismaClient()

/**
 * Seeds the roles table with predefined system roles
 */
async function seedRoles() {
  console.log("Seeding roles...")

  // Optional: Uncomment to clear existing roles before seeding
  // await prisma.role.deleteMany({});

  // Create each role individually to handle the predefined IDs
  const rolePromises = SYSTEM_ROLES.map((role) =>
    prisma.role.upsert({
      where: { id: role.id },
      update: {
        name: role.name,
        description: role.description,
      },
      create: {
        id: role.id,
        name: role.name,
        description: role.description,
      },
    }),
  )

  const roles = await Promise.all(rolePromises)
  console.log(`Seeded ${roles.length} roles`)

  return roles
}

/**
 * Seeds the service lines table
 */
async function seedServiceLines() {
  console.log("Seeding service lines...")

  // Optional: Uncomment to clear existing service lines before seeding
  // await prisma.serviceLine.deleteMany({});

  // Create each service line
  const serviceLinePromises = SERVICE_LINES.map((serviceLine) =>
    prisma.serviceLine.upsert({
      where: { id: serviceLine.id },
      update: {
        name: serviceLine.name,
        organizationLevel2: serviceLine.organizationLevel2,
        description: serviceLine.description,
      },
      create: {
        id: serviceLine.id,
        name: serviceLine.name,
        organizationLevel2: serviceLine.organizationLevel2,
        description: serviceLine.description,
      },
    }),
  )

  const serviceLines = await Promise.all(serviceLinePromises)
  console.log(`Seeded ${serviceLines.length} service lines`)

  return serviceLines
}

/**
 * Seeds the users table and creates user-role relationships
 */
async function seedUsers() {
  console.log("Seeding users...")

  // Optional: Uncomment to clear existing users and user roles before seeding
  // await prisma.userRole.deleteMany({});
  // await prisma.user.deleteMany({});

  // Create each user and their role relationships
  for (const userData of SAMPLE_USERS) {
    const { roles, ...userDataWithoutRoles } = userData

    // Create the user
    const user = await prisma.user.upsert({
      where: { id: userData.id },
      update: {
        ...userDataWithoutRoles,
      },
      create: {
        ...userDataWithoutRoles,
      },
    })

    // If the user has roles, create the user-role relationships
    if (roles && roles.length > 0) {
      // Delete existing role relationships for this user
      await prisma.userRole.deleteMany({
        where: { userId: user.id },
      })

      // Create new role relationships
      for (const roleId of roles) {
        await prisma.userRole.create({
          data: {
            userId: user.id,
            roleId: roleId,
          },
        })
      }
    }

    console.log(`Seeded user: ${user.name}`)
  }

  const userCount = await prisma.user.count()
  console.log(`Seeded ${userCount} users`)
}

/**
 * Seeds the award events table and creates facilitator relationships
 */
async function seedAwardEvents() {
  console.log("Seeding award events...")

  // Optional: Uncomment to clear existing award events before seeding
  // await prisma.awardEventFacilitator.deleteMany({});
  // await prisma.awardEvent.deleteMany({});

  // Create each award event and its facilitator relationships
  for (const eventData of SAMPLE_AWARD_EVENTS) {
    const { facilitatorIds, ...eventDataWithoutFacilitators } = eventData

    // Create the award event
    const awardEvent = await prisma.awardEvent.upsert({
      where: { id: eventData.id },
      update: {
        ...eventDataWithoutFacilitators,
        quotas: eventDataWithoutFacilitators.quotas as any, // Cast to any for JSON field
      },
      create: {
        ...eventDataWithoutFacilitators,
        quotas: eventDataWithoutFacilitators.quotas as any, // Cast to any for JSON field
      },
    })

    // If the event has facilitators, create the event-facilitator relationships
    if (facilitatorIds && facilitatorIds.length > 0) {
      // Delete existing facilitator relationships for this event
      await prisma.awardEventFacilitator.deleteMany({
        where: { awardEventId: awardEvent.id },
      })

      // Create new facilitator relationships
      for (const facilitatorId of facilitatorIds) {
        await prisma.awardEventFacilitator.create({
          data: {
            awardEventId: awardEvent.id,
            facilitatorId: facilitatorId,
          },
        })
      }
    }

    console.log(`Seeded award event: ${awardEvent.title}`)
  }

  const eventCount = await prisma.awardEvent.count()
  console.log(`Seeded ${eventCount} award events`)
}

/**
 * Seeds the award event judges table
 */
async function seedAwardEventJudges() {
  console.log("Seeding award event judges...")

  // Optional: Uncomment to clear existing award event judges before seeding
  // await prisma.awardEventJudge.deleteMany({});

  // Create each award event judge relationship
  for (const judgeData of SAMPLE_AWARD_EVENT_JUDGES) {
    // Create the award event judge
    await prisma.awardEventJudge.upsert({
      where: {
        awardEventId_judgeId: {
          awardEventId: judgeData.awardEventId,
          judgeId: judgeData.judgeId,
        },
      },
      update: {
        isHeadJudge: judgeData.isHeadJudge,
        assignedAt: judgeData.assignedAt,
      },
      create: judgeData,
    })
  }

  const judgeCount = await prisma.awardEventJudge.count()
  console.log(`Seeded ${judgeCount} award event judges`)
}

/**
 * Main seed function
 */
async function main() {
  console.log(`Start seeding...`)

  try {
    // Seed in the correct order to handle relationships
    await seedRoles()
    await seedServiceLines()
    await seedUsers()
    await seedAwardEvents() // Add this line to seed award events
    await seedAwardEventJudges() // Add this line to seed award event judges

    console.log(`Seeding finished successfully`)
  } catch (error) {
    console.error("Error during seeding:", error)
    throw error
  }
}

// Execute the seed function
main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })

