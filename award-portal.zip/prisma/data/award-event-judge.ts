// Direct copy of event judge data formatted for Prisma model
export const SAMPLE_AWARD_EVENT_JUDGES = [
  // Spot Q1 2025 Judges
  { awardEventId: "spot-q1-2025", judgeId: "alex-morgan", isHeadJudge: true, assignedAt: new Date() },
  { awardEventId: "spot-q1-2025", judgeId: "jordan-lee", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q1-2025", judgeId: "casey-smith", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q1-2025", judgeId: "jamie-taylor", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q1-2025", judgeId: "quinn-martinez", isHeadJudge: false, assignedAt: new Date() },

  // Recognition Q1 2025 Judges
  { awardEventId: "recognition-q1-2025", judgeId: "alex-morgan", isHeadJudge: true, assignedAt: new Date() },
  { awardEventId: "recognition-q1-2025", judgeId: "jordan-lee", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "recognition-q1-2025", judgeId: "avery-williams", isHeadJudge: false, assignedAt: new Date() },

  // Spot Q4 2024 Judges
  { awardEventId: "spot-q4-2024", judgeId: "alex-morgan", isHeadJudge: true, assignedAt: new Date() },
  { awardEventId: "spot-q4-2024", judgeId: "jordan-lee", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q4-2024", judgeId: "casey-smith", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q4-2024", judgeId: "jamie-taylor", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q4-2024", judgeId: "avery-williams", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "spot-q4-2024", judgeId: "riley-cooper", isHeadJudge: false, assignedAt: new Date() },

  // Recognition Q4 2024 Judges
  { awardEventId: "recognition-q4-2024", judgeId: "jordan-lee", isHeadJudge: true, assignedAt: new Date() },
  { awardEventId: "recognition-q4-2024", judgeId: "alex-morgan", isHeadJudge: false, assignedAt: new Date() },
  { awardEventId: "recognition-q4-2024", judgeId: "taylor-johnson", isHeadJudge: false, assignedAt: new Date() },
]

