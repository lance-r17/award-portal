// Sample judges for events based on data/event-judges.ts
export interface EventJudge {
  eventId: string
  judgeId: string
  isHeadJudge?: boolean
}

export const EVENT_JUDGES: EventJudge[] = [
  // Spot Q1 2025 Judges
  { eventId: "spot-q1-2025", judgeId: "alex-morgan", isHeadJudge: true },
  { eventId: "spot-q1-2025", judgeId: "jordan-lee" },
  { eventId: "spot-q1-2025", judgeId: "casey-smith" },
  { eventId: "spot-q1-2025", judgeId: "jamie-taylor" },
  { eventId: "spot-q1-2025", judgeId: "quinn-martinez" },

  // Recognition Q1 2025 Judges
  { eventId: "recognition-q1-2025", judgeId: "alex-morgan", isHeadJudge: true },
  { eventId: "recognition-q1-2025", judgeId: "jordan-lee" },
  { eventId: "recognition-q1-2025", judgeId: "avery-williams" },

  // Spot Q4 2024 Judges
  { eventId: "spot-q4-2024", judgeId: "alex-morgan", isHeadJudge: true },
  { eventId: "spot-q4-2024", judgeId: "jordan-lee" },
  { eventId: "spot-q4-2024", judgeId: "casey-smith" },
  { eventId: "spot-q4-2024", judgeId: "jamie-taylor" },
  { eventId: "spot-q4-2024", judgeId: "avery-williams" },
  { eventId: "spot-q4-2024", judgeId: "riley-cooper" },

  // Recognition Q4 2024 Judges
  { eventId: "recognition-q4-2024", judgeId: "jordan-lee", isHeadJudge: true },
  { eventId: "recognition-q4-2024", judgeId: "alex-morgan" },
  { eventId: "recognition-q4-2024", judgeId: "taylor-johnson" },
]
