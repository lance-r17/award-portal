//import type { Nomination } from "@prisma/client"

// Define the types needed for the nomination data
type TeamType = {
  id: string
  name: string
  members: string[]
}

type EndorsementType = {
  status: "pending" | "endorsed" | "rejected"
  endorsedBy?: string
  endorsedAt?: Date | string
  comments: string
}

type VoteType = {
  userId: string
  userName: string
  timestamp: Date | string
}

type CommentType = {
  id: string
  userId: string
  userName: string
  userAvatar: string
  userInitials: string
  text: string
  timestamp: Date | string
}

type ImageType = {
  id: string
  url: string
  filename: string
  contentType: string
  size: number
}

type TangibleMetricType = {
  type: string
  value: number
  unit: string
}

type IntangibleJustificationType = {
  type: string
  justification: string
  otherType?: string
}

type BenefitAndOutcomeType = {
  tangibleMetrics: TangibleMetricType[]
  intangibleJustifications: IntangibleJustificationType[]
}

// Define the nomination data structure
export const nominations: Array<
  Partial<Nomination> & {
    nomineeId: string
    nominatorId: string
    presenterId?: string
    team?: TeamType
    serviceLine: string | string[]
    domainManagers?: string[]
    endorsement?: EndorsementType
    votes?: VoteType[]
    comments?: CommentType[]
    images?: ImageType[]
    benefitAndOutcome?: BenefitAndOutcomeType
    supportingInfo?: string[] | string
  }
> = [
  // Q1 2025 Nominations
  {
    id: "nom-001",
    eventId: "spot-q1-2025",
    awardType: "star-of-agile",
    nominationType: "individual",
    nomineeId: "emily-rodriguez",
    nominatorId: "michael-chen",
    serviceLine: "cloud-services",
    domainManagers: ["alex-morgan", "jordan-lee"],
    nominationSummary:
      "Emily has been instrumental in implementing agile methodologies across our team. She established a new sprint planning process that increased our velocity by 30% and reduced planning overhead. Her daily stand-ups are focused and effective, keeping the team aligned and unblocking issues quickly.\n\nThanks to Emily's agile leadership, we delivered our last project two weeks ahead of schedule. The client specifically mentioned how impressed they were with our iterative approach and responsiveness to their feedback.",
    supportingInfo: ["https://github.com/deepseek-ai/DeepSeek-R1/blob/main/DeepSeek_R1.pdf"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2025-03-10T09:15:00Z"),
      comments: "Emily has consistently demonstrated exceptional agile leadership. Fully endorse this nomination.",
    },
    createdAt: new Date("2025-03-05T10:30:00Z"),
    updatedAt: new Date("2025-03-07T14:15:00Z"),
    votes: [
      { userId: "alex-morgan", userName: "Alex Morgan", timestamp: new Date() },
      { userId: "jordan-lee", userName: "Jordan Lee", timestamp: new Date() },
      { userId: "casey-smith", userName: "Casey Smith", timestamp: new Date() },
    ],
    comments: [
      {
        id: "comment-1",
        userId: "alex-morgan",
        userName: "Alex Morgan",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "AM",
        text: "Great work, Emily! Your agile leadership has truly transformed our team.",
        timestamp: new Date(),
      },
      {
        id: "comment-2",
        userId: "jordan-lee",
        userName: "Jordan Lee",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "JL",
        text: "I agree, Emily's contributions have been invaluable. Well deserved!",
        timestamp: new Date(),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 520,
          unit: "hours/year",
        },
        {
          type: "costSaving",
          value: 45000,
          unit: "USD",
        },
        {
          type: "headcountSaving",
          value: 2,
          unit: "FTE",
        },
      ],
      intangibleJustifications: [
        {
          type: "internalAudit",
          justification: "Improved process documentation and tracking has strengthened our internal audit compliance.",
        },
        {
          type: "riskAvoidance",
          justification: "New procedures have significantly reduced operational risks in project delivery.",
        },
        {
          type: "other",
          justification: "Created new best practices for agile implementation that have been adopted across teams.",
          otherType: "Process Excellence",
        },
      ],
    },
    images: [
      {
        id: "img-001-1",
        url: "/placeholder.svg?height=600&width=800&text=Agile+Sprint+Planning+Session",
        filename: "agile-sprint-planning.png",
        contentType: "image/png",
        size: 245000,
      },
      {
        id: "img-001-2",
        url: "/placeholder.svg?height=600&width=800&text=Daily+Standup+Meeting",
        filename: "daily-standup.png",
        contentType: "image/png",
        size: 198000,
      },
      {
        id: "img-001-3",
        url: "/placeholder.svg?height=600&width=800&text=Retrospective+Results",
        filename: "retrospective-results.png",
        contentType: "image/png",
        size: 312000,
      },
    ],
  },
  {
    id: "nom-002",
    eventId: "spot-q1-2025",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nomineeId: "david-kim",
    nominatorId: "jessica-patel",
    serviceLine: "customer-experience",
    domainManagers: ["casey-smith", "avery-williams"],
    nominationSummary:
      "David went above and beyond for a customer who was experiencing critical issues with our platform. He stayed on a call for over 4 hours, working through dinner time, to ensure the customer's system was back online. He then followed up the next day to make sure everything was still working properly.\n\nThe customer was so impressed with David's dedication that they upgraded their subscription to our premium tier. They also mentioned David specifically in their renewal discussion as a key reason for continuing with our service.",
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "avery-williams",
      endorsedAt: new Date("2025-03-12T14:30:00Z"),
      comments: "David's dedication to customer satisfaction is exemplary. Strong endorsement.",
    },
    createdAt: new Date("2025-03-08T09:45:00Z"),
    updatedAt: new Date("2025-03-10T11:20:00Z"),
    votes: [
      { userId: "quinn-martinez", userName: "Quinn Martinez", timestamp: new Date() },
      { userId: "riley-thompson", userName: "Riley Thompson", timestamp: new Date() },
    ],
    comments: [
      {
        id: "comment-3",
        userId: "quinn-martinez",
        userName: "Quinn Martinez",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "QM",
        text: "David, your commitment to our customers is truly inspiring!",
        timestamp: new Date(),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 208,
          unit: "hours/year",
        },
        {
          type: "costSaving",
          value: 75000,
          unit: "USD",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Customer satisfaction increased by 25% based on post-interaction surveys.",
        },
        {
          type: "riskAvoidance",
          justification: "Prevented potential customer churn through immediate issue resolution and proactive support.",
        },
        {
          type: "regulatoryCompliance",
          justification:
            "Ensured all customer interactions and resolutions were properly documented for compliance requirements.",
        },
        {
          type: "other",
          justification: "Established new customer support protocols that have become standard practice.",
          otherType: "Service Excellence",
        },
      ],
    },
  },
  {
    id: "nom-003",
    eventId: "spot-q1-2025",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nomineeId: "sarah-johnson",
    nominatorId: "james-wilson",
    serviceLine: "digital-transformation",
    domainManagers: ["alex-morgan"],
    nominationSummary:
      "Sarah developed an innovative solution to our data processing bottleneck. She designed and implemented a new caching layer that reduced our API response times by 70%. Her solution was elegant, well-documented, and implemented with minimal disruption to existing systems.\n\nThe performance improvements from Sarah's innovation have directly impacted our user experience metrics. We've seen a 25% increase in user engagement and a 15% reduction in bounce rates since implementing her solution.",
    supportingInfo: ["https://github.com/company/project/pull/1234"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2025-03-15T10:45:00Z"),
      comments: "Sarah's innovation has transformed our platform performance. Enthusiastically endorsed.",
    },
    createdAt: new Date("2025-03-12T14:30:00Z"),
    updatedAt: new Date("2025-03-14T10:45:00Z"),
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 1200,
          unit: "hours/year",
        },
        {
          type: "costSaving",
          value: 35000,
          unit: "USD",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Improved user experience metrics led to 25% higher customer satisfaction.",
        },
        {
          type: "internalAudit",
          justification: "New caching system includes comprehensive audit trails and performance monitoring.",
        },
        {
          type: "riskAvoidance",
          justification: "Implemented redundancy and failover mechanisms to prevent system outages.",
        },
        {
          type: "regulatoryCompliance",
          justification: "Ensured data handling meets all regulatory requirements for customer data protection.",
        },
      ],
    },
  },
  {
    id: "nom-006",
    eventId: "spot-q1-2025",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "platform-team",
      name: "Platform Engineering Team",
      members: ["sarah-johnson", "michael-chen", "emily-rodriguez", "david-kim", "james-wilson"],
    },
    nomineeId: "sarah-johnson", // Primary nominee for the team
    presenterId: "sarah-johnson", // Team presenter
    nominatorId: "jessica-patel",
    serviceLine: ["digital-transformation", "cloud-services", "enterprise-solutions"],
    domainManagers: ["alex-morgan", "jordan-lee"],
    nominationSummary:
      "The Platform Engineering Team worked tirelessly to redesign our core infrastructure to support our growing customer base. They collaborated effectively across multiple time zones, maintained clear documentation, and supported each other through technical challenges. Their work exemplifies true teamwork and technical excellence.\n\nThe platform improvements have resulted in 99.99% uptime (up from 99.9%), 40% faster deployments, and the ability to handle 3x our previous peak load. These improvements directly support our company's growth targets for the year.",
    supportingInfo: ["https://company.confluence.com/platform-redesign-project"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2025-03-25T09:20:00Z"),
      comments:
        "This team has delivered exceptional results. Their collaboration and technical excellence deserve recognition.",
    },
    createdAt: new Date("2025-03-22T10:15:00Z"),
    updatedAt: new Date("2025-03-24T14:30:00Z"),
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "costSaving",
          value: 250000,
          unit: "USD",
        },
        {
          type: "timeSaving",
          value: 3120,
          unit: "hours/year",
        },
        {
          type: "headcountSaving",
          value: 3,
          unit: "FTE",
        },
      ],
      intangibleJustifications: [
        {
          type: "internalAudit",
          justification: "Implemented comprehensive system monitoring and audit trails.",
        },
        {
          type: "riskAvoidance",
          justification: "Achieved 99.99% uptime through robust architecture and failover mechanisms.",
        },
        {
          type: "regulatoryCompliance",
          justification: "Ensured infrastructure meets all security and compliance requirements.",
        },
      ],
    },
  },

  // Q4 2024 Nominations - Star of Agile
  {
    id: "nom-q4-001",
    eventId: "spot-q4-2024",
    awardType: "star-of-agile",
    nominationType: "individual",
    nomineeId: "michael-chen",
    nominatorId: "jordan-lee",
    serviceLine: "enterprise-solutions",
    domainManagers: ["jamie-taylor", "alex-morgan"],
    nominationSummary:
      "Michael has transformed our development process by implementing a tailored agile framework that addresses our unique challenges. He introduced a modified Scrum approach with specialized ceremonies that improved our team's velocity by 45% and reduced our bug backlog by 70%.\n\nHis agile coaching has helped team members at all experience levels embrace the methodology. Michael created custom training materials and mentored five junior developers who are now leading their own agile initiatives. The client has specifically praised our improved delivery cadence and transparency.",
    supportingInfo: [
      "https://company.confluence.com/agile-transformation-case-study",
      "https://github.com/company/agile-metrics-dashboard",
    ],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2024-12-05T14:30:00Z"),
      comments:
        "Michael's agile leadership has transformed not just his team but is influencing our entire delivery approach. Strongly endorsed.",
    },
    createdAt: new Date("2024-11-28T09:15:00Z"),
    updatedAt: new Date("2024-12-02T11:45:00Z"),
    votes: [
      { userId: "emily-rodriguez", userName: "Emily Rodriguez", timestamp: new Date("2024-11-29T10:30:00Z") },
      { userId: "sarah-johnson", userName: "Sarah Johnson", timestamp: new Date("2024-11-30T14:15:00Z") },
      { userId: "alex-morgan", userName: "Alex Morgan", timestamp: new Date("2024-12-01T09:45:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-agile-1",
        userId: "emily-rodriguez",
        userName: "Emily Rodriguez",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "ER",
        text: "Michael's agile framework has completely changed how we approach our work. The results speak for themselves!",
        timestamp: new Date("2024-11-29T10:35:00Z"),
      },
      {
        id: "comment-q4-agile-2",
        userId: "alex-morgan",
        userName: "Alex Morgan",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "AM",
        text: "I've implemented Michael's agile approach with two other teams and seen similar improvements. This is truly transformative work.",
        timestamp: new Date("2024-12-01T09:50:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 780,
          unit: "hours/quarter",
        },
        {
          type: "costSaving",
          value: 65000,
          unit: "USD",
        },
        {
          type: "qualityImprovement",
          value: 70,
          unit: "percent",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Client satisfaction scores for delivery process improved from 6.5 to 9.2 out of 10.",
        },
        {
          type: "teamMorale",
          justification: "Team engagement scores increased by 35% according to quarterly employee surveys.",
        },
        {
          type: "riskAvoidance",
          justification: "Improved visibility and planning reduced project risks and eliminated missed deadlines.",
        },
      ],
    },
    images: [
      {
        id: "img-q4-agile-1",
        url: "/placeholder.svg?height=600&width=800&text=Velocity+Improvement+Chart",
        filename: "velocity-improvement.png",
        contentType: "image/png",
        size: 265000,
      },
      {
        id: "img-q4-agile-2",
        url: "/placeholder.svg?height=600&width=800&text=Agile+Training+Workshop",
        filename: "agile-workshop.png",
        contentType: "image/png",
        size: 310000,
      },
    ],
  },

  // Star of Customer Service
  {
    id: "nom-q4-002",
    eventId: "spot-q4-2024",
    awardType: "star-of-customer-service",
    nominationType: "individual",
    nomineeId: "jessica-patel",
    nominatorId: "david-kim",
    serviceLine: "customer-experience",
    domainManagers: ["casey-smith"],
    nominationSummary:
      "Jessica went above and beyond to rescue a troubled client relationship that was at risk of termination. She developed a comprehensive recovery plan, personally led weekend workshops with the client team, and implemented new communication protocols that restored trust.\n\nAs a result of Jessica's exceptional customer service, not only did we retain the client (worth $1.2M annually), but they also expanded their contract to include two additional service lines, increasing the total contract value by 40%.",
    supportingInfo: ["https://company.sharepoint.com/sites/ClientSuccess/JessicaClientRecovery.pptx"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "casey-smith",
      endorsedAt: new Date("2024-12-15T13:45:00Z"),
      comments:
        "Jessica's dedication to client success exemplifies our values. Her work directly saved and expanded a major account.",
    },
    createdAt: new Date("2024-12-10T11:20:00Z"),
    updatedAt: new Date("2024-12-12T16:30:00Z"),
    votes: [
      { userId: "avery-williams", userName: "Avery Williams", timestamp: new Date("2024-12-11T09:30:00Z") },
      { userId: "quinn-martinez", userName: "Quinn Martinez", timestamp: new Date("2024-12-11T14:15:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-cs-1",
        userId: "avery-williams",
        userName: "Avery Williams",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "AW",
        text: "Jessica's client recovery approach should be our new standard. Incredible work!",
        timestamp: new Date("2024-12-11T09:35:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "revenueSaved",
          value: 1200000,
          unit: "USD",
        },
        {
          type: "revenueGrowth",
          value: 480000,
          unit: "USD",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Client satisfaction scores improved from 2/10 to 9/10 within three months.",
        },
        {
          type: "riskAvoidance",
          justification: "Prevented potential reputation damage and referral losses in the industry.",
        },
        {
          type: "other",
          justification: "Created a new client recovery playbook that has been adopted as a company standard.",
          otherType: "Knowledge Transfer",
        },
      ],
    },
  },

  // Star of Innovation
  {
    id: "nom-q4-003",
    eventId: "spot-q4-2024",
    awardType: "star-of-innovation",
    nominationType: "individual",
    nomineeId: "james-wilson",
    nominatorId: "emily-rodriguez",
    serviceLine: "digital-transformation",
    domainManagers: ["alex-morgan", "jordan-lee"],
    nominationSummary:
      "James developed a groundbreaking machine learning algorithm that improved our data processing efficiency by 65%. His innovation has been implemented across three major client projects, resulting in significant performance improvements and cost savings.\n\nThe algorithm James created is now being considered for a patent application, and has become a key differentiator in our sales presentations. Clients are specifically requesting this solution in their RFPs.",
    supportingInfo: ["https://github.com/company/ml-algorithm/docs/whitepaper.pdf"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "alex-morgan",
      endorsedAt: new Date("2024-12-10T11:30:00Z"),
      comments:
        "James's innovation represents a significant leap forward for our data processing capabilities. Strongly endorsed.",
    },
    createdAt: new Date("2024-12-05T09:15:00Z"),
    updatedAt: new Date("2024-12-08T14:20:00Z"),
    votes: [
      { userId: "michael-chen", userName: "Michael Chen", timestamp: new Date("2024-12-07T10:15:00Z") },
      { userId: "sarah-johnson", userName: "Sarah Johnson", timestamp: new Date("2024-12-07T11:30:00Z") },
      { userId: "jordan-lee", userName: "Jordan Lee", timestamp: new Date("2024-12-08T09:45:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-innovation-1",
        userId: "michael-chen",
        userName: "Michael Chen",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "MC",
        text: "This algorithm has completely transformed how we approach data processing. Amazing work, James!",
        timestamp: new Date("2024-12-07T10:20:00Z"),
      },
      {
        id: "comment-q4-innovation-2",
        userId: "sarah-johnson",
        userName: "Sarah Johnson",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "SJ",
        text: "I've implemented James's algorithm in my project and the results are incredible. Well deserved nomination!",
        timestamp: new Date("2024-12-07T14:35:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 1850,
          unit: "hours/year",
        },
        {
          type: "costSaving",
          value: 120000,
          unit: "USD",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Client feedback shows 35% higher satisfaction with processing times and results quality.",
        },
        {
          type: "riskAvoidance",
          justification: "New algorithm reduces error rates by 78%, significantly lowering operational risks.",
        },
        {
          type: "other",
          justification: "Created intellectual property that differentiates our services in the marketplace.",
          otherType: "Competitive Advantage",
        },
      ],
    },
    images: [
      {
        id: "img-q4-innovation-1",
        url: "/placeholder.svg?height=600&width=800&text=Algorithm+Performance+Graph",
        filename: "algorithm-performance.png",
        contentType: "image/png",
        size: 275000,
      },
      {
        id: "img-q4-innovation-2",
        url: "/placeholder.svg?height=600&width=800&text=Implementation+Architecture",
        filename: "implementation-architecture.png",
        contentType: "image/png",
        size: 320000,
      },
    ],
  },

  // Star of Leadership
  {
    id: "nom-q4-004",
    eventId: "spot-q4-2024",
    awardType: "star-of-leadership",
    nominationType: "individual",
    nomineeId: "alex-morgan",
    nominatorId: "sarah-johnson",
    serviceLine: "enterprise-solutions",
    domainManagers: ["jamie-taylor"],
    nominationSummary:
      "Alex has demonstrated exceptional leadership during our organization's digital transformation initiative. When the project faced significant challenges and was at risk of failing, Alex stepped in to realign the team, clarify objectives, and rebuild stakeholder confidence.\n\nAlex created a structured mentoring program that paired senior and junior team members, improving knowledge transfer and team cohesion. They also implemented a transparent decision-making framework that empowered team members while maintaining accountability. Under Alex's leadership, the project went from being 3 weeks behind schedule to delivering 2 weeks early with all key objectives met.",
    supportingInfo: ["https://company.sharepoint.com/leadership/transformation-case-study.pptx"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2024-12-18T10:15:00Z"),
      comments:
        "Alex's leadership during this critical project exemplifies what we value in our leaders. Their ability to inspire and guide the team through challenges while developing future leaders is commendable.",
    },
    createdAt: new Date("2024-12-12T14:30:00Z"),
    updatedAt: new Date("2024-12-15T09:45:00Z"),
    votes: [
      { userId: "michael-chen", userName: "Michael Chen", timestamp: new Date("2024-12-13T11:20:00Z") },
      { userId: "emily-rodriguez", userName: "Emily Rodriguez", timestamp: new Date("2024-12-14T09:30:00Z") },
      { userId: "james-wilson", userName: "James Wilson", timestamp: new Date("2024-12-14T14:45:00Z") },
      { userId: "jordan-lee", userName: "Jordan Lee", timestamp: new Date("2024-12-15T10:15:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-leadership-1",
        userId: "emily-rodriguez",
        userName: "Emily Rodriguez",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "ER",
        text: "Alex's mentorship has been transformative for my career. Their leadership style brings out the best in everyone.",
        timestamp: new Date("2024-12-14T09:35:00Z"),
      },
      {
        id: "comment-q4-leadership-2",
        userId: "jordan-lee",
        userName: "Jordan Lee",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "JL",
        text: "I've implemented Alex's decision-making framework with my own team and seen immediate improvements in our effectiveness.",
        timestamp: new Date("2024-12-15T10:20:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "timeSaving",
          value: 1200,
          unit: "hours/project",
        },
        {
          type: "costSaving",
          value: 180000,
          unit: "USD",
        },
        {
          type: "qualityImprovement",
          value: 45,
          unit: "percent",
        },
      ],
      intangibleJustifications: [
        {
          type: "teamMorale",
          justification: "Team engagement scores increased from 65% to 92% during the project.",
        },
        {
          type: "customerSatisfaction",
          justification: "Client satisfaction with project leadership improved from 6.8 to 9.5 out of 10.",
        },
        {
          type: "riskAvoidance",
          justification: "Proactive risk management prevented potential project failure and reputational damage.",
        },
        {
          type: "other",
          justification: "Created a leadership development model that is being adopted across the organization.",
          otherType: "Talent Development",
        },
      ],
    },
    images: [
      {
        id: "img-q4-leadership-1",
        url: "/placeholder.svg?height=600&width=800&text=Leadership+Workshop",
        filename: "leadership-workshop.png",
        contentType: "image/png",
        size: 290000,
      },
      {
        id: "img-q4-leadership-2",
        url: "/placeholder.svg?height=600&width=800&text=Project+Turnaround+Metrics",
        filename: "project-turnaround.png",
        contentType: "image/png",
        size: 310000,
      },
    ],
  },

  // Star of Technical Excellence
  {
    id: "nom-q4-005",
    eventId: "spot-q4-2024",
    awardType: "star-of-technical-excellence",
    nominationType: "individual",
    nomineeId: "riley-thompson",
    nominatorId: "quinn-martinez",
    serviceLine: "cloud-services",
    domainManagers: ["jordan-lee", "alex-morgan"],
    nominationSummary:
      "Riley has demonstrated exceptional technical excellence in architecting and implementing our cloud migration framework. They designed a sophisticated multi-cloud solution that optimizes cost, performance, and security while maintaining flexibility for our clients' unique requirements.\n\nRiley's technical documentation is exemplary, with detailed architecture diagrams, performance benchmarks, and security considerations that have become the gold standard across our organization. Their solution reduced cloud costs by 40% while improving performance by 35% and enhancing our security posture.",
    supportingInfo: [
      "https://github.com/company/cloud-framework",
      "https://company.confluence.com/cloud-architecture-patterns",
    ],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jordan-lee",
      endorsedAt: new Date("2024-12-08T15:30:00Z"),
      comments:
        "Riley's technical excellence has elevated our entire cloud practice. Their architecture patterns are now being adopted as company standards.",
    },
    createdAt: new Date("2024-12-02T10:45:00Z"),
    updatedAt: new Date("2024-12-05T14:20:00Z"),
    votes: [
      { userId: "michael-chen", userName: "Michael Chen", timestamp: new Date("2024-12-03T09:15:00Z") },
      { userId: "david-kim", userName: "David Kim", timestamp: new Date("2024-12-03T14:30:00Z") },
      { userId: "avery-williams", userName: "Avery Williams", timestamp: new Date("2024-12-04T11:45:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-tech-1",
        userId: "michael-chen",
        userName: "Michael Chen",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "MC",
        text: "Riley's cloud architecture is brilliant. I've implemented it for two clients with outstanding results.",
        timestamp: new Date("2024-12-03T09:20:00Z"),
      },
      {
        id: "comment-q4-tech-2",
        userId: "avery-williams",
        userName: "Avery Williams",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "AW",
        text: "The documentation Riley created has become our reference architecture. This level of technical excellence is rare.",
        timestamp: new Date("2024-12-04T11:50:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "costSaving",
          value: 320000,
          unit: "USD/year",
        },
        {
          type: "performanceImprovement",
          value: 35,
          unit: "percent",
        },
        {
          type: "timeSaving",
          value: 1500,
          unit: "hours/year",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Client feedback indicates 40% higher satisfaction with our cloud solutions.",
        },
        {
          type: "riskAvoidance",
          justification: "Enhanced security architecture has prevented potential data breaches and compliance issues.",
        },
        {
          type: "regulatoryCompliance",
          justification: "Architecture meets all industry compliance requirements with automated reporting.",
        },
        {
          type: "other",
          justification: "Created reusable architecture patterns that accelerate project delivery across teams.",
          otherType: "Knowledge Assets",
        },
      ],
    },
    images: [
      {
        id: "img-q4-tech-1",
        url: "/placeholder.svg?height=600&width=800&text=Cloud+Architecture+Diagram",
        filename: "cloud-architecture.png",
        contentType: "image/png",
        size: 340000,
      },
      {
        id: "img-q4-tech-2",
        url: "/placeholder.svg?height=600&width=800&text=Performance+Benchmarks",
        filename: "performance-benchmarks.png",
        contentType: "image/png",
        size: 280000,
      },
    ],
  },

  // All-Star Team
  {
    id: "nom-q4-006",
    eventId: "spot-q4-2024",
    awardType: "all-star-team",
    nominationType: "team",
    team: {
      id: "cloud-migration-team",
      name: "Cloud Migration Team",
      members: ["michael-chen", "david-kim", "riley-thompson", "quinn-martinez", "avery-williams"],
    },
    nomineeId: "michael-chen", // Primary nominee for the team
    presenterId: "michael-chen", // Team presenter
    nominatorId: "alex-morgan",
    serviceLine: ["cloud-services", "enterprise-solutions"],
    domainManagers: ["jordan-lee", "jamie-taylor"],
    nominationSummary:
      "The Cloud Migration Team successfully migrated our largest client's legacy infrastructure to a modern cloud platform, completing the project two months ahead of schedule and 15% under budget. The team worked seamlessly across multiple time zones, overcame significant technical challenges, and maintained exceptional documentation throughout.\n\nThis migration has reduced the client's infrastructure costs by 35%, improved system reliability from 99.5% to 99.99%, and enabled them to launch three new digital initiatives that weren't possible on their legacy platform.",
    supportingInfo: [
      "https://company.confluence.com/cloud-migration-case-study",
      "https://github.com/company/cloud-migration-tools",
    ],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2024-12-20T10:15:00Z"),
      comments:
        "This team exemplifies excellence in execution and client value delivery. Their work has set a new standard for cloud migrations.",
    },
    createdAt: new Date("2024-12-15T09:30:00Z"),
    updatedAt: new Date("2024-12-18T14:45:00Z"),
    votes: [
      { userId: "sarah-johnson", userName: "Sarah Johnson", timestamp: new Date("2024-12-16T11:20:00Z") },
      { userId: "james-wilson", userName: "James Wilson", timestamp: new Date("2024-12-16T13:45:00Z") },
      { userId: "emily-rodriguez", userName: "Emily Rodriguez", timestamp: new Date("2024-12-17T09:30:00Z") },
      { userId: "jordan-lee", userName: "Jordan Lee", timestamp: new Date("2024-12-17T14:15:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-team-1",
        userId: "sarah-johnson",
        userName: "Sarah Johnson",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "SJ",
        text: "The automation tools this team developed for the migration are incredible. They've already helped with two other client projects!",
        timestamp: new Date("2024-12-16T11:25:00Z"),
      },
      {
        id: "comment-q4-team-2",
        userId: "jordan-lee",
        userName: "Jordan Lee",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "JL",
        text: "This team's work has become our reference architecture for enterprise cloud migrations. Outstanding achievement!",
        timestamp: new Date("2024-12-17T14:20:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "costSaving",
          value: 450000,
          unit: "USD",
        },
        {
          type: "timeSaving",
          value: 4200,
          unit: "hours/year",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Client executive team specifically praised the migration in their quarterly board meeting.",
        },
        {
          type: "riskAvoidance",
          justification: "Eliminated technical debt and security vulnerabilities in legacy systems.",
        },
        {
          type: "regulatoryCompliance",
          justification: "New cloud architecture meets all industry compliance requirements with automated reporting.",
        },
      ],
    },
    images: [
      {
        id: "img-q4-team-1",
        url: "/placeholder.svg?height=600&width=800&text=Migration+Architecture+Diagram",
        filename: "migration-architecture.png",
        contentType: "image/png",
        size: 350000,
      },
      {
        id: "img-q4-team-2",
        url: "/placeholder.svg?height=600&width=800&text=Performance+Improvement+Metrics",
        filename: "performance-metrics.png",
        contentType: "image/png",
        size: 290000,
      },
    ],
  },

  // Rising Star
  {
    id: "nom-q4-007",
    eventId: "spot-q4-2024",
    awardType: "rising-star",
    nominationType: "individual",
    nomineeId: "avery-williams",
    nominatorId: "casey-smith",
    serviceLine: "customer-experience",
    domainManagers: ["jamie-taylor"],
    nominationSummary:
      "Avery has shown remarkable growth and impact in just their first year with the company. They quickly mastered our customer experience framework and then enhanced it with innovative approaches to user research and journey mapping that have been adopted across multiple projects.\n\nDespite being new to the industry, Avery led a critical client workshop that resulted in a breakthrough understanding of user pain points. Their recommendations led to a complete redesign of the client's customer portal, resulting in a 60% increase in user engagement and a 45% reduction in support tickets.",
    supportingInfo: ["https://company.sharepoint.com/ux-research/avery-case-study.pdf"],
    status: "approved",
    endorsement: {
      status: "endorsed",
      endorsedBy: "jamie-taylor",
      endorsedAt: new Date("2024-12-12T11:30:00Z"),
      comments:
        "Avery's rapid growth and immediate impact exemplify what we look for in rising talent. Their potential is extraordinary.",
    },
    createdAt: new Date("2024-12-08T14:15:00Z"),
    updatedAt: new Date("2024-12-10T09:30:00Z"),
    votes: [
      { userId: "jessica-patel", userName: "Jessica Patel", timestamp: new Date("2024-12-09T10:45:00Z") },
      { userId: "david-kim", userName: "David Kim", timestamp: new Date("2024-12-09T15:20:00Z") },
      { userId: "quinn-martinez", userName: "Quinn Martinez", timestamp: new Date("2024-12-10T11:15:00Z") },
    ],
    comments: [
      {
        id: "comment-q4-rising-1",
        userId: "jessica-patel",
        userName: "Jessica Patel",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "JP",
        text: "Avery's user research approach has transformed how we understand customer needs. Impressive work from someone so new to the team!",
        timestamp: new Date("2024-12-09T10:50:00Z"),
      },
      {
        id: "comment-q4-rising-2",
        userId: "quinn-martinez",
        userName: "Quinn Martinez",
        userAvatar: "/placeholder.svg?height=40&width=40",
        userInitials: "QM",
        text: "I've been implementing Avery's journey mapping techniques with my clients and seeing fantastic results. They're definitely a rising star!",
        timestamp: new Date("2024-12-10T11:20:00Z"),
      },
    ],
    benefitAndOutcome: {
      tangibleMetrics: [
        {
          type: "customerEngagement",
          value: 60,
          unit: "percent",
        },
        {
          type: "supportReduction",
          value: 45,
          unit: "percent",
        },
        {
          type: "revenueLift",
          value: 120000,
          unit: "USD",
        },
      ],
      intangibleJustifications: [
        {
          type: "customerSatisfaction",
          justification: "Client portal user satisfaction increased from 65% to 92% after redesign.",
        },
        {
          type: "teamMorale",
          justification: "Avery's fresh perspective has energized the entire customer experience team.",
        },
        {
          type: "other",
          justification: "Created new user research methodologies that have been adopted across the organization.",
          otherType: "Methodological Innovation",
        },
      ],
    },
    images: [
      {
        id: "img-q4-rising-1",
        url: "/placeholder.svg?height=600&width=800&text=User+Journey+Map",
        filename: "user-journey-map.png",
        contentType: "image/png",
        size: 320000,
      },
      {
        id: "img-q4-rising-2",
        url: "/placeholder.svg?height=600&width=800&text=Customer+Workshop+Session",
        filename: "customer-workshop.png",
        contentType: "image/png",
        size: 275000,
      },
    ],
  },
]

// Helper function to prepare nomination data for Prisma
export const prepareNominationsForSeed = () => {
  return nominations.map((nomination) => {
    // Ensure team has an id if it exists
    const team = nomination.team
      ? {
          ...nomination.team,
          id: nomination.team.id || `team-${nomination.id}`,
        }
      : undefined

    // Convert dates to strings if they're Date objects
    const createdAt =
      nomination.createdAt instanceof Date
        ? nomination.createdAt.toISOString()
        : typeof nomination.createdAt === "string"
          ? nomination.createdAt
          : new Date().toISOString()

    const updatedAt =
      nomination.updatedAt instanceof Date
        ? nomination.updatedAt.toISOString()
        : typeof nomination.updatedAt === "string"
          ? nomination.updatedAt
          : new Date().toISOString()

    // Process endorsement if it exists
    const endorsement = nomination.endorsement
      ? {
          ...nomination.endorsement,
          endorsedAt:
            nomination.endorsement.endorsedAt instanceof Date
              ? nomination.endorsement.endorsedAt.toISOString()
              : typeof nomination.endorsement.endorsedAt === "string"
                ? nomination.endorsement.endorsedAt
                : null,
        }
      : undefined

    // Process votes if they exist
    const votes = nomination.votes
      ? nomination.votes.map((vote) => ({
          ...vote,
          timestamp:
            vote.timestamp instanceof Date
              ? vote.timestamp.toISOString()
              : typeof vote.timestamp === "string"
                ? vote.timestamp
                : new Date().toISOString(),
        }))
      : undefined

    // Process comments if they exist
    const comments = nomination.comments
      ? nomination.comments.map((comment) => ({
          ...comment,
          timestamp:
            comment.timestamp instanceof Date
              ? comment.timestamp.toISOString()
              : typeof comment.timestamp === "string"
                ? comment.timestamp
                : new Date().toISOString(),
        }))
      : undefined

    return {
      ...nomination,
      team,
      createdAt,
      updatedAt,
      endorsement,
      votes,
      comments,
      // Ensure supportingInfo is an array
      supportingInfo: Array.isArray(nomination.supportingInfo)
        ? nomination.supportingInfo
        : nomination.supportingInfo
          ? [nomination.supportingInfo]
          : [],
      // Ensure serviceLine is an array
      serviceLine: Array.isArray(nomination.serviceLine) ? nomination.serviceLine : [nomination.serviceLine],
    }
  })
}

