/**
 * Service line seed data for the database
 */
export const SERVICE_LINES = [
  {
    id: "technology",
    name: "Technology",
    organizationLevel2: "Digital",
    description: "Software development and engineering services",
  },
  {
    id: "cloud-services",
    name: "Cloud Services",
    organizationLevel2: "Digital",
    description: "Cloud infrastructure and platform services",
  },
  {
    id: "data-analytics",
    name: "Data Analytics",
    organizationLevel2: "Digital",
    description: "Data processing and business intelligence solutions",
  },
  {
    id: "cybersecurity",
    name: "Cybersecurity",
    organizationLevel2: "Digital",
    description: "Security solutions and risk management",
  },
  {
    id: "enterprise-solutions",
    name: "Enterprise Solutions",
    organizationLevel2: "Business",
    description: "Enterprise-wide business applications and systems",
  },
  {
    id: "customer-experience",
    name: "Customer Experience",
    organizationLevel2: "Business",
    description: "Customer-focused design and experience solutions",
  },
  {
    id: "financial-services",
    name: "Financial Services",
    organizationLevel2: "Industry",
    description: "Solutions for banking, insurance, and financial institutions",
  },
  {
    id: "healthcare-solutions",
    name: "Healthcare Solutions",
    organizationLevel2: "Industry",
    description: "Healthcare technology and process solutions",
  },
]

