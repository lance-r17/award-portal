export interface AwardEventSeed {
  id: string
  title: string
  slug: string
  type: string
  description: string
  quarter: string
  theme: string | null
  currentStage: string
  status: string
  nominationStartDate: Date
  nominationEndDate: Date
  presentationStartDate: Date
  presentationEndDate: Date
  resultStartDate: Date
  resultEndDate: Date
  isActive: boolean
  createdById: string
  facilitatorIds: string[]
  announcementDate: Date | null
  quotas: Record<string, number>
  createdAt: Date
  updatedAt: Date
  publishedAt: Date | null
}

export const SAMPLE_AWARD_EVENTS: AwardEventSeed[] = [
  {
    id: "spot-q1-2025",
    title: "Q1 2025 Spot Awards",
    slug: "q1-2025-spot-awards",
    type: "spot",
    description: "Recognizing outstanding contributions in the first quarter of 2025.",
    quarter: "Q1 2025",
    theme: "Innovation & Excellence",
    currentStage: "nomination",
    status: "published",
    nominationStartDate: new Date("2025-01-15T00:00:00Z"),
    nominationEndDate: new Date("2025-03-31T23:59:59Z"),
    presentationStartDate: new Date("2025-04-01T00:00:00Z"),
    presentationEndDate: new Date("2025-04-15T23:59:59Z"),
    resultStartDate: new Date("2025-04-16T00:00:00Z"),
    resultEndDate: new Date("2025-04-30T23:59:59Z"),
    isActive: true,
    createdById: "admin-user",
    facilitatorIds: ["jane-smith", "alex-morgan"],
    announcementDate: new Date("2025-04-30T12:00:00Z"),
    quotas: {
      "star-of-agile": 3,
      "star-of-customer-service": 2,
      "star-of-innovation": 3,
      "star-of-leadership": 2,
      "star-of-engagement": 2,
      "all-star-team": 1,
    },
    createdAt: new Date("2025-01-01T10:00:00Z"),
    updatedAt: new Date("2025-01-10T14:30:00Z"),
    publishedAt: new Date("2025-01-12T09:00:00Z"),
  },
  {
    id: "recognition-q1-2025",
    title: "Q1 2025 Recognition Awards",
    slug: "q1-2025-recognition-awards",
    type: "recognition",
    description: "Formal recognition for significant achievements in Q1 2025.",
    quarter: "Q1 2025",
    theme: "Leadership & Impact",
    currentStage: "nomination",
    status: "published",
    nominationStartDate: new Date("2025-01-15T00:00:00Z"),
    nominationEndDate: new Date("2025-03-31T23:59:59Z"),
    presentationStartDate: new Date("2025-04-01T00:00:00Z"),
    presentationEndDate: new Date("2025-04-15T23:59:59Z"),
    resultStartDate: new Date("2025-04-16T00:00:00Z"),
    resultEndDate: new Date("2025-04-30T23:59:59Z"),
    isActive: true,
    createdById: "admin-user",
    facilitatorIds: ["jordan-lee"],
    announcementDate: new Date("2025-04-30T14:00:00Z"),
    quotas: {
      excellence: 2,
      leadership: 2,
      innovation: 3,
      "values-champion": 2,
      impact: 1,
    },
    createdAt: new Date("2025-01-05T11:30:00Z"),
    updatedAt: new Date("2025-01-08T16:45:00Z"),
    publishedAt: new Date("2025-01-10T10:15:00Z"),
  },
  {
    id: "spot-q4-2024",
    title: "Q4 2024 Spot Awards",
    slug: "q4-2024-spot-awards",
    type: "spot",
    description: "Recognizing outstanding contributions in the fourth quarter of 2024.",
    quarter: "Q4 2024",
    theme: "Customer Excellence",
    currentStage: "result",
    status: "published",
    nominationStartDate: new Date("2024-10-15T00:00:00Z"),
    nominationEndDate: new Date("2024-11-15T23:59:59Z"),
    presentationStartDate: new Date("2024-11-16T00:00:00Z"),
    presentationEndDate: new Date("2024-12-01T23:59:59Z"),
    resultStartDate: new Date("2024-12-02T00:00:00Z"),
    resultEndDate: new Date("2024-12-15T23:59:59Z"),
    isActive: false,
    createdById: "admin-user",
    facilitatorIds: ["jane-smith"],
    announcementDate: new Date("2024-12-15T15:00:00Z"),
    quotas: {
      "star-of-agile": 2,
      "star-of-customer-service": 3,
      "star-of-innovation": 2,
      "star-of-leadership": 2,
      "star-of-engagement": 3,
      "all-star-team": 1,
    },
    createdAt: new Date("2024-10-01T09:00:00Z"),
    updatedAt: new Date("2024-10-05T13:20:00Z"),
    publishedAt: new Date("2024-10-10T11:00:00Z"),
  },
  {
    id: "recognition-q4-2024",
    title: "Q4 2024 Recognition Awards",
    slug: "q4-2024-recognition-awards",
    type: "recognition",
    description: "Formal recognition for significant achievements in Q4 2024.",
    quarter: "Q4 2024",
    theme: "Innovation & Collaboration",
    currentStage: "result",
    status: "published",
    nominationStartDate: new Date("2024-10-15T00:00:00Z"),
    nominationEndDate: new Date("2024-11-30T23:59:59Z"),
    presentationStartDate: new Date("2024-12-01T00:00:00Z"),
    presentationEndDate: new Date("2024-12-15T23:59:59Z"),
    resultStartDate: new Date("2024-12-16T00:00:00Z"),
    resultEndDate: new Date("2024-12-31T23:59:59Z"),
    isActive: false,
    createdById: "admin-user",
    facilitatorIds: ["alex-morgan"],
    announcementDate: new Date("2024-12-31T16:00:00Z"),
    quotas: {
      excellence: 3,
      leadership: 2,
      innovation: 2,
      "values-champion": 3,
      impact: 1,
    },
    createdAt: new Date("2024-10-05T14:00:00Z"),
    updatedAt: new Date("2024-10-10T09:30:00Z"),
    publishedAt: new Date("2024-10-12T10:45:00Z"),
  },
  {
    id: "spot-q2-2025-draft",
    title: "Q2 2025 Spot Awards",
    slug: "q2-2025-spot-awards-draft",
    type: "spot",
    description: "Recognizing outstanding contributions in the second quarter of 2025.",
    quarter: "Q2 2025",
    theme: "Agility & Resilience",
    currentStage: "nomination",
    status: "draft",
    nominationStartDate: new Date("2025-04-15T00:00:00Z"),
    nominationEndDate: new Date("2025-05-15T23:59:59Z"),
    presentationStartDate: new Date("2025-05-16T00:00:00Z"),
    presentationEndDate: new Date("2025-06-01T23:59:59Z"),
    resultStartDate: new Date("2025-06-02T00:00:00Z"),
    resultEndDate: new Date("2025-06-15T23:59:59Z"),
    isActive: false,
    createdById: "current-user",
    facilitatorIds: ["jane-smith"],
    announcementDate: new Date("2025-06-15T14:00:00Z"),
    quotas: {
      "star-of-agile": 2,
      "star-of-customer-service": 2,
      "star-of-innovation": 3,
      "star-of-leadership": 3,
      "star-of-engagement": 2,
      "all-star-team": 1,
    },
    createdAt: new Date("2025-03-20T11:00:00Z"),
    updatedAt: new Date("2025-03-20T11:00:00Z"),
    publishedAt: null,
  },
]

