export interface JudgePoolData {
  userId: string
  organizationLevel2: string
  isHeadJudge: boolean
}

export const JUDGE_POOL_DATA: JudgePoolData[] = [
  // Technology judges
  {
    userId: "alex-morgan",
    organizationLevel2: "cto",
    isHeadJudge: true,
  },
  {
    userId: "jordan-lee",
    organizationLevel2: "cto",
    isHeadJudge: false,
  },
  {
    userId: "casey-smith",
    organizationLevel2: "cto",
    isHeadJudge: false,
  },

  // Finance judges
  {
    userId: "jamie-taylor",
    organizationLevel2: "cto",
    isHeadJudge: true,
  },
  {
    userId: "quinn-martinez",
    organizationLevel2: "cto",
    isHeadJudge: false,
  },

  // Operations judges
  {
    userId: "taylor-johnson",
    organizationLevel2: "cto",
    isHeadJudge: true,
  },
  {
    userId: "avery-williams",
    organizationLevel2: "cto",
    isHeadJudge: false,
  },

  // Human Resources judges
  {
    userId: "riley-cooper",
    organizationLevel2: "cto",
    isHeadJudge: true,
  },
]

