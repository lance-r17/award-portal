import { NextResponse } from "next/server"
import { getAllUsers } from "@/data/mock-users"

export async function POST(request, { params }) {
  const { id } = params

  // Get all users from mock data
  const allUsers = getAllUsers()

  // Find the user
  const user = allUsers.find((u) => u.id === id)

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  // Create updated user with inactive status
  const updatedUser = { ...user, status: "inactive" }

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  return NextResponse.json(updatedUser)
}

