import { NextResponse } from "next/server"
import { getAllUsers } from "@/data/mock-users"

export async function GET(request) {
  const { searchParams } = new URL(request.url)

  // Extract query parameters
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")
  const search = searchParams.get("search") || ""
  const role = searchParams.get("role") || ""
  const sort = searchParams.get("sort") || "name"
  const order = searchParams.get("order") || "asc"

  // Get all users from mock data
  const allUsers = getAllUsers()

  // Filter users based on search query
  let filteredUsers = [...allUsers]

  if (search) {
    const searchLower = search.toLowerCase()
    filteredUsers = filteredUsers.filter(
      (user) =>
        user.name.toLowerCase().includes(searchLower) ||
        user.email.toLowerCase().includes(searchLower) ||
        (user.title && user.title.toLowerCase().includes(searchLower)),
    )
  }

  // Filter by role
  if (role && role !== "all") {
    filteredUsers = filteredUsers.filter((user) => user.roles && user.roles.some((r) => r.id === role))
  }

  // Sort users
  filteredUsers.sort((a, b) => {
    let valueA = a[sort]
    let valueB = b[sort]

    // Handle nested properties
    if (sort.includes(".")) {
      const parts = sort.split(".")
      valueA = parts.reduce((obj, key) => obj && obj[key], a)
      valueB = parts.reduce((obj, key) => obj && obj[key], b)
    }

    // Handle string comparison
    if (typeof valueA === "string" && typeof valueB === "string") {
      return order === "asc" ? valueA.localeCompare(valueB) : valueB.localeCompare(valueA)
    }

    // Handle number comparison
    return order === "asc" ? valueA - valueB : valueB - valueA
  })

  // Calculate pagination
  const total = filteredUsers.length
  const totalPages = Math.ceil(total / limit)
  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedUsers = filteredUsers.slice(startIndex, endIndex)

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  return NextResponse.json({
    users: paginatedUsers,
    pagination: {
      total,
      pages: totalPages,
      current: page,
      limit,
    },
  })
}

export async function POST(request) {
  const userData = await request.json()

  // Generate a unique ID
  const newUser = {
    ...userData,
    id: `user-${Date.now()}`,
    status: userData.status || "active",
  }

  // In a real implementation, we would add to the database
  // For now, we'll just simulate success

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  return NextResponse.json(newUser)
}

