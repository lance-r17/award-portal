import { type NextRequest, NextResponse } from "next/server"
import {
  sendNominationSubmittedEmail,
  sendNominationReceivedEmail,
  sendJudgeAssignmentEmail,
  sendWinnerAnnouncementEmail,
  sendCommentNotificationEmail,
} from "@/services/email"

export async function POST(request: NextRequest) {
  try {
    const { templateType, email, data } = await request.json()

    let result

    switch (templateType) {
      case "nomination-submitted":
        result = await sendNominationSubmittedEmail(email, data)
        break
      case "nomination-received":
        result = await sendNominationReceivedEmail(email, data)
        break
      case "judge-assignment":
        result = await sendJudgeAssignmentEmail(email, data)
        break
      case "winner-announcement":
        result = await sendWinnerAnnouncementEmail(email, data)
        break
      case "comment-notification":
        result = await sendCommentNotificationEmail(email, data)
        break
      default:
        return NextResponse.json({ error: "Invalid template type" }, { status: 400 })
    }

    return NextResponse.json({ success: true, result })
  } catch (error) {
    console.error("Error sending test email:", error)
    return NextResponse.json({ error: "Failed to send test email" }, { status: 500 })
  }
}

