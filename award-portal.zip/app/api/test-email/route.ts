import { NextResponse } from "next/server"
import * as EmailService from "@/services/email"

export async function POST(request: Request) {
  try {
    const { template, email, data } = await request.json()

    let result

    switch (template) {
      case "nomination-submitted":
        result = await EmailService.sendNominationSubmittedEmail(email, data)
        break
      case "nomination-received":
        result = await EmailService.sendNominationReceivedEmail(email, data)
        break
      case "judge-assignment":
        result = await EmailService.sendJudgeAssignmentEmail(email, data)
        break
      case "winner-announcement":
        result = await EmailService.sendWinnerAnnouncementEmail(email, data)
        break
      case "comment-notification":
        result = await EmailService.sendCommentNotificationEmail(email, data)
        break
      default:
        return NextResponse.json({ error: "Invalid template type" }, { status: 400 })
    }

    return NextResponse.json({ success: true, result })
  } catch (error) {
    console.error("Error sending test email:", error)
    return NextResponse.json({ error: "Failed to send test email" }, { status: 500 })
  }
}

