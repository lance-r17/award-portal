import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { EmployeeRecognitionForm } from "@/components/employee-recognition-form"
import { RecentRecognitions } from "@/components/recent-recognitions"
import { RecognitionStats } from "@/components/recognition-stats"
import { TopEmployees } from "@/components/top-employees"

export default function DashboardPage() {
  return (
    <DashboardShell>
      <DashboardHeader
        heading="Employee Recognition Dashboard"
        text="Celebrate achievements and recognize your colleagues."
      />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <RecognitionStats className="lg:col-span-2" />
        <TopEmployees className="lg:col-span-1 md:col-span-2" />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <EmployeeRecognitionForm />
        <RecentRecognitions />
      </div>
    </DashboardShell>
  )
}

