"use client"

import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardNominationForm } from "@/components/award/award-nomination-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Award, Heart, Shield, Trophy, Users } from "lucide-react"
import Link from "next/link"

const recognitionAwardTypes = [
  {
    id: "excellence",
    title: "Excellence Award",
    description: "For consistently delivering exceptional results and maintaining high standards.",
    icon: Trophy,
    color: "bg-amber-100 dark:bg-amber-900",
    iconColor: "text-amber-600 dark:text-amber-400",
    criteria: [
      "Consistently exceeds performance expectations",
      "Delivers high-quality work that sets standards for others",
      "Demonstrates mastery in their field of expertise",
      "Achieves significant results that impact the business",
    ],
    reward: "$500 bonus and recognition at quarterly town hall",
  },
  {
    id: "leadership",
    title: "Leadership Award",
    description: "For exemplary leadership that inspires and motivates others to achieve their best.",
    icon: Users,
    color: "bg-blue-100 dark:bg-blue-900",
    iconColor: "text-blue-600 dark:text-blue-400",
    criteria: [
      "Inspires and motivates team members to achieve their best",
      "Provides clear direction and guidance during challenging times",
      "Develops team members' skills and supports their growth",
      "Creates an inclusive environment where everyone can contribute",
    ],
    reward: "$750 bonus and leadership development opportunity",
  },
  {
    id: "innovation",
    title: "Innovation Award",
    description: "For developing creative solutions that drive significant improvements or new opportunities.",
    icon: Award,
    color: "bg-purple-100 dark:bg-purple-900",
    iconColor: "text-purple-600 dark:text-purple-400",
    criteria: [
      "Develops innovative solutions to complex problems",
      "Creates new processes or products that benefit the company",
      "Challenges conventional thinking and explores new approaches",
      "Implements changes that result in significant improvements",
    ],
    reward: "$750 bonus and innovation workshop participation",
  },
  {
    id: "values-champion",
    title: "Values Champion",
    description: "For consistently demonstrating and promoting company values in all actions.",
    icon: Heart,
    color: "bg-red-100 dark:bg-red-900",
    iconColor: "text-red-600 dark:text-red-400",
    criteria: [
      "Consistently demonstrates company values in daily actions",
      "Serves as a role model for others in upholding company culture",
      "Makes decisions that reflect company values, even when difficult",
      "Promotes and reinforces values among team members",
    ],
    reward: "$500 bonus and feature in company newsletter",
  },
  {
    id: "impact",
    title: "Impact Award",
    description: "For contributions that have a significant positive impact on business results.",
    icon: Shield,
    color: "bg-green-100 dark:bg-green-900",
    iconColor: "text-green-600 dark:text-green-400",
    criteria: [
      "Delivers work that significantly impacts business results",
      "Implements changes that lead to measurable improvements",
      "Contributes to achieving important company objectives",
      "Creates value that extends beyond their immediate responsibilities",
    ],
    reward: "$1,000 bonus and recognition at annual company event",
  },
]

export default function RewardsRecognitionPage() {
  return (
    <DashboardShell>
      <div className="mb-4">
        <Link href="/awards" className="flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Awards
        </Link>
      </div>

      <DashboardHeader
        heading="Rewards & Recognition"
        text="Formal recognition for significant achievements and long-term contributions."
      />

      <Tabs defaultValue="nominate" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="nominate">Nominate a Colleague</TabsTrigger>
          <TabsTrigger value="about">About Rewards & Recognition</TabsTrigger>
        </TabsList>

        <TabsContent value="nominate" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Select Award Type</CardTitle>
              <CardDescription>
                Choose the type of award that best matches the achievement you want to recognize.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {recognitionAwardTypes.map((award) => (
                  <div
                    key={award.id}
                    className="rounded-lg border p-4 cursor-pointer transition-all hover:border-primary hover:shadow-sm"
                    onClick={() => {
                      // In a real app, this would set the selected award type
                      document.getElementById("nomination-form")?.scrollIntoView({ behavior: "smooth" })
                    }}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`rounded-full p-2 ${award.color}`}>
                        <award.icon className={`h-5 w-5 ${award.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="font-medium">{award.title}</h3>
                        <p className="text-sm text-muted-foreground">{award.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div id="nomination-form">
            <AwardNominationForm awardType="recognition" />
          </div>
        </TabsContent>

        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>About Rewards & Recognition</CardTitle>
              <CardDescription>
                Our formal recognition program for significant achievements and contributions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                The Rewards & Recognition program is designed to acknowledge significant achievements, long-term
                contributions, and exemplary behavior that aligns with our company values. These awards are more formal
                than Spot Awards and typically recognize larger accomplishments or sustained performance over time.
              </p>

              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium mb-2">Program Overview</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Nominations are reviewed by a committee of leaders</li>
                  <li>Awards are presented quarterly at company town halls</li>
                  <li>Recipients receive both monetary rewards and public recognition</li>
                  <li>Winners are featured in company communications</li>
                  <li>Annual award winners are honored at the year-end celebration</li>
                </ul>
              </div>

              <h4 className="font-medium">Award Categories</h4>
              <div className="space-y-4">
                {recognitionAwardTypes.map((award) => (
                  <div key={award.id} className="rounded-lg border p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`rounded-full p-1.5 ${award.color}`}>
                        <award.icon className={`h-4 w-4 ${award.iconColor}`} />
                      </div>
                      <h5 className="font-medium">{award.title}</h5>
                    </div>
                    <p className="text-sm mb-3">{award.description}</p>
                    <div className="space-y-2">
                      <h6 className="text-sm font-medium">Criteria:</h6>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        {award.criteria.map((criterion, index) => (
                          <li key={index}>{criterion}</li>
                        ))}
                      </ul>
                      <p className="text-sm font-medium mt-2">
                        Reward: <span className="text-muted-foreground">{award.reward}</span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="rounded-lg border p-4 mt-6">
                <h4 className="font-medium mb-2">Nomination Process</h4>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Submit Nomination</span>
                    <p className="text-sm text-muted-foreground">
                      Complete the nomination form with detailed information about the achievement.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Committee Review</span>
                    <p className="text-sm text-muted-foreground">
                      A committee of leaders reviews all nominations and selects recipients.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Notification</span>
                    <p className="text-sm text-muted-foreground">
                      Both nominators and recipients are notified of the decision.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Award Presentation</span>
                    <p className="text-sm text-muted-foreground">
                      Awards are presented at quarterly town halls or special events.
                    </p>
                  </li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}

