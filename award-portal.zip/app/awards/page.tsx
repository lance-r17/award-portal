"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardEventCard } from "@/components/award-event-card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, Filter, Zap } from "lucide-react"
import { getActiveAwardEvents, getActiveAwardEventsByType, awardEvents } from "@/data/award-events"
import { useRouter } from "next/navigation"
import { CreateAwardEventDrawer } from "@/components/create-award-event-drawer"

export default function AwardsPage() {
  const router = useRouter()
  const [showPastEvents, setShowPastEvents] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  // Filter events based on active status
  const filteredEvents = showPastEvents ? awardEvents : getActiveAwardEvents()

  // Get active events by type
  const activeSpotEvents = getActiveAwardEventsByType("spot")
  const activeRecognitionEvents = getActiveAwardEventsByType("recognition")

  // Function to view a specific event
  const viewEvent = (eventId: string, eventType: string) => {
    if (eventType === "spot") {
      router.push(`/awards/spot-awards/${eventId}`)
    } else {
      // For recognition events, keep the original path structure
      router.push(`/awards/${eventType}/${eventId}`)
    }
  }

  return (
    <DashboardShell>
      <div className="flex items-center justify-between">
        <DashboardHeader heading="Awards" text="Nominate colleagues for various awards and recognitions." />
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowPastEvents(!showPastEvents)}>
            <Filter className="mr-2 h-4 w-4" />
            {showPastEvents ? "Show Active Only" : "Show Past Events"}
          </Button>

          <CreateAwardEventDrawer />
        </div>
      </div>

      <div className="grid gap-6">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Awards</TabsTrigger>
            <TabsTrigger value="spot">Spot Awards</TabsTrigger>
            <TabsTrigger value="recognition">Rewards & Recognition</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            {filteredEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents.map((event) => (
                  <div key={event.id} onClick={() => viewEvent(event.id, event.type)} className="cursor-pointer">
                    <AwardEventCard event={event} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Award className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Active Award Events</h3>
                <p className="text-muted-foreground mt-2 mb-6">There are no active award events at this time.</p>
                <CreateAwardEventDrawer buttonVariant="default" buttonSize="default" />
              </div>
            )}
          </TabsContent>

          <TabsContent value="spot">
            {activeSpotEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeSpotEvents.map((event) => (
                  <div key={event.id} onClick={() => viewEvent(event.id, event.type)} className="cursor-pointer">
                    <AwardEventCard key={event.id} event={event} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Zap className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Active Spot Award Events</h3>
                <p className="text-muted-foreground mt-2 mb-6">There are no active spot award events at this time.</p>
                <CreateAwardEventDrawer
                  buttonText="Create Spot Award Event"
                  buttonVariant="default"
                  buttonSize="default"
                />
              </div>
            )}
          </TabsContent>

          <TabsContent value="recognition">
            {activeRecognitionEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeRecognitionEvents.map((event) => (
                  <div key={event.id} onClick={() => viewEvent(event.id, event.type)} className="cursor-pointer">
                    <AwardEventCard key={event.id} event={event} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Award className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Active Recognition Award Events</h3>
                <p className="text-muted-foreground mt-2 mb-6">
                  There are no active recognition award events at this time.
                </p>
                <CreateAwardEventDrawer
                  buttonText="Create Recognition Award Event"
                  buttonVariant="default"
                  buttonSize="default"
                />
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardShell>
  )
}

