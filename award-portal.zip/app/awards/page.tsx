import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardTypeCard } from "@/components/award-type-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, Zap } from "lucide-react"
import Link from "next/link"

export default function AwardsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Awards" text="Nominate colleagues for various awards and recognitions." />

      <div className="grid gap-6">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Awards</TabsTrigger>
            <TabsTrigger value="spot">Spot Awards</TabsTrigger>
            <TabsTrigger value="recognition">Rewards & Recognition</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-2">
              <AwardTypeCard
                title="Spot Awards"
                description="Immediate recognition for outstanding contributions and specific achievements."
                icon={Zap}
                href="/awards/spot-awards"
                color="bg-amber-100 dark:bg-amber-900"
                iconColor="text-amber-600 dark:text-amber-400"
              />

              <AwardTypeCard
                title="Rewards & Recognition"
                description="Formal recognition for significant achievements and long-term contributions."
                icon={Award}
                href="/awards/rewards-recognition"
                color="bg-blue-100 dark:bg-blue-900"
                iconColor="text-blue-600 dark:text-blue-400"
              />
            </div>

            <div className="rounded-lg border p-6">
              <h3 className="text-lg font-medium mb-2">About Our Awards Program</h3>
              <p className="text-muted-foreground mb-4">
                Our awards program is designed to recognize and celebrate the outstanding contributions of our
                employees. We offer two main categories of awards:
              </p>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium">Spot Awards</h4>
                  <p className="text-sm text-muted-foreground">
                    Immediate recognition for specific actions or achievements. These awards can be given at any time to
                    acknowledge exceptional work.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium">Rewards & Recognition</h4>
                  <p className="text-sm text-muted-foreground">
                    Formal recognition for significant achievements, long-term contributions, and exemplary behavior
                    that aligns with our company values.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="spot">
            <div className="flex flex-col gap-4">
              <p className="text-muted-foreground">
                Spot Awards are immediate recognitions for outstanding contributions and specific achievements.
              </p>
              <Link href="/awards/spot-awards" className="text-primary hover:underline font-medium">
                Go to Spot Awards →
              </Link>
            </div>
          </TabsContent>

          <TabsContent value="recognition">
            <div className="flex flex-col gap-4">
              <p className="text-muted-foreground">
                Rewards & Recognition are formal acknowledgments for significant achievements and long-term
                contributions.
              </p>
              <Link href="/awards/rewards-recognition" className="text-primary hover:underline font-medium">
                Go to Rewards & Recognition →
              </Link>
            </div>
          </TabsContent>
        </Tabs>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="rounded-lg border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                <span className="text-green-600 font-medium">42</span>
              </div>
              <h3 className="font-medium">Awards Given This Month</h3>
            </div>
            <p className="text-sm text-muted-foreground">Recognitions across all departments and award types.</p>
          </div>

          <div className="rounded-lg border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
                <span className="text-purple-600 font-medium">12</span>
              </div>
              <h3 className="font-medium">Your Nominations</h3>
            </div>
            <p className="text-sm text-muted-foreground">Colleagues you've nominated for awards this quarter.</p>
          </div>

          <div className="rounded-lg border p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center">
                <span className="text-amber-600 font-medium">3</span>
              </div>
              <h3 className="font-medium">Your Awards</h3>
            </div>
            <p className="text-sm text-muted-foreground">Awards you've received from your colleagues.</p>
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}

