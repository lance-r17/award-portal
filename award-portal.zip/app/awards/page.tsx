"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardEventCard } from "@/components/award-event-card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, CalendarPlus, Filter, Plus, Zap } from "lucide-react"
import { getActiveAwardEvents, getActiveAwardEventsByType, awardEvents } from "@/data/award-events"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { CreateAwardEventForm } from "@/components/create-award-event-form"

export default function AwardsPage() {
  const [showPastEvents, setShowPastEvents] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  // Filter events based on active status
  const filteredEvents = showPastEvents ? awardEvents : getActiveAwardEvents()

  // Get active events by type
  const activeSpotEvents = getActiveAwardEventsByType("spot")
  const activeRecognitionEvents = getActiveAwardEventsByType("recognition")

  return (
    <DashboardShell>
      <div className="flex items-center justify-between">
        <DashboardHeader heading="Awards" text="Nominate colleagues for various awards and recognitions." />
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowPastEvents(!showPastEvents)}>
            <Filter className="mr-2 h-4 w-4" />
            {showPastEvents ? "Show Active Only" : "Show Past Events"}
          </Button>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <CalendarPlus className="mr-2 h-4 w-4" />
                Create Award Event
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Create New Award Event</DialogTitle>
                <DialogDescription>
                  Set up a new award event with nomination, presentation, and result stages.
                </DialogDescription>
              </DialogHeader>
              <CreateAwardEventForm />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-6">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Awards</TabsTrigger>
            <TabsTrigger value="spot">Spot Awards</TabsTrigger>
            <TabsTrigger value="recognition">Rewards & Recognition</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            {filteredEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents.map((event) => (
                  <AwardEventCard key={event.id} event={event} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Award className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Active Award Events</h3>
                <p className="text-muted-foreground mt-2 mb-6">There are no active award events at this time.</p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Award Event
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="spot">
            {activeSpotEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeSpotEvents.map((event) => (
                  <AwardEventCard key={event.id} event={event} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Zap className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Active Spot Award Events</h3>
                <p className="text-muted-foreground mt-2 mb-6">There are no active spot award events at this time.</p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Spot Award Event
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="recognition">
            {activeRecognitionEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeRecognitionEvents.map((event) => (
                  <AwardEventCard key={event.id} event={event} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Award className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Active Recognition Award Events</h3>
                <p className="text-muted-foreground mt-2 mb-6">
                  There are no active recognition award events at this time.
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Recognition Award Event
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardShell>
  )
}

