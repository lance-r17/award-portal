import { NominationPortfolioContent } from "@/components/award/nomination-portfolio-content"

export default function NomineePortfolioPage({ params }: { params: { eventId: string; nomId: string } }) {
  return <NominationPortfolioContent eventId={params.eventId} nomId={params.nomId} />
}
