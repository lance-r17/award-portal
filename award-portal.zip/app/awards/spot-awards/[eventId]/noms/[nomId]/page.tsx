"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  ArrowLeft,
  ArrowRight,
  ThumbsUp,
  MessageSquare,
  Award,
  Trophy,
  Lightbulb,
  BarChart3,
  FileText,
  Globe,
  File,
} from "lucide-react"
import { getAwardEventById, awardEvents } from "@/data/award-events"
import { getNominationById, addVoteToNomination, addCommentToNomination, nominations } from "@/data/nominations"
import { getAwardTypeDisplay } from "@/data/award-types"
import { useUser } from "@/contexts/user-context"
import type { Nomination } from "@/types/nominations"

export default function NomineePortfolioPage({ params }: { params: { eventId: string; nomId: string } }) {
  const router = useRouter()
  const { eventId, nomId } = params
  const { user: currentUser, loading: userLoading } = useUser()

  const [nomination, setNomination] = useState<Nomination | null>(null)
  const [previousAwards, setPreviousAwards] = useState<Nomination[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [commentText, setCommentText] = useState("")

  useEffect(() => {
    const fetchData = () => {
      try {
        const nominationData = getNominationById(nomId)
        if (!nominationData) {
          throw new Error("Nomination not found")
        }
        setNomination(nominationData)

        // Find previous awards that the nominee actually won
        if (nominationData.nominee && nominationData.nominee.id) {
          const previousWonAwards = nominations
            .filter(
              (nom) =>
                nom.id !== nomId && // Not the current nomination
                nom.nominee.id === nominationData.nominee.id && // Same nominee
                nom.status === "awarded", // Only awards that were actually won
            )
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) // Sort by date, newest first
            .slice(0, 3) // Limit to 3 previous awards

          setPreviousAwards(previousWonAwards)
        }
      } catch (err) {
        console.error("Error fetching nomination:", err)
        setError(err instanceof Error ? err : new Error(String(err)))
      } finally {
        setIsLoading(false)
      }
    }

    if (!userLoading) {
      fetchData()
    }
  }, [nomId, userLoading])

  const handleVote = () => {
    if (!currentUser || !nomination) return

    try {
      const updatedNomination = addVoteToNomination(nomination.id, currentUser.id, currentUser.name)
      if (updatedNomination) {
        setNomination(updatedNomination)
      }
    } catch (error) {
      console.error("Error adding vote:", error)
    }
  }

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault()

    if (!currentUser || !nomination || !commentText.trim()) return

    try {
      const userInitials = currentUser.name
        ? currentUser.name
            .split(" ")
            .map((n) => n[0] || "")
            .join("")
        : "U"

      const updatedNomination = addCommentToNomination(
        nomination.id,
        currentUser.id,
        currentUser.name,
        currentUser.avatar || "/placeholder.svg?height=40&width=40",
        currentUser.initials || userInitials,
        commentText.trim(),
      )

      if (updatedNomination) {
        setNomination(updatedNomination)
        setCommentText("")
      }
    } catch (error) {
      console.error("Error adding comment:", error)
    }
  }

  const backToEvent = () => {
    router.push(`/awards/spot-awards/${eventId}`)
  }

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const formatServiceLine = (serviceLine: string | string[] | undefined): string => {
    try {
      if (!serviceLine) return ""

      if (Array.isArray(serviceLine)) {
        if (serviceLine.length === 0) return ""

        return serviceLine
          .map((line) => {
            if (typeof line !== "string") return ""
            return line
              .split("-")
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(" ")
          })
          .filter(Boolean)
          .join(", ")
      }

      if (typeof serviceLine === "string") {
        return serviceLine
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")
      }

      return ""
    } catch (error) {
      console.error("Error formatting service line:", error)
      return ""
    }
  }

  // Get event details for a nomination
  const getEventDetails = (eventId: string) => {
    return awardEvents.find((event) => event.id === eventId) || null
  }

  // Format year range from event quarter
  const formatYearRange = (quarter: string | undefined) => {
    if (!quarter) return "N/A"

    // Extract year from quarter (e.g., "Q4 2024" -> "2024")
    const yearMatch = quarter.match(/\d{4}/)
    if (!yearMatch) return quarter

    const year = Number.parseInt(yearMatch[0])
    return `${year} - ${year + 1}`
  }

  // Check if the current user has already voted
  const hasUserVoted = () => {
    if (!currentUser || !nomination?.votes) return false
    return nomination.votes.some((vote) => vote.userId === currentUser.id)
  }

  // Function to determine file type from URL
  const getFileType = (url: string): "pdf" | "image" | "website" | "document" => {
    try {
      const urlLower = url.toLowerCase()
      if (urlLower.endsWith(".pdf")) return "pdf"
      if (
        urlLower.endsWith(".jpg") ||
        urlLower.endsWith(".jpeg") ||
        urlLower.endsWith(".png") ||
        urlLower.endsWith(".gif")
      )
        return "image"
      if (
        urlLower.endsWith(".doc") ||
        urlLower.endsWith(".docx") ||
        urlLower.endsWith(".xls") ||
        urlLower.endsWith(".xlsx") ||
        urlLower.endsWith(".ppt") ||
        urlLower.endsWith(".pptx")
      )
        return "document"
      return "website"
    } catch (e) {
      return "website"
    }
  }

  // Function to get background color based on file type
  const getFileTypeColor = (fileType: "pdf" | "image" | "website" | "document"): string => {
    switch (fileType) {
      case "pdf":
        return "bg-red-100"
      case "image":
        return "bg-green-100"
      case "document":
        return "bg-blue-100"
      default:
        return "bg-gray-100"
    }
  }

  if (userLoading || isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <div className="container mx-auto py-12">
          <div className="animate-pulse">
            <div className="h-12 w-1/3 bg-gray-200 mb-8"></div>
            <div className="h-6 w-1/4 bg-gray-200 mb-4"></div>
            <div className="h-6 w-1/5 bg-gray-200 mb-12"></div>
            <div className="grid grid-cols-2 gap-12">
              <div className="space-y-4">
                <div className="h-8 w-1/2 bg-gray-200 mb-4"></div>
                <div className="h-4 w-full bg-gray-200"></div>
                <div className="h-4 w-full bg-gray-200"></div>
                <div className="h-4 w-3/4 bg-gray-200"></div>
              </div>
              <div className="space-y-4">
                <div className="h-8 w-1/2 bg-gray-200 mb-4"></div>
                <div className="h-4 w-full bg-gray-200"></div>
                <div className="h-4 w-full bg-gray-200"></div>
                <div className="h-4 w-3/4 bg-gray-200"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error || !nomination) {
    return (
      <div className="min-h-screen bg-white">
        <div className="container mx-auto py-12">
          <Button
            variant="ghost"
            className="mb-8 flex items-center text-sm text-gray-500 hover:text-gray-900"
            onClick={backToEvent}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Award Event
          </Button>

          <div className="text-center py-12">
            <h2 className="text-2xl font-medium mb-4">Nomination Not Found</h2>
            <p className="text-gray-500 mb-8">The nomination you're looking for doesn't exist or has been removed.</p>
            <Button onClick={backToEvent}>Return to Event</Button>
          </div>
        </div>
      </div>
    )
  }

  const event = getAwardEventById(eventId)

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto py-8 px-4 md:px-6">
        <div className="flex justify-between items-center mb-12">
          <Button
            variant="ghost"
            className="flex items-center text-sm text-gray-500 hover:text-gray-900"
            onClick={backToEvent}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to {event?.title || "Award Event"}
          </Button>
        </div>

        {/* Hero Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div>
            <h1 className="text-5xl font-bold tracking-tight mb-6">{nomination.nominee.name}</h1>
            <p className="text-2xl text-gray-600 mb-6">{nomination.nominee.title || "Team Member"}</p>
            <div className="flex items-center gap-4 mb-8">
              {/* Department badge removed as requested */}
              <Badge variant="outline" className="px-3 py-1 text-sm rounded-full">
                {formatServiceLine(nomination.serviceLine)}
              </Badge>
              <Badge
                variant="default"
                className="px-3 py-1 text-sm rounded-full bg-primary text-primary-foreground flex items-center gap-1"
              >
                <Award className="h-3.5 w-3.5" />
                <span>Nominated for: {getAwardTypeDisplay(nomination.awardType)}</span>
              </Badge>
              {nomination.status === "awarded" && (
                <Badge
                  variant="default"
                  className="px-3 py-1 text-sm rounded-full bg-amber-500 text-white flex items-center gap-1"
                >
                  <Trophy className="h-3.5 w-3.5" />
                  <span>Winner</span>
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-6">
              {nomination.votes && nomination.votes.length > 0 && (
                <div className="flex items-center gap-2">
                  <ThumbsUp className="h-5 w-5 text-gray-400" />
                  <span className="text-xl font-semibold">{nomination.votes.length}</span>
                </div>
              )}
              {nomination.comments && nomination.comments.length > 0 && (
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-gray-400" />
                  <span className="text-xl font-semibold">{nomination.comments.length}</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-end">
            <div className="w-64 h-64 rounded-lg overflow-hidden">
              <Avatar className="w-full h-full">
                <AvatarImage src={nomination.nominee.avatar} alt={nomination.nominee.name} />
                <AvatarFallback className="text-4xl">{nomination.nominee.initials}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>

        {/* About Section */}
        <div className="mb-16">
          {nomination.awardType === "team" && (
            <div className="mb-8">
              <h2 className="text-sm font-medium text-gray-500 mb-4">Team Members</h2>
              <div className="flex flex-wrap gap-6">
                {nomination.teamMembers && nomination.teamMembers.length > 0 ? (
                  nomination.teamMembers.map((member, index) => {
                    // Ensure we're handling both string and object members correctly
                    const memberName = typeof member === "object" ? member.name : member
                    const memberAvatar =
                      typeof member === "object" && member.avatar
                        ? member.avatar
                        : `/placeholder.svg?height=64&width=64`
                    const memberInitials =
                      typeof member === "object" && member.initials
                        ? member.initials
                        : typeof memberName === "string"
                          ? memberName.charAt(0)
                          : "T"
                    const memberRole = typeof member === "object" ? member.role || member.title : null

                    return (
                      <div key={index} className="flex flex-col items-center">
                        <Avatar className="h-16 w-16 mb-2">
                          <AvatarImage
                            src={memberAvatar}
                            alt={typeof memberName === "string" ? memberName : "Team Member"}
                          />
                          <AvatarFallback>{memberInitials}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-center">{memberName}</span>
                        {memberRole && <span className="text-xs text-gray-500">{memberRole}</span>}
                      </div>
                    )
                  })
                ) : (
                  <p className="text-gray-500">No team members specified for this team award.</p>
                )}
              </div>
            </div>
          )}
          <h2 className="text-sm font-medium text-gray-500 mb-4">About the Nomination</h2>
          <div>
            <p className="text-lg leading-relaxed whitespace-pre-line">
              {nomination.nominationSummary ||
                (nomination.justification && nomination.impact
                  ? `${nomination.justification}\n\n${nomination.impact}`
                  : nomination.justification || "")}
            </p>
          </div>
        </div>

        {/* Benefit and Outcome Section */}
        {nomination.benefitAndOutcome && (
          <div className="mb-16">
            <h2 className="text-sm font-medium text-gray-500 mb-2">Benefits & Outcomes</h2>
            <h3 className="text-2xl font-bold mb-6">A comprehensive look at impact and value</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Tangible Metrics Card */}
              <div className="bg-white border rounded-lg p-6 hover:shadow-md transition-shadow">
                <h4 className="text-lg font-semibold mb-4 flex items-center">
                  <BarChart3 className="mr-2 h-5 w-5 text-amber-400" />
                  Measurable Outcomes
                </h4>
                {nomination.benefitAndOutcome.tangibleMetrics &&
                nomination.benefitAndOutcome.tangibleMetrics.length > 0 ? (
                  <div className="space-y-4">
                    {nomination.benefitAndOutcome.tangibleMetrics.map((metric, index) => {
                      const label = tangibleOptions.find((option) => option.value === metric.type)?.label || metric.type
                      return (
                        <div key={index} className="group">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-medium text-gray-800">{label}</span>
                            <span className="text-lg font-bold text-primary">
                              {metric.value} <span className="text-sm font-normal text-gray-500">{metric.unit}</span>
                            </span>
                          </div>
                          <div className="w-full bg-gray-100 rounded-full h-1.5">
                            <div
                              className="bg-primary h-1.5 rounded-full"
                              style={{ width: `${Math.min(100, metric.value * 5)}%` }}
                            ></div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-gray-500">No tangible metrics provided.</p>
                )}
              </div>

              {/* Intangible Justifications Card */}
              <div className="bg-black text-white rounded-lg p-6">
                <h4 className="text-lg font-semibold mb-4 flex items-center">
                  <Lightbulb className="mr-2 h-5 w-5 text-amber-400" />
                  Qualitative Impact
                </h4>
                {nomination.benefitAndOutcome.intangibleJustifications &&
                nomination.benefitAndOutcome.intangibleJustifications.length > 0 ? (
                  <div className="space-y-4">
                    {nomination.benefitAndOutcome.intangibleJustifications.map((justification, index) => {
                      const label =
                        intangibleOptions.find((option) => option.value === justification.type)?.label ||
                        justification.type
                      return (
                        <div key={index} className="group">
                          <h5 className="font-medium text-gray-300 mb-1">
                            {justification.type === "other" && justification.otherType
                              ? `${justification.otherType}:`
                              : label}
                          </h5>
                          <p className="text-sm text-gray-400">
                            {justification.justification}
                            {justification.type === "customerSatisfaction" &&
                              justification.value &&
                              justification.unit &&
                              ` (${justification.value} ${justification.unit})`}
                          </p>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-gray-400">No intangible justifications provided.</p>
                )}
                <div className="mt-4 flex justify-end">
                  <ArrowRight className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stats Section */}
        <div className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-4xl font-bold mb-4">+{nomination.votes?.length || 0}</h2>
              <div className="flex flex-col gap-2">
                <p className="text-gray-500">People have voted for this nomination</p>
                {nomination.votes && nomination.votes.length > 0 && (
                  <div className="flex -space-x-2 overflow-hidden">
                    {nomination.votes.slice(0, 5).map((vote, index) => (
                      <Avatar key={index} className="inline-block h-8 w-8 rounded-full ring-2 ring-white">
                        <AvatarImage
                          src={vote.userAvatar || `/placeholder.svg?height=32&width=32`}
                          alt={vote.userName}
                        />
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                          {vote.userName ? vote.userName.charAt(0) : "U"}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                    {nomination.votes.length > 5 && (
                      <span className="flex items-center justify-center h-8 w-8 rounded-full bg-gray-200 text-xs font-medium text-gray-700 ring-2 ring-white">
                        +{nomination.votes.length - 5}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
            <div>
              <h2 className="text-4xl font-bold mb-4">+{nomination.comments?.length || 0}</h2>
              <p className="text-gray-500">Comments from colleagues</p>
            </div>
          </div>
        </div>

        {/* Endorsement Section */}
        <div className="mb-16">
          <h2 className="text-sm font-medium text-gray-500 mb-4">Endorsement</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-4">A comprehensive look at this nomination</h3>
              <p className="text-gray-600 mb-6">
                {nomination.endorsement
                  ? nomination.endorsement.status === "endorsed"
                    ? "This nomination has been endorsed by the domain manager and is being considered for the award."
                    : nomination.endorsement.status === "pending"
                      ? "This nomination is awaiting review from a domain manager."
                      : "This nomination has been reviewed but not endorsed at this time."
                  : "This nomination is awaiting endorsement from a domain manager."}
              </p>
              {nomination.endorsement && nomination.endorsement.comments && (
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Endorsement Comments:</h4>
                  <p className="text-gray-600">{nomination.endorsement.comments}</p>
                </div>
              )}
              <Button className="flex items-center gap-2 rounded-full">
                Vote Now
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
            <div>
              {nomination.endorsement ? (
                <div>
                  <h3 className="text-xl font-medium mb-4">Endorsed By</h3>
                  <div className="flex items-center gap-4 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback>
                        {nomination.endorsement.endorsedBy ? nomination.endorsement.endorsedBy.charAt(0) : "E"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {nomination.endorsement.endorsedBy
                          ? typeof nomination.endorsement.endorsedBy === "object"
                            ? nomination.endorsement.endorsedBy.name
                            : nomination.endorsement.endorsedBy
                          : "Endorser"}
                      </p>
                      <p className="text-sm text-gray-500">
                        {nomination.endorsement.endorsedAt
                          ? new Date(nomination.endorsement.endorsedAt).toLocaleDateString()
                          : "N/A"}
                      </p>
                    </div>
                  </div>
                  <Badge
                    variant={nomination.endorsement.status === "endorsed" ? "outline" : "secondary"}
                    className={`px-3 py-1 text-sm rounded-full ${
                      nomination.endorsement.status === "endorsed"
                        ? "border-green-500 text-green-600 bg-green-50"
                        : nomination.endorsement.status === "pending"
                          ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                          : "bg-red-100 text-red-800 border-red-200"
                    }`}
                  >
                    {nomination.endorsement.status === "endorsed"
                      ? "Endorsed"
                      : nomination.endorsement.status === "pending"
                        ? "Pending Endorsement"
                        : "Declined"}
                  </Badge>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-gray-500">Pending endorsement</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Comments Section */}
        <div className="mb-16">
          <h2 className="text-sm font-medium text-gray-500 mb-4">Comments</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-6">Join the conversation</h3>
              <form onSubmit={handleComment} className="space-y-4">
                <Input
                  placeholder="Add your comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="border-gray-300 rounded-md"
                />
                <Button
                  type="submit"
                  disabled={!commentText.trim() || !currentUser}
                  className="flex items-center gap-2 rounded-full"
                >
                  Post Comment
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </form>
            </div>
            <div>
              {nomination.comments && nomination.comments.length > 0 ? (
                <div className="space-y-6">
                  {nomination.comments.slice(0, 3).map((comment) => (
                    <div key={comment.id} className="flex gap-4">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={comment.userAvatar} />
                        <AvatarFallback>{comment.userInitials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium">{comment.userName}</p>
                          <span className="text-xs text-gray-500">
                            {new Date(comment.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-gray-600">{comment.text}</p>
                      </div>
                    </div>
                  ))}
                  {nomination.comments.length > 3 && (
                    <Button variant="link" className="text-gray-500 p-0">
                      View all {nomination.comments.length} comments
                    </Button>
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-gray-500">No comments yet. Be the first to comment!</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Portfolio Section */}
        <div className="mb-16">
          <h2 className="text-sm font-medium text-gray-500 mb-4">Portfolio</h2>
          <h3 className="text-2xl font-bold mb-6">Explore the achievements of {nomination.nominee.name}</h3>

          {/* Debug information - will help identify what data is available */}
          {console.log("Nomination data:", nomination)}

          {/* Supporting Images - handle different possible data structures */}
          {(nomination.supportingImages || nomination.supportingDocs || nomination.images || []).length > 0 && (
            <div className="mb-8">
              <h4 className="text-lg font-semibold mb-3">Supporting Images</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(nomination.supportingImages || nomination.supportingDocs || nomination.images || []).map(
                  (image, index) => (
                    <div
                      key={index}
                      className="relative aspect-video rounded-lg overflow-hidden border border-gray-200"
                    >
                      <img
                        src={
                          typeof image === "string"
                            ? image
                            : image.url || image.src || `/placeholder.svg?height=200&width=300`
                        }
                        alt={`Supporting image ${index + 1}`}
                        className="object-cover w-full h-full"
                      />
                    </div>
                  ),
                )}
              </div>
            </div>
          )}

          {/* Supporting Information - handle different possible data structures */}
          {(nomination.supportInfo || nomination.supportingInfo || nomination.additionalInfo) && (
            <div className="mb-8">
              <h4 className="text-lg font-semibold mb-3">Additional Support</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {(() => {
                  const info = nomination.supportInfo || nomination.supportingInfo || nomination.additionalInfo

                  // Function to check if text is a URL
                  const isValidUrl = (text) => {
                    try {
                      if (typeof text !== "string") return false
                      new URL(text)
                      return true
                    } catch (e) {
                      return false
                    }
                  }

                  // Handle URL in string format
                  if (typeof info === "string" && isValidUrl(info)) {
                    const url = info
                    const domain = (() => {
                      try {
                        const urlObj = new URL(url)
                        return urlObj.hostname
                      } catch (e) {
                        return "website"
                      }
                    })()
                    const fileType = getFileType(url)
                    const bgColorClass = getFileTypeColor(fileType)

                    return (
                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block hover:shadow-md transition-all"
                      >
                        <div className="border rounded-lg overflow-hidden bg-white h-full flex flex-col">
                          <div className={`${bgColorClass} p-4 flex items-center justify-center h-32`}>
                            {fileType === "pdf" ? (
                              <div className="text-center">
                                <FileText className="h-12 w-12 text-red-500 mx-auto" />
                                <span className="text-sm font-medium text-red-700 mt-2 block">PDF Document</span>
                              </div>
                            ) : fileType === "image" ? (
                              <div className="text-center">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="48"
                                  height="48"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="text-green-500 mx-auto"
                                >
                                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                                  <circle cx="8.5" cy="8.5" r="1.5" />
                                  <path d="M20.4 14.5 16 10 4 20" />
                                </svg>
                                <span className="text-sm font-medium text-green-700 mt-2 block">Image</span>
                              </div>
                            ) : fileType === "document" ? (
                              <div className="text-center">
                                <File className="h-12 w-12 text-blue-500 mx-auto" />
                                <span className="text-sm font-medium text-blue-700 mt-2 block">Document</span>
                              </div>
                            ) : (
                              <div className="text-center">
                                <Globe className="h-12 w-12 text-gray-500 mx-auto" />
                                <span className="text-sm font-medium text-gray-700 mt-2 block">Website</span>
                              </div>
                            )}
                          </div>
                          <div className="p-4 border-t flex-1">
                            <div className="flex items-center text-gray-500 text-xs mb-1">
                              <span>{domain}</span>
                            </div>
                            <h5 className="font-medium text-blue-600 mb-2 line-clamp-1">{url}</h5>
                            <p className="text-gray-600 text-sm">Click to view the linked resource</p>
                          </div>
                        </div>
                      </a>
                    )
                  }

                  // Handle object with URL property
                  else if (typeof info === "object" && info !== null && (info.url || info.link)) {
                    const url = info.url || info.link
                    const title = info.title || info.name || "View document"
                    const description = info.description || "Click to view the linked resource"
                    const domain = (() => {
                      try {
                        const urlObj = new URL(url)
                        return urlObj.hostname
                      } catch (e) {
                        return "website"
                      }
                    })()
                    const fileType = getFileType(url)
                    const bgColorClass = getFileTypeColor(fileType)

                    return (
                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block hover:shadow-md transition-all"
                      >
                        <div className="border rounded-lg overflow-hidden bg-white h-full flex flex-col">
                          <div className={`${bgColorClass} p-4 flex items-center justify-center h-32`}>
                            {fileType === "pdf" ? (
                              <div className="text-center">
                                <FileText className="h-12 w-12 text-red-500 mx-auto" />
                                <span className="text-sm font-medium text-red-700 mt-2 block">PDF Document</span>
                              </div>
                            ) : fileType === "image" ? (
                              <div className="text-center">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="48"
                                  height="48"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="text-green-500 mx-auto"
                                >
                                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                                  <circle cx="8.5" cy="8.5" r="1.5" />
                                  <path d="M20.4 14.5 16 10 4 20" />
                                </svg>
                                <span className="text-sm font-medium text-green-700 mt-2 block">Image</span>
                              </div>
                            ) : fileType === "document" ? (
                              <div className="text-center">
                                <File className="h-12 w-12 text-blue-500 mx-auto" />
                                <span className="text-sm font-medium text-blue-700 mt-2 block">Document</span>
                              </div>
                            ) : (
                              <div className="text-center">
                                <Globe className="h-12 w-12 text-gray-500 mx-auto" />
                                <span className="text-sm font-medium text-gray-700 mt-2 block">Website</span>
                              </div>
                            )}
                          </div>
                          <div className="p-4 border-t flex-1">
                            <div className="flex items-center text-gray-500 text-xs mb-1">
                              <span>{domain}</span>
                            </div>
                            <h5 className="font-medium text-blue-600 mb-2 line-clamp-1">{title}</h5>
                            <p className="text-gray-600 text-sm">{description}</p>
                          </div>
                        </div>
                      </a>
                    )
                  }

                  // Handle other types of content
                  else {
                    return (
                      <div className="border rounded-lg overflow-hidden bg-white">
                        <div className="p-6">
                          <div className="prose max-w-none">
                            {typeof info === "string" ? (
                              <p>{info}</p>
                            ) : (
                              <pre className="whitespace-pre-wrap">{JSON.stringify(info, null, 2)}</pre>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  }
                })()}
              </div>
            </div>
          )}
        </div>

        {/* Testimonial Section */}
        <div className="mb-16">
          <div className="text-center max-w-3xl mx-auto py-12">
            <p className="text-xl italic text-gray-600 mb-6">"Outstanding performance and dedication."</p>
            <div className="flex items-center justify-center gap-2">
              <Avatar className="h-10 w-10">
                <AvatarImage src={nomination.nominator?.avatar} />
                <AvatarFallback>
                  {nomination.nominator?.name ? nomination.nominator.name.charAt(0) : "N"}
                </AvatarFallback>
              </Avatar>
              <div className="text-left">
                <p className="font-medium">{nomination.nominator?.name || "Nominator"}</p>
                <p className="text-sm text-gray-500">Nominator</p>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline Section */}
        <div className="mb-16">
          <h2 className="text-sm font-medium text-gray-500 mb-4">Experience</h2>
          <h3 className="text-2xl font-bold mb-6">A yearly snapshot of award history</h3>

          {previousAwards && previousAwards.length > 0 ? (
            <div className="space-y-8">
              {previousAwards.map((award, index) => {
                const awardEvent = award.eventId ? getEventDetails(award.eventId) : null
                const awardType = award.awardType ? getAwardTypeDisplay(award.awardType) : "Recognition Award"
                const justificationText = "Award received for outstanding performance."

                const navigateToAward = () => {
                  if (award.eventId && award.id) {
                    router.push(`/awards/spot-awards/${award.eventId}/noms/${award.id}`)
                  }
                }

                return (
                  <div
                    key={index}
                    className="flex flex-col md:flex-row justify-between items-start p-4 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                    onClick={navigateToAward}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => e.key === "Enter" && navigateToAward()}
                    aria-label={`View ${awardType} award details`}
                  >
                    <div className="md:w-3/4">
                      <h4 className="text-lg font-medium">{awardType}</h4>
                      <p className="text-gray-600 mb-2">{justificationText}</p>
                      <p className="text-sm text-gray-500">{awardEvent?.title || "Company Recognition Program"}</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <span className="text-2xl font-bold">{formatYearRange(awardEvent?.quarter)}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">This nominee has not won any previous awards.</p>
            </div>
          )}
        </div>

        {/* Connect Section */}
        <div className="bg-black text-white p-12 -mx-4 md:-mx-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">Let's Connect</h2>
            <div className="flex justify-between items-center">
              <p className="text-gray-400">Want to support this nomination? Vote or leave a comment.</p>
              <Button
                variant="outline"
                className="text-white border-white hover:bg-white hover:text-black"
                onClick={handleVote}
                disabled={hasUserVoted()}
              >
                {hasUserVoted() ? "Already Voted" : "Vote Now"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

const tangibleOptions = [
  { value: "headcountSaving", label: "Headcount Saving" },
  { value: "timeSaving", label: "Time Saving" },
  { value: "costSaving", label: "Cost Saving" },
]

const intangibleOptions = [
  { value: "customerSatisfaction", label: "Customer Satisfaction" },
  { value: "internalAudit", label: "Internal audit and compliance adherence" },
  { value: "riskAvoidance", label: "Risk avoidance & mitigation" },
  { value: "regulatoryCompliance", label: "Regulatory compliances" },
  { value: "other", label: "Others" },
]

