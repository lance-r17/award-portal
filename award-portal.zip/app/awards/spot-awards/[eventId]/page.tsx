"use client"

import { useState, useEffect, useRef } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardEventStageIndicator } from "@/components/award/award-event-stage-indicator"
import { NominationCard } from "@/components/award/nomination-card"
import { NominationDrawer } from "@/components/award/nomination-drawer"
import { NominationFormDrawer } from "@/components/award/nomination-form-drawer"
import { CreateAwardEventDrawer } from "@/components/award/create-award-event-drawer"
import { AddNominationCard } from "@/components/award/add-nomination-card"
import { RewardWall } from "@/components/award/reward-wall"
import { WinnerManagement } from "@/components/award/winner-management"
import { AwardQuotas } from "@/components/award/award-quotas"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  CalendarDays,
  Clock,
  Info,
  Lightbulb,
  ListFilter,
  Edit,
  FileText,
  Globe,
  AlertTriangle,
  Users,
  Trophy,
  Award,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { getAwardEventById, isNominationPeriodActive, canEditEvent } from "@/data/award-events"
import { getNominationById, getNominationsByEventId, isUserDomainManagerForNomination } from "@/data/nominations"
import { isUserDomainManager, getCurrentUser } from "@/data/mock-users"
import type { User } from "@/data/mock-users"
import { mockUsers } from "@/data/mock-users"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"
import type { AwardEvent } from "@/types/award-events"
import type { Nomination } from "@/types/nominations"
import { Badge } from "@/components/ui/badge"
import { AwardEventJudges } from "@/components/award/award-event-judges"
import { JudgeScoringPanel } from "@/components/award/judge-scoring-panel"
import { FacilitatorScoringPanel } from "@/components/award/facilitator-scoring-panel"
import { DomainManagerEndorsementPanel } from "@/components/award/domain-manager-endorsement-panel"
import { isUserJudgeForEvent, isUserFacilitatorForEvent, isUserHeadJudgeForEvent } from "@/data/event-judges"

// New component to render the icon
const DynamicIcon = ({ icon: Icon }) => <Icon className="h-6 w-6" />

export default function SpotAwardEventPage({ params }: { params: { eventId: string } }) {
  const router = useRouter()
  const { eventId } = params
  const nominationsListRef = useRef<HTMLDivElement>(null)

  const currentUser = getCurrentUser()

  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedAwardType, setSelectedAwardType] = useState<string | null>(null)
  const [nominationType, setNominationType] = useState<"individual" | "team">("individual")
  const [canNominate, setCanNominate] = useState(false)
  const [canEdit, setCanEdit] = useState(false)
  const [isJudge, setIsJudge] = useState(false)
  const [isHeadJudge, setIsHeadJudge] = useState(false)
  const [isFacilitator, setIsFacilitator] = useState(false)
  const [isDomainManager, setIsDomainManager] = useState(false)
  const [currentJudge, setCurrentJudge] = useState<User | null>(null)

  const [nominations, setNominations] = useState<Nomination[]>([])
  const [filteredNominations, setFilteredNominations] = useState<Nomination[]>([])
  const [selectedFilter, setSelectedFilter] = useState<string>("all")
  const [selectedNomination, setSelectedNomination] = useState<Nomination | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)

  const [formDrawerOpen, setFormDrawerOpen] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  const [endorsementFilter, setEndorsementFilter] = useState<"all" | "endorsed" | "pending" | "rejected">("all")

  const filterNominationsByUserRole = (nominations: Nomination[]) => {
    if (isFacilitator || isJudge) {
      return nominations // Facilitators and assigned judges can see all nominations
    } else if (isDomainManager) {
      return nominations.filter((nomination) => nomination.serviceLine === currentUser.serviceLine)
    } else {
      // Nominee or nominator can only see their own nominations
      return nominations.filter(
        (nomination) => nomination.nominee.id === currentUser.id || nomination.nominator.id === currentUser.id,
      )
    }
  }

  useEffect(() => {
    const awardEvent = getAwardEventById(eventId)
    setEvent(awardEvent || null)

    if (awardEvent) {
      setCanNominate(isNominationPeriodActive(awardEvent.id))
      setCanEdit(canEditEvent(awardEvent, currentUser.id))
      setIsJudge(isUserJudgeForEvent(currentUser.id, eventId))
      setIsHeadJudge(isUserHeadJudgeForEvent(currentUser.id, eventId))
      setIsFacilitator(isUserFacilitatorForEvent(currentUser.id, eventId))
      setIsDomainManager(isUserDomainManager(currentUser.id))

      if (isUserJudgeForEvent(currentUser.id, eventId)) {
        setCurrentJudge(mockUsers.find((user) => user.id === currentUser.id) || null)
      }

      const eventNominations = getNominationsByEventId(eventId)
      setNominations(eventNominations)
      const filteredNoms = filterNominationsByUserRole(eventNominations)
      setFilteredNominations(filteredNoms)
    }

    setIsLoading(false)
  }, [eventId, currentUser.id])

  useEffect(() => {
    let filtered = filterNominationsByUserRole(nominations)

    if (selectedFilter === "all") {
      // No additional filtering needed
    } else if (selectedFilter === "individual" || selectedFilter === "team") {
      filtered = filtered.filter((nomination) => nomination.nominationType === selectedFilter)
    } else {
      filtered = filtered.filter((nomination) => nomination.awardType === selectedFilter)
    }

    if (endorsementFilter !== "all") {
      filtered = filtered.filter((nomination) => {
        if (endorsementFilter === "endorsed") {
          return nomination.endorsement?.status === "endorsed"
        } else if (endorsementFilter === "pending") {
          return !nomination.endorsement || nomination.endorsement.status === "pending"
        } else if (endorsementFilter === "rejected") {
          return nomination.endorsement?.status === "rejected"
        }
        return true
      })
    }

    setFilteredNominations(filtered)
  }, [
    selectedFilter,
    endorsementFilter,
    nominations,
    event?.currentStage,
    isFacilitator,
    isJudge,
    isDomainManager,
    currentUser.id,
  ])

  const handleEndorsementUpdate = (updatedNomination: Nomination) => {
    setNominations((prevNominations) =>
      prevNominations.map((nom) => (nom.id === updatedNomination.id ? updatedNomination : nom)),
    )
  }

  const handleAwardSelection = (awardId: string, type: "individual" | "team") => {
    setSelectedAwardType(awardId)
    setNominationType(type)

    if (selectedFilter === awardId) {
      setSelectedFilter("all")
    } else {
      setSelectedFilter(awardId)
    }

    nominationsListRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const backToList = () => {
    router.push("/awards/spot-awards")
  }

  const handleNominationClick = (nominationId: string) => {
    const nomination = getNominationById(nominationId)
    if (nomination) {
      setSelectedNomination(nomination)
      setDrawerOpen(true)
    }
  }

  const handleAddNominationClick = () => {
    setIsEditing(false)
    setFormDrawerOpen(true)
  }

  const canEditNomination = (nomination: Nomination) => {
    return (
      event?.currentStage === "nomination" &&
      canNominate &&
      (nomination.nominator.id === currentUser.id || nomination.nominee.id === currentUser.id)
    )
  }

  const handleEditNomination = (nomination: Nomination) => {
    if (canEditNomination(nomination)) {
      setSelectedNomination(nomination)
      setIsEditing(true)
      setFormDrawerOpen(true)
    }
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse text-center">
            <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
            <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
          </div>
        </div>
      </DashboardShell>
    )
  }

  if (!event) {
    return (
      <DashboardShell>
        <div className="mb-4">
          <Button
            variant="ghost"
            className="flex items-center text-sm text-muted-foreground hover:text-foreground"
            onClick={backToList}
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back to Spot Awards
          </Button>
        </div>

        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Event Not Found</AlertTitle>
          <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
        </Alert>
      </DashboardShell>
    )
  }

  const isPresentationStage = event.currentStage === "presentation"
  const isResultStage = event.currentStage === "result"
  const isNominationStage = event.currentStage === "nomination"

  const hasEndorsableNominations = nominations.some(
    (nomination) =>
      isUserDomainManagerForNomination(currentUser.id, nomination) &&
      (!nomination.endorsement || nomination.endorsement.status === "pending"),
  )

  return (
    <DashboardShell>
      <div className="mb-4">
        <Button
          variant="ghost"
          className="flex items-center text-sm text-muted-foreground hover:text-foreground"
          onClick={backToList}
        >
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Spot Awards
        </Button>
      </div>

      <div className="flex items-center justify-between">
        <DashboardHeader heading={event.title} text={event.description} />

        {/* Edit button - only shown if user has permission to edit */}
        {canEdit && (
          <div className="flex items-center gap-2">
            {event.status === "draft" && (
              <Badge variant="outline" className="border-dashed">
                <FileText className="mr-1 h-3 w-3" />
                Draft
              </Badge>
            )}
            <CreateAwardEventDrawer
              buttonVariant="outline"
              buttonSize="sm"
              buttonText="Edit Event"
              drawerTitle="Edit Award Event"
              drawerDescription="Update the award event details and timeline."
              existingEvent={event}
              isEditing={true}
              currentUser={currentUser}
            >
              <Button variant="outline" size="sm">
                <Edit className="mr-2 h-4 w-4" />
                Edit Event
              </Button>
            </CreateAwardEventDrawer>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="flex-1">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Event Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Quarter: <span className="font-medium">{event.quarter}</span>
                  </span>
                </div>
                {event.theme && (
                  <div className="flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      Theme: <span className="font-medium">{event.theme}</span>
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Current Stage:{" "}
                    <span className="font-medium">
                      {event.currentStage === "nomination"
                        ? "Nomination"
                        : event.currentStage === "presentation"
                          ? "Presentation"
                          : "Results"}
                    </span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {event.status === "published" ? (
                    <>
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        Status: <span className="font-medium">Published</span>
                      </span>
                    </>
                  ) : (
                    <>
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        Status: <span className="font-medium">Draft</span>
                        <span className="text-xs text-muted-foreground ml-1">
                          (Only visible to creators and facilitators)
                        </span>
                      </span>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Facilitators:{" "}
                    <span className="font-medium">
                      {event.facilitators && event.facilitators.length > 0
                        ? event.facilitators.map((f) => f.name).join(", ")
                        : "None assigned"}
                    </span>
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          <AwardEventStageIndicator event={event} />
        </div>
      </div>

      {isNominationStage && !canNominate && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Nomination Period Not Active</AlertTitle>
          <AlertDescription>
            The nomination period for this award event is not currently active. Nominations will open on{" "}
            {event.stages.nomination.startDate.toLocaleDateString()}.
          </AlertDescription>
        </Alert>
      )}

      {isPresentationStage && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Presentation Stage</AlertTitle>
          <AlertDescription>
            This award event is currently in the presentation stage. Only endorsed nominations are eligible for scoring.
            {isJudge && " As a judge, you can score the presentations in the Scoring tab."}
            {isFacilitator && " As a facilitator, you can view all scores in the Scoring tab."}
          </AlertDescription>
        </Alert>
      )}

      {isNominationStage && isDomainManager && hasEndorsableNominations && (
        <Alert className="mb-6" variant="default">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Nominations Require Your Endorsement</AlertTitle>
          <AlertDescription>
            There are nominations that require your endorsement as a domain manager. Please review them in the
            Endorsements tab.
          </AlertDescription>
        </Alert>
      )}

      {isResultStage && (
        <Alert className="mb-6">
          <Trophy className="h-4 w-4 text-amber-500" />
          <AlertTitle>Results Announced</AlertTitle>
          <AlertDescription>
            The results for this award event have been announced. You can view the winners in the Reward Wall tab.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="individual" className="w-full">
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="individual">Individual Awards</TabsTrigger>
          <TabsTrigger value="team">Team Awards</TabsTrigger>
          <TabsTrigger value="judges">Judges</TabsTrigger>
          {isDomainManager && <TabsTrigger value="endorsements">Endorsements</TabsTrigger>}
          {isFacilitator && <TabsTrigger value="quotas">Award Quotas</TabsTrigger>}
          {(isPresentationStage || isResultStage) && (isJudge || isFacilitator) && (
            <TabsTrigger value="scoring">Scoring</TabsTrigger>
          )}
          {(isFacilitator || isHeadJudge) && (isPresentationStage || isResultStage) && (
            <TabsTrigger value="winners">Winner Management</TabsTrigger>
          )}
          {isResultStage && <TabsTrigger value="rewardwall">Reward Wall</TabsTrigger>}
          <TabsTrigger value="about">About</TabsTrigger>
        </TabsList>

        <TabsContent value="individual" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Individual Award Types</CardTitle>
              <CardDescription>
                {event.currentStage === "nomination" && canNominate
                  ? "Select an award type to recognize outstanding individual contributions"
                  : "Click on an award type to filter nominations"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {spotIndividualAwardTypes.map((award) => (
                  <div
                    key={award.id}
                    className={`rounded-lg border p-4 cursor-pointer transition-all hover:border-primary hover:shadow-sm ${
                      selectedFilter === award.id ? "border-primary bg-primary/5" : ""
                    }`}
                    onClick={() => handleAwardSelection(award.id, "individual")}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`rounded-full p-2 ${award.color}`}>
                        <DynamicIcon icon={award.icon} />
                      </div>
                      <div>
                        <h3 className="font-medium">{award.title}</h3>
                        <p className="text-sm text-muted-foreground">{award.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Team Award</CardTitle>
              <CardDescription>
                {event.currentStage === "nomination" && canNominate
                  ? "Recognize exceptional team collaboration and achievements"
                  : "Click on the award type to filter nominations"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                className={`rounded-lg border p-6 cursor-pointer transition-all hover:border-primary hover:shadow-sm ${
                  selectedFilter === spotTeamAwardTypes[0].id ? "border-primary bg-primary/5" : ""
                }`}
                onClick={() => handleAwardSelection(spotTeamAwardTypes[0].id, "team")}
              >
                <div className="flex items-start gap-4">
                  <div className={`rounded-full p-3 ${spotTeamAwardTypes[0].color}`}>
                    <DynamicIcon icon={spotTeamAwardTypes[0].icon} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{spotTeamAwardTypes[0].title}</h3>
                    <p className="text-muted-foreground">{spotTeamAwardTypes[0].description}</p>

                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Award Criteria:</h4>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        {spotTeamAwardTypes[0].criteria.map((criterion, index) => (
                          <li key={index} className="text-muted-foreground">
                            {criterion}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-2">
                      <p className="text-sm">
                        <span className="font-medium">Reward: </span>
                        <span className="text-muted-foreground">{spotTeamAwardTypes[0].reward}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="judges" className="space-y-6">
          <AwardEventJudges
            eventId={event.id}
            event={event}
            isFacilitator={isFacilitator}
            currentUserId={currentUser.id}
          />
        </TabsContent>

        {isDomainManager && (
          <TabsContent value="endorsements" className="space-y-6">
            <DomainManagerEndorsementPanel
              eventId={event.id}
              nominations={nominations}
              currentUserId={currentUser.id}
              onEndorsementUpdate={handleEndorsementUpdate}
            />
          </TabsContent>
        )}

        {isFacilitator && (
          <TabsContent value="quotas" className="space-y-6">
            <AwardQuotas eventId={event.id} isFacilitator={isFacilitator} isReadOnly={isResultStage} />

            <Alert
              variant="default"
              className="bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800/30 mt-4"
            >
              <Award className="h-4 w-4 text-amber-600" />
              <AlertTitle>Setting Award Quotas</AlertTitle>
              <AlertDescription>
                Award quotas determine how many winners will be selected for each award type. Setting these early helps
                nominees understand the competitive nature of the awards and ensures transparency in the selection
                process.
              </AlertDescription>
            </Alert>
          </TabsContent>
        )}

        {(isPresentationStage || isResultStage) && (isJudge || isFacilitator) && (
          <TabsContent value="scoring" className="space-y-6">
            {isJudge && (
              <JudgeScoringPanel
                eventId={event.id}
                currentJudge={currentJudge}
                isJudge={isJudge}
                isPresentationStage={isPresentationStage}
                isResultStage={isResultStage}
                nominations={nominations.filter((nom) => nom.endorsement?.status === "endorsed")}
              />
            )}

            {isFacilitator && (
              <FacilitatorScoringPanel
                eventId={event.id}
                isPresentationStage={isPresentationStage || isResultStage}
                nominations={nominations.filter((nom) => nom.endorsement?.status === "endorsed")}
              />
            )}
          </TabsContent>
        )}

        {(isFacilitator || isHeadJudge) && (isPresentationStage || isResultStage) && (
          <TabsContent value="winners" className="space-y-6">
            <WinnerManagement
              eventId={event.id}
              isPresentationStage={isPresentationStage}
              isResultStage={isResultStage}
              isFacilitator={isFacilitator}
              isHeadJudge={isHeadJudge}
            />
          </TabsContent>
        )}

        {isResultStage && (
          <TabsContent value="rewardwall" className="space-y-6">
            <RewardWall eventId={event.id} isResultStage={isResultStage} />
          </TabsContent>
        )}

        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>About {event.title}</CardTitle>
              <CardDescription>
                Spot Awards are designed to provide immediate recognition for outstanding contributions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Spot Awards are a way to recognize employees for specific actions or achievements in real-time. Unlike
                formal recognition programs that may have nomination periods and committees, Spot Awards can be given at
                any time to acknowledge exceptional work.
              </p>

              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium mb-2">Key Features of Spot Awards</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Immediate recognition for specific achievements</li>
                  <li>Simple nomination process with quick approval</li>
                  <li>Available for both individual and team recognition</li>
                  <li>Focused on recognizing actions rather than long-term performance</li>
                  <li>Tangible rewards that are delivered promptly</li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Individual Awards</h4>
                <p className="text-sm text-muted-foreground">
                  Individual Spot Awards recognize personal contributions across different areas of excellence. Each
                  award type focuses on a specific aspect of performance or behavior that contributes to our company's
                  success.
                </p>

                <h4 className="font-medium">Team Award</h4>
                <p className="text-sm text-muted-foreground">
                  The All-Star Team award recognizes groups that demonstrate exceptional collaboration, innovation, and
                  results. This award celebrates the power of teamwork and collective achievement.
                </p>
              </div>

              <div className="rounded-lg border p-4 mt-4">
                <h4 className="font-medium mb-2">Award Process</h4>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Nomination Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Employees submit nominations for individuals or teams who deserve recognition.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Domain Manager Endorsement</span>
                    <p className="text-sm text-muted-foreground">
                      Nominations must be endorsed by a domain manager from the relevant service line to proceed.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Presentation Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Endorsed nominees present their achievements to the evaluation committee.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Results Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Winners are announced and awards are presented in team meetings or department gatherings.
                    </p>
                  </li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Nominations List - Shown in all stages */}
      <div className="mt-10" ref={nominationsListRef}>
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <CardTitle>
                  {event.currentStage === "result" ? "Winners" : "Nominees"} for {event.title}
                </CardTitle>
                <CardDescription>
                  {event.currentStage === "nomination" && "View current nominations for this award event."}
                  {event.currentStage === "presentation" &&
                    "Review the endorsed nominations during the presentation stage."}
                  {event.currentStage === "result" && "Congratulations to our award winners!"}
                </CardDescription>
              </div>
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                <div className="flex items-center gap-2">
                  <ListFilter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground mr-2">Award:</span>
                  <select
                    className="text-sm border rounded-md px-2 py-1"
                    value={selectedFilter}
                    onChange={(e) => setSelectedFilter(e.target.value)}
                  >
                    <option value="all">All Nominations</option>
                    <option value="individual">Individual Awards</option>
                    <option value="team">Team Awards</option>
                    {[...spotIndividualAwardTypes, ...spotTeamAwardTypes].map((award) => (
                      <option key={award.id} value={award.id}>
                        {award.title}
                      </option>
                    ))}
                  </select>
                </div>

                {isNominationStage && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground mr-2">Endorsement:</span>
                    <select
                      className="text-sm border rounded-md px-2 py-1"
                      value={endorsementFilter}
                      onChange={(e) => setEndorsementFilter(e.target.value as any)}
                    >
                      <option value="all">All Statuses</option>
                      <option value="endorsed">Endorsed</option>
                      <option value="pending">Pending</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {/* Add Nomination Card - always shown at the beginning during nomination phase */}
              {event.currentStage === "nomination" && canNominate && (
                <AddNominationCard onClick={handleAddNominationClick} />
              )}

              {filteredNominations.length > 0 ? (
                filteredNominations.map((nomination) => (
                  <NominationCard
                    key={nomination.id}
                    nomination={nomination}
                    onClick={() => handleNominationClick(nomination.id)}
                    canEdit={canEditNomination(nomination)}
                    onEdit={() => handleEditNomination(nomination)}
                  />
                ))
              ) : (
                <div className="text-center py-8 col-span-3">
                  <p className="text-muted-foreground">
                    {nominations.length === 0
                      ? "No nominations have been submitted yet."
                      : isPresentationStage
                        ? "No endorsed nominations match the selected filter."
                        : "No nominations match the selected filter."}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Nomination Details Drawer */}
        <NominationDrawer
          nomination={selectedNomination}
          open={drawerOpen}
          onOpenChange={setDrawerOpen}
          canEdit={selectedNomination ? canEditNomination(selectedNomination) : false}
          onEdit={() => selectedNomination && handleEditNomination(selectedNomination)}
          currentUserId={currentUser.id}
        />

        {/* Nomination Form Drawer */}
        <NominationFormDrawer
          open={formDrawerOpen}
          onOpenChange={setFormDrawerOpen}
          eventId={event.id}
          awardType={selectedAwardType}
          nominationType={nominationType}
          nomination={selectedNomination}
          isEditing={isEditing}
        />
      </div>
    </DashboardShell>
  )
}

