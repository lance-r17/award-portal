"use client"

import { useState, useEffect, useRef } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardEventStageIndicator } from "@/components/award/award-event-stage-indicator"
import { NominationCard } from "@/components/award/nomination-card"
import { NominationDrawer } from "@/components/award/nomination-drawer"
import { NominationFormDrawer } from "@/components/award/nomination-form-drawer"
import { CreateAwardEventDrawer } from "@/components/award/create-award-event-drawer"
import { AddNominationCard } from "@/components/award/add-nomination-card"
import { RewardWall } from "@/components/award/reward-wall"
import { RewardWallVariant } from "@/components/award/reward-wall-variant"
import { WinnerManagement } from "@/components/award/winner-management"
import { AwardQuotas } from "@/components/award/award-quotas"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import {
  ArrowLeft,
  CalendarDays,
  Clock,
  Info,
  Lightbulb,
  ListFilter,
  Edit,
  FileText,
  Globe,
  AlertTriangle,
  Users,
  Trophy,
  Award,
  Palette,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { getAwardEventById, isNominationPeriodActive, canEditEvent } from "@/data/award-events"
import {
  getNominationById,
  getNominationsByEventId,
  isUserDomainManagerForNomination,
  addVoteToNomination,
  addCommentToNomination,
} from "@/data/nominations"
import { isUserDomainManager } from "@/data/mock-users"
import { mockUsers } from "@/data/mock-users"
import { spotIndividualAwardTypes, spotTeamAwardTypes } from "@/data/award-types"
import type { AwardEvent } from "@/types/award-events"
import type { Nomination } from "@/types/nominations"
import { Badge } from "@/components/ui/badge"
import { AwardEventJudges } from "@/components/award/award-event-judges"
import { JudgeScoringPanel } from "@/components/award/judge-scoring-panel"
import { FacilitatorScoringPanel } from "@/components/award/facilitator-scoring-panel"
import { DomainManagerEndorsementPanel } from "@/components/award/domain-manager-endorsement-panel"
import { isUserJudgeForEvent, isUserFacilitatorForEvent, isUserHeadJudgeForEvent } from "@/data/event-judges"
import { useUser } from "@/contexts/user-context"
import type { User } from "@/types/users"

// Error boundary component
const ErrorFallback = ({ error }: { error: Error }) => {
  return (
    <DashboardShell>
      <div className="p-6 bg-red-50 border border-red-200 rounded-lg">
        <h2 className="text-lg font-semibold text-red-800 mb-2">Something went wrong</h2>
        <p className="text-red-700 mb-4">An error occurred while loading the page.</p>
        <div className="bg-white p-4 rounded border border-red-100 overflow-auto">
          <pre className="text-sm text-red-800">{error.message}</pre>
          <pre className="text-xs text-gray-500 mt-2">{error.stack}</pre>
        </div>
        <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
          Try again
        </Button>
      </div>
    </DashboardShell>
  )
}

// New component to render the icon
const DynamicIcon = ({ icon: Icon }) => <Icon className="h-6 w-6" />

export default function SpotAwardEventPage({ params }: { params: { eventId: string } }) {
  console.log("Rendering SpotAwardEventPage with params:", params)

  const router = useRouter()
  const { eventId } = params
  const nominationsListRef = useRef<HTMLDivElement>(null)

  // Use our context hook to get the current user
  const { user: currentUser, loading: userLoading } = useUser()
  console.log("User context:", { currentUser, userLoading })

  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedAwardType, setSelectedAwardType] = useState<string | null>(null)
  const [nominationType, setNominationType] = useState<"individual" | "team">("individual")
  const [canNominate, setCanNominate] = useState(false)
  const [canEdit, setCanEdit] = useState(false)
  const [isJudge, setIsJudge] = useState(false)
  const [isHeadJudge, setIsHeadJudge] = useState(false)
  const [isFacilitator, setIsFacilitator] = useState(false)
  const [isDomainManager, setIsDomainManager] = useState(false)
  const [currentJudge, setCurrentJudge] = useState<User | null>(null)

  const [nominations, setNominations] = useState<Nomination[]>([])
  const [filteredNominations, setFilteredNominations] = useState<Nomination[]>([])
  const [selectedFilter, setSelectedFilter] = useState<string>("all")
  const [selectedNomination, setSelectedNomination] = useState<Nomination | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)

  const [formDrawerOpen, setFormDrawerOpen] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  const [endorsementFilter, setEndorsementFilter] = useState<"all" | "endorsed" | "pending" | "rejected">("all")

  // New state for A/B testing the reward wall design
  const [useNewDesign, setUseNewDesign] = useState(false)

  const [error, setError] = useState<Error | null>(null)
  const [renderStage, setRenderStage] = useState<string>("initial")

  // State to track if the initial data fetching has been attempted
  const [initialFetchAttempted, setInitialFetchAttempted] = useState(false)

  // State to determine if the data fetching useEffect should run
  const [shouldFetchData, setShouldFetchData] = useState(false)

  // State to hold the user ID for useEffect dependency
  const [currentUserId, setCurrentUserId] = useState<string | undefined>(undefined)

  // If there's an error, show the error fallback
  if (error) {
    return <ErrorFallback error={error} />
  }

  const filterNominationsByUserRole = (nominations: Nomination[]) => {
    if (!currentUser) return []

    if (isFacilitator || isJudge) {
      return nominations // Facilitators and assigned judges can see all nominations
    } else if (isDomainManager) {
      // Use either serviceLine or serviceLineId
      const userServiceLine = currentUser.serviceLine || currentUser.serviceLineId
      return nominations.filter((nomination) => nomination.serviceLine === userServiceLine)
    } else {
      // Nominee or nominator can only see their own nominations
      return nominations.filter(
        (nomination) => nomination.nominee.id === currentUser.id || nomination.nominator.id === currentUser.id,
      )
    }
  }

  // Function to fetch event data
  const fetchEventData = () => {
    try {
      console.log("Fetching event data for eventId:", eventId)
      setRenderStage("fetching")

      if (!currentUser) {
        console.log("No current user, skipping fetch")
        return
      }

      const awardEvent = getAwardEventById(eventId)
      console.log("Fetched award event:", awardEvent)
      setEvent(awardEvent || null)

      if (awardEvent) {
        setCanNominate(isNominationPeriodActive(awardEvent.id) && currentUser.roles?.includes("anonymous") !== true)
        setCanEdit(canEditEvent(awardEvent, currentUser.id))
        setIsJudge(isUserJudgeForEvent(currentUser.id, eventId))
        setIsHeadJudge(isUserHeadJudgeForEvent(currentUser.id, eventId))
        setIsFacilitator(isUserFacilitatorForEvent(currentUser.id, eventId))
        setIsDomainManager(isUserDomainManager(currentUser.id))

        if (isUserJudgeForEvent(currentUser.id, eventId)) {
          setCurrentJudge(mockUsers.find((user) => user.id === currentUser.id) || null)
        }

        const eventNominations = getNominationsByEventId(eventId)
        console.log("Fetched nominations:", eventNominations.length)
        setNominations(eventNominations)

        const filteredNoms = filterNominationsByUserRole(eventNominations)
        console.log("Filtered nominations:", filteredNoms.length)
        setFilteredNominations(filteredNoms)
      }

      setIsLoading(false)
      setRenderStage("data-loaded")
    } catch (err) {
      console.error("Error fetching event data:", err)
      setError(err instanceof Error ? err : new Error(String(err)))
      setIsLoading(false)
      setRenderStage("error")
    } finally {
      setInitialFetchAttempted(true) // Mark that the initial fetch has been attempted
    }
  }

  // Fetch data when the component mounts or when the user changes
  useEffect(() => {
    // Set shouldFetchData to true when the user context is loaded or if it's the initial attempt
    if (currentUser || !userLoading) {
      setShouldFetchData(true)
      setCurrentUserId(currentUser?.id)
    }
  }, [currentUser, userLoading])

  useEffect(() => {
    console.log("useEffect triggered for data fetching with user:", currentUser?.id)

    // Only fetch data if shouldFetchData is true
    if (shouldFetchData) {
      fetchEventData()
    }
  }, [eventId, currentUserId, shouldFetchData])

  // Update filtered nominations when filters or user role changes
  useEffect(() => {
    console.log("useEffect triggered for filtering nominations")
    if (!currentUser) {
      setFilteredNominations([])
      return
    }

    let filtered = filterNominationsByUserRole(nominations)

    if (selectedFilter === "all") {
      // No additional filtering needed
    } else if (selectedFilter === "individual" || selectedFilter === "team") {
      filtered = filtered.filter((nomination) => nomination.nominationType === selectedFilter)
    } else {
      filtered = filtered.filter((nomination) => nomination.awardType === selectedFilter)
    }

    if (endorsementFilter !== "all") {
      filtered = filtered.filter((nomination) => {
        if (endorsementFilter === "endorsed") {
          return nomination.endorsement?.status === "endorsed"
        } else if (endorsementFilter === "pending") {
          return !nomination.endorsement || nomination.endorsement.status === "pending"
        } else if (endorsementFilter === "rejected") {
          return nomination.endorsement?.status === "rejected"
        }
        return true
      })
    }

    setFilteredNominations(filtered)
  }, [
    selectedFilter,
    endorsementFilter,
    nominations,
    event?.currentStage,
    isFacilitator,
    isJudge,
    isDomainManager,
    currentUser,
  ])

  // Update render stage when event data is loaded
  useEffect(() => {
    if (event && !isLoading && !userLoading) {
      console.log("Setting render stage to rendering")
      setRenderStage("rendering")
    }
  }, [event, isLoading, userLoading])

  const handleEndorsementUpdate = (updatedNomination: Nomination) => {
    setNominations((prevNominations) =>
      prevNominations.map((nom) => (nom.id === updatedNomination.id ? updatedNomination : nom)),
    )
  }

  const handleAwardSelection = (awardId: string, type: "individual" | "team") => {
    setSelectedAwardType(awardId)
    setNominationType(type)

    if (selectedFilter === awardId) {
      setSelectedFilter("all")
    } else {
      setSelectedFilter(awardId)
    }

    nominationsListRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const backToList = () => {
    router.push("/awards/spot-awards")
  }

  const handleNominationClick = (nominationId: string) => {
    const nomination = getNominationById(nominationId)
    if (nomination) {
      setSelectedNomination(nomination)
      setDrawerOpen(true)
    }
  }

  const handleAddNominationClick = () => {
    // Double-check if user is anonymous to prevent any click-through
    if (currentUser?.roles?.includes("anonymous")) {
      console.log("Preventing nomination form for anonymous user")
      alert("Anonymous users cannot submit nominations. Please log in with a different role.")
      return
    }
    setIsEditing(false)
    setFormDrawerOpen(true)
  }

  const canEditNomination = (nomination: Nomination) => {
    return (
      event?.currentStage === "nomination" &&
      canNominate &&
      !currentUser?.roles?.includes("anonymous") &&
      (nomination.nominator.id === currentUser?.id || nomination.nominee.id === currentUser?.id)
    )
  }

  const handleEditNomination = (nomination: Nomination) => {
    if (canEditNomination(nomination)) {
      setSelectedNomination(nomination)
      setIsEditing(true)
      setFormDrawerOpen(true)
    }
  }

  // Determine if the nominations list should be shown
  const shouldShowNominationsList = () => {
    // Always show for facilitators
    if (isFacilitator) return true

    // Hide for everyone else if in result stage
    if (event?.currentStage === "result") return false

    // Show for everyone in other stages
    return true
  }

  // If user is loading or not available, show a loading state
  if (userLoading && !initialFetchAttempted) {
    console.log("Rendering loading state (user loading)")
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse text-center">
            <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
            <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
          </div>
        </div>
      </DashboardShell>
    )
  }

  const handleVote = (nominationId: string, userId: string, userName: string) => {
    try {
      const updatedNomination = addVoteToNomination(nominationId, userId, userName)
      if (updatedNomination) {
        setNominations((prevNominations) =>
          prevNominations.map((nom) => (nom.id === updatedNomination.id ? updatedNomination : nom)),
        )
      }
    } catch (error) {
      console.error("Error adding vote:", error)
    }
  }

  const handleComment = (
    nominationId: string,
    userId: string,
    userName: string,
    userAvatar: string,
    userInitials: string,
    comment: string,
  ) => {
    try {
      const updatedNomination = addCommentToNomination(
        nominationId,
        userId,
        userName,
        userAvatar,
        userInitials,
        comment,
      )
      if (updatedNomination) {
        setNominations((prevNominations) =>
          prevNominations.map((nom) => (nom.id === updatedNomination.id ? updatedNomination : nom)),
        )
      }
    } catch (error) {
      console.error("Error adding comment:", error)
    }
  }

  if (!currentUser) {
    console.log("Rendering no user state")
    return (
      <DashboardShell>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Authentication Error</AlertTitle>
          <AlertDescription>Unable to load user information. Please try refreshing the page.</AlertDescription>
        </Alert>
        <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
          Refresh Page
        </Button>
      </DashboardShell>
    )
  }

  if (isLoading) {
    console.log("Rendering loading state (data loading)")
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse text-center">
            <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
            <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
          </div>
        </div>
      </DashboardShell>
    )
  }

  if (!event) {
    console.log("Rendering no event state")
    return (
      <DashboardShell>
        <div className="mb-4">
          <Button
            variant="ghost"
            className="flex items-center text-sm text-muted-foreground hover:text-foreground"
            onClick={backToList}
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back to Spot Awards
          </Button>
        </div>

        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Event Not Found</AlertTitle>
          <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
        </Alert>
      </DashboardShell>
    )
  }

  console.log("Rendering full page with event:", event.title)

  const isPresentationStage = event.currentStage === "presentation"
  const isResultStage = event.currentStage === "result"
  const isNominationStage = event.currentStage === "nomination"

  const hasEndorsableNominations = nominations.some(
    (nomination) =>
      isUserDomainManagerForNomination(currentUser.id, nomination) &&
      (!nomination.endorsement || nomination.endorsement.status === "pending"),
  )

  // Debug information
  console.log("Render state:", {
    isPresentationStage,
    isResultStage,
    isNominationStage,
    isFacilitator,
    isJudge,
    isHeadJudge,
    isDomainManager,
    canNominate,
    canEdit,
    hasEndorsableNominations,
    renderStage,
  })

  try {
    return (
      <DashboardShell>
        <div className="mb-4">
          <Button
            variant="ghost"
            className="flex items-center text-sm text-muted-foreground hover:text-foreground"
            onClick={backToList}
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back to Spot Awards
          </Button>
        </div>

        <div className="flex items-center justify-between">
          <DashboardHeader heading={event.title} text={event.description} />

          {/* Edit button - only shown if user has permission to edit */}
          {canEdit && (
            <div className="flex items-center gap-2">
              {event.status === "draft" && (
                <Badge variant="outline" className="border-dashed">
                  <FileText className="mr-1 h-3 w-3" />
                  Draft
                </Badge>
              )}
              <CreateAwardEventDrawer
                buttonVariant="outline"
                buttonSize="sm"
                buttonText="Edit Event"
                drawerTitle="Edit Award Event"
                drawerDescription="Update the award event details and timeline."
                existingEvent={event}
                isEditing={true}
                currentUser={currentUser}
              >
                <Button variant="outline" size="sm">
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Event
                </Button>
              </CreateAwardEventDrawer>
            </div>
          )}
        </div>

        <div className="flex flex-col md:flex-row gap-6 mb-6">
          <div className="flex-1">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Event Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <CalendarDays className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      Quarter: <span className="font-medium">{event.quarter}</span>
                    </span>
                  </div>
                  {event.theme && (
                    <div className="flex items-center gap-2">
                      <Lightbulb className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        Theme: <span className="font-medium">{event.theme}</span>
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      Current Stage:{" "}
                      <span className="font-medium">
                        {event.currentStage === "nomination"
                          ? "Nomination"
                          : event.currentStage === "presentation"
                            ? "Presentation"
                            : "Results"}
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {event.status === "published" ? (
                      <>
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          Status: <span className="font-medium">Published</span>
                        </span>
                      </>
                    ) : (
                      <>
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          Status: <span className="font-medium">Draft</span>
                          <span className="text-xs text-muted-foreground ml-1">
                            (Only visible to creators and facilitators)
                          </span>
                        </span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      Facilitators:{" "}
                      <span className="font-medium">
                        {event.facilitators && event.facilitators.length > 0
                          ? event.facilitators.map((f) => f.name).join(", ")
                          : "None assigned"}
                      </span>
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex-1">
            <AwardEventStageIndicator event={event} />
          </div>
        </div>

        {/* Debug information */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Debug Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p>Render Stage: {renderStage}</p>
              <p>
                User: {currentUser.name} (ID: {currentUser.id})
              </p>
              <p>Roles: {currentUser.roles?.join(", ") || "None"}</p>
              <p>Service Line: {currentUser.serviceLine || "None"}</p>
              <p>Selected Role: {localStorage.getItem("selectedRole") || "None"}</p>
              <p>
                Flags: isFacilitator={isFacilitator ? "true" : "false"}, isJudge={isJudge ? "true" : "false"},
                isHeadJudge={isHeadJudge ? "true" : "false"}, isDomainManager={isDomainManager ? "true" : "false"}
              </p>
              <p>
                Nominations: {nominations.length} total, {filteredNominations.length} filtered
              </p>
            </div>
          </CardContent>
        </Card>

        {isNominationStage && !canNominate && (
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertTitle>Nomination Period Not Active</AlertTitle>
            <AlertDescription>
              The nomination period for this award event is not currently active. Nominations will open on{" "}
              {event.stages.nomination.startDate.toLocaleDateString()}.
            </AlertDescription>
          </Alert>
        )}

        {isPresentationStage && (
          <Alert className="mb-6">
            <Info className="h-4 w-4" />
            <AlertTitle>Presentation Stage</AlertTitle>
            <AlertDescription>
              This award event is currently in the presentation stage. Only endorsed nominations are eligible for
              scoring.
              {isJudge && " As a judge, you can score the presentations in the Scoring tab."}
              {isFacilitator && " As a facilitator, you can view all scores in the Scoring tab."}
            </AlertDescription>
          </Alert>
        )}

        {isNominationStage && isDomainManager && hasEndorsableNominations && (
          <Alert className="mb-6" variant="default">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Nominations Require Your Endorsement</AlertTitle>
            <AlertDescription>
              There are nominations that require your endorsement as a domain manager. Please review them in the
              Endorsements tab.
            </AlertDescription>
          </Alert>
        )}

        {isResultStage && (
          <Alert className="mb-6">
            <Trophy className="h-4 w-4 text-amber-500" />
            <AlertTitle>Results Announced</AlertTitle>
            <AlertDescription>
              The results for this award event have been announced. You can view the winners in the Reward Wall tab.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue={isResultStage ? "rewardwall" : "individual"} className="w-full">
          <TabsList className="grid w-full grid-cols-8">
            {isResultStage && <TabsTrigger value="rewardwall">Reward Wall</TabsTrigger>}
            <TabsTrigger value="individual">Individual Awards</TabsTrigger>
            <TabsTrigger value="team">Team Awards</TabsTrigger>
            <TabsTrigger value="judges">Judges</TabsTrigger>
            {isDomainManager && <TabsTrigger value="endorsements">Endorsements</TabsTrigger>}
            {isFacilitator && <TabsTrigger value="quotas">Award Quotas</TabsTrigger>}
            {(isPresentationStage || isResultStage) && (isJudge || isFacilitator) && (
              <TabsTrigger value="scoring">Scoring</TabsTrigger>
            )}
            {(isFacilitator || isHeadJudge) && (isPresentationStage || isResultStage) && (
              <TabsTrigger value="winners">Winner Management</TabsTrigger>
            )}
            <TabsTrigger value="about">About</TabsTrigger>
          </TabsList>

          {isResultStage && (
            <TabsContent value="rewardwall" className="space-y-6">
              {/* A/B Test Design Toggle */}
              <div className="flex items-center justify-end mb-4 gap-2">
                <span className="text-sm text-muted-foreground">UI Design:</span>
                <div className="flex items-center space-x-2">
                  <span className="text-sm">Classic</span>
                  <Switch checked={useNewDesign} onCheckedChange={setUseNewDesign} id="design-toggle" />
                  <span className="text-sm">Modern</span>
                </div>
                <Palette className="h-4 w-4 text-muted-foreground ml-1" />
              </div>

              {useNewDesign ? (
                <RewardWallVariant eventId={event.id} isResultStage={isResultStage} />
              ) : (
                <RewardWall eventId={event.id} isResultStage={isResultStage} />
              )}
            </TabsContent>
          )}

          <TabsContent value="individual" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Individual Award Types</CardTitle>
                <CardDescription>
                  {event.currentStage === "nomination" && canNominate
                    ? "Select an award type to recognize outstanding individual contributions"
                    : "Click on an award type to filter nominations"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {spotIndividualAwardTypes.map((award) => (
                    <div
                      key={award.id}
                      className={`rounded-lg border p-4 cursor-pointer transition-all hover:border-primary hover:shadow-sm ${
                        selectedFilter === award.id ? "border-primary bg-primary/5" : ""
                      }`}
                      onClick={() => handleAwardSelection(award.id, "individual")}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`rounded-full p-2 ${award.color}`}>
                          <DynamicIcon icon={award.icon} />
                        </div>
                        <div>
                          <h3 className="font-medium">{award.title}</h3>
                          <p className="text-sm text-muted-foreground">{award.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="team" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Team Award</CardTitle>
                <CardDescription>
                  {event.currentStage === "nomination" && canNominate
                    ? "Recognize exceptional team collaboration and achievements"
                    : "Click on the award type to filter nominations"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`rounded-lg border p-6 cursor-pointer transition-all hover:border-primary hover:shadow-sm ${
                    selectedFilter === spotTeamAwardTypes[0].id ? "border-primary bg-primary/5" : ""
                  }`}
                  onClick={() => handleAwardSelection(spotTeamAwardTypes[0].id, "team")}
                >
                  <div className="flex items-start gap-4">
                    <div className={`rounded-full p-3 ${spotTeamAwardTypes[0].color}`}>
                      <DynamicIcon icon={spotTeamAwardTypes[0].icon} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium">{spotTeamAwardTypes[0].title}</h3>
                      <p className="text-muted-foreground">{spotTeamAwardTypes[0].description}</p>

                      <div className="mt-4">
                        <h4 className="text-sm font-medium mb-2">Award Criteria:</h4>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          {spotTeamAwardTypes[0].criteria.map((criterion, index) => (
                            <li key={index} className="text-muted-foreground">
                              {criterion}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="mt-2">
                        <p className="text-sm">
                          <span className="font-medium">Reward: </span>
                          <span className="text-muted-foreground">{spotTeamAwardTypes[0].reward}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="judges" className="space-y-6">
            <AwardEventJudges
              eventId={event.id}
              event={event}
              isFacilitator={isFacilitator}
              currentUserId={currentUser.id}
            />
          </TabsContent>

          {isDomainManager && (
            <TabsContent value="endorsements" className="space-y-6">
              <DomainManagerEndorsementPanel
                eventId={event.id}
                nominations={nominations}
                currentUserId={currentUser.id}
                onEndorsementUpdate={handleEndorsementUpdate}
              />
            </TabsContent>
          )}

          {isFacilitator && (
            <TabsContent value="quotas" className="space-y-6">
              <AwardQuotas eventId={event.id} isFacilitator={isFacilitator} isReadOnly={isResultStage} />

              <Alert
                variant="default"
                className="bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800/30 mt-4"
              >
                <Award className="h-4 w-4 text-amber-600" />
                <AlertTitle>Setting Award Quotas</AlertTitle>
                <AlertDescription>
                  Award quotas determine how many winners will be selected for each award type. Setting these early
                  helps nominees understand the competitive nature of the awards and ensures transparency in the
                  selection process.
                </AlertDescription>
              </Alert>
            </TabsContent>
          )}

          {(isPresentationStage || isResultStage) && (isJudge || isFacilitator) && (
            <TabsContent value="scoring" className="space-y-6">
              {isJudge && (
                <JudgeScoringPanel
                  eventId={event.id}
                  currentJudge={currentJudge}
                  isJudge={isJudge}
                  isPresentationStage={isPresentationStage}
                  isResultStage={isResultStage}
                  nominations={nominations.filter((nom) => nom.endorsement?.status === "endorsed")}
                />
              )}

              {isFacilitator && (
                <FacilitatorScoringPanel
                  eventId={event.id}
                  isPresentationStage={isPresentationStage || isResultStage}
                  nominations={nominations.filter((nom) => nom.endorsement?.status === "endorsed")}
                />
              )}
            </TabsContent>
          )}

          {(isFacilitator || isHeadJudge) && (isPresentationStage || isResultStage) && (
            <TabsContent value="winners" className="space-y-6">
              <WinnerManagement
                eventId={event.id}
                isPresentationStage={isPresentationStage}
                isResultStage={isResultStage}
                isFacilitator={isFacilitator}
                isHeadJudge={isHeadJudge}
              />
            </TabsContent>
          )}

          <TabsContent value="about" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>About {event.title}</CardTitle>
                <CardDescription>
                  Spot Awards are designed to provide immediate recognition for outstanding contributions.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  Spot Awards are a way to recognize employees for specific actions or achievements in real-time. Unlike
                  formal recognition programs that may have nomination periods and committees, Spot Awards can be given
                  at any time to acknowledge exceptional work.
                </p>

                <div className="rounded-lg border p-4 bg-muted/50">
                  <h4 className="font-medium mb-2">Key Features of Spot Awards</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Immediate recognition for specific achievements</li>
                    <li>Simple nomination process with quick approval</li>
                    <li>Available for both individual and team recognition</li>
                    <li>Focused on recognizing actions rather than long-term performance</li>
                    <li>Tangible rewards that are delivered promptly</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Individual Awards</h4>
                  <p className="text-sm text-muted-foreground">
                    Individual Spot Awards recognize personal contributions across different areas of excellence. Each
                    award type focuses on a specific aspect of performance or behavior that contributes to our company's
                    success.
                  </p>

                  <h4 className="font-medium">Team Award</h4>
                  <p className="text-sm text-muted-foreground">
                    The All-Star Team award recognizes groups that demonstrate exceptional collaboration, innovation,
                    and results. This award celebrates the power of teamwork and collective achievement.
                  </p>
                </div>

                <div className="rounded-lg border p-4 mt-4">
                  <h4 className="font-medium mb-2">Award Process</h4>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>
                      <span className="font-medium">Nomination Stage</span>
                      <p className="text-sm text-muted-foreground">
                        Employees submit nominations for individuals or teams who deserve recognition.
                      </p>
                    </li>
                    <li>
                      <span className="font-medium">Domain Manager Endorsement</span>
                      <p className="text-sm text-muted-foreground">
                        Nominations must be endorsed by a domain manager from the relevant service line to proceed.
                      </p>
                    </li>
                    <li>
                      <span className="font-medium">Presentation Stage</span>
                      <p className="text-sm text-muted-foreground">
                        Endorsed nominees present their achievements to the evaluation committee.
                      </p>
                    </li>
                    <li>
                      <span className="font-medium">Results Stage</span>
                      <p className="text-sm text-muted-foreground">
                        Winners are announced and awards are presented in team meetings or department gatherings.
                      </p>
                    </li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Nominations List - Only shown if shouldShowNominationsList() returns true */}
        {shouldShowNominationsList() && (
          <div className="mt-10" ref={nominationsListRef}>
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle>Nominee List for {event.title}</CardTitle>
                    <CardDescription>
                      View all nominations for this award event. Use the filters to narrow down the list.
                    </CardDescription>
                  </div>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                    <div className="flex items-center gap-2">
                      <ListFilter className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground mr-2">Award:</span>
                      <select
                        className="text-sm border rounded-md px-2 py-1"
                        value={selectedFilter}
                        onChange={(e) => setSelectedFilter(e.target.value)}
                      >
                        <option value="all">All Nominations</option>
                        <option value="individual">Individual Awards</option>
                        <option value="team">Team Awards</option>
                        {[...spotIndividualAwardTypes, ...spotTeamAwardTypes].map((award) => (
                          <option key={award.id} value={award.id}>
                            {award.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    {isNominationStage && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground mr-2">Endorsement:</span>
                        <select
                          className="text-sm border rounded-md px-2 py-1"
                          value={endorsementFilter}
                          onChange={(e) => setEndorsementFilter(e.target.value as any)}
                        >
                          <option value="all">All Statuses</option>
                          <option value="endorsed">Endorsed</option>
                          <option value="pending">Pending</option>
                          <option value="rejected">Rejected</option>
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {/* Add Nomination Card - always shown at the beginning during nomination phase */}
                  {event.currentStage === "nomination" && canNominate && (
                    <AddNominationCard onClick={handleAddNominationClick} />
                  )}

                  {filteredNominations.length > 0 ? (
                    filteredNominations.map((nomination) => (
                      <NominationCard
                        key={nomination.id}
                        nomination={nomination}
                        onClick={() => handleNominationClick(nomination.id)}
                        canEdit={canEditNomination(nomination)}
                        onEdit={() => handleEditNomination(nomination)}
                        onVote={(userId, userName) => handleVote(nomination.id, userId, userName)}
                        onComment={(userId, userName, userAvatar, userInitials, comment) =>
                          handleComment(nomination.id, userId, userName, userAvatar, userInitials, comment)
                        }
                        eventId={eventId}
                      />
                    ))
                  ) : (
                    <div className="text-center py-8 col-span-3">
                      <p className="text-muted-foreground">
                        {nominations.length === 0
                          ? "No nominations have been submitted yet."
                          : isPresentationStage
                            ? "No endorsed nominations match the selected filter."
                            : "No nominations match the selected filter."}
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Nomination Details Drawer */}
            <NominationDrawer
              nomination={selectedNomination}
              open={drawerOpen}
              onOpenChange={setDrawerOpen}
              canEdit={selectedNomination ? canEditNomination(selectedNomination) : false}
              onEdit={() => selectedNomination && handleEditNomination(selectedNomination)}
              currentUserId={currentUser.id}
            />

            {/* Nomination Form Drawer */}
            <NominationFormDrawer
              open={formDrawerOpen}
              onOpenChange={setFormDrawerOpen}
              eventId={event.id}
              awardType={selectedAwardType}
              nominationType={nominationType}
              nomination={selectedNomination}
              isEditing={isEditing}
            />
          </div>
        )}
      </DashboardShell>
    )
  } catch (err) {
    console.error("Error in render:", err)
    setError(err instanceof Error ? err : new Error(String(err)))
    return <ErrorFallback error={err instanceof Error ? err : new Error(String(err))} />
  }
}

