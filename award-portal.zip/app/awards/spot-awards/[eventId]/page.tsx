"use client"

import { useState, useEffect, useRef } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardEventStageIndicator } from "@/components/award-event-stage-indicator"
import { NominationCard } from "@/components/nomination-card"
import { NominationDrawer } from "@/components/nomination-drawer"
import { NominationFormDrawer } from "@/components/nomination-form-drawer"
import { CreateAwardEventDrawer } from "@/components/create-award-event-drawer"
import { AddNominationCard } from "@/components/add-nomination-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  CalendarDays,
  Clock,
  Info,
  Lightbulb,
  Users,
  Heart,
  Headphones,
  Sparkles,
  Compass,
  ListFilter,
  Edit,
  FileText,
  Globe,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { getAwardEventById, isNominationPeriodActive, canEditEvent } from "@/data/award-events"
import { getNominationById, getNominationsByEventId } from "@/data/nominations"
import type { AwardEvent } from "@/types/award-events"
import type { Nomination } from "@/types/nominations"
import type { Judge } from "@/types/judges"
import { Badge } from "@/components/ui/badge"
import { AwardEventJudges } from "@/components/award-event-judges"
import { JudgeScoringPanel } from "@/components/judge-scoring-panel"
import { FacilitatorScoringPanel } from "@/components/facilitator-scoring-panel"

// Team Award Type
const teamAwardType = {
  id: "all-star-team",
  title: "All-Star Team",
  description: "For teams that demonstrate exceptional collaboration, innovation, and results.",
  icon: Users,
  color: "bg-purple-100 dark:bg-purple-900",
  iconColor: "text-purple-600 dark:text-purple-400",
  criteria: [
    "Demonstrated exceptional teamwork and collaboration",
    "Achieved significant results through collective effort",
    "Overcame challenges through innovative problem-solving",
    "Consistently delivered high-quality work as a unit",
  ],
  reward: "Team celebration event and recognition at company meeting",
}

// Individual Award Types
const individualAwardTypes = [
  {
    id: "star-of-agile",
    title: "Star of Agile",
    description: "For individuals who exemplify agile principles and drive process improvements.",
    icon: Compass,
    color: "bg-blue-100 dark:bg-blue-900",
    iconColor: "text-blue-600 dark:text-blue-400",
    criteria: [
      "Consistently applies agile methodologies to improve workflows",
      "Facilitates effective sprint planning and retrospectives",
      "Removes obstacles to help the team deliver efficiently",
      "Promotes continuous improvement and adaptation",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-customer-service",
    title: "Star of Customer Service",
    description: "For individuals who provide exceptional service and support to customers.",
    icon: Headphones,
    color: "bg-green-100 dark:bg-green-900",
    iconColor: "text-green-600 dark:text-green-400",
    criteria: [
      "Consistently exceeds customer expectations",
      "Resolves complex customer issues with patience and empathy",
      "Receives outstanding customer feedback and testimonials",
      "Goes above and beyond to ensure customer satisfaction",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-engagement",
    title: "Star of Engagement",
    description: "For individuals who foster a positive work environment and team spirit.",
    icon: Heart,
    color: "bg-red-100 dark:bg-red-900",
    iconColor: "text-red-600 dark:text-red-400",
    criteria: [
      "Actively promotes team morale and positive culture",
      "Organizes team-building activities and celebrations",
      "Supports colleagues during challenging times",
      "Contributes to an inclusive and collaborative atmosphere",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-innovation",
    title: "Star of Innovation",
    description: "For individuals who develop creative solutions and drive innovation.",
    icon: Lightbulb,
    color: "bg-amber-100 dark:bg-amber-900",
    iconColor: "text-amber-600 dark:text-amber-400",
    criteria: [
      "Develops innovative solutions to complex problems",
      "Introduces new ideas that improve processes or products",
      "Thinks outside the box to overcome challenges",
      "Encourages and supports innovation from others",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-leadership",
    title: "Star of Leadership",
    description: "For individuals who demonstrate exceptional leadership qualities.",
    icon: Sparkles,
    color: "bg-indigo-100 dark:bg-indigo-900",
    iconColor: "text-indigo-600 dark:text-indigo-400",
    criteria: [
      "Inspires and motivates team members to achieve their best",
      "Provides clear direction and guidance during challenging times",
      "Takes ownership of problems and leads by example",
      "Develops and mentors others effectively",
    ],
    reward: "$150 gift card and recognition certificate",
  },
]

// All award types combined
const allAwardTypes = [...individualAwardTypes, teamAwardType]

// Mock function to check if the current user is a judge for this event
const isUserJudgeForEvent = (userId: string, eventId: string): boolean => {
  // In a real app, this would check against your database
  // For this example, we'll assume the current user is a judge if they're "judge-1"
  return userId === "judge-1" || userId === "judge-4" || userId === "judge-6"
}

// Mock function to check if the current user is a facilitator for this event
const isUserFacilitatorForEvent = (userId: string, eventId: string): boolean => {
  // In a real app, this would check against your database
  return userId === "admin-user" || userId === "jane-smith" || userId === "alex-morgan"
}

// Mock function to get the judge profile for the current user
const getCurrentJudgeProfile = (userId: string, eventId: string): Judge | null => {
  // In a real app, this would fetch from your database
  // For this example, we'll return a mock judge profile
  if (userId === "judge-1") {
    return {
      id: "judge-1",
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SJ",
      serviceLine: "technology",
      title: "Chief Technology Officer",
      bio: "20+ years experience in technology leadership and innovation",
    }
  } else if (userId === "judge-4") {
    return {
      id: "judge-4",
      name: "James Wilson",
      email: "james.wilson@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "JW",
      serviceLine: "cloud-services",
      title: "Cloud Architecture Director",
      bio: "Expert in cloud migration and infrastructure optimization",
    }
  } else if (userId === "judge-6") {
    return {
      id: "judge-6",
      name: "Robert Kim",
      email: "robert.kim@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RK",
      serviceLine: "cybersecurity",
      title: "Security Operations Lead",
      bio: "Expert in enterprise security and risk management",
    }
  }

  return null
}

export default function SpotAwardEventPage({ params }: { params: { eventId: string } }) {
  const router = useRouter()
  const { eventId } = params
  const nominationsListRef = useRef<HTMLDivElement>(null)

  // Mock current user - in a real app, this would come from authentication
  const currentUser = { id: "jane-smith", name: "Jane Smith" }

  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedAwardType, setSelectedAwardType] = useState<string | null>(null)
  const [nominationType, setNominationType] = useState<"individual" | "team">("individual")
  const [canNominate, setCanNominate] = useState(false)
  const [canEdit, setCanEdit] = useState(false)
  const [isJudge, setIsJudge] = useState(false)
  const [isFacilitator, setIsFacilitator] = useState(false)
  const [currentJudge, setCurrentJudge] = useState<Judge | null>(null)

  // For presentation stage
  const [nominations, setNominations] = useState<Nomination[]>([])
  const [filteredNominations, setFilteredNominations] = useState<Nomination[]>([])
  const [selectedFilter, setSelectedFilter] = useState<string>("all")
  const [selectedNomination, setSelectedNomination] = useState<Nomination | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)

  // For nomination form drawer
  const [formDrawerOpen, setFormDrawerOpen] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  useEffect(() => {
    // Fetch event data
    const awardEvent = getAwardEventById(eventId)
    setEvent(awardEvent || null)

    if (awardEvent) {
      setCanNominate(isNominationPeriodActive(awardEvent.id))

      // Check if current user can edit the event
      setCanEdit(canEditEvent(awardEvent, currentUser.id))

      // Check if current user is a judge for this event
      const userIsJudge = isUserJudgeForEvent(currentUser.id, eventId)
      setIsJudge(userIsJudge)

      // Check if current user is a facilitator for this event
      const userIsFacilitator = isUserFacilitatorForEvent(currentUser.id, eventId)
      setIsFacilitator(userIsFacilitator)

      // If user is a judge, get their judge profile
      if (userIsJudge) {
        const judgeProfile = getCurrentJudgeProfile(currentUser.id, eventId)
        setCurrentJudge(judgeProfile)
      }

      // Get nominations for this event
      const eventNominations = getNominationsByEventId(eventId)
      console.log(`Found ${eventNominations.length} nominations for event ${eventId}`)
      setNominations(eventNominations)
      setFilteredNominations(eventNominations)
    }

    setIsLoading(false)
  }, [eventId, currentUser.id])

  // Filter nominations when filter changes
  useEffect(() => {
    if (selectedFilter === "all") {
      setFilteredNominations(nominations)
    } else if (selectedFilter === "individual" || selectedFilter === "team") {
      setFilteredNominations(nominations.filter((nomination) => nomination.nominationType === selectedFilter))
    } else {
      setFilteredNominations(nominations.filter((nomination) => nomination.awardType === selectedFilter))
    }
  }, [selectedFilter, nominations])

  // Function to handle award selection
  const handleAwardSelection = (awardId: string, type: "individual" | "team") => {
    // Always set the selected award type and nomination type for potential new nominations
    setSelectedAwardType(awardId)
    setNominationType(type)

    // Toggle behavior for filtering:
    // If the user clicks on the already selected filter, reset to show all
    // Otherwise, filter to the selected award type
    if (selectedFilter === awardId) {
      setSelectedFilter("all")
    } else {
      setSelectedFilter(awardId)
    }

    // Scroll to the nominations list section
    nominationsListRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  // Function to go back to the main spot awards list
  const backToList = () => {
    router.push("/awards/spot-awards")
  }

  // Function to handle nomination card click
  const handleNominationClick = (nominationId: string) => {
    const nomination = getNominationById(nominationId)
    if (nomination) {
      setSelectedNomination(nomination)
      setDrawerOpen(true)
    }
  }

  // Function to handle add nomination card click
  const handleAddNominationClick = () => {
    setIsEditing(false)
    setFormDrawerOpen(true)
  }

  // Function to handle edit nomination
  const handleEditNomination = () => {
    setIsEditing(true)
    setDrawerOpen(false)
    setFormDrawerOpen(true)
  }

  // Get award type display name
  const getAwardTypeDisplay = (awardType: string) => {
    const awardTypes: Record<string, string> = {
      "star-of-agile": "Star of Agile",
      "star-of-customer-service": "Star of Customer Service",
      "star-of-engagement": "Star of Engagement",
      "star-of-innovation": "Star of Innovation",
      "star-of-leadership": "Star of Leadership",
      "all-star-team": "All-Star Team",
    }
    return awardTypes[awardType] || awardType
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse text-center">
            <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
            <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
          </div>
        </div>
      </DashboardShell>
    )
  }

  if (!event) {
    return (
      <DashboardShell>
        <div className="mb-4">
          <Button
            variant="ghost"
            className="flex items-center text-sm text-muted-foreground hover:text-foreground"
            onClick={backToList}
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back to Spot Awards
          </Button>
        </div>

        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Event Not Found</AlertTitle>
          <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
        </Alert>
      </DashboardShell>
    )
  }

  const isPresentationStage = event.currentStage === "presentation"

  return (
    <DashboardShell>
      <div className="mb-4">
        <Button
          variant="ghost"
          className="flex items-center text-sm text-muted-foreground hover:text-foreground"
          onClick={backToList}
        >
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Spot Awards
        </Button>
      </div>

      <div className="flex items-center justify-between">
        <DashboardHeader heading={event.title} text={event.description} />

        {/* Edit button - only shown if user has permission to edit */}
        {canEdit && (
          <div className="flex items-center gap-2">
            {event.status === "draft" && (
              <Badge variant="outline" className="border-dashed">
                <FileText className="mr-1 h-3 w-3" />
                Draft
              </Badge>
            )}
            <CreateAwardEventDrawer
              buttonVariant="outline"
              buttonSize="sm"
              buttonText="Edit Event"
              drawerTitle="Edit Award Event"
              drawerDescription="Update the award event details and timeline."
              existingEvent={event}
              isEditing={true}
              currentUser={currentUser}
            >
              <Button variant="outline" size="sm">
                <Edit className="mr-2 h-4 w-4" />
                Edit Event
              </Button>
            </CreateAwardEventDrawer>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="flex-1">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Event Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Quarter: <span className="font-medium">{event.quarter}</span>
                  </span>
                </div>
                {event.theme && (
                  <div className="flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      Theme: <span className="font-medium">{event.theme}</span>
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Current Stage:{" "}
                    <span className="font-medium">
                      {event.currentStage === "nomination"
                        ? "Nomination"
                        : event.currentStage === "presentation"
                          ? "Presentation"
                          : "Results"}
                    </span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {event.status === "published" ? (
                    <>
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        Status: <span className="font-medium">Published</span>
                      </span>
                    </>
                  ) : (
                    <>
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        Status: <span className="font-medium">Draft</span>
                        <span className="text-xs text-muted-foreground ml-1">
                          (Only visible to creators and facilitators)
                        </span>
                      </span>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          <AwardEventStageIndicator event={event} />
        </div>
      </div>

      {event.currentStage === "nomination" && !canNominate && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Nomination Period Not Active</AlertTitle>
          <AlertDescription>
            The nomination period for this award event is not currently active. Nominations will open on{" "}
            {event.stages.nomination.startDate.toLocaleDateString()}.
          </AlertDescription>
        </Alert>
      )}

      {event.currentStage === "presentation" && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Presentation Stage</AlertTitle>
          <AlertDescription>
            This award event is currently in the presentation stage. Nominees are presenting their achievements to the
            evaluation committee.
            {isJudge && " As a judge, you can score the presentations in the Scoring tab."}
            {isFacilitator && " As a facilitator, you can view all scores in the Scoring tab."}
          </AlertDescription>
        </Alert>
      )}

      {event.currentStage === "result" && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Results Announced</AlertTitle>
          <AlertDescription>
            The results for this award event have been announced. You can view the winners below.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="individual" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="individual">Individual Awards</TabsTrigger>
          <TabsTrigger value="team">Team Awards</TabsTrigger>
          <TabsTrigger value="judges">Judges</TabsTrigger>
          {isPresentationStage && (isJudge || isFacilitator) && <TabsTrigger value="scoring">Scoring</TabsTrigger>}
          <TabsTrigger value="about">About Spot Awards</TabsTrigger>
        </TabsList>

        <TabsContent value="individual" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Individual Award Types</CardTitle>
              <CardDescription>
                {event.currentStage === "nomination" && canNominate
                  ? "Select an award type to recognize outstanding individual contributions"
                  : "Click on an award type to filter nominations"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {individualAwardTypes.map((award) => (
                  <div
                    key={award.id}
                    className={`rounded-lg border p-4 cursor-pointer transition-all hover:border-primary hover:shadow-sm ${
                      selectedFilter === award.id ? "border-primary bg-primary/5" : ""
                    }`}
                    onClick={() => handleAwardSelection(award.id, "individual")}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`rounded-full p-2 ${award.color}`}>
                        <award.icon className={`h-5 w-5 ${award.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="font-medium">{award.title}</h3>
                        <p className="text-sm text-muted-foreground">{award.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Team Award</CardTitle>
              <CardDescription>
                {event.currentStage === "nomination" && canNominate
                  ? "Recognize exceptional team collaboration and achievements"
                  : "Click on the award type to filter nominations"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                className={`rounded-lg border p-6 cursor-pointer transition-all hover:border-primary hover:shadow-sm ${
                  selectedFilter === teamAwardType.id ? "border-primary bg-primary/5" : ""
                }`}
                onClick={() => handleAwardSelection(teamAwardType.id, "team")}
              >
                <div className="flex items-start gap-4">
                  <div className={`rounded-full p-3 ${teamAwardType.color}`}>
                    <teamAwardType.icon className={`h-6 w-6 ${teamAwardType.iconColor}`} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{teamAwardType.title}</h3>
                    <p className="text-muted-foreground">{teamAwardType.description}</p>

                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Award Criteria:</h4>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        {teamAwardType.criteria.map((criterion, index) => (
                          <li key={index} className="text-muted-foreground">
                            {criterion}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-2">
                      <p className="text-sm">
                        <span className="font-medium">Reward: </span>
                        <span className="text-muted-foreground">{teamAwardType.reward}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="judges" className="space-y-6">
          <AwardEventJudges
            eventId={event.id}
            event={event}
            canManageJudges={canEdit && event.status === "published"}
            currentUserId={currentUser.id}
          />
        </TabsContent>

        {isPresentationStage && (isJudge || isFacilitator) && (
          <TabsContent value="scoring" className="space-y-6">
            {isJudge && (
              <JudgeScoringPanel
                eventId={event.id}
                currentJudge={currentJudge}
                isJudge={isJudge}
                isPresentationStage={isPresentationStage}
                nominations={nominations}
              />
            )}

            {isFacilitator && (
              <FacilitatorScoringPanel
                eventId={event.id}
                isPresentationStage={isPresentationStage}
                nominations={nominations}
              />
            )}
          </TabsContent>
        )}

        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>About {event.title}</CardTitle>
              <CardDescription>
                Spot Awards are designed to provide immediate recognition for outstanding contributions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Spot Awards are a way to recognize employees for specific actions or achievements in real-time. Unlike
                formal recognition programs that may have nomination periods and committees, Spot Awards can be given at
                any time to acknowledge exceptional work.
              </p>

              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium mb-2">Key Features of Spot Awards</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Immediate recognition for specific achievements</li>
                  <li>Simple nomination process with quick approval</li>
                  <li>Available for both individual and team recognition</li>
                  <li>Focused on recognizing actions rather than long-term performance</li>
                  <li>Tangible rewards that are delivered promptly</li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Individual Awards</h4>
                <p className="text-sm text-muted-foreground">
                  Individual Spot Awards recognize personal contributions across different areas of excellence. Each
                  award type focuses on a specific aspect of performance or behavior that contributes to our company's
                  success.
                </p>

                <h4 className="font-medium">Team Award</h4>
                <p className="text-sm text-muted-foreground">
                  The All-Star Team award recognizes groups that demonstrate exceptional collaboration, innovation, and
                  results. This award celebrates the power of teamwork and collective achievement.
                </p>
              </div>

              <div className="rounded-lg border p-4 mt-4">
                <h4 className="font-medium mb-2">Award Process</h4>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Nomination Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Employees submit nominations for individuals or teams who deserve recognition.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Presentation Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Nominees present their achievements to the evaluation committee.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Results Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Winners are announced and awards are presented in team meetings or department gatherings.
                    </p>
                  </li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Nominations List - Shown in all stages */}
      <div className="mt-10" ref={nominationsListRef}>
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <CardTitle>
                  {event.currentStage === "result" ? "Winners" : "Nominees"} for {event.title}
                </CardTitle>
                <CardDescription>
                  {event.currentStage === "nomination" && "View current nominations for this award event."}
                  {event.currentStage === "presentation" &&
                    "Review the nominations and their achievements during the presentation stage."}
                  {event.currentStage === "result" && "Congratulations to our award winners!"}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <ListFilter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground mr-2">Filter by:</span>
                <select
                  className="text-sm border rounded-md px-2 py-1"
                  value={selectedFilter}
                  onChange={(e) => setSelectedFilter(e.target.value)}
                >
                  <option value="all">All Nominations</option>
                  <option value="individual">Individual Awards</option>
                  <option value="team">Team Awards</option>
                  {allAwardTypes.map((award) => (
                    <option key={award.id} value={award.id}>
                      {award.title}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredNominations.length > 0 ? (
                <>
                  {filteredNominations.map((nomination) => (
                    <NominationCard
                      key={nomination.id}
                      nomination={nomination}
                      onClick={() => handleNominationClick(nomination.id)}
                    />
                  ))}

                  {/* Add Nomination Card - only shown in nomination phase */}
                  {event.currentStage === "nomination" && canNominate && (
                    <AddNominationCard onClick={handleAddNominationClick} />
                  )}
                </>
              ) : (
                <>
                  <div className="text-center py-8 col-span-3">
                    <p className="text-muted-foreground">
                      {nominations.length === 0
                        ? "No nominations have been submitted yet."
                        : "No nominations match the selected filter."}
                    </p>
                  </div>

                  {/* Add Nomination Card when no nominations exist */}
                  {event.currentStage === "nomination" && canNominate && nominations.length === 0 && (
                    <div className="col-span-3 max-w-md mx-auto">
                      <AddNominationCard onClick={handleAddNominationClick} />
                    </div>
                  )}
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Nomination Details Drawer */}
        <NominationDrawer
          nomination={selectedNomination}
          open={drawerOpen}
          onOpenChange={setDrawerOpen}
          canEdit={event.currentStage === "nomination" && canNominate}
          onEdit={handleEditNomination}
        />

        {/* Nomination Form Drawer */}
        <NominationFormDrawer
          open={formDrawerOpen}
          onOpenChange={setFormDrawerOpen}
          eventId={event.id}
          awardType={selectedAwardType}
          nominationType={nominationType}
          nomination={selectedNomination}
          isEditing={isEditing}
        />
      </div>
    </DashboardShell>
  )
}

