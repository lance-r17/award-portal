"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { SpotAwardCarousel } from "@/components/award/spot-award-carousel"
import { AwardEventCard } from "@/components/award/award-event-card"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Filter, Zap } from "lucide-react"
import { getAwardEventsByType, getActiveAwardEventsByType } from "@/data/award-events"

export default function SpotAwardsPage() {
  const router = useRouter()
  const [showPastEvents, setShowPastEvents] = useState(false)

  // Filter events based on active status
  const spotEvents = showPastEvents ? getAwardEventsByType("spot") : getActiveAwardEventsByType("spot")

  // Get the latest 3 active spot award events for the carousel
  const featuredEvents = getActiveAwardEventsByType("spot").slice(0, 3)

  // Function to view a specific event
  const viewEvent = (eventId: string) => {
    router.push(`/awards/spot-awards/${eventId}`)
  }

  return (
    <DashboardShell>
      <div className="flex items-center justify-between">
        <DashboardHeader
          heading="Spot Awards"
          text="Immediate recognition for outstanding contributions and specific achievements."
        />
        <Button variant="outline" size="sm" onClick={() => setShowPastEvents(!showPastEvents)}>
          <Filter className="mr-2 h-4 w-4" />
          {showPastEvents ? "Show Active Only" : "Show Past Events"}
        </Button>
      </div>

      {/* Featured Events Carousel */}
      {featuredEvents.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Featured Spot Award Events</h2>
          <SpotAwardCarousel events={featuredEvents} onEventSelect={viewEvent} />
        </div>
      )}

      {/* All Spot Award Events */}
      <div className="space-y-6">
        <h2 className="text-xl font-semibold">All Spot Award Events</h2>

        {spotEvents.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {spotEvents.map((event) => (
              <AwardEventCard key={event.id} event={event} onSelect={viewEvent} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Zap className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No Spot Award Events</h3>
            <p className="text-muted-foreground mt-2 mb-6">
              {showPastEvents
                ? "There are no spot award events in the system."
                : "There are no active spot award events at this time."}
            </p>
          </div>
        )}
      </div>

      {/* About Spot Awards */}
      <div className="mt-10">
        <Card>
          <CardHeader>
            <CardTitle>About Spot Awards</CardTitle>
            <CardDescription>
              Spot Awards are designed to provide immediate recognition for outstanding contributions.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              Spot Awards are quarterly events that recognize employees for specific actions or achievements. Each
              quarter, a new Spot Award event is created with a specific theme and focus.
            </p>

            <div className="rounded-lg border p-4 bg-muted/50">
              <h4 className="font-medium mb-2">The Spot Award Process</h4>
              <ol className="list-decimal pl-5 space-y-2">
                <li>
                  <span className="font-medium">Nomination Stage</span>
                  <p className="text-sm text-muted-foreground">
                    Employees submit nominations for individuals or teams who deserve recognition.
                  </p>
                </li>
                <li>
                  <span className="font-medium">Presentation Stage</span>
                  <p className="text-sm text-muted-foreground">
                    Nominees present their achievements to the evaluation committee.
                  </p>
                </li>
                <li>
                  <span className="font-medium">Results Stage</span>
                  <p className="text-sm text-muted-foreground">
                    Winners are announced and awards are presented in team meetings or department gatherings.
                  </p>
                </li>
              </ol>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 rounded-lg border p-4">
                <h4 className="font-medium mb-2">Individual Awards</h4>
                <p className="text-sm text-muted-foreground">
                  Individual Spot Awards recognize personal contributions across different areas of excellence including
                  agile practices, customer service, team engagement, innovation, and leadership.
                </p>
              </div>
              <div className="flex-1 rounded-lg border p-4">
                <h4 className="font-medium mb-2">Team Awards</h4>
                <p className="text-sm text-muted-foreground">
                  The All-Star Team award recognizes groups that demonstrate exceptional collaboration, innovation, and
                  results. This award celebrates the power of teamwork and collective achievement.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
