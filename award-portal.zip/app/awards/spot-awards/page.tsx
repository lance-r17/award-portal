"use client"

import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardNominationForm } from "@/components/award-nomination-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Lightbulb, Users, Heart, Headphones, Sparkles, Compass } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

// Team Award Type
const teamAwardType = {
  id: "all-star-team",
  title: "All-Star Team",
  description: "For teams that demonstrate exceptional collaboration, innovation, and results.",
  icon: Users,
  color: "bg-purple-100 dark:bg-purple-900",
  iconColor: "text-purple-600 dark:text-purple-400",
  criteria: [
    "Demonstrated exceptional teamwork and collaboration",
    "Achieved significant results through collective effort",
    "Overcame challenges through innovative problem-solving",
    "Consistently delivered high-quality work as a unit",
  ],
  reward: "Team celebration event and recognition at company meeting",
}

// Individual Award Types
const individualAwardTypes = [
  {
    id: "star-of-agile",
    title: "Star of Agile",
    description: "For individuals who exemplify agile principles and drive process improvements.",
    icon: Compass,
    color: "bg-blue-100 dark:bg-blue-900",
    iconColor: "text-blue-600 dark:text-blue-400",
    criteria: [
      "Consistently applies agile methodologies to improve workflows",
      "Facilitates effective sprint planning and retrospectives",
      "Removes obstacles to help the team deliver efficiently",
      "Promotes continuous improvement and adaptation",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-customer-service",
    title: "Star of Customer Service",
    description: "For individuals who provide exceptional service and support to customers.",
    icon: Headphones,
    color: "bg-green-100 dark:bg-green-900",
    iconColor: "text-green-600 dark:text-green-400",
    criteria: [
      "Consistently exceeds customer expectations",
      "Resolves complex customer issues with patience and empathy",
      "Receives outstanding customer feedback and testimonials",
      "Goes above and beyond to ensure customer satisfaction",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-engagement",
    title: "Star of Engagement",
    description: "For individuals who foster a positive work environment and team spirit.",
    icon: Heart,
    color: "bg-red-100 dark:bg-red-900",
    iconColor: "text-red-600 dark:text-red-400",
    criteria: [
      "Actively promotes team morale and positive culture",
      "Organizes team-building activities and celebrations",
      "Supports colleagues during challenging times",
      "Contributes to an inclusive and collaborative atmosphere",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-innovation",
    title: "Star of Innovation",
    description: "For individuals who develop creative solutions and drive innovation.",
    icon: Lightbulb,
    color: "bg-amber-100 dark:bg-amber-900",
    iconColor: "text-amber-600 dark:text-amber-400",
    criteria: [
      "Develops innovative solutions to complex problems",
      "Introduces new ideas that improve processes or products",
      "Thinks outside the box to overcome challenges",
      "Encourages and supports innovation from others",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-leadership",
    title: "Star of Leadership",
    description: "For individuals who demonstrate exceptional leadership qualities.",
    icon: Sparkles,
    color: "bg-indigo-100 dark:bg-indigo-900",
    iconColor: "text-indigo-600 dark:text-indigo-400",
    criteria: [
      "Inspires and motivates team members to achieve their best",
      "Provides clear direction and guidance during challenging times",
      "Takes ownership of problems and leads by example",
      "Develops and mentors others effectively",
    ],
    reward: "$150 gift card and recognition certificate",
  },
]

// Add state for selected award type at the top of the component
export default function SpotAwardsPage() {
  const [selectedAwardType, setSelectedAwardType] = useState<string | null>(null)
  const [nominationType, setNominationType] = useState<"individual" | "team">("individual")

  // Function to handle award selection
  const handleAwardSelection = (awardId: string, type: "individual" | "team") => {
    setSelectedAwardType(awardId)
    setNominationType(type)
    document.getElementById(type === "individual" ? "nomination-form" : "team-nomination-form")?.scrollIntoView({
      behavior: "smooth",
    })
  }

  return (
    <DashboardShell>
      <div className="mb-4">
        <Link href="/awards" className="flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Awards
        </Link>
      </div>

      <DashboardHeader
        heading="Spot Awards"
        text="Immediate recognition for outstanding contributions and specific achievements."
      />

      <Tabs defaultValue="individual" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="individual">Individual Awards</TabsTrigger>
          <TabsTrigger value="team">Team Awards</TabsTrigger>
          <TabsTrigger value="about">About Spot Awards</TabsTrigger>
        </TabsList>

        <TabsContent value="individual" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Individual Award Types</CardTitle>
              <CardDescription>Select an award type to recognize outstanding individual contributions.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {individualAwardTypes.map((award) => (
                  <div
                    key={award.id}
                    className="rounded-lg border p-4 cursor-pointer transition-all hover:border-primary hover:shadow-sm"
                    onClick={() => handleAwardSelection(award.id, "individual")}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`rounded-full p-2 ${award.color}`}>
                        <award.icon className={`h-5 w-5 ${award.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="font-medium">{award.title}</h3>
                        <p className="text-sm text-muted-foreground">{award.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div id="nomination-form">
            <AwardNominationForm awardType="spot" nominationType="individual" selectedAwardType={selectedAwardType} />
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Team Award</CardTitle>
              <CardDescription>Recognize exceptional team collaboration and achievements.</CardDescription>
            </CardHeader>
            <CardContent>
              <div
                className="rounded-lg border p-6 cursor-pointer transition-all hover:border-primary hover:shadow-sm"
                onClick={() => handleAwardSelection(teamAwardType.id, "team")}
              >
                <div className="flex items-start gap-4">
                  <div className={`rounded-full p-3 ${teamAwardType.color}`}>
                    <teamAwardType.icon className={`h-6 w-6 ${teamAwardType.iconColor}`} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{teamAwardType.title}</h3>
                    <p className="text-muted-foreground">{teamAwardType.description}</p>

                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Award Criteria:</h4>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        {teamAwardType.criteria.map((criterion, index) => (
                          <li key={index} className="text-muted-foreground">
                            {criterion}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-2">
                      <p className="text-sm">
                        <span className="font-medium">Reward: </span>
                        <span className="text-muted-foreground">{teamAwardType.reward}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div id="team-nomination-form">
            <AwardNominationForm awardType="spot" nominationType="team" selectedAwardType={selectedAwardType} />
          </div>
        </TabsContent>

        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>About Spot Awards</CardTitle>
              <CardDescription>
                Spot Awards are designed to provide immediate recognition for outstanding contributions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Spot Awards are a way to recognize employees for specific actions or achievements in real-time. Unlike
                formal recognition programs that may have nomination periods and committees, Spot Awards can be given at
                any time to acknowledge exceptional work.
              </p>

              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium mb-2">Key Features of Spot Awards</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Immediate recognition for specific achievements</li>
                  <li>Simple nomination process with quick approval</li>
                  <li>Available for both individual and team recognition</li>
                  <li>Focused on recognizing actions rather than long-term performance</li>
                  <li>Tangible rewards that are delivered promptly</li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Individual Awards</h4>
                <p className="text-sm text-muted-foreground">
                  Individual Spot Awards recognize personal contributions across different areas of excellence. Each
                  award type focuses on a specific aspect of performance or behavior that contributes to our company's
                  success.
                </p>

                <h4 className="font-medium">Team Award</h4>
                <p className="text-sm text-muted-foreground">
                  The All-Star Team award recognizes groups that demonstrate exceptional collaboration, innovation, and
                  results. This award celebrates the power of teamwork and collective achievement.
                </p>
              </div>

              <div className="rounded-lg border p-4 mt-4">
                <h4 className="font-medium mb-2">Nomination Process</h4>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Select Award Type</span>
                    <p className="text-sm text-muted-foreground">Choose between individual or team award categories.</p>
                  </li>
                  <li>
                    <span className="font-medium">Complete Nomination Form</span>
                    <p className="text-sm text-muted-foreground">
                      Provide details about the achievement and its impact.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Manager Review</span>
                    <p className="text-sm text-muted-foreground">
                      Nominations are reviewed by department managers within 3 business days.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Award Presentation</span>
                    <p className="text-sm text-muted-foreground">
                      Approved awards are presented in team meetings or department gatherings.
                    </p>
                  </li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}

