"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { AwardNominationForm } from "@/components/award-nomination-form"
import { AwardEventStageIndicator } from "@/components/award-event-stage-indicator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  ArrowLeft,
  CalendarDays,
  Clock,
  Info,
  Lightbulb,
  Users,
  Heart,
  Headphones,
  Sparkles,
  Compass,
} from "lucide-react"
import Link from "next/link"
import { getAwardEventById, isNominationPeriodActive } from "@/data/award-events"
import type { AwardEvent } from "@/types/award-events"
import { useParams } from "next/navigation"

// Team Award Type
const teamAwardType = {
  id: "all-star-team",
  title: "All-Star Team",
  description: "For teams that demonstrate exceptional collaboration, innovation, and results.",
  icon: Users,
  color: "bg-purple-100 dark:bg-purple-900",
  iconColor: "text-purple-600 dark:text-purple-400",
  criteria: [
    "Demonstrated exceptional teamwork and collaboration",
    "Achieved significant results through collective effort",
    "Overcame challenges through innovative problem-solving",
    "Consistently delivered high-quality work as a unit",
  ],
  reward: "Team celebration event and recognition at company meeting",
}

// Individual Award Types
const individualAwardTypes = [
  {
    id: "star-of-agile",
    title: "Star of Agile",
    description: "For individuals who exemplify agile principles and drive process improvements.",
    icon: Compass,
    color: "bg-blue-100 dark:bg-blue-900",
    iconColor: "text-blue-600 dark:text-blue-400",
    criteria: [
      "Consistently applies agile methodologies to improve workflows",
      "Facilitates effective sprint planning and retrospectives",
      "Removes obstacles to help the team deliver efficiently",
      "Promotes continuous improvement and adaptation",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-customer-service",
    title: "Star of Customer Service",
    description: "For individuals who provide exceptional service and support to customers.",
    icon: Headphones,
    color: "bg-green-100 dark:bg-green-900",
    iconColor: "text-green-600 dark:text-green-400",
    criteria: [
      "Consistently exceeds customer expectations",
      "Resolves complex customer issues with patience and empathy",
      "Receives outstanding customer feedback and testimonials",
      "Goes above and beyond to ensure customer satisfaction",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-engagement",
    title: "Star of Engagement",
    description: "For individuals who foster a positive work environment and team spirit.",
    icon: Heart,
    color: "bg-red-100 dark:bg-red-900",
    iconColor: "text-red-600 dark:text-red-400",
    criteria: [
      "Actively promotes team morale and positive culture",
      "Organizes team-building activities and celebrations",
      "Supports colleagues during challenging times",
      "Contributes to an inclusive and collaborative atmosphere",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-innovation",
    title: "Star of Innovation",
    description: "For individuals who develop creative solutions and drive innovation.",
    icon: Lightbulb,
    color: "bg-amber-100 dark:bg-amber-900",
    iconColor: "text-amber-600 dark:text-amber-400",
    criteria: [
      "Develops innovative solutions to complex problems",
      "Introduces new ideas that improve processes or products",
      "Thinks outside the box to overcome challenges",
      "Encourages and supports innovation from others",
    ],
    reward: "$150 gift card and recognition certificate",
  },
  {
    id: "star-of-leadership",
    title: "Star of Leadership",
    description: "For individuals who demonstrate exceptional leadership qualities.",
    icon: Sparkles,
    color: "bg-indigo-100 dark:bg-indigo-900",
    iconColor: "text-indigo-600 dark:text-indigo-400",
    criteria: [
      "Inspires and motivates team members to achieve their best",
      "Provides clear direction and guidance during challenging times",
      "Takes ownership of problems and leads by example",
      "Develops and mentors others effectively",
    ],
    reward: "$150 gift card and recognition certificate",
  },
]

export default function SpotAwardEventPage() {
  const params = useParams()
  const eventId = params.eventId as string

  const [event, setEvent] = useState<AwardEvent | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedAwardType, setSelectedAwardType] = useState<string | null>(null)
  const [nominationType, setNominationType] = useState<"individual" | "team">("individual")
  const [canNominate, setCanNominate] = useState(false)

  useEffect(() => {
    // Fetch event data
    const awardEvent = getAwardEventById(eventId)
    setEvent(awardEvent || null)

    if (awardEvent) {
      setCanNominate(isNominationPeriodActive(awardEvent.id))
    }

    setIsLoading(false)
  }, [eventId])

  // Function to handle award selection
  const handleAwardSelection = (awardId: string, type: "individual" | "team") => {
    setSelectedAwardType(awardId)
    setNominationType(type)
    document.getElementById(type === "individual" ? "nomination-form" : "team-nomination-form")?.scrollIntoView({
      behavior: "smooth",
    })
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse text-center">
            <div className="h-8 w-64 bg-muted rounded mb-4 mx-auto"></div>
            <div className="h-4 w-48 bg-muted rounded mx-auto"></div>
          </div>
        </div>
      </DashboardShell>
    )
  }

  if (!event) {
    return (
      <DashboardShell>
        <div className="mb-4">
          <Link href="/awards" className="flex items-center text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back to Awards
          </Link>
        </div>

        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Event Not Found</AlertTitle>
          <AlertDescription>The award event you're looking for doesn't exist or has been removed.</AlertDescription>
        </Alert>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <div className="mb-4">
        <Link href="/awards" className="flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Awards
        </Link>
      </div>

      <DashboardHeader heading={event.title} text={event.description} />

      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="flex-1">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Event Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Quarter: <span className="font-medium">{event.quarter}</span>
                  </span>
                </div>
                {event.theme && (
                  <div className="flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      Theme: <span className="font-medium">{event.theme}</span>
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    Current Stage:{" "}
                    <span className="font-medium">
                      {event.currentStage === "nomination"
                        ? "Nomination"
                        : event.currentStage === "presentation"
                          ? "Presentation"
                          : "Results"}
                    </span>
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          <AwardEventStageIndicator event={event} />
        </div>
      </div>

      {event.currentStage === "nomination" && !canNominate && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Nomination Period Not Active</AlertTitle>
          <AlertDescription>
            The nomination period for this award event is not currently active. Nominations will open on{" "}
            {event.stages.nomination.startDate.toLocaleDateString()}.
          </AlertDescription>
        </Alert>
      )}

      {event.currentStage === "presentation" && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Presentation Stage</AlertTitle>
          <AlertDescription>
            This award event is currently in the presentation stage. Nominees are presenting their achievements to the
            evaluation committee.
          </AlertDescription>
        </Alert>
      )}

      {event.currentStage === "result" && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Results Announced</AlertTitle>
          <AlertDescription>
            The results for this award event have been announced. You can view the winners below.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="individual" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="individual">Individual Awards</TabsTrigger>
          <TabsTrigger value="team">Team Awards</TabsTrigger>
          <TabsTrigger value="about">About Spot Awards</TabsTrigger>
        </TabsList>

        <TabsContent value="individual" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Individual Award Types</CardTitle>
              <CardDescription>Select an award type to recognize outstanding individual contributions.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {individualAwardTypes.map((award) => (
                  <div
                    key={award.id}
                    className={`rounded-lg border p-4 ${canNominate ? "cursor-pointer transition-all hover:border-primary hover:shadow-sm" : "opacity-70"}`}
                    onClick={() => canNominate && handleAwardSelection(award.id, "individual")}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`rounded-full p-2 ${award.color}`}>
                        <award.icon className={`h-5 w-5 ${award.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="font-medium">{award.title}</h3>
                        <p className="text-sm text-muted-foreground">{award.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {canNominate && (
            <div id="nomination-form">
              <AwardNominationForm
                awardType="spot"
                nominationType="individual"
                selectedAwardType={selectedAwardType}
                eventId={event.id}
              />
            </div>
          )}
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Team Award</CardTitle>
              <CardDescription>Recognize exceptional team collaboration and achievements.</CardDescription>
            </CardHeader>
            <CardContent>
              <div
                className={`rounded-lg border p-6 ${canNominate ? "cursor-pointer transition-all hover:border-primary hover:shadow-sm" : "opacity-70"}`}
                onClick={() => canNominate && handleAwardSelection(teamAwardType.id, "team")}
              >
                <div className="flex items-start gap-4">
                  <div className={`rounded-full p-3 ${teamAwardType.color}`}>
                    <teamAwardType.icon className={`h-6 w-6 ${teamAwardType.iconColor}`} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">{teamAwardType.title}</h3>
                    <p className="text-muted-foreground">{teamAwardType.description}</p>

                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Award Criteria:</h4>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        {teamAwardType.criteria.map((criterion, index) => (
                          <li key={index} className="text-muted-foreground">
                            {criterion}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-2">
                      <p className="text-sm">
                        <span className="font-medium">Reward: </span>
                        <span className="text-muted-foreground">{teamAwardType.reward}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {canNominate && (
            <div id="team-nomination-form">
              <AwardNominationForm
                awardType="spot"
                nominationType="team"
                selectedAwardType={selectedAwardType}
                eventId={event.id}
              />
            </div>
          )}
        </TabsContent>

        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>About {event.title}</CardTitle>
              <CardDescription>
                Spot Awards are designed to provide immediate recognition for outstanding contributions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Spot Awards are a way to recognize employees for specific actions or achievements in real-time. Unlike
                formal recognition programs that may have nomination periods and committees, Spot Awards can be given at
                any time to acknowledge exceptional work.
              </p>

              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium mb-2">Key Features of Spot Awards</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Immediate recognition for specific achievements</li>
                  <li>Simple nomination process with quick approval</li>
                  <li>Available for both individual and team recognition</li>
                  <li>Focused on recognizing actions rather than long-term performance</li>
                  <li>Tangible rewards that are delivered promptly</li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Individual Awards</h4>
                <p className="text-sm text-muted-foreground">
                  Individual Spot Awards recognize personal contributions across different areas of excellence. Each
                  award type focuses on a specific aspect of performance or behavior that contributes to our company's
                  success.
                </p>

                <h4 className="font-medium">Team Award</h4>
                <p className="text-sm text-muted-foreground">
                  The All-Star Team award recognizes groups that demonstrate exceptional collaboration, innovation, and
                  results. This award celebrates the power of teamwork and collective achievement.
                </p>
              </div>

              <div className="rounded-lg border p-4 mt-4">
                <h4 className="font-medium mb-2">Award Process</h4>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Nomination Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Employees submit nominations for individuals or teams who deserve recognition.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Presentation Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Nominees present their achievements to the evaluation committee.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Results Stage</span>
                    <p className="text-sm text-muted-foreground">
                      Winners are announced and awards are presented in team meetings or department gatherings.
                    </p>
                  </li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}

