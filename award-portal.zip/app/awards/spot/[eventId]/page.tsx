"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useState } from "react"

export default function SpotAwardRedirectPage({ params }: { params: { eventId: string } }) {
  const router = useRouter()
  const { eventId } = params
  const [canEdit, setCanEdit] = useState(false)

  useEffect(() => {
    // Redirect to the new unified spot awards page with the event ID as a path parameter
    router.replace(`/awards/spot-awards/${eventId}`)
    // Check if current user can edit the event
    // setCanEdit(canEditEvent(awardEvent, currentUser.id))
  }, [router, eventId])

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center">
        <h2 className="text-xl font-semibold mb-2">Redirecting...</h2>
        <p className="text-muted-foreground">Taking you to the Spot Awards page</p>
      </div>
    </div>
  )
}

