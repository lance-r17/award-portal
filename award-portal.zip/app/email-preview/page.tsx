"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { render } from "@react-email/render"

// Import email templates
import NominationSubmittedEmail from "@/components/email-templates/nomination/nomination-submitted"
import NominationReceivedEmail from "@/components/email-templates/nomination/nomination-received"
import JudgeAssignmentEmail from "@/components/email-templates/judging/judge-assignment"
import WinnerAnnouncementEmail from "@/components/email-templates/events/winner-announcement"
import CommentNotificationEmail from "@/components/email-templates/system/comment-notification"

// Sample data for email previews
const sampleData = {
  nomination: {
    submitted: {
      nominatorName: "Jane Smith",
      nomineeName: "John Doe",
      awardType: "Spot Award",
      eventName: "Q2 Recognition Event",
      nominationDate: "April 15, 2023",
      previewUrl: "#",
    },
    received: {
      nomineeName: "John Doe",
      nominatorName: "Jane Smith",
      awardType: "Spot Award",
      eventName: "Q2 Recognition Event",
      nominationDate: "April 15, 2023",
      previewUrl: "#",
    },
  },
  judging: {
    assignment: {
      judgeName: "Michael Johnson",
      eventName: "Q2 Recognition Event",
      awardType: "Spot Award",
      nominationCount: 12,
      deadline: "May 10, 2023",
      judgingUrl: "#",
    },
  },
  events: {
    winner: {
      recipientName: "Team Member",
      winnerName: "John Doe",
      awardType: "Spot Award",
      eventName: "Q2 Recognition Event",
      announcementDate: "May 20, 2023",
      celebrationDetails: "We will be celebrating this achievement during our next all-hands meeting on May 25, 2023.",
      viewDetailsUrl: "#",
    },
  },
  system: {
    comment: {
      recipientName: "John Doe",
      commenterName: "Sarah Williams",
      nominationTitle: "Outstanding Customer Support",
      commentPreview:
        "I completely agree with this nomination. John has consistently gone above and beyond in supporting our customers.",
      commentDate: "April 18, 2023",
      viewCommentUrl: "#",
    },
  },
}

export default function EmailPreviewPage() {
  const [selectedTemplate, setSelectedTemplate] = useState<string>("nomination-submitted")

  // Function to render the selected email template
  const renderSelectedTemplate = () => {
    switch (selectedTemplate) {
      case "nomination-submitted":
        return render(NominationSubmittedEmail(sampleData.nomination.submitted))
      case "nomination-received":
        return render(NominationReceivedEmail(sampleData.nomination.received))
      case "judge-assignment":
        return render(JudgeAssignmentEmail(sampleData.judging.assignment))
      case "winner-announcement":
        return render(WinnerAnnouncementEmail(sampleData.events.winner))
      case "comment-notification":
        return render(CommentNotificationEmail(sampleData.system.comment))
      default:
        return "<p>Select a template to preview</p>"
    }
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Email Template Preview</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Select Template</CardTitle>
              <CardDescription>Choose an email template to preview</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="nomination" className="w-full">
                <TabsList className="grid grid-cols-4 mb-4">
                  <TabsTrigger value="nomination">Nomination</TabsTrigger>
                  <TabsTrigger value="judging">Judging</TabsTrigger>
                  <TabsTrigger value="events">Events</TabsTrigger>
                  <TabsTrigger value="system">System</TabsTrigger>
                </TabsList>

                <TabsContent value="nomination">
                  <Select onValueChange={setSelectedTemplate} defaultValue="nomination-submitted">
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nomination-submitted">Nomination Submitted</SelectItem>
                      <SelectItem value="nomination-received">Nomination Received</SelectItem>
                    </SelectContent>
                  </Select>
                </TabsContent>

                <TabsContent value="judging">
                  <Select onValueChange={setSelectedTemplate} defaultValue="judge-assignment">
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="judge-assignment">Judge Assignment</SelectItem>
                    </SelectContent>
                  </Select>
                </TabsContent>

                <TabsContent value="events">
                  <Select onValueChange={setSelectedTemplate} defaultValue="winner-announcement">
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="winner-announcement">Winner Announcement</SelectItem>
                    </SelectContent>
                  </Select>
                </TabsContent>

                <TabsContent value="system">
                  <Select onValueChange={setSelectedTemplate} defaultValue="comment-notification">
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="comment-notification">Comment Notification</SelectItem>
                    </SelectContent>
                  </Select>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Email Preview</CardTitle>
              <CardDescription>This is how the email will appear to recipients</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg p-4 bg-white overflow-auto max-h-[600px]">
                <iframe srcDoc={renderSelectedTemplate()} className="w-full h-[600px] border-0" title="Email Preview" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

