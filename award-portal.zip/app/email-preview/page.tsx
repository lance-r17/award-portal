"use client"

import { useState, useEffect, useMemo } from "react"
import { render } from "@react-email/render"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileExplorer, type EmailTemplateFile } from "@/components/email-preview/file-explorer"
import { TemplateMetadata } from "@/components/email-preview/template-metadata"
import { ParameterEditor } from "@/components/email-preview/parameter-editor"
import { ExportTools } from "@/components/email-preview/export-tools"
import { TemplateComparison } from "@/components/email-preview/template-comparison"
import { AnalyticsPanel } from "@/components/email-preview/analytics-panel"

// Import email templates
import NominationSubmittedEmail from "@/components/email-templates/nomination/nomination-submitted"
import NominationReceivedEmail from "@/components/email-templates/nomination/nomination-received"
import JudgeAssignmentEmail from "@/components/email-templates/judging/judge-assignment"
import WinnerAnnouncementEmail from "@/components/email-templates/events/winner-announcement"
import CommentNotificationEmail from "@/components/email-templates/system/comment-notification"

// Sample data for email previews
const sampleData = {
  "nomination-submitted": {
    nominatorName: "Jane Smith",
    nomineeName: "John Doe",
    awardType: "Spot Award",
    eventName: "Q2 Recognition Event",
    nominationDate: "April 15, 2023",
    previewUrl: "#",
  },
  "nomination-received": {
    nomineeName: "John Doe",
    nominatorName: "Jane Smith",
    awardType: "Spot Award",
    eventName: "Q2 Recognition Event",
    nominationDate: "April 15, 2023",
    previewUrl: "#",
  },
  "judge-assignment": {
    judgeName: "Michael Johnson",
    eventName: "Q2 Recognition Event",
    awardType: "Spot Award",
    nominationCount: 12,
    deadline: "May 10, 2023",
    judgingUrl: "#",
  },
  "winner-announcement": {
    recipientName: "Team Member",
    winnerName: "John Doe",
    awardType: "Spot Award",
    eventName: "Q2 Recognition Event",
    announcementDate: "May 20, 2023",
    celebrationDetails: "We will be celebrating this achievement during our next all-hands meeting on May 25, 2023.",
    viewDetailsUrl: "#",
  },
  "comment-notification": {
    recipientName: "John Doe",
    commenterName: "Sarah Williams",
    nominationTitle: "Outstanding Customer Support",
    commentPreview:
      "I completely agree with this nomination. John has consistently gone above and beyond in supporting our customers.",
    commentDate: "April 18, 2023",
    viewCommentUrl: "#",
  },
}

// Template metadata
const templateMetadata: Record<string, Partial<EmailTemplateFile>> = {
  "nomination-submitted": {
    description: "Sent to the nominator when they submit a nomination for an award.",
    category: "Nomination",
    lastModified: "June 15, 2023",
  },
  "nomination-received": {
    description: "Sent to the nominee when they have been nominated for an award.",
    category: "Nomination",
    lastModified: "June 15, 2023",
  },
  "judge-assignment": {
    description: "Sent to judges when they are assigned to evaluate nominations for an award event.",
    category: "Judging",
    lastModified: "June 20, 2023",
  },
  "winner-announcement": {
    description: "Sent to all participants when winners are announced for an award event.",
    category: "Events",
    lastModified: "June 25, 2023",
  },
  "comment-notification": {
    description: "Sent when someone comments on a nomination.",
    category: "System",
    lastModified: "June 10, 2023",
  },
}

// Related templates mapping
const relatedTemplates: Record<string, string[]> = {
  "nomination-submitted": ["nomination-received"],
  "nomination-received": ["nomination-submitted"],
  "judge-assignment": ["winner-announcement"],
  "winner-announcement": ["judge-assignment"],
  "comment-notification": [],
}

// File tree structure
const emailTemplateFiles: EmailTemplateFile[] = [
  {
    id: "nomination",
    name: "nomination",
    path: "nomination",
    type: "folder",
    children: [
      {
        id: "nomination-submitted",
        name: "nomination-submitted.tsx",
        path: "nomination-submitted",
        type: "file",
        ...templateMetadata["nomination-submitted"],
      },
      {
        id: "nomination-received",
        name: "nomination-received.tsx",
        path: "nomination-received",
        type: "file",
        ...templateMetadata["nomination-received"],
      },
    ],
  },
  {
    id: "judging",
    name: "judging",
    path: "judging",
    type: "folder",
    children: [
      {
        id: "judge-assignment",
        name: "judge-assignment.tsx",
        path: "judge-assignment",
        type: "file",
        ...templateMetadata["judge-assignment"],
      },
    ],
  },
  {
    id: "events",
    name: "events",
    path: "events",
    type: "folder",
    children: [
      {
        id: "winner-announcement",
        name: "winner-announcement.tsx",
        path: "winner-announcement",
        type: "file",
        ...templateMetadata["winner-announcement"],
      },
    ],
  },
  {
    id: "system",
    name: "system",
    path: "system",
    type: "folder",
    children: [
      {
        id: "comment-notification",
        name: "comment-notification.tsx",
        path: "comment-notification",
        type: "file",
        ...templateMetadata["comment-notification"],
      },
    ],
  },
]

export default function EmailPreviewPage() {
  const [selectedTemplatePath, setSelectedTemplatePath] = useState<string>("nomination-submitted")
  const [secondTemplatePath, setSecondTemplatePath] = useState<string>("")
  const [templateData, setTemplateData] = useState<Record<string, any>>(sampleData["nomination-submitted"])
  const [secondTemplateData, setSecondTemplateData] = useState<Record<string, any>>({})
  const [isComparing, setIsComparing] = useState(false)
  const [activeTab, setActiveTab] = useState<string>("preview")

  // Find the selected template object
  const selectedTemplate = useMemo(() => {
    const findTemplate = (items: EmailTemplateFile[]): EmailTemplateFile | null => {
      for (const item of items) {
        if (item.path === selectedTemplatePath) {
          return item
        }
        if (item.children) {
          const found = findTemplate(item.children)
          if (found) return found
        }
      }
      return null
    }

    return findTemplate(emailTemplateFiles)
  }, [selectedTemplatePath])

  // Get related templates
  const relatedTemplateObjects = useMemo(() => {
    if (!selectedTemplate) return []

    const related = relatedTemplates[selectedTemplate.path] || []
    return related
      .map((path) => {
        const findTemplate = (items: EmailTemplateFile[]): EmailTemplateFile | null => {
          for (const item of items) {
            if (item.path === path) {
              return item
            }
            if (item.children) {
              const found = findTemplate(item.children)
              if (found) return found
            }
          }
          return null
        }

        return findTemplate(emailTemplateFiles)
      })
      .filter(Boolean) as EmailTemplateFile[]
  }, [selectedTemplate])

  // Update template data when selected template changes
  useEffect(() => {
    if (selectedTemplatePath && sampleData[selectedTemplatePath as keyof typeof sampleData]) {
      setTemplateData(sampleData[selectedTemplatePath as keyof typeof sampleData])
    }
  }, [selectedTemplatePath])

  // Update second template data when second template changes
  useEffect(() => {
    if (secondTemplatePath && sampleData[secondTemplatePath as keyof typeof sampleData]) {
      setSecondTemplateData(sampleData[secondTemplatePath as keyof typeof sampleData])
      setIsComparing(true)
    } else {
      setIsComparing(false)
    }
  }, [secondTemplatePath])

  // Function to render the selected email template
  const renderSelectedTemplate = () => {
    switch (selectedTemplatePath) {
      case "nomination-submitted":
        return render(NominationSubmittedEmail(templateData))
      case "nomination-received":
        return render(NominationReceivedEmail(templateData))
      case "judge-assignment":
        return render(JudgeAssignmentEmail(templateData))
      case "winner-announcement":
        return render(WinnerAnnouncementEmail(templateData))
      case "comment-notification":
        return render(CommentNotificationEmail(templateData))
      default:
        return "<p>Select a template to preview</p>"
    }
  }

  // Function to render the second template for comparison
  const renderSecondTemplate = () => {
    if (!secondTemplatePath) return null

    switch (secondTemplatePath) {
      case "nomination-submitted":
        return render(NominationSubmittedEmail(secondTemplateData))
      case "nomination-received":
        return render(NominationReceivedEmail(secondTemplateData))
      case "judge-assignment":
        return render(JudgeAssignmentEmail(secondTemplateData))
      case "winner-announcement":
        return render(WinnerAnnouncementEmail(secondTemplateData))
      case "comment-notification":
        return render(CommentNotificationEmail(secondTemplateData))
      default:
        return null
    }
  }

  // Handle template selection
  const handleSelectTemplate = (template: EmailTemplateFile) => {
    if (template.type === "file") {
      setSelectedTemplatePath(template.path)
    }
  }

  // Handle second template selection for comparison
  const handleSelectSecondTemplate = (path: string) => {
    setSecondTemplatePath(path)
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Email Template Preview</h1>

      <div className="grid grid-cols-12 gap-6">
        {/* Left sidebar - File explorer */}
        <div className="col-span-12 md:col-span-3">
          <div className="space-y-6">
            <FileExplorer
              files={emailTemplateFiles}
              onSelectFile={handleSelectTemplate}
              selectedFilePath={selectedTemplatePath}
            />

            <TemplateMetadata
              template={selectedTemplate}
              relatedTemplates={relatedTemplateObjects}
              onSelectRelated={handleSelectTemplate}
            />
          </div>
        </div>

        {/* Main content area */}
        <div className="col-span-12 md:col-span-9">
          <div className="space-y-6">
            {/* Template comparison tool */}
            <TemplateComparison
              allTemplates={emailTemplateFiles}
              currentTemplate={selectedTemplate}
              currentHtml={renderSelectedTemplate()}
              onSelectSecondTemplate={handleSelectSecondTemplate}
              secondTemplateHtml={renderSecondTemplate()}
            />

            {/* Export tools */}
            <ExportTools
              template={selectedTemplate}
              htmlContent={renderSelectedTemplate()}
              templateData={templateData}
            />

            <div className="grid grid-cols-12 gap-6">
              {/* Parameter editor */}
              <div className="col-span-12 md:col-span-4">
                <ParameterEditor
                  template={selectedTemplate}
                  initialData={templateData}
                  onDataChange={setTemplateData}
                />
              </div>

              {/* Preview and analytics tabs */}
              <div className="col-span-12 md:col-span-8">
                <Tabs defaultValue="preview" onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="preview">Preview</TabsTrigger>
                    <TabsTrigger value="analytics">Analytics</TabsTrigger>
                  </TabsList>

                  <TabsContent value="preview" className="mt-4">
                    <div className={`grid ${isComparing ? "grid-cols-2" : "grid-cols-1"} gap-4`}>
                      {/* Main template preview */}
                      <div className="border rounded-lg p-4 bg-white overflow-auto max-h-[600px]">
                        <iframe
                          srcDoc={renderSelectedTemplate()}
                          className="w-full h-[600px] border-0"
                          title="Email Preview"
                        />
                      </div>

                      {/* Second template preview (if comparing) */}
                      {isComparing && secondTemplatePath && (
                        <div className="border rounded-lg p-4 bg-white overflow-auto max-h-[600px]">
                          <iframe
                            srcDoc={renderSecondTemplate()}
                            className="w-full h-[600px] border-0"
                            title="Comparison Preview"
                          />
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="analytics">
                    <AnalyticsPanel template={selectedTemplate} />
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

