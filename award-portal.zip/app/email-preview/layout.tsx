import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Email Template Preview - Spot Award",
  description: "Preview email templates for the Spot Award application",
}

export default function EmailPreviewLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <div className="min-h-screen bg-gray-50">{children}</div>
}
