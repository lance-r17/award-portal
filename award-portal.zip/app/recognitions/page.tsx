import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { RecognitionsFilter } from "@/components/recognitions-filter"
import { RecognitionsTable } from "@/components/recognitions-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default function RecognitionsPage() {
  return (
    <DashboardShell>
      <div className="flex items-center justify-between">
        <DashboardHeader heading="Recognitions" text="View and manage all employee recognitions." />
        <Button asChild>
          <Link href="#give-recognition">
            <Plus className="mr-2 h-4 w-4" />
            Give Recognition
          </Link>
        </Button>
      </div>
      <RecognitionsFilter />
      <RecognitionsTable />
    </DashboardShell>
  )
}

