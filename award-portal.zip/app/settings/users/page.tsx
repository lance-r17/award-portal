import { DialogFooter } from "@/components/ui/dialog"
;("use client")

import type React from "react"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, Edit, Ban, Loader2, ArrowUp, ArrowDown } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { User } from "@/types/users"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Checkbox } from "@/components/ui/checkbox"
import { SYSTEM_ROLES } from "@/types/roles"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useUsers, useCreateUser, useUpdateUser, useDisableUser } from "@/hooks/use-users"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function UsersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [debouncedSearch, setDebouncedSearch] = useState("")
  const [roleFilter, setRoleFilter] = useState<string>("all")
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [sortField, setSortField] = useState("name")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")
  const [activeTab, setActiveTab] = useState("all")
  const { toast } = useToast()
  const limit = 10
  const [idFilter, setIdFilter] = useState("")
  const [serviceLineFilter, setServiceLineFilter] = useState("")
  const [organizationLevel2Filter, setOrganizationLevel2Filter] = useState("")

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery)
      setCurrentPage(1) // Reset to first page on new search
    }, 300)

    return () => clearTimeout(timer)
  }, [searchQuery])

  // Use the custom hook with all filter parameters
  const { data, isLoading, isError, error } = useUsers({
    page: currentPage,
    limit,
    search: debouncedSearch,
    role: roleFilter,
    sort: sortField,
    order: sortOrder,
  })

  const createUserMutation = useCreateUser()
  const updateUserMutation = useUpdateUser()
  const disableUserMutation = useDisableUser()

  // Handle role filter change
  const handleRoleFilterChange = (value: string) => {
    setRoleFilter(value)
    setCurrentPage(1) // Reset to first page on new filter
  }

  // Handle sort change
  const handleSortChange = (field: string) => {
    if (sortField === field) {
      // Toggle order if clicking the same field
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      // Default to ascending for new sort field
      setSortField(field)
      setSortOrder("asc")
    }
  }

  // Handle edit user
  const handleEditUser = (userData: User) => {
    updateUserMutation.mutate({ id: userData.id, data: userData }, { onSuccess: () => setEditingUser(null) })
  }

  // Handle disable user
  const handleDisableUser = (userId: string) => {
    disableUserMutation.mutate(userId)
  }

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setCurrentPage(1) // Reset to first page on tab change
  }

  // Filter users based on active tab
  const getFilteredUsers = () => {
    if (!data?.users) return []

    let filteredUsers = [...data.users]

    switch (activeTab) {
      case "active":
        filteredUsers = filteredUsers.filter((user) => user.status !== "inactive")
        break
      case "inactive":
        filteredUsers = filteredUsers.filter((user) => user.status === "inactive")
        break
      default:
        break
    }

    // Apply search filter
    if (debouncedSearch) {
      const search = debouncedSearch
      const searchLower = search.toLowerCase()
      filteredUsers = filteredUsers.filter(
        (user) =>
          user.name.toLowerCase().includes(searchLower) ||
          user.email.toLowerCase().includes(searchLower) ||
          (user.id && user.id.toLowerCase().includes(searchLower)) ||
          (user.title && user.title.toLowerCase().includes(searchLower)),
      )
    }

    return filteredUsers
  }

  // Handle error state
  if (isError && error instanceof Error) {
    toast({
      title: "Error",
      description: error.message || "Failed to load users",
      variant: "destructive",
    })
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="User Management" text="Manage users and their roles in the system." />

      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-col gap-2 md:flex-row md:items-center">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search users..."
              className="w-full pl-8 md:w-[300px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={roleFilter} onValueChange={handleRoleFilterChange}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="Filter by role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
              <SelectItem value="facilitator">Facilitator</SelectItem>
              <SelectItem value="judge">Judge</SelectItem>
              <SelectItem value="employee">Employee</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="mt-6">
        <TabsList>
          <TabsTrigger value="all">All Users</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="inactive">Inactive</TabsTrigger>
        </TabsList>
        <TabsContent value={activeTab} className="mt-4">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              <UsersTable
                users={getFilteredUsers()}
                onEdit={setEditingUser}
                onDisable={handleDisableUser}
                onSort={handleSortChange}
                sortField={sortField}
                sortOrder={sortOrder}
                isDisabling={disableUserMutation.isPending}
              />

              {/* Pagination */}
              {data?.pagination && data.pagination.pages > 1 && (
                <Pagination className="mt-4">
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious
                        href="#"
                        onClick={(e) => {
                          e.preventDefault()
                          if (currentPage > 1) setCurrentPage(currentPage - 1)
                        }}
                        disabled={currentPage === 1}
                      />
                    </PaginationItem>
                    {Array.from({ length: data.pagination.pages }, (_, i) => i + 1).map((page) => (
                      <PaginationItem key={page}>
                        <PaginationLink
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setCurrentPage(page)
                          }}
                          isActive={page === currentPage}
                        >
                          {page}
                        </PaginationLink>
                      </PaginationItem>
                    ))}
                    <PaginationItem>
                      <PaginationNext
                        href="#"
                        onClick={(e) => {
                          e.preventDefault()
                          if (currentPage < data.pagination.pages) setCurrentPage(currentPage + 1)
                        }}
                        disabled={currentPage === data.pagination.pages}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* Edit User Dialog */}
      <Dialog open={!!editingUser} onOpenChange={(open) => !open && setEditingUser(null)}>
        <DialogContent>
          {editingUser && (
            <UserForm
              user={editingUser}
              onSubmit={handleEditUser}
              onCancel={() => setEditingUser(null)}
              isSubmitting={updateUserMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>
    </DashboardShell>
  )
}

interface UsersTableProps {
  users: User[]
  onEdit: (user: User) => void
  onDisable: (userId: string) => void
  onSort: (field: string) => void
  sortField: string
  sortOrder: "asc" | "desc"
  isDisabling: boolean
}

// Ensure UsersTable is a default export
function UsersTable({ users, onEdit, onDisable, onSort, sortField, sortOrder, isDisabling }: UsersTableProps) {
  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) return null
    return sortOrder === "asc" ? (
      <ArrowUp className="ml-1 h-4 w-4 inline" />
    ) : (
      <ArrowDown className="ml-1 h-4 w-4 inline" />
    )
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => onSort("id")}>
              <div className="flex items-center">
                ID <SortIcon field="id" />
              </div>
            </TableHead>
            <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => onSort("name")}>
              <div className="flex items-center">
                Name <SortIcon field="name" />
              </div>
            </TableHead>
            <TableHead>Email</TableHead>
            <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => onSort("serviceLine")}>
              <div className="flex items-center">
                Service Line <SortIcon field="serviceLine" />
              </div>
            </TableHead>
            <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => onSort("organizationLevel2")}>
              <div className="flex items-center">
                Organization Level 2 <SortIcon field="organizationLevel2" />
              </div>
            </TableHead>
            <TableHead>Roles</TableHead>
            <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => onSort("department")}>
              <div className="flex items-center">
                Department <SortIcon field="department" />
              </div>
            </TableHead>
            <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => onSort("status")}>
              <div className="flex items-center">
                Status <SortIcon field="status" />
              </div>
            </TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="h-24 text-center">
                No users found.
              </TableCell>
            </TableRow>
          ) : (
            users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.id}</TableCell>
                <TableCell className="font-medium">{user.name}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{user.email}</span>
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback>{user.initials}</AvatarFallback>
                    </Avatar>
                  </div>
                </TableCell>
                <TableCell>{user.serviceLineId || "N/A"}</TableCell>
                <TableCell>{user.organization?.level2 || "N/A"}</TableCell>
                <TableCell>
                  {user.roles && user.roles.length > 0
                    ? user.roles.map((role) => (
                        <Badge key={role.id} variant="secondary" className="mr-1">
                          {role.name}
                        </Badge>
                      ))
                    : "Employee"}
                </TableCell>
                <TableCell>{user.department || "N/A"}</TableCell>
                <TableCell>
                  <Badge variant={user.status === "inactive" ? "destructive" : "default"}>
                    {user.status || "Active"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="icon" onClick={() => onEdit(user)}>
                      <Edit className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" disabled={user.status === "inactive" || isDisabling}>
                          <Ban className="h-4 w-4" />
                          <span className="sr-only">Disable</span>
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently disable the user account.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => onDisable(user.id)}>
                            {isDisabling ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Disable
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

interface UserFormProps {
  user?: User
  onSubmit: (user: Partial<User>) => void
  onCancel: () => void
  isSubmitting: boolean
}

function UserForm({ user, onSubmit, onCancel, isSubmitting }: UserFormProps) {
  const [formData, setFormData] = useState<Partial<User>>(
    user || {
      name: "",
      email: "",
      roles: [],
      status: "active",
    },
  )

  const handleChange = (field: keyof User, value: any) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleRoleChange = (roleId: string, checked: boolean) => {
    setFormData((prev) => {
      let newRoles = prev.roles ? [...prev.roles] : []
      if (checked) {
        newRoles.push({ id: roleId, name: roleId, description: "" })
      } else {
        newRoles = newRoles.filter((role) => role.id !== roleId)
      }
      return { ...prev, roles: newRoles }
    })
  }

  const handleSubmit = (e: React.Event) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>{user ? "Edit User" : "Add New User"}</DialogTitle>
        <DialogDescription>
          {user ? "Update user role and status." : "Fill in the information to create a new user."}
        </DialogDescription>
      </DialogHeader>
      <form onSubmit={handleSubmit}>
        <div className="grid gap-4 py-4">
          {!user && (
            <>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  value={formData.name || ""}
                  onChange={(e) => handleChange("name", e.target.value)}
                  className="col-span-3"
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email || ""}
                  onChange={(e) => handleChange("email", e.target.value)}
                  className="col-span-3"
                  required
                  disabled={isSubmitting}
                />
              </div>
            </>
          )}
          <div className="grid grid-cols-4 items-start gap-4">
            <Label className="text-right mt-2">Roles</Label>
            <div className="col-span-3 space-y-1">
              {SYSTEM_ROLES.map((role) => (
                <div key={role.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={role.id}
                    checked={formData.roles?.some((r) => r.id === role.id) || false}
                    onCheckedChange={(checked) => handleRoleChange(role.id, checked === true)}
                    disabled={isSubmitting}
                  />
                  <Label
                    htmlFor={role.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {role.name}
                  </Label>
                </div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="status" className="text-right">
              Status
            </Label>
            <Select
              value={formData.status || "active"}
              onValueChange={(value) => handleChange("status", value)}
              disabled={isSubmitting}
            >
              <SelectTrigger id="status" className="col-span-3">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {user ? "Update User" : "Save Changes"}
          </Button>
        </DialogFooter>
      </form>
    </>
  )
}

