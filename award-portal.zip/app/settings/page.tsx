\
```tsx file="app/settings/page.tsx"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Award, Mail, Trophy, Users } from "lucide-react"
import Link from "next/link"

export default function SettingsPage() {
  const settingsCards = [
    {
      title: "User Management",
      description: "Manage users, roles, and permissions",
      icon: Users,
      href: "/settings/users",
    },
    {
      title: "Award Types",
      description: "Configure award types and criteria",
      icon: Award,
      href: "/settings/award-types",
    },
    {
      title: "Judge Pool",
      description: "Manage judges and their assignments",
      icon: Trophy,
      href: "/settings/judge-pool",
    },
    {
      title: "Email Logs",
      description: "View and analyze system email communications",
      icon: Mail,
      href: "/settings/email-logs",
    },
  ]

  return (
    <DashboardShell>
      <DashboardHeader heading="Settings" text="Manage system settings and configurations." />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {settingsCards.map((card) => (
          <Link href={card.href} key={card.href}>
            <Card className="h-full transition-all hover:bg-accent hover:text-accent-foreground">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                <card.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <CardDescription>{card.description}</CardDescription>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </DashboardShell>
  )
}
