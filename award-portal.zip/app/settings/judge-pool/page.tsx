"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { JudgePoolTable } from "@/components/settings/judge-pool-table"
import { AddToJudgePoolDialog } from "@/components/settings/add-to-judge-pool-dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, X } from "lucide-react"
import { useJudgePool } from "@/hooks/use-judge-pool"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Info } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useDebounce } from "@/hooks/use-debounce"

export default function JudgePoolPage() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<"all" | "head" | "regular">("all")
  const [searchQuery, setSearchQuery] = useState("")
  const debouncedSearchQuery = useDebounce(searchQuery, 300)

  const { data: judges, isLoading, isError, error } = useJudgePool()
  const [filteredJudges, setFilteredJudges] = useState(judges || [])
  const [isSearching, setIsSearching] = useState(false)

  // Filter judges based on search query
  useEffect(() => {
    if (!judges) return

    setIsSearching(true)

    // Simulate search delay for UX
    const timer = setTimeout(() => {
      if (!debouncedSearchQuery.trim()) {
        setFilteredJudges(judges)
      } else {
        const query = debouncedSearchQuery.toLowerCase()
        const filtered = judges.filter(
          (judge) =>
            judge.name.toLowerCase().includes(query) ||
            judge.email.toLowerCase().includes(query) ||
            (judge.serviceLine && judge.serviceLine.toLowerCase().includes(query)),
        )
        setFilteredJudges(filtered)
      }
      setIsSearching(false)
    }, 300)

    return () => clearTimeout(timer)
  }, [debouncedSearchQuery, judges])

  // Filter by tab selection
  useEffect(() => {
    if (!judges) return

    let tabFiltered = judges

    if (activeTab === "head") {
      tabFiltered = judges.filter((judge) => judge.isHeadJudge)
    } else if (activeTab === "regular") {
      tabFiltered = judges.filter((judge) => !judge.isHeadJudge)
    }

    // Apply search filter on top of tab filter
    if (debouncedSearchQuery.trim()) {
      const query = debouncedSearchQuery.toLowerCase()
      tabFiltered = tabFiltered.filter(
        (judge) =>
          judge.name.toLowerCase().includes(query) ||
          judge.email.toLowerCase().includes(query) ||
          (judge.serviceLine && judge.serviceLine.toLowerCase().includes(query)),
      )
    }

    setFilteredJudges(tabFiltered)
  }, [activeTab, judges, debouncedSearchQuery])

  const handleAddUsers = (users) => {
    console.log("Adding users to judge pool:", users)
    // In a real app, this would call an API to add the users to the judge pool
    // Then refresh the table data
  }

  const handleClearSearch = () => {
    setSearchQuery("")
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Judge Pool Management" text="Manage judges and their assignments.">
        <div className="flex w-full items-center gap-2 sm:ml-auto sm:justify-end">
          <div className="relative flex-1 sm:max-w-[260px] md:max-w-[320px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search judges..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-10"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 p-0"
                onClick={handleClearSearch}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Clear search</span>
              </Button>
            )}
          </div>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add to Judge Pool
          </Button>
        </div>
      </DashboardHeader>

      {/* Search Status */}
      {debouncedSearchQuery && (
        <div className="mb-4 flex items-center gap-2">
          <Badge variant="outline" className="text-sm">
            Search: {debouncedSearchQuery}
            <Button variant="ghost" size="sm" className="ml-1 h-4 w-4 p-0" onClick={handleClearSearch}>
              <X className="h-3 w-3" />
              <span className="sr-only">Clear search</span>
            </Button>
          </Badge>
          <span className="text-sm text-muted-foreground">
            {isSearching
              ? "Searching..."
              : `Found ${filteredJudges.length} ${filteredJudges.length === 1 ? "result" : "results"}`}
          </span>
        </div>
      )}

      <Tabs defaultValue="all" className="space-y-4" onValueChange={(value) => setActiveTab(value as any)}>
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="all">All Judges</TabsTrigger>
            <TabsTrigger value="head">Head Judges</TabsTrigger>
            <TabsTrigger value="regular">Regular Judges</TabsTrigger>
          </TabsList>
        </div>
        <TabsContent value="all" className="space-y-4">
          {isLoading ? (
            <div>Loading...</div>
          ) : isError && error instanceof Error ? (
            <Alert variant="destructive">
              <Info className="h-4 w-4" />
              <AlertTitle>Error loading judge pool</AlertTitle>
              <AlertDescription>{error.message}</AlertDescription>
            </Alert>
          ) : (
            <JudgePoolTable
              filter="all"
              judges={filteredJudges}
              isSearching={isSearching}
              totalCount={judges?.length || 0}
            />
          )}
        </TabsContent>
        <TabsContent value="head" className="space-y-4">
          {isLoading ? (
            <div>Loading...</div>
          ) : isError && error instanceof Error ? (
            <Alert variant="destructive">
              <Info className="h-4 w-4" />
              <AlertTitle>Error loading judge pool</AlertTitle>
              <AlertDescription>{error.message}</AlertDescription>
            </Alert>
          ) : (
            <JudgePoolTable
              filter="head"
              judges={filteredJudges}
              isSearching={isSearching}
              totalCount={judges?.filter((judge) => judge.isHeadJudge).length || 0}
            />
          )}
        </TabsContent>
        <TabsContent value="regular" className="space-y-4">
          {isLoading ? (
            <div>Loading...</div>
          ) : isError && error instanceof Error ? (
            <Alert variant="destructive">
              <Info className="h-4 w-4" />
              <AlertTitle>Error loading judge pool</AlertTitle>
              <AlertDescription>{error.message}</AlertDescription>
            </Alert>
          ) : (
            <JudgePoolTable
              filter="regular"
              judges={filteredJudges}
              isSearching={isSearching}
              totalCount={judges?.filter((judge) => !judge.isHeadJudge).length || 0}
            />
          )}
        </TabsContent>
      </Tabs>

      <AddToJudgePoolDialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen} onAdd={handleAddUsers} />
    </DashboardShell>
  )
}

